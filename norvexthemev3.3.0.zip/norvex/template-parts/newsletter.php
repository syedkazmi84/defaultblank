<?php
/**
 * Reusable newsletter band (dark).
 *
 * Posts to the same handler as the footer form (inc/newsletter.php): the
 * norvex_news_email field, honeypot and nonce are all it needs. The submit is
 * enhanced by assets/js/theme.js when JavaScript is available.
 *
 * @package Norvex
 */

$norvex_news_eyebrow = ( isset( $args['eyebrow'] ) && '' !== $args['eyebrow'] ) ? $args['eyebrow'] : __( 'The inbox edition', 'norvex' );
$norvex_news_title   = ( isset( $args['title'] ) && '' !== $args['title'] ) ? $args['title'] : __( 'Get writing & publishing tips in your inbox', 'norvex' );
$norvex_news_intro   = ( isset( $args['intro'] ) && '' !== $args['intro'] ) ? $args['intro'] : __( 'Twice a month, no spam — unsubscribe any time.', 'norvex' );
?>
<section class="norvex-section norvex-section--tight">
	<div class="norvex-wrap">
		<div class="norvex-news-band">
			<span class="norvex-eyebrow" style="color:var(--norvex-gold);"><?php echo esc_html( $norvex_news_eyebrow ); ?></span>
			<h2><?php echo esc_html( $norvex_news_title ); ?></h2>
			<p><?php echo esc_html( $norvex_news_intro ); ?></p>
			<form class="norvex-newsletter norvex-news-band__form" action="<?php echo esc_url( home_url( add_query_arg( array() ) ) ); ?>" method="post">
				<label class="screen-reader-text" for="norvex-news-band"><?php esc_html_e( 'Email address', 'norvex' ); ?></label>
				<input id="norvex-news-band" name="norvex_news_email" type="email" placeholder="<?php esc_attr_e( 'you@email.com', 'norvex' ); ?>" required />
				<?php
				// Honeypot — hidden from humans, tempting to bots.
				echo '<input type="text" name="norvex_website" value="" tabindex="-1" autocomplete="off" aria-hidden="true" style="position:absolute;left:-9999px;" />';
				wp_nonce_field( 'norvex_newsletter', 'norvex_news_nonce' );
				norvex_gclid_field();
				?>
				<button class="norvex-btn norvex-btn--primary" type="submit"><?php esc_html_e( 'Subscribe', 'norvex' ); ?></button>
			</form>
		</div>
	</div>
</section>
