<?php
/**
 * Shared term-archive body (Journal style) for category and tag archives:
 * a dark hero with a badge, name, description and post count; category
 * navigation tabs; a featured lead post; a card grid; pagination; and a
 * newsletter band. Include between get_header() and get_footer().
 *
 * @param array $args ['badge' => label shown in the hero pill].
 * @package Norvex
 */

$norvex_term        = get_queried_object();
$norvex_name        = ( $norvex_term && isset( $norvex_term->name ) ) ? $norvex_term->name : '';
$norvex_badge       = ( isset( $args['badge'] ) && '' !== $args['badge'] ) ? $args['badge'] : __( 'Archive', 'norvex' );
$norvex_count       = ( $norvex_term && isset( $norvex_term->count ) ) ? (int) $norvex_term->count : 0;
$norvex_posts_page  = get_option( 'page_for_posts' );
$norvex_journal_url = $norvex_posts_page ? get_permalink( $norvex_posts_page ) : home_url( '/' );
$norvex_all_cats    = get_categories( array( 'hide_empty' => true, 'number' => 8 ) );
$norvex_current_cat = ( $norvex_term && isset( $norvex_term->taxonomy ) && 'category' === $norvex_term->taxonomy ) ? (int) $norvex_term->term_id : 0;
?>

<section class="norvex-page-hero">
	<div class="norvex-wrap">
		<?php norvex_breadcrumb(); ?>
		<span class="norvex-hero-badge"><?php echo esc_html( $norvex_badge ); ?></span>
		<h1><?php norvex_hero_title( $norvex_name ); ?></h1>
		<?php if ( $norvex_term && ! empty( $norvex_term->description ) ) : ?>
			<p><?php echo esc_html( wp_strip_all_tags( $norvex_term->description ) ); ?></p>
		<?php endif; ?>
		<p class="norvex-post-count">
			<?php
			/* translators: %s: number of articles. */
			printf( esc_html( _n( '%s article', '%s articles', $norvex_count, 'norvex' ) ), esc_html( number_format_i18n( $norvex_count ) ) );
			?>
		</p>
	</div>
</section>

<?php if ( $norvex_all_cats ) : ?>
<!-- Category navigation -->
<section class="norvex-section norvex-section--tight">
	<div class="norvex-wrap">
		<div class="norvex-filter">
			<a class="norvex-filter__tab" href="<?php echo esc_url( $norvex_journal_url ); ?>"><?php esc_html_e( 'All', 'norvex' ); ?></a>
			<?php foreach ( $norvex_all_cats as $norvex_c ) : ?>
				<a class="norvex-filter__tab<?php echo ( $norvex_current_cat && (int) $norvex_c->term_id === $norvex_current_cat ) ? ' is-active' : ''; ?>" href="<?php echo esc_url( get_category_link( $norvex_c->term_id ) ); ?>"><?php echo esc_html( $norvex_c->name ); ?></a>
			<?php endforeach; ?>
		</div>
	</div>
</section>
<?php endif; ?>

<?php if ( have_posts() ) : ?>

	<?php
	// On the first page, lift the newest post out as a featured lead.
	$norvex_list     = $GLOBALS['wp_query']->posts;
	$norvex_featured = ( ! is_paged() && $norvex_list ) ? array_shift( $norvex_list ) : null;
	?>

	<?php if ( $norvex_featured ) : ?>
	<section class="norvex-section norvex-section--tight" style="padding-top:0;">
		<div class="norvex-wrap">
			<?php
			$GLOBALS['post'] = $norvex_featured; // phpcs:ignore WordPress.WP.GlobalVariablesOverride
			setup_postdata( $norvex_featured );
			?>
			<article class="norvex-jfeature norvex-lift">
				<a class="norvex-jfeature__thumb" href="<?php the_permalink(); ?>"><?php norvex_thumbnail(); ?></a>
				<div class="norvex-jfeature__body">
					<span class="norvex-eyebrow"><?php esc_html_e( 'Featured', 'norvex' ); ?></span>
					<div class="norvex-article__meta"><?php norvex_post_meta(); ?></div>
					<h2><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>
					<p class="norvex-jfeature__excerpt"><?php echo esc_html( wp_trim_words( get_the_excerpt(), 34 ) ); ?></p>
					<a class="norvex-readmore" href="<?php the_permalink(); ?>"><?php esc_html_e( 'Read article', 'norvex' ); ?> <?php norvex_icon( 'arrow' ); ?></a>
				</div>
			</article>
			<?php wp_reset_postdata(); ?>
		</div>
	</section>
	<?php endif; ?>

	<section class="norvex-section"<?php echo $norvex_featured ? ' style="padding-top:0;"' : ''; ?>>
		<div class="norvex-wrap">
			<?php if ( $norvex_list ) : ?>
				<div class="norvex-cards norvex-journal-grid">
					<?php
					foreach ( $norvex_list as $norvex_p ) :
						$GLOBALS['post'] = $norvex_p; // phpcs:ignore WordPress.WP.GlobalVariablesOverride
						setup_postdata( $norvex_p );
						?>
						<article class="norvex-article norvex-lift">
							<a href="<?php the_permalink(); ?>" class="norvex-article__thumb"><?php norvex_thumbnail(); ?></a>
							<div class="norvex-article__body">
								<div class="norvex-article__meta"><?php norvex_post_meta(); ?></div>
								<h2 style="font-size:1.2rem;"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>
								<p class="norvex-article__excerpt"><?php echo esc_html( wp_trim_words( get_the_excerpt(), 20 ) ); ?></p>
								<a class="norvex-readmore" href="<?php the_permalink(); ?>"><?php esc_html_e( 'Read article', 'norvex' ); ?> <?php norvex_icon( 'arrow' ); ?></a>
							</div>
						</article>
						<?php
					endforeach;
					wp_reset_postdata();
					?>
				</div>
			<?php endif; ?>
			<?php norvex_pagination(); ?>
		</div>
	</section>

<?php else : ?>

	<section class="norvex-section">
		<div class="norvex-wrap">
			<div class="norvex-card norvex-center">
				<h2><?php esc_html_e( 'Nothing here yet', 'norvex' ); ?></h2>
				<p><?php esc_html_e( 'No articles here yet. Check back soon.', 'norvex' ); ?></p>
			</div>
		</div>
	</section>

<?php endif; ?>

<?php
get_template_part(
	'template-parts/newsletter',
	null,
	array(
		'eyebrow' => __( 'Stay in the loop', 'norvex' ),
		/* translators: %s: term name, lower-cased. */
		'title'   => '' !== $norvex_name ? sprintf( __( 'Never miss a %s tip', 'norvex' ), strtolower( $norvex_name ) ) : __( 'Get writing & publishing tips in your inbox', 'norvex' ),
		'intro'   => __( 'Twice a month, no spam — unsubscribe any time.', 'norvex' ),
	)
);
