<?php
/**
 * Portfolio project card (showcase only — no pricing).
 *
 * @package Norvex
 */

$norvex_author  = norvex_book_meta( '_norvex_author' );
$norvex_service = norvex_book_meta( '_norvex_service' );
$norvex_cover   = norvex_book_meta( '_norvex_cover' );
$norvex_cat     = get_the_terms( get_the_ID(), 'genre' );
?>
<article <?php post_class( 'norvex-book norvex-lift' ); ?>>
	<a href="<?php the_permalink(); ?>" class="norvex-book__cover">
		<?php if ( $norvex_service ) : ?>
			<span class="norvex-book__tag"><?php echo esc_html( $norvex_service ); ?></span>
		<?php elseif ( $norvex_cat && ! is_wp_error( $norvex_cat ) ) : ?>
			<span class="norvex-book__tag"><?php echo esc_html( $norvex_cat[0]->name ); ?></span>
		<?php endif; ?>
		<?php
		if ( has_post_thumbnail() ) {
			the_post_thumbnail( 'norvex-cover', array( 'loading' => 'lazy' ) );
		} else {
			$cover = $norvex_cover ? $norvex_cover : 'cover-1.svg';
			echo '<img src="' . norvex_img( $cover ) . '" alt="' . esc_attr( get_the_title() ) . '" loading="lazy" />';
		}
		?>
	</a>
	<h3><a href="<?php the_permalink(); ?>" style="color:var(--norvex-ink);"><?php the_title(); ?></a></h3>
	<?php if ( $norvex_author ) : ?>
		<p class="norvex-book__author"><?php echo esc_html( $norvex_author ); ?></p>
	<?php endif; ?>
</article>
