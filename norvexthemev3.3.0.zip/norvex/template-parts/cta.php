<?php
/**
 * Reusable closing call-to-action band.
 *
 * @package Norvex
 */

?>
<section class="norvex-section norvex-section--tight">
	<div class="norvex-wrap">
		<div class="norvex-cta">
			<span class="norvex-eyebrow" style="color:var(--norvex-gold);"><?php esc_html_e( 'Let’s begin', 'norvex' ); ?></span>
			<h2><?php esc_html_e( 'Your book deserves a proper launch', 'norvex' ); ?></h2>
			<p><?php esc_html_e( 'Tell us about your project and get a free, no-obligation quote within one business day.', 'norvex' ); ?></p>
			<div class="norvex-cta__actions">
				<a class="norvex-btn norvex-btn--primary" href="<?php echo esc_url( get_permalink( get_page_by_path( 'contact' ) ) ); ?>"><?php esc_html_e( 'Start your book', 'norvex' ); ?></a>
				<a class="norvex-btn norvex-btn--ghost" href="<?php echo esc_url( get_permalink( get_page_by_path( 'pricing' ) ) ); ?>"><?php esc_html_e( 'View pricing', 'norvex' ); ?></a>
			</div>
		</div>
	</div>
</section>
