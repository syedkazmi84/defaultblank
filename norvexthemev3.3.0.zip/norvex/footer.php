<?php
/**
 * Footer template.
 *
 * @package Norvex
 */

?>
	<?php do_action( 'norvex_after_main' ); ?>
	</main><!-- #norvex-main -->

	<?php do_action( 'norvex_before_footer' ); ?>

	<footer class="norvex-footer">
		<div class="norvex-wrap">
			<?php do_action( 'norvex_footer_top' ); ?>
			<div class="norvex-footer__grid">

				<div class="norvex-footer__brand">
					<div class="norvex-brand" style="margin-bottom:16px;">
						<img src="<?php echo norvex_img( 'logo-white.svg' ); ?>" alt="<?php echo esc_attr( get_bloginfo( 'name' ) ); ?>" width="44" height="44" />
						<span class="norvex-brand__text">
							<span class="norvex-brand__name" style="color:#fff;"><?php bloginfo( 'name' ); ?></span>
							<span class="norvex-brand__tag"><?php echo esc_html( norvex_option( 'norvex_tagline', 'Publishing Services' ) ); ?></span>
						</span>
					</div>
					<p><?php echo esc_html( norvex_option( 'norvex_footer_txt', 'Norvex LLC is a New York–registered book publishing services company. We help authors write, edit, design, publish and market their books on a flat fee — and you keep 100% of your rights and royalties.' ) ); ?></p>
					<div class="norvex-footer__social">
						<a href="<?php echo esc_url( norvex_option( 'norvex_social_tw', '#' ) ); ?>" aria-label="Twitter"><?php norvex_icon( 'twitter' ); ?></a>
						<a href="<?php echo esc_url( norvex_option( 'norvex_social_ig', '#' ) ); ?>" aria-label="Instagram"><?php norvex_icon( 'instagram' ); ?></a>
						<a href="<?php echo esc_url( norvex_option( 'norvex_social_fb', '#' ) ); ?>" aria-label="Facebook"><?php norvex_icon( 'facebook' ); ?></a>
						<a href="<?php echo esc_url( norvex_option( 'norvex_social_in', '#' ) ); ?>" aria-label="LinkedIn"><?php norvex_icon( 'linkedin' ); ?></a>
					</div>
				</div>

				<div class="norvex-footer__col">
					<h4><?php echo esc_html( get_theme_mod( 'norvex_footer_services_title', __( 'Services', 'norvex' ) ) ); ?></h4>
					<ul>
						<?php foreach ( norvex_footer_services_links() as $norvex_flink ) : ?>
							<li><a href="<?php echo esc_url( $norvex_flink[1] ); ?>"><?php echo esc_html( $norvex_flink[0] ); ?></a></li>
						<?php endforeach; ?>
					</ul>
				</div>

				<div class="norvex-footer__col">
					<h4><?php esc_html_e( 'Company', 'norvex' ); ?></h4>
					<?php
					if ( has_nav_menu( 'footer' ) ) {
						wp_nav_menu(
							array(
								'theme_location' => 'footer',
								'container'      => false,
								'menu_class'     => '',
								'depth'          => 1,
								'fallback_cb'    => false,
							)
						);
					} else {
						echo '<ul>';
						wp_list_pages( array( 'title_li' => '', 'depth' => 1 ) );
						echo '</ul>';
					}
					?>
				</div>

				<div class="norvex-footer__col">
					<h4><?php echo esc_html( get_theme_mod( 'norvex_footer_news_title', __( 'Stay in the loop', 'norvex' ) ) ); ?></h4>
					<p><?php echo esc_html( get_theme_mod( 'norvex_footer_news_text', __( 'Craft, publishing and marketing tips — twice a month, no spam.', 'norvex' ) ) ); ?></p>
					<form class="norvex-newsletter" action="<?php echo esc_url( home_url( add_query_arg( array() ) ) ); ?>" method="post">
						<label class="screen-reader-text" for="norvex-news"><?php esc_html_e( 'Email address', 'norvex' ); ?></label>
						<input id="norvex-news" name="norvex_news_email" type="email" placeholder="<?php esc_attr_e( 'you@email.com', 'norvex' ); ?>" required />
						<?php
						// Honeypot — hidden from humans, tempting to bots.
						echo '<input type="text" name="norvex_website" value="" tabindex="-1" autocomplete="off" aria-hidden="true" style="position:absolute;left:-9999px;" />';
						wp_nonce_field( 'norvex_newsletter', 'norvex_news_nonce' );
						norvex_gclid_field();
						?>
						<button class="norvex-btn norvex-btn--primary" type="submit" aria-label="<?php esc_attr_e( 'Subscribe', 'norvex' ); ?>"><?php norvex_icon( 'arrow' ); ?></button>
					</form>
					<?php
					$norvex_news_notice = norvex_newsletter_notice();
					if ( ! empty( $norvex_news_notice ) ) :
						?>
						<p class="norvex-form__note norvex-form__note--<?php echo esc_attr( $norvex_news_notice['status'] ); ?>" style="font-size:.85rem;margin-top:10px;color:<?php echo 'ok' === $norvex_news_notice['status'] ? 'var(--norvex-gold)' : 'var(--norvex-burgundy)'; ?>;"><?php echo esc_html( $norvex_news_notice['message'] ); ?></p>
					<?php endif; ?>
					<div style="margin-top:18px;font-size:.92rem;">
						<div><?php norvex_icon( 'phone' ); ?> <a href="tel:<?php echo esc_attr( norvex_option( 'norvex_phone', '+1 (732) 454-6871' ) ); ?>"><?php echo esc_html( norvex_option( 'norvex_phone', '+1 (732) 454-6871' ) ); ?></a></div>
						<div style="margin-top:6px;"><?php norvex_icon( 'pin' ); ?> <?php echo esc_html( norvex_option( 'norvex_address', '1102 Glenwood Road, F4, Brooklyn, NY 11230' ) ); ?></div>
					</div>
				</div>

			</div>

			<div class="norvex-footer__bottom">
				<span><?php echo esc_html( norvex_footer_copyright() ); ?></span>
				<ul>
					<li><a href="<?php echo esc_url( home_url( '/privacy-policy/' ) ); ?>"><?php esc_html_e( 'Privacy', 'norvex' ); ?></a></li>
					<li><a href="<?php echo esc_url( home_url( '/terms/' ) ); ?>"><?php esc_html_e( 'Terms', 'norvex' ); ?></a></li>
					<li><a href="<?php echo esc_url( get_permalink( get_page_by_path( 'contact' ) ) ); ?>"><?php esc_html_e( 'Contact', 'norvex' ); ?></a></li>
				</ul>
				<?php do_action( 'norvex_footer_bottom' ); ?>
			</div>
		</div>
	</footer>

	<?php do_action( 'norvex_after_footer' ); ?>

</div><!-- #page -->

<?php wp_footer(); ?>
</body>
</html>
