<?php
/**
 * Single portfolio project page (showcase — no pricing/buy).
 *
 * @package Norvex
 */

get_header();

while ( have_posts() ) :
	the_post();

	$norvex_author  = norvex_book_meta( '_norvex_author' );
	$norvex_service = norvex_book_meta( '_norvex_service' );
	$norvex_cover   = norvex_book_meta( '_norvex_cover' );
	$norvex_cat     = get_the_terms( get_the_ID(), 'genre' );
	?>
	<section class="norvex-page-hero">
		<div class="norvex-wrap">
			<?php norvex_breadcrumb(); ?>
			<h1><?php norvex_hero_title( get_the_title() ); ?></h1>
			<?php if ( $norvex_author ) : ?>
				<p><?php
					/* translators: %s: author name. */
					printf( esc_html__( 'by %s', 'norvex' ), esc_html( $norvex_author ) );
				?></p>
			<?php endif; ?>
		</div>
	</section>

	<section class="norvex-section">
		<div class="norvex-wrap">
			<div class="norvex-split" style="align-items:start;">
				<div style="max-width:360px;margin:0 auto;">
					<?php
					$cover_style = 'display:block;width:100%;height:auto;border-radius:12px;box-shadow:var(--norvex-shadow);';
					if ( has_post_thumbnail() ) {
						the_post_thumbnail( 'norvex-cover', array( 'style' => $cover_style ) );
					} else {
						echo '<img src="' . norvex_img( $norvex_cover ? $norvex_cover : 'cover-1.svg' ) . '" alt="' . esc_attr( get_the_title() ) . '" style="' . esc_attr( $cover_style ) . '" />';
					}
					?>
				</div>

				<div>
					<?php if ( $norvex_cat && ! is_wp_error( $norvex_cat ) ) : ?>
						<span class="norvex-badge-soft"><?php echo esc_html( $norvex_cat[0]->name ); ?></span>
					<?php endif; ?>

					<?php if ( $norvex_service ) : ?>
						<p style="margin:16px 0 0;color:var(--norvex-gold-dark);font-weight:600;"><?php
							/* translators: %s: service provided. */
							printf( esc_html__( 'What we did: %s', 'norvex' ), esc_html( $norvex_service ) );
						?></p>
					<?php endif; ?>

					<div class="norvex-entry" style="margin-top:14px;">
						<?php the_content(); ?>
					</div>

					<div style="margin-top:26px;">
						<a class="norvex-btn norvex-btn--primary" href="<?php echo esc_url( get_permalink( get_page_by_path( 'contact' ) ) ); ?>"><?php esc_html_e( 'Start your book', 'norvex' ); ?> <?php norvex_icon( 'arrow' ); ?></a>
					</div>
				</div>
			</div>

			<!-- Related projects -->
			<?php
			$related = new WP_Query(
				array(
					'post_type'      => 'book',
					'posts_per_page' => 4,
					'post__not_in'   => array( get_the_ID() ),
					'orderby'        => 'rand',
				)
			);
			if ( $related->have_posts() ) :
				?>
				<div style="margin-top:80px;">
					<div class="norvex-section-head norvex-center"><h2><?php esc_html_e( 'More of our work', 'norvex' ); ?></h2></div>
					<div class="norvex-books">
						<?php
						while ( $related->have_posts() ) :
							$related->the_post();
							get_template_part( 'template-parts/book', 'card' );
						endwhile;
						wp_reset_postdata();
						?>
					</div>
				</div>
			<?php endif; ?>
		</div>
	</section>
	<?php
endwhile;

get_footer();
