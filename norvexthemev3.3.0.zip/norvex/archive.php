<?php
/**
 * Generic archive (categories, tags, dates, author).
 *
 * @package Norvex
 */

get_header();
?>
<section class="norvex-page-hero">
	<div class="norvex-wrap">
		<?php norvex_breadcrumb(); ?>
		<h1><?php norvex_hero_title( wp_strip_all_tags( get_the_archive_title() ) ); ?></h1>
		<?php the_archive_description( '<p>', '</p>' ); ?>
	</div>
</section>

<section class="norvex-section">
	<div class="norvex-wrap">
		<div class="norvex-content-grid">
			<div class="norvex-content-main">
				<?php if ( have_posts() ) : ?>
					<?php
					while ( have_posts() ) :
						the_post();
						?>
						<article <?php post_class( 'norvex-article norvex-lift' ); ?>>
							<a href="<?php the_permalink(); ?>" class="norvex-article__thumb"><?php norvex_thumbnail(); ?></a>
							<div class="norvex-article__body">
								<div class="norvex-article__meta"><?php norvex_post_meta(); ?></div>
								<h2><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>
								<p class="norvex-article__excerpt"><?php echo esc_html( wp_trim_words( get_the_excerpt(), 28 ) ); ?></p>
								<a class="norvex-readmore" href="<?php the_permalink(); ?>"><?php esc_html_e( 'Continue reading', 'norvex' ); ?> <?php norvex_icon( 'arrow' ); ?></a>
							</div>
						</article>
						<?php
					endwhile;
					norvex_pagination();
					?>
				<?php else : ?>
					<div class="norvex-card"><p><?php esc_html_e( 'Nothing found in this archive yet.', 'norvex' ); ?></p></div>
				<?php endif; ?>
			</div>
			<?php get_sidebar(); ?>
		</div>
	</div>
</section>
<?php
get_footer();
