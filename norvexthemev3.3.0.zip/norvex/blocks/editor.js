/**
 * Norvex homepage blocks — editor registration (no build step).
 *
 * Registers every section listed in window.NorvexBlocks (printed by
 * inc/blocks.php). Each block is server-rendered: the editor shows a live
 * ServerSideRender preview, and its editable text/number fields live in the
 * block's Inspector (sidebar) panel. save() returns null because the markup is
 * produced by the PHP render_callback on the front end.
 */
( function ( wp ) {
	'use strict';

	if ( ! wp || ! wp.blocks || ! window.NorvexBlocks ) {
		return;
	}

	var el = wp.element.createElement;
	var Fragment = wp.element.Fragment;
	var __ = wp.i18n.__;
	var sprintf = wp.i18n.sprintf;
	var InspectorControls = wp.blockEditor.InspectorControls;
	var useBlockProps = wp.blockEditor.useBlockProps;
	var MediaUpload = wp.blockEditor.MediaUpload;
	var MediaUploadCheck = wp.blockEditor.MediaUploadCheck;
	var RichText = wp.blockEditor.RichText;
	var URLInput = wp.blockEditor.URLInput;
	var ToggleControl = wp.components.ToggleControl;
	var PanelBody = wp.components.PanelBody;
	var TextControl = wp.components.TextControl;
	var TextareaControl = wp.components.TextareaControl;
	var SelectControl = wp.components.SelectControl;
	var Button = wp.components.Button;
	var ColorPalette = wp.components.ColorPalette;
	var ServerSideRender = wp.serverSideRender;

	// Theme palette offered in the per-line colour pickers (mirrors theme.json).
	var NORVEX_PALETTE = [
		{ name: 'Ink', color: '#1c2438' },
		{ name: 'Ink Soft', color: '#33405e' },
		{ name: 'Accent (Gold)', color: '#c08a3e' },
		{ name: 'Accent Dark', color: '#9a6a2f' },
		{ name: 'Burgundy', color: '#7c2b3b' },
		{ name: 'Cream', color: '#faf7f1' },
		{ name: 'Paper', color: '#ffffff' },
		{ name: 'Sand', color: '#f2ebdd' },
		{ name: 'Text', color: '#2b2a27' },
		{ name: 'Muted', color: '#6c6a64' }
	];

	// A single per-line colour picker (label + clearable palette).
	function colorControl( f, props ) {
		var value = props.attributes[ f.key ] || '';
		return el(
			'div',
			{ key: f.key, className: 'norvex-color-control', style: { marginBottom: '18px' } },
			el( 'p', { style: { margin: '0 0 6px', fontWeight: 600, fontSize: '11px', textTransform: 'uppercase', letterSpacing: '.04em' } }, f.label ),
			el( ColorPalette, {
				colors: NORVEX_PALETTE,
				value: value,
				onChange: function ( c ) { var n = {}; n[ f.key ] = c || ''; props.setAttributes( n ); },
				clearable: true,
				enableAlpha: false
			} )
		);
	}

	// Build one image picker control (preview + select/replace/remove).
	function imageControl( f, props ) {
		var value = props.attributes[ f.key ];
		var setUrl = function ( url ) {
			var next = {};
			next[ f.key ] = url;
			props.setAttributes( next );
		};
		return el(
			'div',
			{ key: f.key, className: 'norvex-image-control', style: { marginBottom: '20px' } },
			el( 'p', { style: { margin: '0 0 8px', fontWeight: 600 } }, f.label ),
			value
				? el( 'img', { src: value, alt: '', style: { display: 'block', maxWidth: '100%', height: 'auto', borderRadius: '4px', marginBottom: '8px' } } )
				: null,
			el(
				MediaUploadCheck,
				null,
				el( MediaUpload, {
					onSelect: function ( media ) { setUrl( media && media.url ? media.url : '' ); },
					allowedTypes: [ 'image' ],
					render: function ( o ) {
						return el(
							Button,
							{ variant: 'secondary', onClick: o.open },
							value ? __( 'Replace image', 'norvex' ) : __( 'Select image', 'norvex' )
						);
					},
				} )
			),
			value
				? el(
						Button,
						{ variant: 'link', isDestructive: true, style: { marginLeft: '8px' }, onClick: function () { setUrl( '' ); } },
						__( 'Remove', 'norvex' )
				  )
				: null
		);
	}

	// Parse/serialise a "A <sep> B" per-line string into row objects (matches the
	// block's PHP render, which splits each line on the first separator).
	function parsePairs( value, sep ) {
		return String( value || '' ).split( /\n/ ).filter( function ( l ) { return '' !== l.trim(); } ).map( function ( l ) {
			var i = l.indexOf( sep );
			return i === -1 ? { a: l.trim(), b: '' } : { a: l.slice( 0, i ).trim(), b: l.slice( i + sep.length ).trim() };
		} );
	}
	function serializePairs( rows, sep ) {
		return rows.filter( function ( r ) { return '' !== ( r.a || '' ).trim() || '' !== ( r.b || '' ).trim(); } )
			.map( function ( r ) { return ( r.a || '' ).trim() + ' ' + sep + ' ' + ( r.b || '' ).trim(); } ).join( '\n' );
	}
	function assignRow( row, key, val ) {
		var out = {};
		for ( var k in row ) { if ( Object.prototype.hasOwnProperty.call( row, k ) ) { out[ k ] = row[ k ]; } }
		out[ key ] = val;
		return out;
	}

	// A repeatable Question/Answer (pairs) control for the block Inspector.
	function PairsControl( p ) {
		var field = p.field, props = p.props;
		var cfg = field.options || {};
		var sep = cfg.sep || '|';
		var state = wp.element.useState( function () { return parsePairs( props.attributes[ field.key ], sep ); } );
		var rows = state[ 0 ], setRows = state[ 1 ];

		function commit( next ) {
			setRows( next );
			var attrs = {};
			attrs[ field.key ] = serializePairs( next, sep );
			props.setAttributes( attrs );
		}
		function update( i, key, val ) {
			commit( rows.map( function ( r, idx ) { return idx === i ? assignRow( r, key, val ) : r; } ) );
		}

		var children = [ el( 'p', { key: 'lbl', style: { fontWeight: 600, margin: '0 0 6px' } }, field.label ) ];
		rows.forEach( function ( row, i ) {
			children.push(
				el(
					'div',
					{ key: 'r' + i, style: { border: '1px solid #e0e0e0', borderRadius: '4px', padding: '10px 10px 4px', marginBottom: '8px', background: '#fff' } },
					el( TextControl, { label: cfg.a || __( 'Question', 'norvex' ), value: row.a, onChange: function ( v ) { update( i, 'a', v ); } } ),
					el( TextareaControl, { label: cfg.b || __( 'Answer', 'norvex' ), value: row.b, rows: 3, onChange: function ( v ) { update( i, 'b', v ); } } ),
					el( Button, { variant: 'link', isDestructive: true, onClick: function () { commit( rows.filter( function ( r, idx ) { return idx !== i; } ) ); } }, __( 'Remove', 'norvex' ) )
				)
			);
		} );
		children.push( el( Button, { key: 'add', variant: 'secondary', onClick: function () { commit( rows.concat( [ { a: '', b: '' } ] ) ); } }, cfg.add || __( 'Add row', 'norvex' ) ) );

		return el( 'div', { className: 'norvex-pairs-control', style: { marginBottom: '20px' } }, children );
	}

	// --- Single-value list control ("one per line" or comma-separated). ---
	function parseLines( value, splitRe ) {
		return String( value || '' ).split( splitRe ).map( function ( l ) { return l.trim(); } ).filter( function ( l ) { return '' !== l; } ).map( function ( l ) { return { text: l }; } );
	}
	function serializeLines( rows, join ) {
		return rows.filter( function ( r ) { return '' !== ( r.text || '' ).trim(); } ).map( function ( r ) { return ( r.text || '' ).trim(); } ).join( join );
	}
	function LinesControl( p ) {
		var field = p.field, props = p.props, cfg = field.options || {};
		var join = ', ' === cfg.join || 'comma' === cfg.join ? ', ' : '\n';
		var splitRe = ', ' === join ? /,/ : /\r\n|\r|\n/;
		var state = wp.element.useState( function () { return parseLines( props.attributes[ field.key ], splitRe ); } );
		var rows = state[ 0 ], setRows = state[ 1 ];
		function commit( next ) {
			setRows( next );
			var attrs = {}; attrs[ field.key ] = serializeLines( next, join );
			props.setAttributes( attrs );
		}
		var children = [ el( 'p', { key: 'lbl', style: { fontWeight: 600, margin: '0 0 6px' } }, field.label ) ];
		rows.forEach( function ( row, i ) {
			children.push( el( 'div', { key: 'r' + i, style: { display: 'flex', gap: '6px', alignItems: 'center', marginBottom: '6px' } },
				el( TextControl, { value: row.text, placeholder: cfg.placeholder || '', onChange: function ( v ) { commit( rows.map( function ( r, idx ) { return idx === i ? { text: v } : r; } ) ); } } ),
				el( Button, { variant: 'link', isDestructive: true, onClick: function () { commit( rows.filter( function ( r, idx ) { return idx !== i; } ) ); } }, '×' )
			) );
		} );
		children.push( el( Button, { key: 'add', variant: 'secondary', onClick: function () { commit( rows.concat( [ { text: '' } ] ) ); } }, cfg.add || __( 'Add row', 'norvex' ) ) );
		return el( 'div', { className: 'norvex-lines-control', style: { marginBottom: '20px' } }, children );
	}

	// --- Multi-column row control ("A | B | C" per line). ---
	function parseRows( value, cols, sep ) {
		return String( value || '' ).split( /\r\n|\r|\n/ ).filter( function ( l ) { return '' !== l.trim(); } ).map( function ( line ) {
			var parts = line.split( sep ).map( function ( s ) { return s.trim(); } );
			var row = {};
			cols.forEach( function ( c, i ) {
				row[ i ] = 'flag' === c.type ? !! ( parts[ i ] && '' !== parts[ i ].trim() ) : ( undefined !== parts[ i ] ? parts[ i ] : '' );
			} );
			return row;
		} );
	}
	function serializeRows( rows, cols, sep ) {
		return rows.filter( function ( row ) { return '' !== ( row[ 0 ] || '' ).toString().trim(); } ).map( function ( row ) {
			var parts = cols.map( function ( c, i ) { return 'flag' === c.type ? ( row[ i ] ? c.flag : '' ) : ( row[ i ] || '' ); } );
			while ( parts.length && '' === parts[ parts.length - 1 ] ) { parts.pop(); }
			return parts.join( ' ' + sep + ' ' );
		} ).join( '\n' );
	}
	function RowsControl( p ) {
		var field = p.field, props = p.props, cfg = field.options || {};
		var cols = cfg.cols || [], sep = cfg.sep || '|';
		var state = wp.element.useState( function () { return parseRows( props.attributes[ field.key ], cols, sep ); } );
		var rows = state[ 0 ], setRows = state[ 1 ];
		function commit( next ) {
			setRows( next );
			var attrs = {}; attrs[ field.key ] = serializeRows( next, cols, sep );
			props.setAttributes( attrs );
		}
		function set( i, ci, val ) {
			commit( rows.map( function ( r, idx ) { if ( idx !== i ) { return r; } var nr = {}; for ( var k in r ) { nr[ k ] = r[ k ]; } nr[ ci ] = val; return nr; } ) );
		}
		var children = [ el( 'p', { key: 'lbl', style: { fontWeight: 600, margin: '0 0 6px' } }, field.label ) ];
		rows.forEach( function ( row, i ) {
			var inner = cols.map( function ( c, ci ) {
				if ( 'select' === c.type ) {
					return el( SelectControl, { key: ci, label: c.label, value: row[ ci ], options: Object.keys( c.options || {} ).map( function ( k ) { return { label: c.options[ k ], value: k }; } ), onChange: function ( v ) { set( i, ci, v ); } } );
				}
				if ( 'flag' === c.type ) {
					return el( wp.components.CheckboxControl, { key: ci, label: c.label, checked: !! row[ ci ], onChange: function ( v ) { set( i, ci, v ); } } );
				}
				return el( TextControl, { key: ci, label: c.label, value: row[ ci ], onChange: function ( v ) { set( i, ci, v ); } } );
			} );
			inner.push( el( Button, { key: 'rm', variant: 'link', isDestructive: true, onClick: function () { commit( rows.filter( function ( r, idx ) { return idx !== i; } ) ); } }, __( 'Remove', 'norvex' ) ) );
			children.push( el( 'div', { key: 'r' + i, style: { border: '1px solid #e0e0e0', borderRadius: '4px', padding: '10px 10px 4px', marginBottom: '8px', background: '#fff' } }, inner ) );
		} );
		children.push( el( Button, { key: 'add', variant: 'secondary', onClick: function () { commit( rows.concat( [ {} ] ) ); } }, cfg.add || __( 'Add row', 'norvex' ) ) );
		return el( 'div', { className: 'norvex-rows-control', style: { marginBottom: '20px' } }, children );
	}

	// --- Grid cards control: a repeater of cards (image/icon/title/text/link). ---
	function parseCards( value ) {
		try { var a = JSON.parse( value || '[]' ); return Array.isArray( a ) ? a : []; } catch ( e ) { return []; }
	}
	// Icon control: a "Choose icon" button opens the library; or type a number/letter.
	function IconPicker( props ) {
		var card = props.card, i = props.i, groups = props.groups, set = props.set;
		var current = card.icon || '';
		var isCustom = '<' === current.charAt( 0 );
		var known = false, currentSvg = '';
		groups.forEach( function ( g ) { g.icons.forEach( function ( ic ) { if ( ic.value === current ) { known = true; currentSvg = ic.svg; } } ); } );
		var isText = ! isCustom && current && ! known;
		var openState = wp.element.useState( false );
		var open = openState[ 0 ], setOpen = openState[ 1 ];

		var previewInner;
		if ( known ) { previewInner = el( 'span', { style: { fontSize: '20px', display: 'inline-flex' }, dangerouslySetInnerHTML: { __html: currentSvg } } ); }
		else if ( isText ) { previewInner = el( 'span', { style: { fontWeight: 700, fontSize: '16px' } }, current ); }
		else if ( isCustom ) { previewInner = el( 'span', { style: { fontSize: '11px', color: '#646970' } }, 'SVG' ); }
		else { previewInner = el( 'span', { style: { color: '#a7aaad' } }, '—' ); }
		var preview = el( 'span', { key: 'pv', style: { width: '40px', height: '40px', display: 'inline-flex', alignItems: 'center', justifyContent: 'center', border: '1px solid #dcdcde', borderRadius: '6px', background: '#fff', flex: '0 0 auto', color: '#1d2327' } }, previewInner );
		var toggle = el( Button, { key: 'tg', variant: 'secondary', onClick: function () { setOpen( ! open ); } }, open ? __( 'Close', 'norvex' ) : __( 'Choose icon', 'norvex' ) );
		var bar = el( 'div', { key: 'bar', style: { display: 'flex', alignItems: 'center', gap: '8px', marginBottom: '8px' } }, [ preview, toggle ] );

		var panel = null;
		if ( open ) {
			var sections = [ el( 'div', { key: 'none', style: { marginBottom: '10px' } }, el( Button, { variant: current ? 'secondary' : 'primary', onClick: function () { set( i, 'icon', '' ); } }, __( 'No icon', 'norvex' ) ) ) ];
			groups.forEach( function ( g, gi ) {
				var grid = g.icons.map( function ( ic ) {
					var selected = known && current === ic.value;
					return el( 'button', {
						key: ic.value, type: 'button', title: ic.label,
						onClick: function () { set( i, 'icon', ic.value ); setOpen( false ); },
						style: { width: '34px', height: '34px', fontSize: '19px', display: 'inline-flex', alignItems: 'center', justifyContent: 'center', border: selected ? '2px solid #c08a3e' : '1px solid #dcdcde', borderRadius: '5px', background: selected ? '#f5efe0' : '#fff', color: '#1d2327', cursor: 'pointer', padding: 0 },
						dangerouslySetInnerHTML: { __html: ic.svg },
					} );
				} );
				sections.push( el( 'div', { key: 'g' + gi, style: { marginBottom: '12px' } }, [
					el( 'p', { key: 'h', style: { margin: '0 0 5px', fontSize: '11px', fontWeight: 600, textTransform: 'uppercase', letterSpacing: '.03em', color: '#646970' } }, g.label ),
					el( 'div', { key: 'gr', style: { display: 'flex', flexWrap: 'wrap', gap: '5px' } }, grid ),
				] ) );
			} );
			sections.push( el( 'div', { key: 'custom', style: { borderTop: '1px solid #e0e0e0', marginTop: '4px', paddingTop: '10px' } }, [
				el( TextareaControl, { key: 'svg', label: __( 'Custom SVG', 'norvex' ), value: isCustom ? current : '', rows: 4, placeholder: '<svg ...>…</svg>', onChange: function ( v ) { set( i, 'icon', '' === v.trim() ? '' : v ); } } ),
				el( 'p', { key: 'hint', style: { fontSize: '11px', color: '#646970', margin: '-6px 0 0' } }, __( 'Paste an SVG to use your own icon. Scripts are removed for safety.', 'norvex' ) ),
			] ) );
			panel = el( 'div', { key: 'lib', style: { border: '1px solid #e0e0e0', borderRadius: '5px', padding: '10px', maxHeight: '280px', overflowY: 'auto', marginBottom: '10px' } }, sections );
		}

		var numInput = el( TextControl, { key: 'num', label: __( 'Or a number / letter (instead of an icon)', 'norvex' ), value: isText ? current : '', onChange: function ( v ) { var tt = v.trim(); if ( tt !== '' ) { set( i, 'icon', tt ); } else if ( isText ) { set( i, 'icon', '' ); } } } );

		return el( 'div', { key: 'iconwrap', style: { marginBottom: '12px' } }, [
			el( 'p', { key: 'l', style: { margin: '0 0 4px', fontWeight: 600, fontSize: '12px' } }, __( 'Icon (shown when no image)', 'norvex' ) ),
			bar,
			panel,
			numInput,
		] );
	}

	function CardsControl( p ) {
		var field = p.field, props = p.props, cfg = field.options || {};
		var iconlist = cfg.iconlist || [];
		var state = wp.element.useState( function () { return parseCards( props.attributes[ field.key ] ); } );
		var cards = state[ 0 ], setCards = state[ 1 ];
		function commit( next ) {
			setCards( next );
			var attrs = {}; attrs[ field.key ] = JSON.stringify( next );
			props.setAttributes( attrs );
		}
		function set( i, key, val ) {
			commit( cards.map( function ( c, idx ) { if ( idx !== i ) { return c; } var nc = {}; for ( var k in c ) { nc[ k ] = c[ k ]; } nc[ key ] = val; return nc; } ) );
		}
		var children = [ el( 'p', { key: 'lbl', style: { fontWeight: 600, margin: '0 0 6px' } }, field.label ) ];
		cards.forEach( function ( card, i ) {
			var kids = [ el( 'p', { key: 'il', style: { margin: '0 0 4px', fontWeight: 600, fontSize: '12px' } }, __( 'Image (optional)', 'norvex' ) ) ];
			if ( card.image ) { kids.push( el( 'img', { key: 'ip', src: card.image, alt: '', style: { display: 'block', maxWidth: '100%', borderRadius: '4px', marginBottom: '6px' } } ) ); }
			kids.push( el( MediaUploadCheck, { key: 'iu' }, el( MediaUpload, { onSelect: function ( m ) { set( i, 'image', m && m.url ? m.url : '' ); }, allowedTypes: [ 'image' ], render: function ( o ) { return el( Button, { variant: 'secondary', onClick: o.open }, card.image ? __( 'Replace image', 'norvex' ) : __( 'Select image', 'norvex' ) ); } } ) ) );
			if ( card.image ) { kids.push( el( Button, { key: 'ir', variant: 'link', isDestructive: true, style: { marginLeft: '8px' }, onClick: function () { set( i, 'image', '' ); } }, __( 'Remove image', 'norvex' ) ) ); }
			kids.push( el( IconPicker, { key: 'icon', card: card, i: i, groups: iconlist, set: set } ) );
			kids.push( el( TextControl, { key: 'ti', label: __( 'Title', 'norvex' ), value: card.title || '', onChange: function ( v ) { set( i, 'title', v ); } } ) );
			kids.push( el( TextareaControl, { key: 'tx', label: __( 'Text', 'norvex' ), value: card.text || '', rows: 3, onChange: function ( v ) { set( i, 'text', v ); } } ) );
			kids.push( el( TextControl, { key: 'lu', label: __( 'Link URL (optional)', 'norvex' ), value: card.url || '', onChange: function ( v ) { set( i, 'url', v ); } } ) );
			kids.push( el( TextControl, { key: 'll', label: __( 'Link label', 'norvex' ), value: card.linklabel || '', onChange: function ( v ) { set( i, 'linklabel', v ); } } ) );
			kids.push( el( TextControl, { key: 'pr', label: __( 'Footer price / note (optional)', 'norvex' ), help: __( 'Shows bottom-left, e.g. “From $499”. The link (if set) sits bottom-right.', 'norvex' ), value: card.price || '', onChange: function ( v ) { set( i, 'price', v ); } } ) );
			kids.push( el( TextControl, { key: 'fn', label: __( 'Footer note (optional)', 'norvex' ), help: __( 'A small line under the footer, e.g. “One-time fee”.', 'norvex' ), value: card.note || '', onChange: function ( v ) { set( i, 'note', v ); } } ) );
			kids.push( el( SelectControl, { key: 'bs', label: __( 'Border', 'norvex' ), value: card.bside || '', options: [ { label: __( 'None', 'norvex' ), value: '' }, { label: __( 'All sides', 'norvex' ), value: 'all' }, { label: __( 'Top', 'norvex' ), value: 'top' }, { label: __( 'Right', 'norvex' ), value: 'right' }, { label: __( 'Bottom', 'norvex' ), value: 'bottom' }, { label: __( 'Left', 'norvex' ), value: 'left' } ], onChange: function ( v ) { set( i, 'bside', v ); } } ) );
			if ( card.bside ) {
				kids.push( el( 'div', { key: 'bx', style: { display: 'flex', gap: '10px', alignItems: 'flex-end' } }, [
					el( 'label', { key: 'bcl', style: { fontSize: '12px', display: 'flex', flexDirection: 'column', gap: '4px' } }, [ __( 'Colour', 'norvex' ), el( 'input', { key: 'bci', type: 'color', value: card.bcolor || '#c08a3e', onChange: function ( e ) { set( i, 'bcolor', e.target.value ); }, style: { width: '48px', height: '32px', padding: 0, border: '1px solid #ccc', borderRadius: '4px', background: 'none' } } ) ] ),
					el( 'div', { key: 'bw', style: { flex: 1 } }, el( TextControl, { label: __( 'Width (px)', 'norvex' ), type: 'number', min: 1, value: card.bwidth || '', placeholder: '3', onChange: function ( v ) { set( i, 'bwidth', v ); } } ) )
				] ) );
			}
			kids.push( el( Button, { key: 'rm', variant: 'link', isDestructive: true, onClick: function () { commit( cards.filter( function ( c, idx ) { return idx !== i; } ) ); } }, __( 'Remove card', 'norvex' ) ) );
			children.push( el( 'div', { key: 'c' + i, style: { border: '1px solid #e0e0e0', borderRadius: '4px', padding: '12px 12px 6px', marginBottom: '12px', background: '#fff' } }, kids ) );
		} );
		children.push( el( Button, { key: 'add', variant: 'primary', onClick: function () { commit( cards.concat( [ { icon: '', image: '', title: '', text: '', url: '', linklabel: '', price: '', note: '', bside: '', bcolor: '', bwidth: '' } ] ) ); } }, __( 'Add card', 'norvex' ) ) );
		return el( 'div', { className: 'norvex-cards-control', style: { marginBottom: '20px' } }, children );
	}

	// --- Inline (in-canvas) editor for the Grid cards block. -----------------
	// Card body text is typed directly on the card in the canvas; icon, image,
	// link and border "style" choices live in the sidebar for the selected card.

	// Strip HTML so values stay plain text (the PHP render escapes them, so any
	// stray markup would show literally on the front end).
	function stripTags( v ) {
		return ( v || '' ).replace( /<[^>]*>/g, '' );
	}
	// Whether an icon value is free text (number / letter) vs a known icon key
	// or a pasted SVG — mirrors norvex_icon_is_text() in PHP.
	function iconIsText( value, groups ) {
		var v = ( value || '' ).trim();
		if ( '' === v || '<' === v.charAt( 0 ) ) { return false; }
		var known = false;
		groups.forEach( function ( g ) { g.icons.forEach( function ( ic ) { if ( ic.value === v ) { known = true; } } ); } );
		return ! known;
	}
	function iconSvg( value, groups ) {
		var svg = '';
		groups.forEach( function ( g ) { g.icons.forEach( function ( ic ) { if ( ic.value === value ) { svg = ic.svg; } } ); } );
		return svg;
	}
	// Build the inline border style object from a card's fields (mirrors
	// norvex_card_border_style() in PHP).
	function cardBorderStyle( card ) {
		var side = ( card.bside || '' ).toLowerCase();
		if ( [ 'all', 'top', 'right', 'bottom', 'left' ].indexOf( side ) === -1 ) { return {}; }
		var w = parseInt( card.bwidth, 10 ); if ( ! w || w < 1 ) { w = 3; }
		var col = /^#([0-9a-f]{3}|[0-9a-f]{6})$/i.test( ( card.bcolor || '' ).trim() ) ? card.bcolor.trim() : '#c08a3e';
		var val = w + 'px solid ' + col;
		if ( 'all' === side ) { return { border: val }; }
		var o = {}; o[ 'border' + side.charAt( 0 ).toUpperCase() + side.slice( 1 ) ] = val; return o;
	}

	function CardsInlineEdit( p ) {
		var block = p.block, props = p.props, a = props.attributes;
		var cardsField = block.fields.filter( function ( f ) { return f.key === 'cards'; } )[ 0 ] || {};
		var groups = ( cardsField.options && cardsField.options.iconlist ) || [];
		var selState = wp.element.useState( 0 );
		var sel = selState[ 0 ], setSel = selState[ 1 ];
		var cards = parseCards( a.cards );

		function commitCards( next ) { props.setAttributes( { cards: JSON.stringify( next ) } ); }
		function setCard( i, key, val ) {
			commitCards( cards.map( function ( c, idx ) { if ( idx !== i ) { return c; } var nc = {}; for ( var k in c ) { nc[ k ] = c[ k ]; } nc[ key ] = val; return nc; } ) );
		}
		function addCard() {
			commitCards( cards.concat( [ { icon: '', image: '', title: __( 'New card', 'norvex' ), text: '', url: '', linklabel: '', price: '', note: '', caption: '', bside: '', bcolor: '', bwidth: '' } ] ) );
			setSel( cards.length );
		}

		// --- Canvas: section head + card grid, all typed in place. ---
		var head = el( 'div', { key: 'head', className: 'norvex-section-head norvex-center' }, [
			el( RichText, { key: 'eb', tagName: 'span', className: 'norvex-eyebrow', style: a.ceyebrow ? { color: a.ceyebrow } : undefined, value: a.eyebrow || '', allowedFormats: [], placeholder: __( 'Eyebrow (optional)', 'norvex' ), onChange: function ( v ) { props.setAttributes( { eyebrow: stripTags( v ) } ); } } ),
			el( RichText, { key: 'hd', tagName: 'h2', style: a.cheading ? { color: a.cheading } : undefined, value: a.heading || '', allowedFormats: [], placeholder: __( 'Heading', 'norvex' ), onChange: function ( v ) { props.setAttributes( { heading: stripTags( v ) } ); } } ),
			el( RichText, { key: 'ld', tagName: 'p', className: 'norvex-lead', style: a.clead ? { color: a.clead } : undefined, value: a.lead || '', allowedFormats: [], placeholder: __( 'Lead text (optional)', 'norvex' ), onChange: function ( v ) { props.setAttributes( { lead: stripTags( v ) } ); } } ),
		] );

		var gridCls = 'norvex-cards' + ( '2' === a.cols ? ' norvex-cards--2' : ( '4' === a.cols ? ' norvex-cards--4' : '' ) );

		var cardEls = cards.map( function ( card, i ) {
			var kids = [];
			if ( card.image ) {
				kids.push( el( 'div', { key: 'media', className: 'norvex-card__media' }, el( 'img', { src: card.image, alt: '' } ) ) );
			} else if ( iconIsText( card.icon, groups ) ) {
				kids.push( el( 'span', { key: 'num', className: 'norvex-card__num' }, ( card.icon || '' ).trim() ) );
			} else {
				var svg = iconSvg( card.icon, groups );
				if ( svg ) { kids.push( el( 'div', { key: 'icon', className: 'norvex-card__icon', dangerouslySetInnerHTML: { __html: svg } } ) ); }
			}
			var selected = i === sel;
			var hasText  = card.text && '' !== card.text.trim();
			var hasPrice = card.price && '' !== card.price.trim();
			var hasLink  = card.url && card.linklabel;
			// Image-only "caption" card: an image with the Title shown as a caption
			// strip, and no body text / link / price. Explicit toggle (card.caption)
			// or auto-detected the same way the PHP render does. Mirrors the front end.
			var isMedia = card.image && ( '1' === card.caption || ( ! hasText && ! hasLink && ! hasPrice ) );

			if ( isMedia ) {
				var showCaption = card.title || selected;
				var mediaCls = 'norvex-card norvex-lift ' + ( showCaption ? 'norvex-card--figure' : 'norvex-card--media-only' ) + ( selected ? ' norvex-card--selected' : '' );
				var mkids = [ el( 'div', { key: 'media', className: 'norvex-card__media' }, el( 'img', { src: card.image, alt: '' } ) ) ];
				if ( showCaption ) {
					mkids.push( el( RichText, { key: 'cap', tagName: 'div', className: 'norvex-card__caption', value: card.title || '', allowedFormats: [], placeholder: __( 'Caption (optional)', 'norvex' ), onChange: function ( v ) { setCard( i, 'title', stripTags( v ) ); } } ) );
				}
				return el( 'article', { key: 'c' + i, className: mediaCls, style: cardBorderStyle( card ), onClick: function () { setSel( i ); } }, mkids );
			}

			kids.push( el( RichText, { key: 'title', tagName: 'h3', value: card.title || '', allowedFormats: [], placeholder: __( 'Card title', 'norvex' ), onChange: function ( v ) { setCard( i, 'title', stripTags( v ) ); } } ) );
			kids.push( el( RichText, { key: 'text', tagName: 'p', value: card.text || '', allowedFormats: [], placeholder: __( 'Card text…', 'norvex' ), onChange: function ( v ) { setCard( i, 'text', stripTags( v ) ); } } ) );
			// Inline link: the label is typed on the card; the URL is set via the
			// The label is typed here; its URL is set in the sidebar (searchable).
			function linkArea( key ) {
				return el( 'span', { key: key, className: 'norvex-card__linkwrap' }, el( RichText, { key: 'll', tagName: 'span', className: 'norvex-card__link', value: card.linklabel || '', allowedFormats: [], placeholder: __( 'Link label', 'norvex' ), onChange: function ( v ) { setCard( i, 'linklabel', stripTags( v ) ); } } ) );
			}
			// The footer (price + link) and footer note only show on the front end
			// once they have content, but the selected card always shows them as
			// editable placeholders so they can be added in place.
			var showFoot = hasPrice || selected;
			var showLink = hasLink || selected;
			if ( showFoot ) {
				var footKids = [ el( RichText, { key: 'price', tagName: 'span', className: 'norvex-card__note', value: card.price || '', allowedFormats: [], placeholder: __( 'Price (optional)', 'norvex' ), onChange: function ( v ) { setCard( i, 'price', stripTags( v ) ); } } ) ];
				if ( showLink ) { footKids.push( linkArea( 'foot-link' ) ); }
				kids.push( el( 'div', { key: 'foot', className: 'norvex-card__foot' }, footKids ) );
			} else if ( showLink ) {
				kids.push( linkArea( 'inline-link' ) );
			}
			if ( ( card.note && '' !== card.note.trim() ) || selected ) {
				kids.push( el( RichText, { key: 'note', tagName: 'p', className: 'norvex-card__fnote', value: card.note || '', allowedFormats: [], placeholder: __( 'Footer note (optional)', 'norvex' ), onChange: function ( v ) { setCard( i, 'note', stripTags( v ) ); } } ) );
			}
			var cls = 'norvex-card norvex-lift' + ( showFoot ? ' norvex-card--has-foot' : '' ) + ( selected ? ' norvex-card--selected' : '' );
			return el( 'article', { key: 'c' + i, className: cls, style: cardBorderStyle( card ), onClick: function () { setSel( i ); } }, kids );
		} );

		var grid = el( 'div', { key: 'grid', className: gridCls }, cardEls );
		var addBtn = el( 'div', { key: 'add', className: 'norvex-cards-add', style: { textAlign: 'center', marginTop: '14px' } }, el( Button, { variant: 'primary', onClick: addCard }, __( 'Add card', 'norvex' ) ) );

		var canvas = el( 'div', useBlockProps( { key: 'canvas' } ), el( 'section', { className: 'norvex-section' }, el( 'div', { className: 'norvex-wrap' }, cards.length ? [ head, grid, addBtn ] : [ head, el( 'p', { key: 'empty', style: { textAlign: 'center', opacity: 0.7 } }, __( 'No cards yet.', 'norvex' ) ), addBtn ] ) ) );

		// --- Sidebar: layout + the selected card's style choices. ---
		var selCard = cards[ sel ] || null;
		var panels = [
			el( PanelBody, { key: 'layout', title: __( 'Layout', 'norvex' ), initialOpen: true }, [
				el( SelectControl, { key: 'cols', label: __( 'Cards per row', 'norvex' ), value: a.cols, options: [ { label: __( '2 per row', 'norvex' ), value: '2' }, { label: __( '3 per row', 'norvex' ), value: '3' }, { label: __( '4 per row', 'norvex' ), value: '4' } ], onChange: function ( v ) { props.setAttributes( { cols: v } ); } } ),
				el( SelectControl, { key: 'disp', label: __( 'Display', 'norvex' ), value: a.carousel, options: [ { label: __( 'Grid', 'norvex' ), value: 'grid' }, { label: __( 'Carousel / slider', 'norvex' ), value: '1' } ], onChange: function ( v ) { props.setAttributes( { carousel: v } ); } } ),
			] ),
		];
		if ( selCard ) {
			var cardPanel = [
				el( 'p', { key: 'hint', style: { margin: '0 0 10px', fontSize: '12px', color: '#646970' } }, __( 'Editing the card you clicked in the preview. Title, text, price, note and the link label are typed on the card itself; set the link’s address below.', 'norvex' ) ),
				urlSearch( 'lu', __( 'Link URL', 'norvex' ), selCard.url, function ( v ) { setCard( sel, 'url', v ); } ),
				el( 'p', { key: 'il', style: { margin: '0 0 4px', fontWeight: 600, fontSize: '12px' } }, __( 'Image (optional)', 'norvex' ) ),
			];
			if ( selCard.image ) { cardPanel.push( el( 'img', { key: 'ip', src: selCard.image, alt: '', style: { display: 'block', maxWidth: '100%', borderRadius: '4px', marginBottom: '6px' } } ) ); }
			cardPanel.push( el( MediaUploadCheck, { key: 'iu' }, el( MediaUpload, { onSelect: function ( m ) { setCard( sel, 'image', m && m.url ? m.url : '' ); }, allowedTypes: [ 'image' ], render: function ( o ) { return el( Button, { variant: 'secondary', onClick: o.open }, selCard.image ? __( 'Replace image', 'norvex' ) : __( 'Select image', 'norvex' ) ); } } ) ) );
			if ( selCard.image ) { cardPanel.push( el( Button, { key: 'ir', variant: 'link', isDestructive: true, style: { marginLeft: '8px' }, onClick: function () { setCard( sel, 'image', '' ); } }, __( 'Remove image', 'norvex' ) ) ); }
			cardPanel.push( el( IconPicker, { key: 'icon', card: selCard, i: sel, groups: groups, set: setCard } ) );
			if ( selCard.image ) {
				cardPanel.push( el( ToggleControl, { key: 'cap', label: __( 'Image only (caption tile)', 'norvex' ), help: __( 'Show just the image with the Title as a caption — no body text, link or price.', 'norvex' ), checked: '1' === selCard.caption, onChange: function ( on ) { setCard( sel, 'caption', on ? '1' : '' ); } } ) );
			}
			cardPanel.push( el( SelectControl, { key: 'bs', label: __( 'Border', 'norvex' ), value: selCard.bside || '', options: [ { label: __( 'None', 'norvex' ), value: '' }, { label: __( 'All sides', 'norvex' ), value: 'all' }, { label: __( 'Top', 'norvex' ), value: 'top' }, { label: __( 'Right', 'norvex' ), value: 'right' }, { label: __( 'Bottom', 'norvex' ), value: 'bottom' }, { label: __( 'Left', 'norvex' ), value: 'left' } ], onChange: function ( v ) { setCard( sel, 'bside', v ); } } ) );
			if ( selCard.bside ) {
				cardPanel.push( el( 'div', { key: 'bx', style: { display: 'flex', gap: '10px', alignItems: 'flex-end', marginBottom: '10px' } }, [
					el( 'label', { key: 'bcl', style: { fontSize: '12px', display: 'flex', flexDirection: 'column', gap: '4px' } }, [ __( 'Colour', 'norvex' ), el( 'input', { key: 'bci', type: 'color', value: selCard.bcolor || '#c08a3e', onChange: function ( e ) { setCard( sel, 'bcolor', e.target.value ); }, style: { width: '48px', height: '32px', padding: 0, border: '1px solid #ccc', borderRadius: '4px', background: 'none' } } ) ] ),
					el( 'div', { key: 'bw', style: { flex: 1 } }, el( TextControl, { label: __( 'Width (px)', 'norvex' ), type: 'number', min: 1, value: selCard.bwidth || '', placeholder: '3', onChange: function ( v ) { setCard( sel, 'bwidth', v ); } } ) )
				] ) );
			}
			cardPanel.push( el( Button, { key: 'rm', variant: 'link', isDestructive: true, onClick: function () { commitCards( cards.filter( function ( c, idx ) { return idx !== sel; } ) ); setSel( 0 ); } }, __( 'Remove this card', 'norvex' ) ) );
			panels.push( el( PanelBody, { key: 'card', title: __( 'Card', 'norvex' ) + ' ' + ( sel + 1 ), initialOpen: true }, cardPanel ) );
		}

		return el( Fragment, null, [ el( InspectorControls, { key: 'insp' }, panels ), canvas ] );
	}

	// --- Table control: a 2D grid of cells with add/remove row & column. ---
	function parseTable( value ) {
		try {
			var a = JSON.parse( value || '[]' );
			if ( Array.isArray( a ) && a.length ) { return a.map( function ( r ) { return Array.isArray( r ) ? r : []; } ); }
		} catch ( e ) {}
		return [ [ '', '' ], [ '', '' ] ];
	}
	function TableControl( p ) {
		var field = p.field, props = p.props;
		var state = wp.element.useState( function () { return parseTable( props.attributes[ field.key ] ); } );
		var rows = state[ 0 ], setRows = state[ 1 ];
		function commit( next ) {
			setRows( next );
			var attrs = {}; attrs[ field.key ] = JSON.stringify( next );
			props.setAttributes( attrs );
		}
		var ncols = rows.reduce( function ( m, r ) { return Math.max( m, r.length ); }, 1 );
		function setCell( ri, ci, val ) {
			commit( rows.map( function ( r, i ) { if ( i !== ri ) { return r; } var nr = r.slice(); while ( nr.length <= ci ) { nr.push( '' ); } nr[ ci ] = val; return nr; } ) );
		}
		function addRow() { var nr = []; for ( var c = 0; c < ncols; c++ ) { nr.push( '' ); } commit( rows.concat( [ nr ] ) ); }
		function removeRow() { if ( rows.length > 1 ) { commit( rows.slice( 0, -1 ) ); } }
		function addCol() { commit( rows.map( function ( r ) { var nr = r.slice(); nr.push( '' ); return nr; } ) ); }
		function removeCol() { if ( ncols > 1 ) { commit( rows.map( function ( r ) { return r.slice( 0, ncols - 1 ); } ) ); } }

		var grid = rows.map( function ( row, ri ) {
			var cells = [];
			for ( var ci = 0; ci < ncols; ci++ ) {
				( function ( ci ) {
					cells.push( el( 'input', { key: ci, type: 'text', value: undefined !== row[ ci ] ? row[ ci ] : '', style: { flex: '1 1 60px', minWidth: '0', boxSizing: 'border-box', padding: '4px 6px', border: '1px solid #dcdcde', borderRadius: '3px', fontWeight: 0 === ri ? 600 : 400 }, onChange: function ( e ) { setCell( ri, ci, e.target.value ); } } ) );
				} )( ci );
			}
			return el( 'div', { key: 'r' + ri, style: { display: 'flex', gap: '4px', marginBottom: '4px' } }, cells );
		} );
		var controls = el( 'div', { key: 'ctrl', style: { display: 'flex', flexWrap: 'wrap', gap: '6px', marginTop: '8px' } }, [
			el( Button, { key: 'ar', variant: 'secondary', onClick: addRow }, __( '+ Row', 'norvex' ) ),
			el( Button, { key: 'rr', variant: 'secondary', onClick: removeRow }, __( '– Row', 'norvex' ) ),
			el( Button, { key: 'ac', variant: 'secondary', onClick: addCol }, __( '+ Column', 'norvex' ) ),
			el( Button, { key: 'rc', variant: 'secondary', onClick: removeCol }, __( '– Column', 'norvex' ) ),
		] );
		return el( 'div', { className: 'norvex-table-control', style: { marginBottom: '20px' } }, [
			el( 'p', { key: 'l', style: { fontWeight: 600, margin: '0 0 6px' } }, field.label ),
			el( 'div', { key: 'g' }, grid ),
			controls,
		] );
	}

	// --- Tabs control: a repeater of { title, content } tabs. ---
	function parseTabs( value ) {
		try { var a = JSON.parse( value || '[]' ); return Array.isArray( a ) ? a : []; } catch ( e ) { return []; }
	}
	function TabsControl( p ) {
		var field = p.field, props = p.props;
		var state = wp.element.useState( function () { return parseTabs( props.attributes[ field.key ] ); } );
		var tabs = state[ 0 ], setTabs = state[ 1 ];
		function commit( next ) {
			setTabs( next );
			var attrs = {}; attrs[ field.key ] = JSON.stringify( next );
			props.setAttributes( attrs );
		}
		function set( i, key, val ) {
			commit( tabs.map( function ( t, idx ) { if ( idx !== i ) { return t; } var nt = {}; for ( var k in t ) { nt[ k ] = t[ k ]; } nt[ key ] = val; return nt; } ) );
		}
		var children = [ el( 'p', { key: 'lbl', style: { fontWeight: 600, margin: '0 0 6px' } }, field.label ) ];
		tabs.forEach( function ( tab, i ) {
			var kids = [
				el( TextControl, { key: 'ti', label: __( 'Tab title', 'norvex' ), value: tab.title || '', onChange: function ( v ) { set( i, 'title', v ); } } ),
				el( TextareaControl, { key: 'co', label: __( 'Content', 'norvex' ), value: tab.content || '', rows: 5, onChange: function ( v ) { set( i, 'content', v ); } } ),
				el( Button, { key: 'rm', variant: 'link', isDestructive: true, onClick: function () { commit( tabs.filter( function ( t, idx ) { return idx !== i; } ) ); } }, __( 'Remove tab', 'norvex' ) ),
			];
			children.push( el( 'div', { key: 't' + i, style: { border: '1px solid #e0e0e0', borderRadius: '4px', padding: '12px 12px 6px', marginBottom: '12px', background: '#fff' } }, kids ) );
		} );
		children.push( el( Button, { key: 'add', variant: 'primary', onClick: function () { commit( tabs.concat( [ { title: '', content: '' } ] ) ); } }, __( 'Add tab', 'norvex' ) ) );
		return el( 'div', { className: 'norvex-tabs-control', style: { marginBottom: '20px' } }, children );
	}

	// =========================================================================
	// Inline (in-canvas) editors for the fixed-field content blocks. Each one
	// mirrors the front-end markup so the canvas matches the site; text is typed
	// in place, and only non-text "style" fields (URLs, image, alignment, accent,
	// header toggle) live in the sidebar. The PHP render_callbacks are unchanged.
	// =========================================================================

	// A RichText bound to a top-level block attribute, kept as plain text.
	// Maps a header line to its "Header line colours" attribute so the inline
	// editors reflect the picked colour in the canvas (the front end applies it
	// in PHP). eyebrow → ceyebrow, heading/title → cheading, lead → clead.
	var HEADER_COLOR_KEY = { eyebrow: 'ceyebrow', heading: 'cheading', title: 'cheading', lead: 'clead' };

	function attrRT( props, key, tag, cls, ph, style ) {
		var ck = HEADER_COLOR_KEY[ key ];
		var color = ck && props.attributes[ ck ];
		if ( color ) {
			style = Object.assign( {}, style || {}, { color: color } );
		}
		return el( RichText, { key: key, tagName: tag, className: cls, style: style, value: props.attributes[ key ] || '', allowedFormats: [], placeholder: ph, onChange: function ( v ) { var n = {}; n[ key ] = stripTags( v ); props.setAttributes( n ); } } );
	}
	// A sidebar text field bound to a top-level attribute.
	function attrField( props, key, label ) {
		return el( TextControl, { key: key, label: label, value: props.attributes[ key ] || '', onChange: function ( v ) { var n = {}; n[ key ] = v; props.setAttributes( n ); } } );
	}
	// A sidebar link field with page/post search (type to find, or paste a URL).
	function urlSearch( key, label, value, onChange ) {
		return el( 'div', { key: key, className: 'norvex-url-field', style: { marginBottom: '16px' } }, [
			el( 'p', { key: 'l', style: { margin: '0 0 4px', fontWeight: 600, fontSize: '12px' } }, label ),
			el( URLInput, { key: 'i', value: value || '', onChange: function ( u ) { onChange( u ); } } ),
		] );
	}
	// The same, bound to a top-level attribute.
	function attrUrl( props, key, label ) {
		return urlSearch( key, label, props.attributes[ key ], function ( u ) { var n = {}; n[ key ] = u; props.setAttributes( n ); } );
	}
	// A button styled like the front end, its label typed in place.
	function inlineBtn( props, key, styleCls, ph ) {
		return el( 'span', { key: key, className: 'norvex-btn norvex-btn--' + styleCls, style: { cursor: 'text' } }, attrRT( props, key, 'span', null, ph ) );
	}
	function sidebar( key, title, kids ) {
		return el( InspectorControls, { key: 'insp' }, el( PanelBody, { title: title, initialOpen: true }, kids ) );
	}

	function HeroInline( p ) {
		var props = p.props, a = props.attributes;
		var intro = el( 'div', { key: 'intro', className: 'norvex-hero__intro' }, [
			attrRT( props, 'eyebrow', 'span', 'norvex-eyebrow', __( 'Eyebrow', 'norvex' ) ),
			attrRT( props, 'title', 'h1', null, __( 'Title', 'norvex' ) ),
			attrRT( props, 'lead', 'p', 'norvex-hero__lead', __( 'Lead text', 'norvex' ) ),
			el( 'div', { key: 'act', className: 'norvex-hero__actions' }, [ inlineBtn( props, 'btn1', 'primary', __( 'Primary button', 'norvex' ) ), inlineBtn( props, 'btn2', 'ghost', __( 'Secondary button', 'norvex' ) ) ] ),
			el( 'div', { key: 'stats', className: 'norvex-hero__stats' }, [ 1, 2, 3 ].map( function ( i ) {
				return el( 'div', { key: 's' + i, className: 'norvex-hero__stat' }, [ attrRT( props, 's' + i + 'n', 'strong', null, '100%' ), attrRT( props, 's' + i + 'l', 'span', null, __( 'Label', 'norvex' ) ) ] );
			} ) ),
		] );
		var art = el( 'div', { key: 'art', className: 'norvex-hero__art' }, [
			el( 'img', { key: 'img', src: a.image || '', alt: '', style: a.image ? null : { display: 'block', minHeight: '220px', width: '100%', background: 'rgba(0,0,0,.06)', borderRadius: '12px' } } ),
			el( 'div', { key: 'badge', className: 'norvex-hero__badge' }, [
				el( 'span', { key: 'st', className: 'norvex-stars', title: __( 'Click a star to set the rating', 'norvex' ) }, ( function () {
					var nStars = parseInt( a.stars, 10 ) || 5;
					var out = [];
					for ( var s = 1; s <= 5; s++ ) { ( function ( s ) { out.push( el( 'span', { key: s, onClick: function () { props.setAttributes( { stars: s } ); }, style: { cursor: 'pointer' } }, s <= nStars ? '★' : '☆' ) ); } )( s ); }
					return out;
				} )() ),
				el( 'span', { key: 'bt' }, [ attrRT( props, 'badge', 'strong', null, __( 'Rating', 'norvex' ) ), attrRT( props, 'badgesub', 'span', null, __( 'Subtext', 'norvex' ) ) ] ),
			] ),
		] );
		var canvas = el( 'div', useBlockProps( { key: 'canvas' } ), el( 'section', { className: 'norvex-hero' }, el( 'div', { className: 'norvex-wrap norvex-hero__grid' }, [ intro, art ] ) ) );
		return el( Fragment, null, [ sidebar( 'h', __( 'Links & image', 'norvex' ), [ imageControl( { key: 'image', label: __( 'Hero image', 'norvex' ) }, props ), attrUrl( props, 'btn1url', __( 'Primary button URL', 'norvex' ) ), attrUrl( props, 'btn2url', __( 'Secondary button URL', 'norvex' ) ) ] ), canvas ] );
	}

	function CtaInline( p ) {
		var props = p.props;
		var box = el( 'div', { key: 'cta', className: 'norvex-cta' }, [
			attrRT( props, 'eyebrow', 'span', 'norvex-eyebrow', __( 'Eyebrow', 'norvex' ), { color: 'var(--norvex-gold)' } ),
			attrRT( props, 'title', 'h2', null, __( 'Title', 'norvex' ) ),
			attrRT( props, 'text', 'p', null, __( 'Text', 'norvex' ) ),
			el( 'div', { key: 'act', className: 'norvex-cta__actions' }, [ inlineBtn( props, 'btn1', 'primary', __( 'Primary button', 'norvex' ) ), inlineBtn( props, 'btn2', 'ghost', __( 'Secondary button', 'norvex' ) ) ] ),
		] );
		var canvas = el( 'div', useBlockProps( { key: 'canvas' } ), el( 'section', { className: 'norvex-section norvex-section--tight' }, el( 'div', { className: 'norvex-wrap' }, box ) ) );
		return el( Fragment, null, [ sidebar( 'c', __( 'Button links', 'norvex' ), [ attrUrl( props, 'btn1url', __( 'Primary button URL', 'norvex' ) ), attrUrl( props, 'btn2url', __( 'Secondary button URL', 'norvex' ) ) ] ), canvas ] );
	}

	function CalloutInline( p ) {
		var props = p.props, a = props.attributes;
		var accent = a.accent || 'green';
		var quote = el( 'blockquote', { className: 'norvex-verdict norvex-verdict--' + accent }, [
			attrRT( props, 'text', 'p', 'norvex-verdict__text', __( 'Statement', 'norvex' ) ),
			attrRT( props, 'cite', 'cite', 'norvex-verdict__cite', __( 'Attribution (optional)', 'norvex' ) ),
		] );
		var canvas = el( 'div', useBlockProps( { key: 'canvas' } ), quote );
		var accents = { green: __( 'Green', 'norvex' ), rust: __( 'Rust', 'norvex' ), ink: __( 'Ink', 'norvex' ), muted: __( 'Muted', 'norvex' ) };
		return el( Fragment, null, [ sidebar( 'v', __( 'Style', 'norvex' ), [ el( SelectControl, { key: 'ac', label: __( 'Accent colour', 'norvex' ), value: accent, options: Object.keys( accents ).map( function ( k ) { return { label: accents[ k ], value: k }; } ), onChange: function ( v ) { props.setAttributes( { accent: v } ); } } ) ] ), canvas ] );
	}

	function StatsInline( p ) {
		var props = p.props;
		var band = el( 'div', { className: 'norvex-stats-band' }, [ 1, 2, 3, 4 ].map( function ( i ) {
			return el( 'div', { key: 'st' + i, className: 'norvex-stat-lg' }, [ attrRT( props, 'n' + i, 'strong', null, '100%' ), attrRT( props, 'l' + i, 'span', null, __( 'Label', 'norvex' ) ) ] );
		} ) );
		var canvas = el( 'div', useBlockProps( { key: 'canvas' } ), el( 'section', { className: 'norvex-section norvex-section--tight norvex-section--ink' }, el( 'div', { className: 'norvex-wrap' }, band ) ) );
		return el( Fragment, null, [ canvas ] );
	}

	function parsePairs( v ) {
		return ( v || '' ).split( '\n' ).map( function ( l ) { return l.trim(); } ).filter( Boolean ).map( function ( l ) { var i = l.indexOf( '|' ); return i < 0 ? { q: l, a: '' } : { q: l.slice( 0, i ).trim(), a: l.slice( i + 1 ).trim() }; } );
	}
	function joinPairs( arr ) { return arr.map( function ( x ) { return ( x.q || '' ) + ' | ' + ( x.a || '' ); } ).join( '\n' ); }

	function FaqInline( p ) {
		var props = p.props, a = props.attributes;
		var items = parsePairs( a.items );
		function commit( next ) { props.setAttributes( { items: joinPairs( next ) } ); }
		function setItem( i, key, val ) { commit( items.map( function ( x, idx ) { if ( idx !== i ) { return x; } var nx = { q: x.q, a: x.a }; nx[ key ] = stripTags( val ); return nx; } ) ); }
		var head = el( 'div', { key: 'head', className: 'norvex-section-head norvex-center' }, [ attrRT( props, 'eyebrow', 'span', 'norvex-eyebrow', __( 'Eyebrow', 'norvex' ) ), attrRT( props, 'title', 'h2', null, __( 'Title', 'norvex' ) ) ] );
		var list = items.map( function ( x, i ) {
			return el( 'div', { key: 'f' + i, className: 'norvex-faq-edit', style: { border: '1px solid var(--norvex-line,#e7ddca)', borderRadius: '10px', padding: '14px 18px', marginBottom: '10px', background: '#fff' } }, [
				el( RichText, { key: 'q', tagName: 'p', style: { fontWeight: 700, margin: '0 0 6px' }, value: x.q || '', allowedFormats: [], placeholder: __( 'Question', 'norvex' ), onChange: function ( v ) { setItem( i, 'q', v ); } } ),
				el( RichText, { key: 'a', tagName: 'p', style: { margin: 0, opacity: 0.85 }, value: x.a || '', allowedFormats: [], placeholder: __( 'Answer', 'norvex' ), onChange: function ( v ) { setItem( i, 'a', v ); } } ),
				el( Button, { key: 'rm', variant: 'link', isDestructive: true, onClick: function () { commit( items.filter( function ( y, idx ) { return idx !== i; } ) ); } }, __( 'Remove', 'norvex' ) ),
			] );
		} );
		var addBtn = el( 'div', { key: 'add', style: { textAlign: 'center', margin: '4px 0 14px' } }, el( Button, { variant: 'secondary', onClick: function () { commit( items.concat( [ { q: __( 'New question', 'norvex' ), a: '' } ] ) ); } }, __( 'Add FAQ', 'norvex' ) ) );
		var btn = el( 'p', { key: 'btn', className: 'norvex-center', style: { marginTop: '10px' } }, inlineBtn( props, 'btn', 'ghost', __( 'Button (optional)', 'norvex' ) ) );
		var canvas = el( 'div', useBlockProps( { key: 'canvas' } ), el( 'section', { className: 'norvex-section norvex-section--sand' }, el( 'div', { className: 'norvex-wrap' }, [ head, el( 'div', { key: 'items' }, list ), addBtn, btn ] ) ) );
		return el( Fragment, null, [ sidebar( 'f', __( 'Button link', 'norvex' ), [ attrUrl( props, 'btnurl', __( 'Button URL', 'norvex' ) ) ] ), canvas ] );
	}

	function parseBtns( v ) {
		return ( v || '' ).split( '\n' ).map( function ( l ) { return l.trim(); } ).filter( Boolean ).map( function ( l ) { var pp = l.split( '|' ).map( function ( s ) { return s.trim(); } ); return { label: pp[ 0 ] || '', url: pp[ 1 ] || '', style: [ 'primary', 'ghost', 'light' ].indexOf( pp[ 2 ] ) >= 0 ? pp[ 2 ] : 'primary', blank: !! ( pp[ 3 ] && '' !== pp[ 3 ] ) }; } );
	}
	function joinBtns( arr ) { return arr.map( function ( b ) { return [ b.label, b.url, b.style, b.blank ? '_blank' : '' ].join( ' | ' ); } ).join( '\n' ); }

	function ButtonsInline( p ) {
		var props = p.props, a = props.attributes;
		var btns = parseBtns( a.items );
		var selState = wp.element.useState( 0 );
		var sel = selState[ 0 ], setSel = selState[ 1 ];
		function commit( next ) { props.setAttributes( { items: joinBtns( next ) } ); }
		function setBtn( i, key, val ) { commit( btns.map( function ( b, idx ) { if ( idx !== i ) { return b; } var nb = { label: b.label, url: b.url, style: b.style, blank: b.blank }; nb[ key ] = val; return nb; } ) ); }
		var align = a.align || 'left';
		var row = el( 'div', { className: 'norvex-buttons norvex-buttons--' + align }, btns.map( function ( b, i ) {
			return el( 'span', { key: 'b' + i, className: 'norvex-btn norvex-btn--' + b.style + ( i === sel ? ' norvex-card--selected' : '' ), style: { cursor: 'text' }, onClick: function () { setSel( i ); } }, el( RichText, { tagName: 'span', value: b.label || '', allowedFormats: [], placeholder: __( 'Button', 'norvex' ), onChange: function ( v ) { setBtn( i, 'label', stripTags( v ) ); } } ) );
		} ) );
		var addBtn = el( 'div', { key: 'add', style: { textAlign: 'center', marginTop: '12px' } }, el( Button, { variant: 'secondary', onClick: function () { commit( btns.concat( [ { label: __( 'New button', 'norvex' ), url: '', style: 'primary', blank: false } ] ) ); setSel( btns.length ); } }, __( 'Add button', 'norvex' ) ) );
		var canvas = el( 'div', useBlockProps( { key: 'canvas' } ), el( 'div', { className: 'norvex-section norvex-section--tight' }, el( 'div', { className: 'norvex-wrap' }, [ row, addBtn ] ) ) );
		var selBtn = btns[ sel ] || null;
		var panel = [ el( SelectControl, { key: 'al', label: __( 'Alignment', 'norvex' ), value: align, options: [ { label: __( 'Left', 'norvex' ), value: 'left' }, { label: __( 'Center', 'norvex' ), value: 'center' }, { label: __( 'Right', 'norvex' ), value: 'right' } ], onChange: function ( v ) { props.setAttributes( { align: v } ); } } ) ];
		if ( selBtn ) {
			panel.push( el( 'p', { key: 'hint', style: { margin: '10px 0 4px', fontSize: '12px', color: '#646970' } }, __( 'Editing the button you clicked (its label is typed on the button).', 'norvex' ) ) );
			panel.push( urlSearch( 'u', __( 'Link URL', 'norvex' ), selBtn.url, function ( v ) { setBtn( sel, 'url', v ); } ) );
			panel.push( el( SelectControl, { key: 's', label: __( 'Style', 'norvex' ), value: selBtn.style, options: [ { label: __( 'Primary (filled)', 'norvex' ), value: 'primary' }, { label: __( 'Outline', 'norvex' ), value: 'ghost' }, { label: __( 'Light', 'norvex' ), value: 'light' } ], onChange: function ( v ) { setBtn( sel, 'style', v ); } } ) );
			panel.push( el( ToggleControl, { key: 't', label: __( 'Open in new tab', 'norvex' ), checked: !! selBtn.blank, onChange: function ( on ) { setBtn( sel, 'blank', on ); } } ) );
			panel.push( el( Button, { key: 'rm', variant: 'link', isDestructive: true, onClick: function () { commit( btns.filter( function ( b, idx ) { return idx !== sel; } ) ); setSel( 0 ); } }, __( 'Remove this button', 'norvex' ) ) );
		}
		return el( Fragment, null, [ sidebar( 'b', __( 'Buttons', 'norvex' ), panel ), canvas ] );
	}

	function TableInline( p ) {
		var props = p.props, a = props.attributes;
		var rows = parseTable( a.data );
		var header = '1' === String( a.header );
		function commit( next ) { props.setAttributes( { data: JSON.stringify( next ) } ); }
		var ncols = rows.reduce( function ( m, r ) { return Math.max( m, r.length ); }, 1 );
		function setCell( ri, ci, val ) { commit( rows.map( function ( r, i ) { if ( i !== ri ) { return r; } var nr = r.slice(); while ( nr.length <= ci ) { nr.push( '' ); } nr[ ci ] = stripTags( val ); return nr; } ) ); }
		function addRow() { var nr = []; for ( var c = 0; c < ncols; c++ ) { nr.push( '' ); } commit( rows.concat( [ nr ] ) ); }
		function addCol() { commit( rows.map( function ( r ) { var nr = r.slice(); nr.push( '' ); return nr; } ) ); }
		function removeRow( ri ) { if ( rows.length > 1 ) { commit( rows.filter( function ( r, i ) { return i !== ri; } ) ); } }
		function removeCol( ci ) { if ( ncols > 1 ) { commit( rows.map( function ( r ) { return r.filter( function ( c, i ) { return i !== ci; } ); } ) ); } }
		function cell( tag, ri, ci ) {
			return el( tag, { key: 'c' + ci }, el( RichText, { tagName: 'span', value: ( rows[ ri ] && rows[ ri ][ ci ] ) || '', allowedFormats: [], placeholder: '—', onChange: function ( v ) { setCell( ri, ci, v ); } } ) );
		}
		var colremove = el( 'tr', { key: 'colx' }, ( function () { var out = []; for ( var c = 0; c < ncols; c++ ) { ( function ( c ) { out.push( el( 'td', { key: 'x' + c, style: { textAlign: 'center', border: 0, padding: '2px' } }, el( Button, { variant: 'link', isDestructive: true, onClick: function () { removeCol( c ); }, style: { minWidth: 0, padding: '0 4px' } }, '×' ) ) ); } )( c ); } return out; } )() );
		var bodyRows = [];
		var start = header ? 1 : 0;
		for ( var ri = start; ri < rows.length; ri++ ) {
			( function ( ri ) {
				var tds = [];
				for ( var c = 0; c < ncols; c++ ) { tds.push( cell( 'td', ri, c ) ); }
				tds.push( el( 'td', { key: 'rx', style: { border: 0, padding: '2px' } }, el( Button, { variant: 'link', isDestructive: true, onClick: function () { removeRow( ri ); }, style: { minWidth: 0, padding: '0 4px' } }, '×' ) ) );
				bodyRows.push( el( 'tr', { key: 'r' + ri }, tds ) );
			} )( ri );
		}
		var thead = null;
		if ( header ) {
			var ths = [];
			for ( var hc = 0; hc < ncols; hc++ ) { ths.push( cell( 'th', 0, hc ) ); }
			ths.push( el( 'th', { key: 'hx', style: { border: 0 } } ) );
			thead = el( 'thead', { key: 'th' }, el( 'tr', null, ths ) );
		}
		var table = el( 'table', { className: 'norvex-table' }, [ thead, el( 'tbody', { key: 'tb' }, bodyRows.concat( [ colremove ] ) ) ] );
		var tools = el( 'div', { key: 'tools', style: { display: 'flex', gap: '8px', marginTop: '10px' } }, [ el( Button, { key: 'ar', variant: 'secondary', onClick: addRow }, __( 'Add row', 'norvex' ) ), el( Button, { key: 'ac', variant: 'secondary', onClick: addCol }, __( 'Add column', 'norvex' ) ) ] );
		var canvas = el( 'div', useBlockProps( { key: 'canvas' } ), el( 'div', { className: 'norvex-section norvex-section--tight' }, el( 'div', { className: 'norvex-wrap' }, [
			attrRT( props, 'heading', 'h2', 'norvex-table__title', __( 'Heading (optional)', 'norvex' ) ),
			el( 'div', { key: 'tw', className: 'norvex-table-wrap' }, table ),
			tools,
		] ) ) );
		return el( Fragment, null, [ sidebar( 't', __( 'Table', 'norvex' ), [ el( SelectControl, { key: 'h', label: __( 'First row is a header', 'norvex' ), value: header ? '1' : '0', options: [ { label: __( 'Yes', 'norvex' ), value: '1' }, { label: __( 'No', 'norvex' ), value: '0' } ], onChange: function ( v ) { props.setAttributes( { header: v } ); } } ) ] ), canvas ] );
	}

	// --- Small helpers for line/comma list fields edited inline. ---
	function splitLines( v ) { return ( v == null ? '' : String( v ) ).split( '\n' ); }
	function joinLines( arr ) { return arr.join( '\n' ); }
	// First numeric amount inside a free-form price string, or null.
	function priceAmount( price ) {
		var m = String( price == null ? '' : price ).match( /[\d][\d.,]*/ );
		if ( ! m ) { return null; }
		var n = parseFloat( m[ 0 ].replace( /,/g, '' ).replace( /\.$/, '' ) );
		return isNaN( n ) ? null : n;
	}
	// Whole-number percent saved from an old price to a new one (0 when N/A).
	function priceSavingPct( was, now ) {
		var o = priceAmount( was ), n = priceAmount( now );
		if ( o == null || n == null || o <= 0 || n >= o ) { return 0; }
		return Math.round( ( ( o - n ) / o ) * 100 );
	}
	function splitComma( v ) { return ( v == null ? '' : String( v ) ).split( ',' ).map( function ( s ) { return s.trim(); } ); }

	function ProcessInline( p ) {
		var props = p.props, a = props.attributes;
		var items = parseArr( a.steps );
		function commit( next ) { props.setAttributes( { steps: JSON.stringify( next ) } ); }
		function setStep( i, key, val ) { commit( items.map( function ( s, idx ) { if ( idx !== i ) { return s; } var ns = { title: s.title, text: s.text }; ns[ key ] = stripTags( val ); return ns; } ) ); }
		var intro = el( 'div', { key: 'intro', className: 'norvex-process__intro' }, [
			attrRT( props, 'eyebrow', 'span', 'norvex-eyebrow', __( 'Eyebrow', 'norvex' ), { color: 'var(--norvex-gold)' } ),
			attrRT( props, 'title', 'h2', null, __( 'Title', 'norvex' ) ),
			attrRT( props, 'lead', 'p', 'norvex-process__lead', __( 'Lead text', 'norvex' ) ),
			inlineBtn( props, 'btn', 'primary', __( 'Button', 'norvex' ) ),
		] );
		var stepEls = items.map( function ( st, i ) {
			return el( 'li', { key: 'p' + i, className: 'norvex-pstep' }, [
				el( 'span', { key: 'num', className: 'norvex-pstep__num' }, ( i + 1 < 10 ? '0' : '' ) + ( i + 1 ) ),
				el( 'div', { key: 'body', className: 'norvex-pstep__body' }, [
					el( RichText, { key: 't', tagName: 'h4', value: st.title || '', allowedFormats: [], placeholder: __( 'Step title', 'norvex' ), onChange: function ( v ) { setStep( i, 'title', v ); } } ),
					el( RichText, { key: 'd', tagName: 'p', value: st.text || '', allowedFormats: [], placeholder: __( 'Step text', 'norvex' ), onChange: function ( v ) { setStep( i, 'text', v ); } } ),
					el( Button, { key: 'rm', variant: 'link', isDestructive: true, style: { fontSize: '12px' }, onClick: function () { commit( items.filter( function ( x, idx ) { return idx !== i; } ) ); } }, __( 'Remove step', 'norvex' ) ),
				] ),
			] );
		} );
		var addBtn = el( 'li', { key: 'add', style: { listStyle: 'none' } }, el( Button, { variant: 'secondary', onClick: function () { commit( items.concat( [ { title: __( 'New step', 'norvex' ), text: '' } ] ) ); } }, __( 'Add step', 'norvex' ) ) );
		var steps = el( 'ol', { key: 'steps', className: 'norvex-process__steps' }, stepEls.concat( [ addBtn ] ) );
		var canvas = el( 'div', useBlockProps( { key: 'canvas' } ), el( 'section', { className: 'norvex-section norvex-section--ink norvex-process' }, el( 'div', { className: 'norvex-wrap norvex-process__grid' }, [ intro, steps ] ) ) );
		return el( Fragment, null, [ sidebar( 'pr', __( 'Button link', 'norvex' ), [ attrUrl( props, 'btnurl', __( 'Button URL', 'norvex' ) ) ] ), canvas ] );
	}

	function ConsultInline( p ) {
		var props = p.props;
		var text = el( 'div', { key: 'txt', className: 'norvex-consult__text' }, [
			attrRT( props, 'eyebrow', 'span', 'norvex-eyebrow', __( 'Eyebrow', 'norvex' ), { color: 'var(--norvex-gold)' } ),
			attrRT( props, 'title', 'h2', null, __( 'Title', 'norvex' ) ),
			attrRT( props, 'text', 'p', null, __( 'Text', 'norvex' ) ),
			el( 'p', { key: 'hrs', className: 'norvex-consult__hours', style: { opacity: 0.7 } }, __( 'Opening hours — set in Customizer', 'norvex' ) ),
		] );
		var actions = el( 'div', { key: 'act', className: 'norvex-consult__actions' }, [ inlineBtn( props, 'btn', 'primary', __( 'Button label', 'norvex' ) ), el( 'span', { key: 'ph', className: 'norvex-btn norvex-btn--light', style: { opacity: 0.7 } }, __( 'Phone — from Customizer', 'norvex' ) ) ] );
		var canvas = el( 'div', useBlockProps( { key: 'canvas' } ), el( 'section', { className: 'norvex-section norvex-section--tight' }, el( 'div', { className: 'norvex-wrap' }, el( 'div', { className: 'norvex-consult' }, [ text, actions ] ) ) ) );
		return el( Fragment, null, [ sidebar( 'co', __( 'Button link', 'norvex' ), [ attrUrl( props, 'btnurl', __( 'Button URL', 'norvex' ) ) ] ), canvas ] );
	}

	function WhyUsInline( p ) {
		var props = p.props;
		var head = el( 'div', { key: 'head', className: 'norvex-whyus__head' }, [
			el( 'div', { key: 'l' }, [ attrRT( props, 'eyebrow', 'span', 'norvex-eyebrow', __( 'Eyebrow', 'norvex' ) ), attrRT( props, 'title', 'h2', null, __( 'Title', 'norvex' ) ) ] ),
			el( 'div', { key: 'r', className: 'norvex-whyus__intro' }, [ attrRT( props, 'lead', 'p', 'norvex-lead', __( 'Lead text', 'norvex' ) ), inlineBtn( props, 'btn', 'primary', __( 'Button', 'norvex' ) ) ] ),
		] );
		var grid = el( 'div', { key: 'grid', className: 'norvex-whyus__grid' }, [ 1, 2, 3, 4 ].map( function ( n ) {
			return el( 'div', { key: 'i' + n, className: 'norvex-whyus__item' }, [ attrRT( props, 'f' + n + 't', 'h4', null, __( 'Point title', 'norvex' ) ), attrRT( props, 'f' + n + 'd', 'p', null, __( 'Point text', 'norvex' ) ) ] );
		} ) );
		var canvas = el( 'div', useBlockProps( { key: 'canvas' } ), el( 'section', { className: 'norvex-section' }, el( 'div', { className: 'norvex-wrap' }, [ head, grid ] ) ) );
		return el( Fragment, null, [ sidebar( 'wu', __( 'Button link', 'norvex' ), [ attrUrl( props, 'btnurl', __( 'Button URL', 'norvex' ) ) ] ), canvas ] );
	}

	function PageHeroInline( p ) {
		var props = p.props;
		var canvas = el( 'div', useBlockProps( { key: 'canvas' } ), el( 'section', { className: 'norvex-page-hero' }, el( 'div', { className: 'norvex-wrap' }, [ attrRT( props, 'title', 'h1', null, __( 'Page title', 'norvex' ) ), attrRT( props, 'lead', 'p', null, __( 'Intro text (optional)', 'norvex' ) ) ] ) ) );
		return el( Fragment, null, [ canvas ] );
	}

	function SectionHeaderInline( p ) {
		var props = p.props, a = props.attributes;
		var center = 'center' === a.align ? ' norvex-center' : '';
		var canvas = el( 'div', useBlockProps( { key: 'canvas' } ), el( 'div', { className: 'norvex-section-head' + center }, [ attrRT( props, 'eyebrow', 'span', 'norvex-eyebrow', __( 'Eyebrow', 'norvex' ) ), attrRT( props, 'title', 'h2', null, __( 'Heading', 'norvex' ) ), attrRT( props, 'lead', 'p', 'norvex-lead', __( 'Lead text (optional)', 'norvex' ) ) ] ) );
		return el( Fragment, null, [ sidebar( 'sh', __( 'Alignment', 'norvex' ), [ el( SelectControl, { key: 'al', label: __( 'Alignment', 'norvex' ), value: a.align || 'center', options: [ { label: __( 'Left', 'norvex' ), value: 'left' }, { label: __( 'Center', 'norvex' ), value: 'center' } ], onChange: function ( v ) { props.setAttributes( { align: v } ); } } ) ] ), canvas ] );
	}

	function AboutStoryInline( p ) {
		var props = p.props, a = props.attributes;
		var items = splitLines( a.list );
		function commitList( next ) { props.setAttributes( { list: joinLines( next ) } ); }
		var listEl = el( 'ul', { key: 'list', className: 'norvex-checklist' }, items.map( function ( it, i ) {
			return el( 'li', { key: 'li' + i }, [
				el( RichText, { key: 't', tagName: 'span', value: it || '', allowedFormats: [], placeholder: __( 'Checklist item', 'norvex' ), onChange: function ( v ) { commitList( items.map( function ( x, idx ) { return idx === i ? stripTags( v ) : x; } ) ); } } ),
				el( Button, { key: 'rm', variant: 'link', isDestructive: true, style: { marginLeft: '6px', minWidth: 0, padding: '0 4px' }, onClick: function () { commitList( items.filter( function ( x, idx ) { return idx !== i; } ) ); } }, '×' ),
			] );
		} ) );
		var addLi = el( Button, { key: 'add', variant: 'link', onClick: function () { commitList( items.concat( [ '' ] ) ); } }, __( '+ Add item', 'norvex' ) );
		var right = el( 'div', { key: 'right' }, [ attrRT( props, 'eyebrow', 'span', 'norvex-eyebrow', __( 'Eyebrow', 'norvex' ) ), attrRT( props, 'title', 'h2', null, __( 'Title', 'norvex' ) ), attrRT( props, 'para1', 'p', null, __( 'Paragraph 1', 'norvex' ) ), attrRT( props, 'para2', 'p', null, __( 'Paragraph 2', 'norvex' ) ), listEl, addLi ] );
		var media = el( 'div', { key: 'media', className: 'norvex-media' }, el( 'img', { src: a.image || '', alt: '', style: a.image ? null : { display: 'block', minHeight: '260px', width: '100%', background: 'rgba(0,0,0,.06)', borderRadius: '12px' } } ) );
		var canvas = el( 'div', useBlockProps( { key: 'canvas' } ), el( 'section', { className: 'norvex-section' }, el( 'div', { className: 'norvex-wrap norvex-split' }, [ media, right ] ) ) );
		return el( Fragment, null, [ sidebar( 'as', __( 'Image', 'norvex' ), [ imageControl( { key: 'image', label: __( 'Image (optional — falls back to featured image)', 'norvex' ) }, props ) ] ), canvas ] );
	}

	function LogosInline( p ) {
		var props = p.props, a = props.attributes;
		var names = splitComma( a.items );
		function commitNames( next ) { props.setAttributes( { items: next.join( ', ' ) } ); }
		var list = el( 'ul', null, names.map( function ( nm, i ) {
			return el( 'li', { key: 'n' + i, style: { display: 'inline-flex', alignItems: 'center' } }, [
				el( RichText, { key: 't', tagName: 'span', value: nm || '', allowedFormats: [], placeholder: __( 'Name', 'norvex' ), onChange: function ( v ) { commitNames( names.map( function ( x, idx ) { return idx === i ? stripTags( v ) : x; } ) ); } } ),
				el( Button, { key: 'rm', variant: 'link', isDestructive: true, style: { minWidth: 0, padding: '0 4px' }, onClick: function () { commitNames( names.filter( function ( x, idx ) { return idx !== i; } ) ); } }, '×' ),
			] );
		} ).concat( [ el( 'li', { key: 'add' }, el( Button, { variant: 'link', onClick: function () { commitNames( names.concat( [ '' ] ) ); } }, __( '+ Add', 'norvex' ) ) ) ] ) );
		var canvas = el( 'div', useBlockProps( { key: 'canvas' } ), el( 'div', { className: 'norvex-logos' }, el( 'div', { className: 'norvex-wrap' }, [ attrRT( props, 'label', 'p', null, __( 'Label', 'norvex' ) ), list ] ) ) );
		return el( Fragment, null, [ canvas ] );
	}

	function ChecklistInline( p ) {
		var props = p.props, a = props.attributes;
		var lines = splitLines( a.items ).map( function ( l ) { var ex = '!' === l.charAt( 0 ); return { label: ex ? l.slice( 1 ) : l, inc: ! ex }; } );
		function commit( next ) { props.setAttributes( { items: joinLines( next.map( function ( x ) { return ( x.inc ? '' : '!' ) + x.label; } ) ) } ); }
		function setItem( i, patch ) { commit( lines.map( function ( x, idx ) { if ( idx !== i ) { return x; } return { label: 'label' in patch ? patch.label : x.label, inc: 'inc' in patch ? patch.inc : x.inc }; } ) ); }
		var cols = '2' === String( a.cols ) ? ' norvex-checks--2col' : '';
		var listEl = el( 'ul', { className: 'norvex-checks' + cols }, lines.map( function ( it, i ) {
			return el( 'li', { key: 'li' + i, className: 'norvex-checks__item' + ( it.inc ? '' : ' is-excluded' ) }, [
				el( 'button', { key: 'ic', type: 'button', className: 'norvex-checks__icon', title: __( 'Toggle include / exclude', 'norvex' ), onClick: function () { setItem( i, { inc: ! it.inc } ); }, style: { cursor: 'pointer', border: 0, background: 'none', font: 'inherit' }, dangerouslySetInnerHTML: { __html: it.inc ? '&#10003;' : '&#10007;' } } ),
				el( RichText, { key: 't', tagName: 'span', value: it.label || '', allowedFormats: [], placeholder: __( 'List item', 'norvex' ), onChange: function ( v ) { setItem( i, { label: stripTags( v ) } ); } } ),
				el( Button, { key: 'rm', variant: 'link', isDestructive: true, style: { minWidth: 0, padding: '0 4px' }, onClick: function () { commit( lines.filter( function ( x, idx ) { return idx !== i; } ) ); } }, '×' ),
			] );
		} ) );
		var addBtn = el( 'div', { key: 'add', style: { marginTop: '8px' } }, el( Button, { variant: 'secondary', onClick: function () { commit( lines.concat( [ { label: __( 'New item', 'norvex' ), inc: true } ] ) ); } }, __( 'Add item', 'norvex' ) ) );
		var canvas = el( 'div', useBlockProps( { key: 'canvas' } ), el( 'div', null, [ listEl, addBtn ] ) );
		return el( Fragment, null, [ sidebar( 'ch', __( 'Layout', 'norvex' ), [ el( SelectControl, { key: 'cols', label: __( 'Columns', 'norvex' ), value: String( a.cols || '1' ), options: [ { label: __( '1 column', 'norvex' ), value: '1' }, { label: __( '2 columns', 'norvex' ), value: '2' } ], onChange: function ( v ) { props.setAttributes( { cols: v } ); } } ) ] ), canvas ] );
	}

	// Generic sidebar + ServerSideRender editor (used by every non-inline block,
	// and by the data blocks below while they are in "From dashboard" mode).
	function GenericEdit( block, props ) {
		var contentControls = [];
		block.fields.forEach( function ( f ) {
			if ( 'hidden' === f.type ) { return; }
			if ( f.showif && props.attributes[ f.showif[ 0 ] ] !== f.showif[ 1 ] ) { return; }
			// Per-line colour pickers live in a shared panel added at registration
			// (headerColorPanel) so inline-edited blocks get them too.
			if ( f.type === 'color' ) { return; }
			var ctrl;
			if ( f.type === 'image' ) { ctrl = imageControl( f, props ); }
			else if ( f.type === 'pairs' ) { ctrl = el( PairsControl, { field: f, props: props, key: f.key } ); }
			else if ( f.type === 'lines' ) { ctrl = el( LinesControl, { field: f, props: props, key: f.key } ); }
			else if ( f.type === 'rows' ) { ctrl = el( RowsControl, { field: f, props: props, key: f.key } ); }
			else if ( f.type === 'cards' ) { ctrl = el( CardsControl, { field: f, props: props, key: f.key } ); }
			else if ( f.type === 'table' ) { ctrl = el( TableControl, { field: f, props: props, key: f.key } ); }
			else if ( f.type === 'tabs' ) { ctrl = el( TabsControl, { field: f, props: props, key: f.key } ); }
			else if ( f.type === 'url' ) { ctrl = urlSearch( f.key, f.label, props.attributes[ f.key ], function ( v ) { var n = {}; n[ f.key ] = v; props.setAttributes( n ); } ); }
			else {
				var common = { key: f.key, label: f.label, value: props.attributes[ f.key ], onChange: function ( value ) { var next = {}; next[ f.key ] = f.type === 'number' ? parseInt( value, 10 ) || 0 : value; props.setAttributes( next ); } };
				if ( f.type === 'select' ) { common.options = Object.keys( f.options || {} ).map( function ( k ) { return { label: f.options[ k ], value: k }; } ); ctrl = el( SelectControl, common ); }
				else if ( f.type === 'textarea' ) { ctrl = el( TextareaControl, common ); }
				else { if ( f.type === 'number' ) { common.type = 'number'; } ctrl = el( TextControl, common ); }
			}
			contentControls.push( ctrl );
		} );
		var children = [ el( 'div', useBlockProps( { key: 'preview' } ), el( ServerSideRender, { block: block.name, attributes: props.attributes } ) ) ];
		if ( contentControls.length ) {
			children.unshift( el( InspectorControls, { key: 'inspector' }, el( PanelBody, { title: __( 'Content', 'norvex' ), initialOpen: true }, contentControls ) ) );
		}
		return el( Fragment, null, children );
	}

	// Shared "Header line colours" panel (eyebrow / heading / lead). Added to
	// every block that has colour fields — including the inline-edited ones —
	// via a second InspectorControls, which WordPress merges into the sidebar.
	function headerColorPanel( block, props ) {
		var colorFields = ( block.fields || [] ).filter( function ( f ) { return f.type === 'color'; } );
		if ( ! colorFields.length ) { return null; }
		return el(
			InspectorControls,
			{ key: 'nx-header-colors' },
			el(
				PanelBody,
				{ title: __( 'Header line colours', 'norvex' ), initialOpen: false },
				colorFields.map( function ( f ) { return colorControl( f, props ); } )
			)
		);
	}

	// --- Data blocks with a "From dashboard" / "Custom (type here)" toggle. ---
	function parseArr( v ) { try { var a = JSON.parse( v || '[]' ); return Array.isArray( a ) ? a : []; } catch ( e ) { return []; } }
	function starsEdit( rating, onSet ) {
		var out = [];
		for ( var s = 1; s <= 5; s++ ) { ( function ( s ) { out.push( el( 'span', { key: s, onClick: function ( e ) { e.stopPropagation(); onSet( s ); }, style: { cursor: 'pointer' } }, s <= rating ? '★' : '☆' ) ); } )( s ); }
		return el( 'div', { className: 'norvex-quote__stars' }, out );
	}

	function TestimonialsInline( p ) {
		var props = p.props, a = props.attributes;
		var items = parseArr( a.custom );
		var selState = wp.element.useState( 0 );
		var sel = selState[ 0 ], setSel = selState[ 1 ];
		function commit( next ) { props.setAttributes( { custom: JSON.stringify( next ) } ); }
		function setItem( i, key, val ) { commit( items.map( function ( t, idx ) { if ( idx !== i ) { return t; } var nt = {}; for ( var k in t ) { nt[ k ] = t[ k ]; } nt[ key ] = val; return nt; } ) ); }
		var head = el( 'div', { key: 'head', className: 'norvex-section-head norvex-center' }, [ attrRT( props, 'eyebrow', 'span', 'norvex-eyebrow', __( 'Eyebrow', 'norvex' ) ), attrRT( props, 'title', 'h2', null, __( 'Title', 'norvex' ) ) ] );
		var quotes = items.map( function ( t, i ) {
			return el( 'figure', { key: 'q' + i, className: 'norvex-quote norvex-lift' + ( i === sel ? ' norvex-card--selected' : '' ), onClick: function () { setSel( i ); } }, [
				starsEdit( parseInt( t.rating, 10 ) || 5, function ( r ) { setItem( i, 'rating', r ); } ),
				el( 'blockquote', { key: 'bq', style: { border: 0, background: 'none', padding: 0, margin: 0, fontSize: '1.12rem' } }, el( RichText, { tagName: 'p', style: { margin: 0 }, value: t.quote || '', allowedFormats: [], placeholder: __( 'Testimonial quote…', 'norvex' ), onChange: function ( v ) { setItem( i, 'quote', stripTags( v ) ); } } ) ),
				el( 'figcaption', { key: 'by', className: 'norvex-quote__by' }, [
					t.photo ? el( 'img', { key: 'img', src: t.photo, alt: '' } ) : el( 'span', { key: 'ph', style: { width: '48px', height: '48px', borderRadius: '50%', background: 'rgba(0,0,0,.08)', display: 'inline-block', flex: '0 0 auto' } } ),
					el( 'span', { key: 'nm' }, [ el( RichText, { key: 'n', tagName: 'strong', value: t.name || '', allowedFormats: [], placeholder: __( 'Name', 'norvex' ), onChange: function ( v ) { setItem( i, 'name', stripTags( v ) ); } } ), el( RichText, { key: 'r', tagName: 'span', value: t.role || '', allowedFormats: [], placeholder: __( 'Role', 'norvex' ), onChange: function ( v ) { setItem( i, 'role', stripTags( v ) ); } } ) ] ),
				] ),
			] );
		} );
		var addBtn = el( 'div', { key: 'add', style: { textAlign: 'center', marginTop: '14px', width: '100%' } }, el( Button, { variant: 'primary', onClick: function () { commit( items.concat( [ { quote: '', name: __( 'New author', 'norvex' ), role: '', rating: 5, photo: '' } ] ) ); setSel( items.length ); } }, __( 'Add testimonial', 'norvex' ) ) );
		var canvas = el( 'div', useBlockProps( { key: 'canvas' } ), el( 'section', { className: 'norvex-section norvex-section--sand' }, el( 'div', { className: 'norvex-wrap' }, [ head, el( 'div', { key: 'grid', className: 'norvex-quotes' }, quotes ), addBtn ] ) ) );
		var selItem = items[ sel ] || null;
		var panel = [ el( 'p', { key: 'intro', style: { margin: '0 0 8px', fontSize: '12px', color: '#646970' } }, __( 'Testimonials are typed on the block. Click one to set its photo or remove it.', 'norvex' ) ) ];
		if ( selItem ) {
			panel.push( el( 'p', { key: 'h', style: { margin: '10px 0 4px', fontSize: '12px', color: '#646970' } }, __( 'Editing the testimonial you clicked. Quote, name and role are typed on the card; click the stars to set the rating.', 'norvex' ) ) );
			panel.push( el( 'p', { key: 'pl', style: { margin: '0 0 4px', fontWeight: 600, fontSize: '12px' } }, __( 'Photo (optional)', 'norvex' ) ) );
			if ( selItem.photo ) { panel.push( el( 'img', { key: 'pi', src: selItem.photo, alt: '', style: { width: '64px', height: '64px', borderRadius: '50%', objectFit: 'cover', marginBottom: '6px', display: 'block' } } ) ); }
			panel.push( el( MediaUploadCheck, { key: 'pu' }, el( MediaUpload, { onSelect: function ( m ) { setItem( sel, 'photo', m && m.url ? m.url : '' ); }, allowedTypes: [ 'image' ], render: function ( o ) { return el( Button, { variant: 'secondary', onClick: o.open }, selItem.photo ? __( 'Replace photo', 'norvex' ) : __( 'Select photo', 'norvex' ) ); } } ) ) );
			if ( selItem.photo ) { panel.push( el( Button, { key: 'pr', variant: 'link', isDestructive: true, style: { marginLeft: '8px' }, onClick: function () { setItem( sel, 'photo', '' ); } }, __( 'Remove photo', 'norvex' ) ) ); }
			panel.push( el( Button, { key: 'rm', variant: 'link', isDestructive: true, onClick: function () { commit( items.filter( function ( x, idx ) { return idx !== sel; } ) ); setSel( 0 ); } }, __( 'Remove this testimonial', 'norvex' ) ) );
		}
		return el( Fragment, null, [ sidebar( 'ti', __( 'Testimonials', 'norvex' ), panel ), canvas ] );
	}

	function PricingInline( p ) {
		var props = p.props, a = props.attributes;
		var plans = parseArr( a.custom );
		var selState = wp.element.useState( 0 );
		var sel = selState[ 0 ], setSel = selState[ 1 ];
		function commit( next ) { props.setAttributes( { custom: JSON.stringify( next ) } ); }
		function setPlan( i, key, val ) { commit( plans.map( function ( pl, idx ) { if ( idx !== i ) { return pl; } var np = {}; for ( var k in pl ) { np[ k ] = pl[ k ]; } np[ key ] = val; return np; } ) ); }
		var head = el( 'div', { key: 'head', className: 'norvex-section-head norvex-center' }, [ attrRT( props, 'eyebrow', 'span', 'norvex-eyebrow', __( 'Eyebrow (optional)', 'norvex' ) ), attrRT( props, 'heading', 'h2', null, __( 'Heading (optional)', 'norvex' ) ), attrRT( props, 'lead', 'p', 'norvex-lead', __( 'Lead text (optional)', 'norvex' ) ) ] );
		var btnLabel = a.btn || __( 'Get a custom quote', 'norvex' );
		var cards = plans.map( function ( pl, i ) {
			var feats = splitLines( pl.features ).map( function ( l ) { var ex = '!' === l.charAt( 0 ); return { label: ex ? l.slice( 1 ) : l, inc: ! ex }; } );
			function commitFeats( next ) { setPlan( i, 'features', joinLines( next.map( function ( x ) { return ( x.inc ? '' : '!' ) + x.label; } ) ) ); }
			var featEls = feats.map( function ( ft, fi ) {
				return el( 'li', { key: 'f' + fi, className: ft.inc ? '' : 'norvex-off', style: { display: 'flex', alignItems: 'center', gap: '6px' } }, [
					el( 'button', { key: 't', type: 'button', title: __( 'Include / exclude', 'norvex' ), onClick: function ( e ) { e.stopPropagation(); commitFeats( feats.map( function ( x, idx ) { return idx === fi ? { label: x.label, inc: ! x.inc } : x; } ) ); }, style: { cursor: 'pointer', border: 0, background: 'none', padding: 0, color: 'inherit', font: 'inherit' }, dangerouslySetInnerHTML: { __html: ft.inc ? '&#10003;' : '&#10007;' } } ),
					el( RichText, { key: 'l', tagName: 'span', value: ft.label || '', allowedFormats: [], placeholder: __( 'Feature', 'norvex' ), onChange: function ( v ) { commitFeats( feats.map( function ( x, idx ) { return idx === fi ? { label: stripTags( v ), inc: x.inc } : x; } ) ); } } ),
					el( 'button', { key: 'x', type: 'button', onClick: function ( e ) { e.stopPropagation(); commitFeats( feats.filter( function ( x, idx ) { return idx !== fi; } ) ); }, style: { cursor: 'pointer', border: 0, background: 'none', color: '#b32d2e', marginLeft: 'auto' } }, '×' ),
				] );
			} );
			featEls.push( el( 'li', { key: 'add', style: { listStyle: 'none' } }, el( Button, { variant: 'link', onClick: function ( e ) { e.stopPropagation(); commitFeats( feats.concat( [ { label: '', inc: true } ] ) ); } }, __( '+ Add feature', 'norvex' ) ) ) );
			var save = priceSavingPct( pl.was, pl.price );
			return el( 'div', { key: 'p' + i, className: 'norvex-plan norvex-lift' + ( pl.featured ? ' norvex-plan--featured' : '' ) + ( i === sel ? ' norvex-card--selected' : '' ), onClick: function () { setSel( i ); } }, [
				pl.featured ? el( 'span', { key: 'flag', className: 'norvex-plan__flag' }, __( 'Most popular', 'norvex' ) ) : null,
				el( RichText, { key: 'nm', tagName: 'h3', value: pl.name || '', allowedFormats: [], placeholder: __( 'Plan name', 'norvex' ), onChange: function ( v ) { setPlan( i, 'name', stripTags( v ) ); } } ),
				el( 'div', { key: 'pr', className: 'norvex-plan__price' }, [
					el( RichText, { key: 'price', tagName: 'span', className: 'norvex-plan__amount', value: pl.price || '', allowedFormats: [], placeholder: __( 'Price', 'norvex' ), onChange: function ( v ) { setPlan( i, 'price', stripTags( v ) ); } } ),
					el( RichText, { key: 'per', tagName: 'span', className: 'norvex-plan__per', value: pl.per || '', allowedFormats: [], placeholder: __( '/period', 'norvex' ), onChange: function ( v ) { setPlan( i, 'per', stripTags( v ) ); } } ),
				] ),
				save > 0 ? el( 'div', { key: 'cmp', className: 'norvex-plan__compare' }, [
					el( 'span', { key: 'was', className: 'norvex-plan__was' }, pl.was ),
					el( 'span', { key: 'save', className: 'norvex-plan__save' }, sprintf( __( 'Save %d%%', 'norvex' ), save ) ),
				] ) : null,
				el( RichText, { key: 'desc', tagName: 'p', className: 'norvex-plan__desc', value: pl.desc || '', allowedFormats: [], placeholder: __( 'Short description', 'norvex' ), onChange: function ( v ) { setPlan( i, 'desc', stripTags( v ) ); } } ),
				el( 'ul', { key: 'feats' }, featEls ),
				el( RichText, { key: 'btn', tagName: 'span', className: 'norvex-btn ' + ( pl.featured ? 'norvex-btn--primary' : 'norvex-btn--ghost' ), value: pl.btn || '', allowedFormats: [], placeholder: btnLabel, onChange: function ( v ) { setPlan( i, 'btn', stripTags( v ) ); } } ),
			] );
		} );
		var addBtn = el( 'div', { key: 'add', style: { textAlign: 'center', marginTop: '14px', width: '100%' } }, el( Button, { variant: 'primary', onClick: function () { commit( plans.concat( [ { name: __( 'New plan', 'norvex' ), price: '', was: '', per: '', desc: '', featured: false, btn: '', btnurl: '', features: '' } ] ) ); setSel( plans.length ); } }, __( 'Add plan', 'norvex' ) ) );
		var note = el( 'p', { key: 'note', className: 'norvex-center', style: { marginTop: '34px', color: 'var(--norvex-muted)' } }, el( RichText, { tagName: 'span', value: a.note || '', allowedFormats: [], placeholder: __( 'Note below the plans (optional)', 'norvex' ), onChange: function ( v ) { props.setAttributes( { note: stripTags( v ) } ); } } ) );
		var canvas = el( 'div', useBlockProps( { key: 'canvas' } ), el( 'section', { className: 'norvex-section' }, el( 'div', { className: 'norvex-wrap' }, [ head, el( 'div', { key: 'grid', className: 'norvex-pricing' }, cards ), addBtn, note ] ) ) );
		var selPlan = plans[ sel ] || null;
		var planName = ( selPlan && selPlan.name && '' !== selPlan.name.trim() ) ? selPlan.name : __( 'this plan', 'norvex' );
		var panel = [ el( 'p', { key: 'intro', style: { margin: '0 0 10px', fontSize: '12px', color: '#646970' } }, __( 'Click a plan in the preview to edit it. Name, price, features and the button are all per-card — you can even type the button label straight onto the button on the card.', 'norvex' ) ) ];
		if ( selPlan ) {
			panel.push( el( 'p', { key: 'h', style: { margin: '4px 0 6px', fontSize: '13px', fontWeight: 600, color: '#1e1e1e' } }, sprintf( __( 'Editing: %s', 'norvex' ), planName ) ) );
			panel.push( el( TextControl, { key: 'wasf', label: __( 'Old price (was, optional)', 'norvex' ), help: __( 'Enter a price higher than the current one to show it struck through with an auto “Save X%” badge.', 'norvex' ), value: selPlan.was || '', onChange: function ( v ) { setPlan( sel, 'was', v ); } } ) );
			panel.push( el( TextControl, { key: 'nowf', label: __( 'Price', 'norvex' ), value: selPlan.price || '', onChange: function ( v ) { setPlan( sel, 'price', v ); } } ) );
			panel.push( el( TextControl, { key: 'perf', label: __( 'Period (optional, e.g. /year)', 'norvex' ), value: selPlan.per || '', onChange: function ( v ) { setPlan( sel, 'per', v ); } } ) );
			panel.push( el( ToggleControl, { key: 'ft', label: __( 'Highlight as “Most popular”', 'norvex' ), checked: !! selPlan.featured, onChange: function ( on ) { setPlan( sel, 'featured', on ); } } ) );
			panel.push( el( 'p', { key: 'bh', style: { margin: '16px 0 2px', fontSize: '12px', fontWeight: 600, color: '#1e1e1e' } }, __( 'Button for this plan', 'norvex' ) ) );
			panel.push( el( 'p', { key: 'bhint', style: { margin: '0 0 8px', fontSize: '12px', color: '#646970' } }, __( 'Sets only this card’s button. Leave the label blank to fall back to the default below.', 'norvex' ) ) );
			panel.push( el( TextControl, { key: 'pbtn', label: __( 'Button label', 'norvex' ), placeholder: a.btn || __( 'Get a custom quote', 'norvex' ), value: selPlan.btn || '', onChange: function ( v ) { setPlan( sel, 'btn', v ); } } ) );
			panel.push( urlSearch( 'pbtnurl', __( 'Button URL', 'norvex' ), selPlan.btnurl || '', function ( u ) { setPlan( sel, 'btnurl', u ); } ) );
			panel.push( el( Button, { key: 'rm', variant: 'link', isDestructive: true, style: { marginTop: '4px' }, onClick: function () { commit( plans.filter( function ( x, idx ) { return idx !== sel; } ) ); setSel( 0 ); } }, __( 'Remove this plan', 'norvex' ) ) );
		}
		panel.push( el( 'p', { key: 'dh', style: { margin: '20px 0 2px', paddingTop: '14px', borderTop: '1px solid #e0e0e0', fontSize: '12px', fontWeight: 600, color: '#1e1e1e' } }, __( 'Default button', 'norvex' ) ) );
		panel.push( el( 'p', { key: 'dhint', style: { margin: '0 0 8px', fontSize: '12px', color: '#646970' } }, __( 'Used only for plans whose own button label/URL are left blank.', 'norvex' ) ) );
		panel.push( attrField( props, 'btn', __( 'Default button label', 'norvex' ) ) );
		panel.push( attrUrl( props, 'btnurl', __( 'Default button URL', 'norvex' ) ) );
		return el( Fragment, null, [ sidebar( 'pi', __( 'Pricing', 'norvex' ), panel ), canvas ] );
	}

	function TeamInline( p ) {
		var props = p.props, a = props.attributes;
		var items = parseArr( a.custom );
		var selState = wp.element.useState( 0 );
		var sel = selState[ 0 ], setSel = selState[ 1 ];
		function commit( next ) { props.setAttributes( { custom: JSON.stringify( next ) } ); }
		function setItem( i, key, val ) { commit( items.map( function ( m, idx ) { if ( idx !== i ) { return m; } var nm = {}; for ( var k in m ) { nm[ k ] = m[ k ]; } nm[ key ] = val; return nm; } ) ); }
		var head = el( 'div', { key: 'head', className: 'norvex-section-head norvex-center' }, [ attrRT( props, 'eyebrow', 'span', 'norvex-eyebrow', __( 'Eyebrow', 'norvex' ) ), attrRT( props, 'title', 'h2', null, __( 'Title', 'norvex' ) ) ] );
		var members = items.map( function ( m, i ) {
			return el( 'div', { key: 'm' + i, className: 'norvex-member norvex-lift' + ( i === sel ? ' norvex-card--selected' : '' ), onClick: function () { setSel( i ); } }, [
				el( 'div', { key: 'ph', className: 'norvex-member__photo' }, m.photo ? el( 'img', { src: m.photo, alt: '' } ) : el( 'div', { style: { aspectRatio: '1 / 1', background: 'rgba(0,0,0,.06)' } } ) ),
				el( RichText, { key: 'n', tagName: 'h4', value: m.name || '', allowedFormats: [], placeholder: __( 'Name', 'norvex' ), onChange: function ( v ) { setItem( i, 'name', stripTags( v ) ); } } ),
				el( RichText, { key: 'r', tagName: 'span', value: m.role || '', allowedFormats: [], placeholder: __( 'Role', 'norvex' ), onChange: function ( v ) { setItem( i, 'role', stripTags( v ) ); } } ),
			] );
		} );
		var addBtn = el( 'div', { key: 'add', style: { textAlign: 'center', marginTop: '14px', width: '100%' } }, el( Button, { variant: 'primary', onClick: function () { commit( items.concat( [ { name: __( 'New member', 'norvex' ), role: '', photo: '' } ] ) ); setSel( items.length ); } }, __( 'Add member', 'norvex' ) ) );
		var canvas = el( 'div', useBlockProps( { key: 'canvas' } ), el( 'section', { className: 'norvex-section norvex-section--sand' }, el( 'div', { className: 'norvex-wrap' }, [ head, el( 'div', { key: 'grid', className: 'norvex-team' }, members ), addBtn ] ) ) );
		var selItem = items[ sel ] || null;
		var panel = [ el( 'p', { key: 'intro', style: { margin: '0 0 8px', fontSize: '12px', color: '#646970' } }, __( 'Members are typed on the block. Click one to set its photo.', 'norvex' ) ) ];
		if ( selItem ) {
			panel.push( el( 'p', { key: 'pl', style: { margin: '0 0 4px', fontWeight: 600, fontSize: '12px' } }, __( 'Photo', 'norvex' ) ) );
			if ( selItem.photo ) { panel.push( el( 'img', { key: 'pi', src: selItem.photo, alt: '', style: { width: '72px', height: '72px', borderRadius: '8px', objectFit: 'cover', marginBottom: '6px', display: 'block' } } ) ); }
			panel.push( el( MediaUploadCheck, { key: 'pu' }, el( MediaUpload, { onSelect: function ( mm ) { setItem( sel, 'photo', mm && mm.url ? mm.url : '' ); }, allowedTypes: [ 'image' ], render: function ( o ) { return el( Button, { variant: 'secondary', onClick: o.open }, selItem.photo ? __( 'Replace photo', 'norvex' ) : __( 'Select photo', 'norvex' ) ); } } ) ) );
			panel.push( el( Button, { key: 'rm', variant: 'link', isDestructive: true, onClick: function () { commit( items.filter( function ( x, idx ) { return idx !== sel; } ) ); setSel( 0 ); } }, __( 'Remove this member', 'norvex' ) ) );
		}
		return el( Fragment, null, [ sidebar( 'tm', __( 'Team', 'norvex' ), panel ), canvas ] );
	}

	function BooksInline( p ) {
		var props = p.props, a = props.attributes;
		var items = parseArr( a.custom );
		var selState = wp.element.useState( 0 );
		var sel = selState[ 0 ], setSel = selState[ 1 ];
		function commit( next ) { props.setAttributes( { custom: JSON.stringify( next ) } ); }
		function setItem( i, key, val ) { commit( items.map( function ( b, idx ) { if ( idx !== i ) { return b; } var nb = {}; for ( var k in b ) { nb[ k ] = b[ k ]; } nb[ key ] = val; return nb; } ) ); }
		var head = el( 'div', { key: 'head', className: 'norvex-section-head norvex-center' }, [ attrRT( props, 'eyebrow', 'span', 'norvex-eyebrow', __( 'Eyebrow', 'norvex' ) ), attrRT( props, 'title', 'h2', null, __( 'Title', 'norvex' ) ) ] );
		var books = items.map( function ( b, i ) {
			return el( 'article', { key: 'b' + i, className: 'norvex-book norvex-lift' + ( i === sel ? ' norvex-card--selected' : '' ), onClick: function () { setSel( i ); } }, [
				el( 'div', { key: 'cover', className: 'norvex-book__cover' }, [ b.tag ? el( 'span', { key: 'tag', className: 'norvex-book__tag' }, b.tag ) : null, el( 'img', { key: 'img', src: b.cover || '', alt: '' } ) ] ),
				el( RichText, { key: 't', tagName: 'h3', value: b.title || '', allowedFormats: [], placeholder: __( 'Book title', 'norvex' ), onChange: function ( v ) { setItem( i, 'title', stripTags( v ) ); } } ),
				el( RichText, { key: 'au', tagName: 'p', className: 'norvex-book__author', value: b.author || '', allowedFormats: [], placeholder: __( 'Author', 'norvex' ), onChange: function ( v ) { setItem( i, 'author', stripTags( v ) ); } } ),
			] );
		} );
		var addBtn = el( 'div', { key: 'add', style: { textAlign: 'center', marginTop: '14px', width: '100%' } }, el( Button, { variant: 'primary', onClick: function () { commit( items.concat( [ { cover: '', title: __( 'New book', 'norvex' ), author: '', url: '', tag: '' } ] ) ); setSel( items.length ); } }, __( 'Add book', 'norvex' ) ) );
		var canvas = el( 'div', useBlockProps( { key: 'canvas' } ), el( 'section', { className: 'norvex-section' }, el( 'div', { className: 'norvex-wrap' }, [ head, el( 'div', { key: 'grid', className: 'norvex-books' }, books ), addBtn ] ) ) );
		var selItem = items[ sel ] || null;
		var panel = [ el( SelectControl, { key: 'disp', label: __( 'Display', 'norvex' ), value: a.carousel, options: [ { label: __( 'Grid', 'norvex' ), value: 'grid' }, { label: __( 'Carousel / slider', 'norvex' ), value: '1' } ], onChange: function ( v ) { props.setAttributes( { carousel: v } ); } } ) ];
		if ( selItem ) {
			panel.push( el( 'p', { key: 'pl', style: { margin: '10px 0 4px', fontWeight: 600, fontSize: '12px' } }, __( 'Cover image', 'norvex' ) ) );
			if ( selItem.cover ) { panel.push( el( 'img', { key: 'pi', src: selItem.cover, alt: '', style: { width: '80px', borderRadius: '4px', marginBottom: '6px', display: 'block' } } ) ); }
			panel.push( el( MediaUploadCheck, { key: 'pu' }, el( MediaUpload, { onSelect: function ( mm ) { setItem( sel, 'cover', mm && mm.url ? mm.url : '' ); }, allowedTypes: [ 'image' ], render: function ( o ) { return el( Button, { variant: 'secondary', onClick: o.open }, selItem.cover ? __( 'Replace cover', 'norvex' ) : __( 'Select cover', 'norvex' ) ); } } ) ) );
			panel.push( el( TextControl, { key: 'tag', label: __( 'Tag (optional, e.g. genre)', 'norvex' ), value: selItem.tag || '', onChange: function ( v ) { setItem( sel, 'tag', v ); } } ) );
			panel.push( el( TextControl, { key: 'u', label: __( 'Link URL (optional)', 'norvex' ), value: selItem.url || '', onChange: function ( v ) { setItem( sel, 'url', v ); } } ) );
			panel.push( el( Button, { key: 'rm', variant: 'link', isDestructive: true, onClick: function () { commit( items.filter( function ( x, idx ) { return idx !== sel; } ) ); setSel( 0 ); } }, __( 'Remove this book', 'norvex' ) ) );
		}
		return el( Fragment, null, [ sidebar( 'bk', __( 'Featured books', 'norvex' ), panel ), canvas ] );
	}

	/* ---------------------------------------------------------------------
	   Inline editors for the split / list / grid section blocks. Text is
	   typed directly on the block; URLs, selects, icons and images sit in
	   the sidebar (same convention as the Pricing / Cards blocks).
	   --------------------------------------------------------------------- */
	function awRows( v ) { return String( v == null ? '' : v ).split( /\r\n|\r|\n/ ).filter( function ( l ) { return '' !== l.trim(); } ).map( function ( l ) { return l.split( '|' ).map( function ( s ) { return s.trim(); } ); } ); }
	function awRowsJoin( rows ) { return rows.map( function ( r ) { var p = r.map( function ( x ) { return ( x == null ? '' : String( x ) ).trim(); } ); while ( p.length > 1 && '' === p[ p.length - 1 ] ) { p.pop(); } return p.join( ' | ' ); } ).join( '\n' ); }
	function awPairs( v ) { return String( v == null ? '' : v ).split( /\r\n|\r|\n/ ).filter( function ( l ) { return '' !== l.trim(); } ).map( function ( l ) { var i = l.indexOf( '::' ); return i === -1 ? [ l.trim(), '' ] : [ l.slice( 0, i ).trim(), l.slice( i + 2 ).trim() ]; } ); }
	function awPairsJoin( rows ) { return rows.map( function ( r ) { return ( '' + ( r[ 0 ] || '' ) ).trim() + ' :: ' + ( '' + ( r[ 1 ] || '' ) ).trim(); } ).join( '\n' ); }
	function awSetCell( rows, i, ci, val ) { return rows.map( function ( r, idx ) { if ( idx !== i ) { return r; } var nr = r.slice(); while ( nr.length <= ci ) { nr.push( '' ); } nr[ ci ] = val; return nr; } ); }
	function awCell( k, val, ph, cb, tag, cls ) { return el( RichText, { key: k, tagName: tag || 'span', className: cls, value: val || '', allowedFormats: [], placeholder: ph, onChange: function ( v ) { cb( stripTags( v ) ); } } ); }
	function awX( cb ) { return el( 'button', { key: 'rm', type: 'button', title: __( 'Remove', 'norvex' ), onClick: function ( e ) { e.stopPropagation(); cb(); }, style: { cursor: 'pointer', border: 0, background: 'none', color: '#b32d2e', fontSize: '18px', lineHeight: 1, padding: '0 4px', marginLeft: 'auto', alignSelf: 'flex-start' } }, '×' ) ; }
	function awAccentHead( props, hkey, akey, hph, aph ) {
		return el( 'h2', { key: 'ah', className: 'norvex-accent-heading' }, [
			awCell( 'hd', props.attributes[ hkey ], hph, function ( v ) { var n = {}; n[ hkey ] = v; props.setAttributes( n ); }, 'span' ),
			el( RichText, { key: 'ac', tagName: 'span', className: 'norvex-accent-word', style: { marginLeft: '.3em' }, value: props.attributes[ akey ] || '', allowedFormats: [], placeholder: aph, onChange: function ( v ) { var n = {}; n[ akey ] = stripTags( v ); props.setAttributes( n ); } } ),
		] );
	}
	function awNum( i ) { return ( i + 1 < 10 ? '0' : '' ) + ( i + 1 ); }
	// Render a built-in icon's SVG (from the block's icon library) in the editor.
	function awIcon( groups, key ) {
		key = key || '';
		if ( key && '<' !== String( key ).charAt( 0 ) ) {
			var svg = '';
			( groups || [] ).forEach( function ( g ) { g.icons.forEach( function ( ic ) { if ( ic.value === key ) { svg = ic.svg; } } ); } );
			if ( svg ) { return el( 'span', { style: { display: 'inline-flex' }, dangerouslySetInnerHTML: { __html: svg } } ); }
			return el( 'span', { style: { fontWeight: 700 } }, key );
		}
		return el( 'span', { style: { opacity: .5 } }, '★' );
	}

	function FeatureSplitInline( p ) {
		var props = p.props, block = p.block, a = props.attributes;
		var iconField = ( block.fields || [] ).filter( function ( f ) { return 'cards' === f.key; } )[ 0 ];
		var groups = iconField && iconField.options ? ( iconField.options.iconlist || [] ) : [];
		var cards = parseArr( a.cards );
		var selState = wp.element.useState( 0 ); var sel = selState[ 0 ], setSel = selState[ 1 ];
		function commit( next ) { props.setAttributes( { cards: JSON.stringify( next ) } ); }
		function setCard( i, key, val ) { commit( cards.map( function ( c, idx ) { if ( idx !== i ) { return c; } var nc = {}; for ( var k in c ) { nc[ k ] = c[ k ]; } nc[ key ] = val; return nc; } ) ); }
		var grid = el( 'div', { key: 'grid', className: 'norvex-featuresplit__grid' }, cards.map( function ( c, i ) {
			return el( 'div', { key: 'c' + i, className: 'norvex-fcard norvex-lift' + ( i === sel ? ' norvex-card--selected' : '' ), onClick: function () { setSel( i ); } }, [
				el( 'span', { key: 'ic', className: 'norvex-fcard__icon' }, awIcon( groups, c.icon ) ),
				awCell( 't', c.title, __( 'Title', 'norvex' ), function ( v ) { setCard( i, 'title', v ); }, 'h3' ),
				awCell( 'd', c.text, __( 'Text', 'norvex' ), function ( v ) { setCard( i, 'text', v ); }, 'p' ),
				awX( function () { commit( cards.filter( function ( x, idx ) { return idx !== i; } ) ); setSel( 0 ); } ),
			] );
		} ).concat( [ el( 'div', { key: 'add', style: { alignSelf: 'center' } }, el( Button, { variant: 'secondary', onClick: function () { commit( cards.concat( [ { icon: 'star', title: __( 'New feature', 'norvex' ), text: '' } ] ) ); setSel( cards.length ); } }, __( 'Add card', 'norvex' ) ) ) ] ) );
		var text = el( 'div', { key: 'text', className: 'norvex-featuresplit__text' }, [
			attrRT( props, 'eyebrow', 'span', 'norvex-eyebrow', __( 'Eyebrow', 'norvex' ) ),
			awAccentHead( props, 'heading', 'accent', __( 'Heading', 'norvex' ), __( 'accent', 'norvex' ) ),
			attrRT( props, 'lead', 'p', 'norvex-lead', __( 'Lead text', 'norvex' ) ),
			el( 'span', { key: 'btn', className: 'norvex-btn norvex-btn--primary' }, attrRT( props, 'btn', 'span', null, __( 'Button label', 'norvex' ) ) ),
		] );
		var sideClass = 'norvex-wrap norvex-featuresplit norvex-featuresplit--' + ( 'left' === a.side ? 'left' : 'right' );
		var canvas = el( 'div', useBlockProps( { key: 'canvas' } ), el( 'section', { className: 'norvex-section' }, el( 'div', { className: sideClass }, [ grid, text ] ) ) );
		var selCard = cards[ sel ] || null;
		var panel = [
			el( SelectControl, { key: 'side', label: __( 'Text column side', 'norvex' ), value: a.side || 'right', options: [ { label: __( 'Right', 'norvex' ), value: 'right' }, { label: __( 'Left', 'norvex' ), value: 'left' } ], onChange: function ( v ) { props.setAttributes( { side: v } ); } } ),
			urlSearch( 'btnurl', __( 'Button URL', 'norvex' ), a.btnurl, function ( u ) { props.setAttributes( { btnurl: u } ); } ),
		];
		if ( selCard ) {
			panel.push( el( 'p', { key: 'h', style: { fontSize: '12px', color: '#646970', margin: '8px 0 4px' } }, __( 'Icon for the selected card:', 'norvex' ) ) );
			panel.push( el( IconPicker, { key: 'ip', card: selCard, i: sel, groups: groups, set: setCard } ) );
		}
		return el( Fragment, null, [ sidebar( 'fs', __( 'Feature split', 'norvex' ), panel ), canvas ] );
	}

	function HighlightsInline( p ) {
		var props = p.props, a = props.attributes;
		var items = awPairs( a.items );
		var featured = parseInt( a.featured, 10 ) || 0;
		function commit( next ) { props.setAttributes( { items: awPairsJoin( next ) } ); }
		var list = el( 'div', { key: 'list', className: 'norvex-splitlist__list' }, items.map( function ( it, i ) {
			var on = ( i + 1 ) === featured;
			return el( 'div', { key: 'h' + i, className: 'norvex-hl' + ( on ? ' norvex-hl--on' : '' ) }, [
				el( 'span', { key: 'n', className: 'norvex-hl__num' }, on ? el( 'span', { className: 'norvex-hl__check', dangerouslySetInnerHTML: { __html: '&#10003;' } } ) : awNum( i ) ),
				el( 'div', { key: 'b', className: 'norvex-hl__body' }, [
					awCell( 't', it[ 0 ], __( 'Title', 'norvex' ), function ( v ) { commit( awSetCell( items, i, 0, v ) ); }, 'h4' ),
					awCell( 'd', it[ 1 ], __( 'Description', 'norvex' ), function ( v ) { commit( awSetCell( items, i, 1, v ) ); }, 'p' ),
				] ),
				awX( function () { commit( items.filter( function ( x, idx ) { return idx !== i; } ) ); } ),
			] );
		} ).concat( [ el( 'div', { key: 'add' }, el( Button, { variant: 'secondary', onClick: function () { commit( items.concat( [ [ __( 'New highlight', 'norvex' ), '' ] ] ) ); } }, __( 'Add highlight', 'norvex' ) ) ) ] ) );
		var aside = el( 'div', { key: 'aside', className: 'norvex-splitlist__aside' }, [
			awAccentHead( props, 'heading', 'accent', __( 'Heading', 'norvex' ), __( 'accent', 'norvex' ) ),
			attrRT( props, 'subhead', 'p', 'norvex-splitlist__sub', __( 'Sub-heading', 'norvex' ) ),
			attrRT( props, 'body', 'p', null, __( 'Body text', 'norvex' ) ),
			el( 'div', { key: 'sign', className: 'norvex-sign' }, [
				a.sigphoto ? el( 'img', { key: 'ph', className: 'norvex-sign__photo', src: a.sigphoto, alt: '' } ) : el( 'span', { key: 'ph', className: 'norvex-sign__photo norvex-sign__photo--ph' } ),
				el( 'span', { key: 'meta', className: 'norvex-sign__meta' }, [ attrRT( props, 'signame', 'strong', null, __( 'Name', 'norvex' ) ), attrRT( props, 'sigrole', 'span', null, __( 'Role', 'norvex' ) ) ] ),
			] ),
		] );
		var canvas = el( 'div', useBlockProps( { key: 'canvas' } ), el( 'section', { className: 'norvex-section' }, el( 'div', { className: 'norvex-wrap norvex-splitlist' }, [ list, aside ] ) ) );
		var opts = [ { label: __( 'None', 'norvex' ), value: '0' } ];
		items.forEach( function ( x, i ) { opts.push( { label: String( i + 1 ), value: String( i + 1 ) } ); } );
		var panel = [
			el( SelectControl, { key: 'ft', label: __( 'Highlight which item', 'norvex' ), value: String( featured ), options: opts, onChange: function ( v ) { props.setAttributes( { featured: v } ); } } ),
			imageControl( { key: 'sigphoto', label: __( 'Signature photo (optional)', 'norvex' ) }, props ),
		];
		return el( Fragment, null, [ sidebar( 'hl', __( 'Highlights', 'norvex' ), panel ), canvas ] );
	}

	function ShowcaseInline( p ) {
		var props = p.props, a = props.attributes;
		var items = awPairs( a.items );
		function commit( next ) { props.setAttributes( { items: awPairsJoin( next ) } ); }
		var intro = el( 'div', { key: 'intro', className: 'norvex-showcase__intro' }, [
			attrRT( props, 'eyebrow', 'span', 'norvex-eyebrow', __( 'Eyebrow', 'norvex' ) ),
			awAccentHead( props, 'heading', 'accent', __( 'Heading', 'norvex' ), __( 'accent', 'norvex' ) ),
			el( 'span', { key: 'rule', className: 'norvex-showcase__rule' } ),
			attrRT( props, 'body', 'p', 'norvex-showcase__lead norvex-dropcap', __( 'Body text', 'norvex' ) ),
			el( 'span', { key: 'btn', className: 'norvex-btn norvex-btn--primary' }, attrRT( props, 'btn', 'span', null, __( 'Button label', 'norvex' ) ) ),
		] );
		var ol = el( 'ol', { key: 'list', className: 'norvex-showcase__list' }, items.map( function ( it, i ) {
			return el( 'li', { key: 's' + i, className: 'norvex-showitem' }, [
				el( 'span', { key: 'n', className: 'norvex-showitem__num' }, awNum( i ) ),
				el( 'div', { key: 'b', className: 'norvex-showitem__body' }, [
					awCell( 't', it[ 0 ], __( 'Title', 'norvex' ), function ( v ) { commit( awSetCell( items, i, 0, v ) ); }, 'h4' ),
					awCell( 'd', it[ 1 ], __( 'Description', 'norvex' ), function ( v ) { commit( awSetCell( items, i, 1, v ) ); }, 'p' ),
				] ),
				awX( function () { commit( items.filter( function ( x, idx ) { return idx !== i; } ) ); } ),
			] );
		} ).concat( [ el( 'li', { key: 'add', style: { listStyle: 'none' } }, el( Button, { variant: 'secondary', onClick: function () { commit( items.concat( [ [ __( 'New feature', 'norvex' ), '' ] ] ) ); } }, __( 'Add feature', 'norvex' ) ) ) ] ) );
		var canvas = el( 'div', useBlockProps( { key: 'canvas' } ), el( 'section', { className: 'norvex-section' }, el( 'div', { className: 'norvex-wrap norvex-showcase' }, [ intro, ol ] ) ) );
		var panel = [ urlSearch( 'btnurl', __( 'Button URL', 'norvex' ), a.btnurl, function ( u ) { props.setAttributes( { btnurl: u } ); } ) ];
		return el( Fragment, null, [ sidebar( 'sc', __( 'Showcase', 'norvex' ), panel ), canvas ] );
	}

	function BroadsheetInline( p ) {
		var props = p.props, a = props.attributes;
		var rates = awRows( a.rates );
		function commit( next ) { props.setAttributes( { rates: awRowsJoin( next ) } ); }
		var head = el( 'div', { key: 'head', className: 'norvex-section-head norvex-center' }, [
			attrRT( props, 'eyebrow', 'span', 'norvex-eyebrow', __( 'Eyebrow', 'norvex' ) ),
			awAccentHead( props, 'heading', 'accent', __( 'Heading', 'norvex' ), __( 'accent', 'norvex' ) ),
			attrRT( props, 'lead', 'p', 'norvex-lead', __( 'Lead text', 'norvex' ) ),
		] );
		var prose = el( 'div', { key: 'prose', className: 'norvex-ratesplit__prose' }, [
			attrRT( props, 'body', 'p', null, __( 'Story…', 'norvex' ) ),
			el( 'blockquote', { key: 'q', className: 'norvex-ratesplit__quote' }, [ attrRT( props, 'quote', 'p', null, __( 'Pull quote', 'norvex' ) ), attrRT( props, 'quoteby', 'cite', null, __( 'Attribution', 'norvex' ) ) ] ),
		] );
		var card = el( 'aside', { key: 'card', className: 'norvex-ratecard norvex-lift' }, [
			attrRT( props, 'ratestitle', 'h3', null, __( 'Rates title', 'norvex' ) ),
			attrRT( props, 'ratessub', 'p', 'norvex-ratecard__sub', __( 'Strapline', 'norvex' ) ),
			el( 'ul', { key: 'ul' }, rates.map( function ( r, i ) {
				return el( 'li', { key: 'r' + i }, [
					awCell( 'nm', r[ 0 ], __( 'Service', 'norvex' ), function ( v ) { commit( awSetCell( rates, i, 0, v ) ); }, 'span', 'norvex-ratecard__name' ),
					el( 'span', { key: 'd', className: 'norvex-ratecard__dots' } ),
					awCell( 'pr', r[ 1 ], __( 'Price', 'norvex' ), function ( v ) { commit( awSetCell( rates, i, 1, v ) ); }, 'span', 'norvex-ratecard__price' ),
					awX( function () { commit( rates.filter( function ( x, idx ) { return idx !== i; } ) ); } ),
				] );
			} ).concat( [ el( 'li', { key: 'add', style: { border: 0 } }, el( Button, { variant: 'link', onClick: function () { commit( rates.concat( [ [ __( 'New service', 'norvex' ), '' ] ] ) ); } }, __( '+ Add rate', 'norvex' ) ) ) ] ) ),
		] );
		var canvas = el( 'div', useBlockProps( { key: 'canvas' } ), el( 'section', { className: 'norvex-section' }, el( 'div', { className: 'norvex-wrap' }, [ head, el( 'div', { key: 'rs', className: 'norvex-ratesplit' }, [ prose, card ] ) ] ) ) );
		return el( Fragment, null, [ canvas ] );
	}

	function MarginaliaInline( p ) {
		var props = p.props, a = props.attributes;
		var items = awRows( a.items );
		function commit( next ) { props.setAttributes( { items: awRowsJoin( next ) } ); }
		var head = el( 'div', { key: 'head', className: 'norvex-section-head norvex-center' }, [
			attrRT( props, 'eyebrow', 'span', 'norvex-eyebrow', __( 'Eyebrow', 'norvex' ) ),
			el( 'h2', { key: 'h', className: 'norvex-accent-heading' }, [
				awCell( 'hb', a.headbefore, __( 'Start', 'norvex' ), function ( v ) { props.setAttributes( { headbefore: v } ); }, 'span' ),
				el( RichText, { key: 'st', tagName: 'span', className: 'norvex-strike', style: { marginLeft: '.3em' }, value: a.strike || '', allowedFormats: [], placeholder: __( 'struck word', 'norvex' ), onChange: function ( v ) { props.setAttributes( { strike: stripTags( v ) } ); } } ),
				el( RichText, { key: 'fx', tagName: 'span', className: 'norvex-accent-word', style: { marginLeft: '.3em' }, value: a.fix || '', allowedFormats: [], placeholder: __( 'correction', 'norvex' ), onChange: function ( v ) { props.setAttributes( { fix: stripTags( v ) } ); } } ),
			] ),
			attrRT( props, 'lead', 'p', 'norvex-lead', __( 'Lead text', 'norvex' ) ),
		] );
		var card = el( 'div', { key: 'card', className: 'norvex-checkcard norvex-lift' }, [
			attrRT( props, 'checkh', 'div', 'norvex-checkcard__h', __( 'Checklist heading', 'norvex' ) ),
			el( 'ul', { key: 'ul' }, items.map( function ( it, i ) {
				var done = 'done' === ( it[ 2 ] || '' );
				return el( 'li', { key: 'r' + i, className: done ? 'is-done' : '' }, [
					el( 'button', { key: 'bx', type: 'button', className: 'norvex-checkcard__box' + ( done ? ' is-done' : '' ), title: __( 'Toggle done', 'norvex' ), onClick: function () { commit( awSetCell( items, i, 2, done ? '' : 'done' ) ); }, style: { cursor: 'pointer', padding: 0 }, dangerouslySetInnerHTML: { __html: done ? '&#10003;' : '' } } ),
					awCell( 'l', it[ 0 ], __( 'Item', 'norvex' ), function ( v ) { commit( awSetCell( items, i, 0, v ) ); }, 'span', 'norvex-checkcard__label' ),
					awCell( 'pr', it[ 1 ], __( 'Price', 'norvex' ), function ( v ) { commit( awSetCell( items, i, 1, v ) ); }, 'span', 'norvex-checkcard__pr' ),
					awX( function () { commit( items.filter( function ( x, idx ) { return idx !== i; } ) ); } ),
				] );
			} ).concat( [ el( 'li', { key: 'add', style: { border: 0 } }, el( Button, { variant: 'link', onClick: function () { commit( items.concat( [ [ __( 'New item', 'norvex' ), '', '' ] ] ) ); } }, __( '+ Add item', 'norvex' ) ) ) ] ) ),
			el( 'div', { key: 'cta', className: 'norvex-checkcard__cta' }, el( 'span', { className: 'norvex-btn norvex-btn--primary' }, attrRT( props, 'btn', 'span', null, __( 'Button label', 'norvex' ) ) ) ),
		] );
		var canvas = el( 'div', useBlockProps( { key: 'canvas' } ), el( 'section', { className: 'norvex-section norvex-section--sand' }, el( 'div', { className: 'norvex-wrap' }, [ head, card ] ) ) );
		var panel = [ urlSearch( 'btnurl', __( 'Button URL', 'norvex' ), a.btnurl, function ( u ) { props.setAttributes( { btnurl: u } ); } ) ];
		return el( Fragment, null, [ sidebar( 'mg', __( 'Launch checklist', 'norvex' ), panel ), canvas ] );
	}

	function ChaptersInline( p ) {
		var props = p.props, a = props.attributes;
		var items = awRows( a.items );
		function commit( next ) { props.setAttributes( { items: awRowsJoin( next ) } ); }
		var head = el( 'div', { key: 'head', className: 'norvex-chapters__head' }, [
			el( 'div', { key: 'l' }, [ attrRT( props, 'eyebrow', 'span', 'norvex-eyebrow', __( 'Eyebrow', 'norvex' ) ), attrRT( props, 'heading', 'h2', null, __( 'Heading', 'norvex' ) ) ] ),
			attrRT( props, 'meta', 'span', 'norvex-chapters__meta', __( 'Meta note', 'norvex' ) ),
		] );
		var grid = el( 'div', { key: 'grid', className: 'norvex-chapters__grid' }, items.map( function ( it, i ) {
			return el( 'div', { key: 'c' + i, className: 'norvex-chapters__item' }, [
				el( 'div', { key: 'top', className: 'norvex-chapters__top' }, [
					el( 'span', { key: 'n', className: 'norvex-chapters__num' }, awNum( i ) ),
					awCell( 't', it[ 0 ], __( 'Title', 'norvex' ), function ( v ) { commit( awSetCell( items, i, 0, v ) ); }, 'h3' ),
					awX( function () { commit( items.filter( function ( x, idx ) { return idx !== i; } ) ); } ),
				] ),
				awCell( 'd', it[ 1 ], __( 'Description', 'norvex' ), function ( v ) { commit( awSetCell( items, i, 1, v ) ); }, 'p' ),
			] );
		} ) );
		var addBtn = el( 'div', { key: 'add', style: { marginTop: '14px' } }, el( Button, { variant: 'secondary', onClick: function () { commit( items.concat( [ [ __( 'New entry', 'norvex' ), '' ] ] ) ); } }, __( 'Add entry', 'norvex' ) ) );
		var canvas = el( 'div', useBlockProps( { key: 'canvas' } ), el( 'section', { className: 'norvex-section' }, el( 'div', { className: 'norvex-wrap' }, [ head, grid, addBtn ] ) ) );
		return el( Fragment, null, [ canvas ] );
	}

	function DataColumnsInline( p ) {
		var props = p.props, a = props.attributes;
		var cols = awRows( a.cols );
		var selState = wp.element.useState( 0 ); var sel = selState[ 0 ], setSel = selState[ 1 ];
		function commit( next ) { props.setAttributes( { cols: awRowsJoin( next ) } ); }
		var head = el( 'div', { key: 'head', className: 'norvex-section-head norvex-section-head--left' }, [
			attrRT( props, 'eyebrow', 'span', 'norvex-eyebrow', __( 'Eyebrow', 'norvex' ) ),
			attrRT( props, 'heading', 'h2', null, __( 'Heading', 'norvex' ) ),
			attrRT( props, 'lead', 'p', 'norvex-lead', __( 'Lead text', 'norvex' ) ),
		] );
		var grid = el( 'div', { key: 'grid', className: 'norvex-datacols' }, cols.map( function ( c, i ) {
			return el( 'div', { key: 'c' + i, className: 'norvex-datacol' + ( i === sel ? ' norvex-card--selected' : '' ), onClick: function () { setSel( i ); } }, [
				awCell( 'src', c[ 0 ], __( 'Source', 'norvex' ), function ( v ) { commit( awSetCell( cols, i, 0, v ) ); }, 'span', 'norvex-datacol__src' ),
				awCell( 'fig', c[ 1 ], __( 'Figure', 'norvex' ), function ( v ) { commit( awSetCell( cols, i, 1, v ) ); }, 'div', 'norvex-datacol__fig' ),
				awCell( 'sub', c[ 2 ], __( 'Sub-heading', 'norvex' ), function ( v ) { commit( awSetCell( cols, i, 2, v ) ); }, 'h4' ),
				awCell( 'ds', c[ 3 ], __( 'Description', 'norvex' ), function ( v ) { commit( awSetCell( cols, i, 3, v ) ); }, 'p' ),
				el( 'span', { key: 'ln', className: 'norvex-readmore' }, awCell( 'lb', c[ 4 ], __( 'Link label', 'norvex' ), function ( v ) { commit( awSetCell( cols, i, 4, v ) ); }, 'span' ) ),
				awX( function () { commit( cols.filter( function ( x, idx ) { return idx !== i; } ) ); setSel( 0 ); } ),
			] );
		} ) );
		var addBtn = el( 'div', { key: 'add', style: { marginTop: '14px' } }, el( Button, { variant: 'secondary', onClick: function () { commit( cols.concat( [ [ __( 'Source', 'norvex' ), __( 'Figure', 'norvex' ), '', '', '', '' ] ] ) ); setSel( cols.length ); } }, __( 'Add column', 'norvex' ) ) );
		var canvas = el( 'div', useBlockProps( { key: 'canvas' } ), el( 'section', { className: 'norvex-section' }, el( 'div', { className: 'norvex-wrap' }, [ head, grid, addBtn ] ) ) );
		var selCol = cols[ sel ] || null;
		var panel = [];
		if ( selCol ) {
			panel.push( el( 'p', { key: 'h', style: { fontSize: '12px', color: '#646970', margin: '0 0 6px' } }, __( 'Link for the selected column:', 'norvex' ) ) );
			panel.push( urlSearch( 'dcurl', __( 'Link URL', 'norvex' ), selCol[ 5 ] || '', function ( u ) { commit( awSetCell( cols, sel, 5, u ) ); } ) );
		}
		return el( Fragment, null, [ sidebar( 'dc', __( 'Data columns', 'norvex' ), panel ), canvas ] );
	}

	function ServicesListInline( p ) {
		var props = p.props, a = props.attributes;
		var items = awRows( a.items );
		var selState = wp.element.useState( 0 ); var sel = selState[ 0 ], setSel = selState[ 1 ];
		function commit( next ) { props.setAttributes( { items: awRowsJoin( next ) } ); }
		var learn = a.learn || '';
		var head = el( 'div', { key: 'head', className: 'norvex-section-head norvex-section-head--left' }, [
			attrRT( props, 'eyebrow', 'span', 'norvex-eyebrow', __( 'Eyebrow', 'norvex' ) ),
			awAccentHead( props, 'heading', 'accent', __( 'Heading', 'norvex' ), __( 'accent (optional)', 'norvex' ) ),
			attrRT( props, 'lead', 'p', 'norvex-lead', __( 'Lead text', 'norvex' ) ),
		] );
		var list = el( 'ul', { key: 'list', className: 'norvex-servlist' }, items.map( function ( it, i ) {
			return el( 'li', { key: 'r' + i, className: 'norvex-servlist__row' + ( i === sel ? ' norvex-card--selected' : '' ), onClick: function () { setSel( i ); } }, [
				el( 'span', { key: 'n', className: 'norvex-servlist__num' }, awNum( i ) ),
				el( 'div', { key: 'm', className: 'norvex-servlist__main' }, [
					el( 'h3', { key: 'h' }, [ awCell( 't', it[ 0 ], __( 'Title', 'norvex' ), function ( v ) { commit( awSetCell( items, i, 0, v ) ); }, 'span' ), el( 'span', { key: 'bg', className: 'norvex-servlist__badge' }, awCell( 'b', it[ 1 ], __( 'badge', 'norvex' ), function ( v ) { commit( awSetCell( items, i, 1, v ) ); }, 'span' ) ) ] ),
					awCell( 'd', it[ 2 ], __( 'Description', 'norvex' ), function ( v ) { commit( awSetCell( items, i, 2, v ) ); }, 'p' ),
				] ),
				el( 'div', { key: 's', className: 'norvex-servlist__side' }, [
					awCell( 'pr', it[ 3 ], __( 'Price', 'norvex' ), function ( v ) { commit( awSetCell( items, i, 3, v ) ); }, 'span', 'norvex-servlist__price' ),
					learn ? el( 'span', { key: 'l', className: 'norvex-servlist__learn' }, learn ) : null,
				] ),
				awX( function () { commit( items.filter( function ( x, idx ) { return idx !== i; } ) ); setSel( 0 ); } ),
			] );
		} ) );
		var addBtn = el( 'div', { key: 'add', style: { marginTop: '14px' } }, el( Button, { variant: 'secondary', onClick: function () { commit( items.concat( [ [ __( 'New service', 'norvex' ), '', '', '', '' ] ] ) ); setSel( items.length ); } }, __( 'Add service', 'norvex' ) ) );
		var canvas = el( 'div', useBlockProps( { key: 'canvas' } ), el( 'section', { className: 'norvex-section' }, el( 'div', { className: 'norvex-wrap' }, [ head, list, addBtn ] ) ) );
		var selItem = items[ sel ] || null;
		var panel = [ el( TextControl, { key: 'learn', label: __( 'Row link label (blank = hide)', 'norvex' ), value: a.learn || '', onChange: function ( v ) { props.setAttributes( { learn: v } ); } } ) ];
		if ( selItem ) {
			panel.push( el( 'p', { key: 'h', style: { fontSize: '12px', color: '#646970', margin: '8px 0 6px' } }, __( 'Link for the selected service:', 'norvex' ) ) );
			panel.push( urlSearch( 'svurl', __( 'Link URL', 'norvex' ), selItem[ 4 ] || '', function ( u ) { commit( awSetCell( items, sel, 4, u ) ); } ) );
		}
		return el( Fragment, null, [ sidebar( 'sv', __( 'Services list', 'norvex' ), panel ), canvas ] );
	}

	function StepsMediaInline( p ) {
		var props = p.props, a = props.attributes;
		var steps = parseArr( a.steps );
		var selState = wp.element.useState( 0 ); var sel = selState[ 0 ], setSel = selState[ 1 ];
		function commit( next ) { props.setAttributes( { steps: JSON.stringify( next ) } ); }
		function setStep( i, key, val ) { commit( steps.map( function ( s, idx ) { if ( idx !== i ) { return s; } var ns = {}; for ( var k in s ) { ns[ k ] = s[ k ]; } ns[ key ] = val; return ns; } ) ); }
		var center = 'left' === a.align ? '' : ' norvex-center';
		var head = el( 'div', { key: 'head', className: 'norvex-section-head' + center }, [
			attrRT( props, 'eyebrow', 'span', 'norvex-eyebrow', __( 'Eyebrow', 'norvex' ) ),
			attrRT( props, 'heading', 'h2', null, __( 'Heading', 'norvex' ) ),
			attrRT( props, 'lead', 'p', 'norvex-lead', __( 'Lead text', 'norvex' ) ),
		] );
		var rows = el( 'div', { key: 'steps', className: 'norvex-steps' }, steps.map( function ( s, i ) {
			return el( 'div', { key: 'st' + i, className: 'norvex-step' + ( s.image ? '' : ' norvex-step--noimg' ) + ( i === sel ? ' norvex-card--selected' : '' ), onClick: function () { setSel( i ); } }, [
				el( 'span', { key: 'n', className: 'norvex-step__num' }, i + 1 ),
				el( 'div', { key: 'b', className: 'norvex-step__body' }, [
					awCell( 't', s.title, __( 'Step title', 'norvex' ), function ( v ) { setStep( i, 'title', v ); }, 'h3' ),
					awCell( 'd', s.text, __( 'Description', 'norvex' ), function ( v ) { setStep( i, 'text', v ); }, 'p' ),
				] ),
				s.image ? el( 'div', { key: 'm', className: 'norvex-step__media' }, el( 'img', { src: s.image, alt: '' } ) ) : null,
				awX( function () { commit( steps.filter( function ( x, idx ) { return idx !== i; } ) ); setSel( 0 ); } ),
			] );
		} ) );
		var addBtn = el( 'div', { key: 'add', style: { marginTop: '14px' } }, el( Button, { variant: 'secondary', onClick: function () { commit( steps.concat( [ { title: __( 'New step', 'norvex' ), text: '', image: '' } ] ) ); setSel( steps.length ); } }, __( 'Add step', 'norvex' ) ) );
		var canvas = el( 'div', useBlockProps( { key: 'canvas' } ), el( 'section', { className: 'norvex-section' }, el( 'div', { className: 'norvex-wrap' }, [ head, rows, addBtn ] ) ) );
		var selStep = steps[ sel ] || null;
		var panel = [ el( SelectControl, { key: 'al', label: __( 'Heading alignment', 'norvex' ), value: a.align || 'center', options: [ { label: __( 'Center', 'norvex' ), value: 'center' }, { label: __( 'Left', 'norvex' ), value: 'left' } ], onChange: function ( v ) { props.setAttributes( { align: v } ); } } ) ];
		if ( selStep ) {
			panel.push( el( 'p', { key: 'ph', style: { margin: '10px 0 4px', fontWeight: 600, fontSize: '12px' } }, __( 'Image for the selected step', 'norvex' ) ) );
			if ( selStep.image ) { panel.push( el( 'img', { key: 'pi', src: selStep.image, alt: '', style: { width: '100%', borderRadius: '6px', marginBottom: '6px', display: 'block' } } ) ); }
			panel.push( el( MediaUploadCheck, { key: 'pu' }, el( MediaUpload, { onSelect: function ( m ) { setStep( sel, 'image', m && m.url ? m.url : '' ); }, allowedTypes: [ 'image' ], render: function ( o ) { return el( Button, { variant: 'secondary', onClick: o.open }, selStep.image ? __( 'Replace image', 'norvex' ) : __( 'Select image', 'norvex' ) ); } } ) ) );
			if ( selStep.image ) { panel.push( el( Button, { key: 'rm', variant: 'link', isDestructive: true, style: { marginLeft: '8px' }, onClick: function () { setStep( sel, 'image', '' ); } }, __( 'Remove image', 'norvex' ) ) ); }
		}
		return el( Fragment, null, [ sidebar( 'sm', __( 'Steps', 'norvex' ), panel ), canvas ] );
	}

	function TimelineHInline( p ) {
		var props = p.props, a = props.attributes;
		var items = awRows( a.items );
		var scale = String( a.scale || '' ).split( '|' ).map( function ( s ) { return s.trim(); } ).filter( function ( s ) { return '' !== s; } );
		function commit( next ) { props.setAttributes( { items: awRowsJoin( next ) } ); }
		function commitScale( next ) { props.setAttributes( { scale: next.filter( function ( s ) { return '' !== ( '' + s ).trim(); } ).join( ' | ' ) } ); }
		var head = el( 'div', { key: 'head', className: 'norvex-section-head norvex-center' }, [
			attrRT( props, 'eyebrow', 'span', 'norvex-eyebrow', __( 'Eyebrow', 'norvex' ) ),
			awAccentHead( props, 'heading', 'accent', __( 'Heading', 'norvex' ), __( 'accent (optional)', 'norvex' ) ),
			attrRT( props, 'lead', 'p', 'norvex-lead', __( 'Lead text', 'norvex' ) ),
		] );
		var track = el( 'div', { key: 'track', className: 'norvex-hztl__track' }, items.map( function ( it, i ) {
			return el( 'div', { key: 'm' + i, className: 'norvex-hztl__item' }, [
				el( 'span', { key: 'd', className: 'norvex-hztl__dot' }, awNum( i ) ),
				el( 'div', { key: 'b', className: 'norvex-hztl__body' }, [
					awCell( 'ph', it[ 0 ], __( 'Phase', 'norvex' ), function ( v ) { commit( awSetCell( items, i, 0, v ) ); }, 'span', 'norvex-hztl__phase' ),
					awCell( 't', it[ 1 ], __( 'Title', 'norvex' ), function ( v ) { commit( awSetCell( items, i, 1, v ) ); }, 'h4' ),
					awCell( 'x', it[ 2 ], __( 'Description', 'norvex' ), function ( v ) { commit( awSetCell( items, i, 2, v ) ); }, 'p' ),
					awX( function () { commit( items.filter( function ( z, idx ) { return idx !== i; } ) ); } ),
				] ),
			] );
		} ) );
		var scaleEls = scale.map( function ( s, i ) {
			return el( 'span', { key: 'sc' + i, style: { display: 'inline-flex', alignItems: 'center' } }, [
				awCell( 'v', s, __( 'marker', 'norvex' ), function ( v ) { commitScale( scale.map( function ( z, idx ) { return idx === i ? v : z; } ) ); }, 'span' ),
				awX( function () { commitScale( scale.filter( function ( z, idx ) { return idx !== i; } ) ); } ),
			] );
		} );
		scaleEls.push( el( 'span', { key: 'sadd' }, el( Button, { variant: 'link', onClick: function () { commitScale( scale.concat( [ 'Day' ] ) ); } }, __( '+ marker', 'norvex' ) ) ) );
		var wrap = el( 'div', { key: 'hztl', className: 'norvex-hztl' }, [ track, el( 'div', { key: 'sc', className: 'norvex-hztl__scale' }, scaleEls ) ] );
		var addBtn = el( 'div', { key: 'add', style: { textAlign: 'center', marginTop: '16px' } }, el( Button, { variant: 'secondary', onClick: function () { commit( items.concat( [ [ __( 'Phase', 'norvex' ), __( 'New milestone', 'norvex' ), '' ] ] ) ); } }, __( 'Add milestone', 'norvex' ) ) );
		var canvas = el( 'div', useBlockProps( { key: 'canvas' } ), el( 'section', { className: 'norvex-section' }, el( 'div', { className: 'norvex-wrap' }, [ head, wrap, addBtn ] ) ) );
		return el( Fragment, null, [ canvas ] );
	}

	function ZigzagInline( p ) {
		var props = p.props, a = props.attributes;
		var items = awRows( a.items );
		function commit( next ) { props.setAttributes( { items: awRowsJoin( next ) } ); }
		var head = el( 'div', { key: 'head', className: 'norvex-section-head norvex-center' }, [
			attrRT( props, 'eyebrow', 'span', 'norvex-eyebrow', __( 'Eyebrow', 'norvex' ) ),
			awAccentHead( props, 'heading', 'accent', __( 'Heading', 'norvex' ), __( 'accent (optional)', 'norvex' ) ),
			attrRT( props, 'lead', 'p', 'norvex-lead', __( 'Lead text', 'norvex' ) ),
		] );
		var zz = el( 'div', { key: 'zz', className: 'norvex-zz' }, items.map( function ( it, i ) {
			return el( 'div', { key: 's' + i, className: 'norvex-zz__step' }, [
				el( 'span', { key: 'n', className: 'norvex-zz__no' }, awNum( i ) ),
				el( 'div', { key: 'b', className: 'norvex-zz__body' }, [
					awCell( 'l', it[ 0 ], __( 'Label', 'norvex' ), function ( v ) { commit( awSetCell( items, i, 0, v ) ); }, 'span', 'norvex-zz__label' ),
					awCell( 't', it[ 1 ], __( 'Title', 'norvex' ), function ( v ) { commit( awSetCell( items, i, 1, v ) ); }, 'h4' ),
					awCell( 'x', it[ 2 ], __( 'Description', 'norvex' ), function ( v ) { commit( awSetCell( items, i, 2, v ) ); }, 'p' ),
					awX( function () { commit( items.filter( function ( z, idx ) { return idx !== i; } ) ); } ),
				] ),
			] );
		} ) );
		var addBtn = el( 'div', { key: 'add', style: { textAlign: 'center', marginTop: '20px' } }, el( Button, { variant: 'secondary', onClick: function () { commit( items.concat( [ [ __( 'Label', 'norvex' ), __( 'New step', 'norvex' ), '' ] ] ) ); } }, __( 'Add step', 'norvex' ) ) );
		var canvas = el( 'div', useBlockProps( { key: 'canvas' } ), el( 'section', { className: 'norvex-section' }, el( 'div', { className: 'norvex-wrap' }, [ head, zz, addBtn ] ) ) );
		return el( Fragment, null, [ canvas ] );
	}

	var INLINE = {
		'norvex/feature-split': FeatureSplitInline,
		'norvex/steps-media': StepsMediaInline,
		'norvex/timeline-h': TimelineHInline,
		'norvex/zigzag': ZigzagInline,
		'norvex/highlights': HighlightsInline,
		'norvex/showcase': ShowcaseInline,
		'norvex/broadsheet': BroadsheetInline,
		'norvex/marginalia': MarginaliaInline,
		'norvex/chapters-index': ChaptersInline,
		'norvex/data-columns': DataColumnsInline,
		'norvex/services-list': ServicesListInline,
		'norvex/cards': CardsInlineEdit,
		'norvex/testimonials': TestimonialsInline,
		'norvex/pricing': PricingInline,
		'norvex/services': CardsInlineEdit,
		'norvex/team': TeamInline,
		'norvex/featured-books': BooksInline,
		'norvex/hero': HeroInline,
		'norvex/cta': CtaInline,
		'norvex/callout': CalloutInline,
		'norvex/stats': StatsInline,
		'norvex/faq': FaqInline,
		'norvex/buttons': ButtonsInline,
		'norvex/table': TableInline,
		'norvex/process': ProcessInline,
		'norvex/consult': ConsultInline,
		'norvex/why-us': WhyUsInline,
		'norvex/page-hero': PageHeroInline,
		'norvex/section-header': SectionHeaderInline,
		'norvex/about-story': AboutStoryInline,
		'norvex/logos': LogosInline,
		'norvex/checklist': ChecklistInline,
	};

	// A fitting Dashicon per block. Every Norvex block is tinted the brand
	// sage green so it's easy to spot in the inserter and list view.
	var NORVEX_GREEN = '#c08a3e';
	var BLOCK_ICONS = {
		'hero': 'cover-image',
		'logos': 'awards',
		'services': 'screenoptions',
		'process': 'editor-ol',
		'consult': 'calendar-alt',
		'featured-books': 'book-alt',
		'stats': 'chart-bar',
		'why-us': 'shield',
		'testimonials': 'testimonial',
		'journal': 'admin-post',
		'faq': 'editor-help',
		'cta': 'megaphone',
		'page-hero': 'align-wide',
		'about-story': 'id',
		'team': 'groups',
		'pricing': 'money-alt',
		'contact': 'email-alt',
		'cards': 'grid-view',
		'buttons': 'button',
		'table': 'editor-table',
		'section-header': 'heading',
		'callout': 'format-quote',
		'checklist': 'yes-alt',
		'notice': 'megaphone',
		'feature-split': 'grid-view',
		'highlights': 'star-filled',
		'showcase': 'editor-ol',
		'broadsheet': 'money-alt',
		'marginalia': 'yes-alt',
		'chapters-index': 'list-view',
		'data-columns': 'chart-bar',
		'services-list': 'editor-ol',
		'steps-media': 'images-alt2',
		'timeline-h': 'clock',
		'zigzag': 'randomize',
	};

	window.NorvexBlocks.forEach( function ( block ) {

		var shortName = block.name.replace( 'norvex/', '' );

		// Build the attribute schema from the config fields.
		var attributes = {};
		block.fields.forEach( function ( f ) {
			attributes[ f.key ] = {
				type: f.type === 'number' ? 'number' : 'string',
				default: f.default,
			};
		} );

		wp.blocks.registerBlockType( block.name, {
			apiVersion: 2,
			title: block.title.replace( /^Norvex:\s*/i, '' ),
			category: block.category || 'norvex',
			icon: { src: BLOCK_ICONS[ shortName ] || 'admin-page', foreground: NORVEX_GREEN },
			description: INLINE[ block.name ]
				? __( 'Edit directly on the block — click and type in the canvas.', 'norvex' )
				: ( block.dynamic
					? __( 'Live section — pulls from your dashboard content.', 'norvex' )
					: __( 'Editable section — every field is in this sidebar.', 'norvex' ) ),
			supports: {
				html: false,
				reusable: false,
				multiple: true,
				anchor: true,
				align: [ 'wide', 'full' ],
				// Native design tools: Color (text / background / gradient /
				// link), Dimensions (padding & margin) and Border. WordPress
				// adds these panels to the block sidebar automatically; the PHP
				// render_callback applies the resulting styles on the front end.
				color: { background: true, text: true, gradients: true, link: true },
				spacing: { padding: true, margin: true },
				__experimentalBorder: { color: true, radius: true, style: true, width: true },
			},
			attributes: attributes,

			edit: function ( props ) {
				// Content blocks with an inline editor: type directly in the
				// canvas; only non-text "style" fields sit in the sidebar. The
				// data blocks (testimonials, pricing) fall back to the generic
				// sidebar + preview when their source is "From dashboard".
				var main = INLINE[ block.name ]
					? el( INLINE[ block.name ], { block: block, props: props } )
					: GenericEdit( block, props );
				// Append the shared per-line colour panel (if the block has one)
				// so inline-edited sections get it in the sidebar too.
				var colors = headerColorPanel( block, props );
				return colors ? el( Fragment, null, [ main, colors ] ) : main;
			},

			save: function () {
				return null;
			},
		} );
	} );

} )( window.wp );
