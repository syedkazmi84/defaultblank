/**
 * Norvex — "Tabs (with blocks)" editor registration.
 *
 * norvex/tabset — parent; shows a real tab bar in the editor and edits one
 *                      panel at a time (dynamic: PHP renders the front end).
 * norvex/tab    — a single tab: a label + InnerBlocks panel that accepts
 *                      ANY blocks (Grid cards, Featured books, paragraphs…).
 *
 * The front-end markup is produced by the PHP render_callback and reuses the
 * theme's existing .norvex-tabs styles + tab-switching script.
 */
( function ( wp ) {
	if ( ! wp || ! wp.blocks ) { return; }

	var el                = wp.element.createElement;
	var useState          = wp.element.useState;
	var registerBlockType = wp.blocks.registerBlockType;
	var createBlock       = wp.blocks.createBlock;
	var blockEditor       = wp.blockEditor || wp.editor;
	var InnerBlocks       = blockEditor.InnerBlocks;
	var useBlockProps     = blockEditor.useBlockProps;
	var useInnerBlocksProps = blockEditor.useInnerBlocksProps || ( InnerBlocks && InnerBlocks.useInnerBlocksProps );
	var components        = wp.components;
	var data              = wp.data;
	var __                = ( wp.i18n && wp.i18n.__ ) ? wp.i18n.__ : function ( s ) { return s; };

	/* ---- Child: a single tab ---- */
	registerBlockType( 'norvex/tab', {
		apiVersion: 2,
		title: __( 'Tab', 'norvex' ),
		parent: [ 'norvex/tabset' ],
		icon: 'index-card',
		attributes: { title: { type: 'string', default: 'Tab' } },
		supports: { html: false, reusable: false, lock: false },
		edit: function ( props ) {
			var blockProps = useBlockProps( { className: 'norvex-tab-edit' } );
			return el(
				'div',
				blockProps,
				el( components.TextControl, {
					label: __( 'Tab label', 'norvex' ),
					value: props.attributes.title,
					onChange: function ( v ) { props.setAttributes( { title: v } ); }
				} ),
				el( 'div', { className: 'norvex-tab-edit__body' }, el( InnerBlocks, { templateLock: false } ) )
			);
		},
		save: function () {
			return el( 'div', useBlockProps.save( { className: 'norvex-tab-inner' } ), el( InnerBlocks.Content ) );
		}
	} );

	/* ---- Parent: the tab set — real tabs in the editor ---- */
	registerBlockType( 'norvex/tabset', {
		apiVersion: 2,
		title: __( 'Tabs', 'norvex' ),
		category: 'norvex-block',
		icon: 'category',
		attributes: { heading: { type: 'string', default: '' } },
		supports: {
			html: false,
			anchor: true,
			align: [ 'wide', 'full' ],
			color: { background: true, text: true, gradients: true, link: true },
			spacing: { padding: true, margin: true },
			__experimentalBorder: { color: true, radius: true, style: true, width: true },
		},
		edit: function ( props ) {
			var clientId = props.clientId;
			var st       = useState( 0 );
			var active   = st[0], setActive = st[1];

			// Live list of child tabs (for the tab bar labels).
			var tabs = data.useSelect( function ( select ) {
				var blocks = select( 'core/block-editor' ).getBlocks( clientId );
				return blocks.map( function ( b ) {
					return { clientId: b.clientId, title: ( b.attributes && b.attributes.title ) || '' };
				} );
			}, [ clientId ] );

			var count   = tabs.length;
			var current = count ? Math.min( active, count - 1 ) : 0;

			var dispatch = data.useDispatch( 'core/block-editor' );
			function addTab() {
				var b = createBlock( 'norvex/tab', { title: __( 'New tab', 'norvex' ) } );
				dispatch.insertBlock( b, count, clientId );
				setActive( count );
			}

			var innerProps = useInnerBlocksProps(
				{ className: 'norvex-tabset-edit__panels', 'data-active': current },
				{
					allowedBlocks: [ 'norvex/tab' ],
					template: [
						[ 'norvex/tab', { title: __( 'Tab one', 'norvex' ) } ],
						[ 'norvex/tab', { title: __( 'Tab two', 'norvex' ) } ]
					],
					templateLock: false,
					renderAppender: false
				}
			);

			var blockProps = useBlockProps( { className: 'norvex-tabset-edit' } );

			return el(
				'div',
				blockProps,
				el( components.TextControl, {
					label: __( 'Heading (optional)', 'norvex' ),
					value: props.attributes.heading,
					onChange: function ( v ) { props.setAttributes( { heading: v } ); }
				} ),
				el(
					'div',
					{ className: 'norvex-tabset-edit__nav' },
					tabs.map( function ( t, i ) {
						return el( 'button', {
							key: t.clientId,
							type: 'button',
							className: 'norvex-tabset-edit__tab' + ( i === current ? ' is-active' : '' ),
							onClick: function () { setActive( i ); }
						}, ( t.title && t.title.length ) ? t.title : ( __( 'Tab', 'norvex' ) + ' ' + ( i + 1 ) ) );
					} ),
					el( 'button', {
						type: 'button',
						className: 'norvex-tabset-edit__add',
						onClick: addTab
					}, '+ ' + __( 'Add tab', 'norvex' ) )
				),
				el( 'div', innerProps )
			);
		},
		save: function () {
			return el( InnerBlocks.Content );
		}
	} );
} )( window.wp );
