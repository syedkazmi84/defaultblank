<?php
/**
 * Template Name: Full-width (Gutenberg blocks)
 *
 * Renders the page content edge-to-edge with no boxed prose wrapper and no
 * auto-inserted page hero, so pages built purely from core WordPress blocks
 * (the "block-only" demo) lay themselves out using the theme.json layout and
 * palette. Assigned automatically to the block-only demo pages.
 *
 * @package Norvex
 */

get_header();

while ( have_posts() ) :
	the_post();
	the_content();
endwhile;

get_footer();
