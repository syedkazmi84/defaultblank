<?php
/**
 * Tag archive — same Journal-style layout as categories
 * (see template-parts/term-archive.php).
 *
 * @package Norvex
 */

get_header();
get_template_part( 'template-parts/term-archive', null, array( 'badge' => __( 'Tag', 'norvex' ) ) );
get_footer();
