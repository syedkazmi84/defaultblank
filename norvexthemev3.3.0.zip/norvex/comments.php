<?php
/**
 * Comments template — Journal article style: a heading with the count, the
 * comment form, then the threaded list.
 *
 * @package Norvex
 */

if ( post_password_required() ) {
	return;
}

$norvex_count = get_comments_number();
?>
<section id="comments" class="norvex-comments">

	<div class="norvex-comments__head">
		<h2 class="norvex-comments__title">
			<?php
			if ( $norvex_count ) {
				/* translators: %s: comment count. */
				printf( esc_html( _n( 'Comments (%s)', 'Comments (%s)', $norvex_count, 'norvex' ) ), esc_html( number_format_i18n( $norvex_count ) ) );
			} else {
				esc_html_e( 'Comments', 'norvex' );
			}
			?>
		</h2>
		<?php if ( comments_open() ) : ?>
			<p class="norvex-comments__intro"><?php esc_html_e( 'Join the conversation — we read every comment.', 'norvex' ); ?></p>
		<?php endif; ?>
	</div>

	<?php
	comment_form(
		array(
			'class_form'          => 'norvex-commentform',
			'class_submit'        => 'norvex-btn norvex-btn--primary',
			'label_submit'        => __( 'Post comment', 'norvex' ),
			'title_reply'         => __( 'Leave a comment', 'norvex' ),
			'title_reply_before'  => '<h3 id="reply-title" class="norvex-commentform__title">',
			'title_reply_after'   => '</h3>',
			'comment_notes_before' => '',
			'comment_notes_after' => '<p class="norvex-commentform__note">' . esc_html__( 'Anti-spam: comments are moderated before they appear.', 'norvex' ) . '</p>',
			'comment_field'       => '<p class="comment-form-comment"><label class="screen-reader-text" for="comment">' . esc_html__( 'Comment', 'norvex' ) . '</label><textarea id="comment" name="comment" rows="5" required placeholder="' . esc_attr__( 'Share your thoughts…', 'norvex' ) . '"></textarea></p>',
			'fields'              => array(
				'author' => '<div class="norvex-commentform__row"><p class="comment-form-author"><label class="screen-reader-text" for="author">' . esc_html__( 'Name', 'norvex' ) . '</label><input id="author" name="author" type="text" required placeholder="' . esc_attr__( 'Your name', 'norvex' ) . '" /></p>',
				'email'  => '<p class="comment-form-email"><label class="screen-reader-text" for="email">' . esc_html__( 'Email', 'norvex' ) . '</label><input id="email" name="email" type="email" required placeholder="' . esc_attr__( 'Email (won’t be published)', 'norvex' ) . '" /></p></div>',
			),
		)
	);
	?>

	<?php if ( have_comments() ) : ?>
		<ol class="norvex-commentlist">
			<?php
			wp_list_comments(
				array(
					'callback'    => 'norvex_comment',
					'style'       => 'ol',
					'avatar_size' => 48,
					'short_ping'  => true,
				)
			);
			?>
		</ol>

		<?php
		the_comments_pagination(
			array(
				'prev_text' => '&larr;',
				'next_text' => '&rarr;',
				'class'     => 'norvex-pagination',
			)
		);
		?>
	<?php endif; ?>

	<?php if ( ! comments_open() && $norvex_count ) : ?>
		<p class="norvex-comments__closed"><?php esc_html_e( 'Comments are closed.', 'norvex' ); ?></p>
	<?php endif; ?>

</section>
