/**
 * Norvex admin field builder.
 *
 * Turns the packages / process / FAQ / feature textareas on the Service and
 * Pricing-Plan editors into friendly repeatable fields. The original textarea
 * stays in the DOM (hidden) as the single source of truth: the builder parses
 * its value on load and re-serialises to the exact same text format on every
 * edit, so saving and front-end rendering are completely unchanged. A "raw
 * text" toggle reveals the underlying textarea for power users / no-JS.
 */
( function () {
	'use strict';

	var I18N = window.norvexBuilderI18n || {};
	function t( key, fallback ) {
		return I18N[ key ] || fallback;
	}

	/* ---------- tiny DOM helper ---------- */
	function el( tag, attrs, kids ) {
		var node = document.createElement( tag );
		if ( attrs ) {
			Object.keys( attrs ).forEach( function ( k ) {
				var v = attrs[ k ];
				if ( 'class' === k ) {
					node.className = v;
				} else if ( 'text' === k ) {
					node.textContent = v;
				} else if ( 'on' === k.slice( 0, 2 ) ) {
					node.addEventListener( k.slice( 2 ).toLowerCase(), v );
				} else {
					node.setAttribute( k, v );
				}
			} );
		}
		( kids || [] ).forEach( function ( c ) {
			if ( c ) {
				node.appendChild( 'string' === typeof c ? document.createTextNode( c ) : c );
			}
		} );
		return node;
	}

	function removeBtn( fn ) {
		return el( 'button', { type: 'button', class: 'norvex-b-remove', title: t( 'remove', 'Remove' ), 'aria-label': t( 'remove', 'Remove' ), text: '×', onClick: fn } );
	}
	function addBtn( label, fn ) {
		return el( 'button', { type: 'button', class: 'button norvex-b-add', onClick: fn }, [ '+ ' + label ] );
	}
	function fieldLabel( txt ) {
		return el( 'span', { class: 'norvex-b-label', text: txt } );
	}
	function focusLast( ui ) {
		var inputs = ui.querySelectorAll( '.norvex-b-input' );
		if ( inputs.length ) {
			inputs[ inputs.length - 1 ].focus();
		}
	}

	/* ---------- codecs: text format <-> model (must mirror the PHP parsers) ---------- */
	function splitLines( text ) {
		return String( text || '' ).split( /\r\n|\r|\n/ );
	}

	var PAIRS = {
		parse: function ( text ) {
			return splitLines( text ).filter( function ( l ) { return '' !== l.trim(); } ).map( function ( l ) {
				var i = l.indexOf( '::' );
				return i === -1 ? { a: l.trim(), b: '' } : { a: l.slice( 0, i ).trim(), b: l.slice( i + 2 ).trim() };
			} );
		},
		serialize: function ( rows ) {
			return rows.filter( function ( r ) { return '' !== ( r.a || '' ).trim() || '' !== ( r.b || '' ).trim(); } )
				.map( function ( r ) { return ( r.a || '' ).trim() + ' :: ' + ( r.b || '' ).trim(); } ).join( '\n' );
		},
		blank: function () { return { a: '', b: '' }; },
	};

	var LINES = {
		parse: function ( text ) {
			return splitLines( text ).map( function ( l ) { return l.trim(); } ).filter( function ( l ) { return '' !== l; } ).map( function ( l ) {
				var ex = '!' === l.charAt( 0 );
				return { text: ex ? l.replace( /^!+/, '' ).trim() : l, excluded: ex };
			} );
		},
		serialize: function ( rows ) {
			return rows.filter( function ( r ) { return '' !== ( r.text || '' ).trim(); } )
				.map( function ( r ) { return ( r.excluded ? '!' : '' ) + ( r.text || '' ).trim(); } ).join( '\n' );
		},
		blank: function () { return { text: '', excluded: false }; },
	};

	var PACKAGES = {
		parse: function ( text ) {
			var pkgs = [], cur = null;
			splitLines( text ).forEach( function ( raw ) {
				var line = raw.replace( /\s+$/, '' );
				if ( '' === line.trim() ) { return; }
				var lt = line.replace( /^\s+/, '' );
				if ( '==' === lt.slice( 0, 2 ) ) {
					if ( cur ) { pkgs.push( cur ); }
					var parts = lt.replace( /^[=\s]+/, '' ).split( '|' ).map( function ( p ) { return p.trim(); } );
					cur = { name: parts[ 0 ] || '', price: parts[ 1 ] || '', period: parts[ 2 ] || '', featured: !! ( parts[ 3 ] && '' !== parts[ 3 ].trim() ), was: parts[ 4 ] ? parts[ 4 ].trim() : '', desc: '', features: [] };
					return;
				}
				if ( ! cur ) { return; }
				if ( '-' === lt.charAt( 0 ) ) {
					var feat = lt.replace( /^-+\s*/, '' ).trim();
					var ex = '!' === feat.charAt( 0 );
					cur.features.push( { text: ex ? feat.replace( /^!+/, '' ).trim() : feat, excluded: ex } );
				} else if ( '' === cur.desc ) {
					cur.desc = line.trim();
				}
			} );
			if ( cur ) { pkgs.push( cur ); }
			return pkgs;
		},
		serialize: function ( pkgs ) {
			var out = [];
			pkgs.forEach( function ( p ) {
				var head = [ ( p.name || '' ).trim(), ( p.price || '' ).trim(), ( p.period || '' ).trim(), p.featured ? 'popular' : '', ( p.was || '' ).trim() ];
				while ( head.length > 3 && '' === head[ head.length - 1 ] ) { head.pop(); }
				out.push( '== ' + head.join( ' | ' ) );
				if ( '' !== ( p.desc || '' ).trim() ) { out.push( ( p.desc || '' ).trim() ); }
				( p.features || [] ).forEach( function ( f ) {
					if ( '' === ( f.text || '' ).trim() ) { return; }
					out.push( '- ' + ( f.excluded ? '!' : '' ) + ( f.text || '' ).trim() );
				} );
				out.push( '' );
			} );
			return out.join( '\n' ).replace( /\n+$/, '' );
		},
		blank: function () { return { name: '', price: '', period: '', featured: false, was: '', desc: '', features: [] }; },
	};

	var CODECS = { pairs: PAIRS, lines: LINES, packages: PACKAGES };

	/* ---------- renderers ---------- */
	var RENDER = {};

	RENDER.lines = function ( ui, model, cfg, sync, rerender ) {
		emptyNote( ui, model );
		model.forEach( function ( row, i ) {
			var input = el( 'input', { type: 'text', class: 'norvex-b-input', value: row.text || '', placeholder: cfg.placeholder || '', onInput: function ( e ) { row.text = e.target.value; sync(); } } );
			var kids = [ input ];
			if ( cfg.exclude ) {
				kids.push( checkbox( row, 'excluded', t( 'excluded', 'Not included' ), sync ) );
			}
			kids.push( removeBtn( function () { model.splice( i, 1 ); rerender(); } ) );
			ui.appendChild( el( 'div', { class: 'norvex-b-row' }, kids ) );
		} );
		ui.appendChild( addBtn( cfg.add || t( 'addRow', 'Add row' ), function () { model.push( LINES.blank() ); rerender(); focusLast( ui ); } ) );
	};

	RENDER.pairs = function ( ui, model, cfg, sync, rerender ) {
		emptyNote( ui, model );
		model.forEach( function ( row, i ) {
			var a = el( 'input', { type: 'text', class: 'norvex-b-input', value: row.a || '', placeholder: cfg.a || '', onInput: function ( e ) { row.a = e.target.value; sync(); } } );
			var b = el( 'textarea', { class: 'norvex-b-input norvex-b-textarea', rows: '2', placeholder: cfg.b || '', onInput: function ( e ) { row.b = e.target.value; sync(); } } );
			b.value = row.b || '';
			var body = el( 'div', { class: 'norvex-b-pair' }, [ a, b ] );
			ui.appendChild( el( 'div', { class: 'norvex-b-row norvex-b-row--pair' }, [ body, removeBtn( function () { model.splice( i, 1 ); rerender(); } ) ] ) );
		} );
		ui.appendChild( addBtn( cfg.add || t( 'addRow', 'Add row' ), function () { model.push( PAIRS.blank() ); rerender(); focusLast( ui ); } ) );
	};

	RENDER.packages = function ( ui, model, cfg, sync, rerender ) {
		emptyNote( ui, model );
		model.forEach( function ( pkg, i ) {
			var card = el( 'div', { class: 'norvex-b-pkg' + ( pkg.featured ? ' is-featured' : '' ) } );

			var name = textField( pkg, 'name', t( 'name', 'Package name' ), sync );
			var was = textField( pkg, 'was', t( 'was', 'Was price' ), sync );
			var price = textField( pkg, 'price', t( 'price', 'Price' ), sync );
			var period = textField( pkg, 'period', t( 'period', 'Period' ), sync );
			card.appendChild( el( 'div', { class: 'norvex-b-pkg-head' }, [
				el( 'div', { class: 'norvex-b-field norvex-b-grow' }, [ fieldLabel( t( 'name', 'Package name' ) ), name ] ),
				el( 'div', { class: 'norvex-b-field' }, [ fieldLabel( t( 'was', 'Was price' ) ), was ] ),
				el( 'div', { class: 'norvex-b-field' }, [ fieldLabel( t( 'price', 'Price' ) ), price ] ),
				el( 'div', { class: 'norvex-b-field' }, [ fieldLabel( t( 'period', 'Period' ) ), period ] ),
				removeBtn( function () { model.splice( i, 1 ); rerender(); } ),
			] ) );

			var desc = el( 'textarea', { class: 'norvex-b-input norvex-b-textarea', rows: '2', placeholder: t( 'desc', 'Short description' ), onInput: function ( e ) { pkg.desc = e.target.value; sync(); } } );
			desc.value = pkg.desc || '';
			card.appendChild( el( 'div', { class: 'norvex-b-field' }, [ fieldLabel( t( 'desc', 'Short description' ) ), desc ] ) );

			var popular = checkbox( pkg, 'featured', t( 'popular', 'Most popular' ), function () { card.classList.toggle( 'is-featured', pkg.featured ); sync(); } );
			card.appendChild( popular );

			if ( ! pkg.features ) { pkg.features = []; }
			var feats = el( 'div', { class: 'norvex-b-feats' }, [ fieldLabel( t( 'feature', 'Feature' ) + 's' ) ] );
			pkg.features.forEach( function ( f, fi ) {
				feats.appendChild( el( 'div', { class: 'norvex-b-row' }, [
					el( 'input', { type: 'text', class: 'norvex-b-input', value: f.text || '', placeholder: t( 'feature', 'Feature' ), onInput: function ( e ) { f.text = e.target.value; sync(); } } ),
					checkbox( f, 'excluded', t( 'excluded', 'Not included' ), sync ),
					removeBtn( function () { pkg.features.splice( fi, 1 ); rerender(); } ),
				] ) );
			} );
			feats.appendChild( addBtn( t( 'addFeature', 'Add feature' ), function () { pkg.features.push( LINES.blank() ); rerender(); } ) );
			card.appendChild( feats );

			ui.appendChild( card );
		} );
		ui.appendChild( addBtn( t( 'addPackage', 'Add package' ), function () { model.push( PACKAGES.blank() ); rerender(); } ) );
	};

	function emptyNote( ui, model ) {
		if ( ! model.length ) {
			ui.appendChild( el( 'p', { class: 'norvex-b-empty', text: t( 'empty', 'Nothing yet — click add to create your first one.' ) } ) );
		}
	}
	function textField( obj, prop, placeholder, sync ) {
		return el( 'input', { type: 'text', class: 'norvex-b-input', value: obj[ prop ] || '', placeholder: placeholder, onInput: function ( e ) { obj[ prop ] = e.target.value; sync(); } } );
	}
	function checkbox( obj, prop, label, sync ) {
		var box = el( 'input', { type: 'checkbox' } );
		box.checked = !! obj[ prop ];
		box.addEventListener( 'change', function ( e ) { obj[ prop ] = e.target.checked; sync(); } );
		return el( 'label', { class: 'norvex-b-check' }, [ box, el( 'span', { text: label } ) ] );
	}

	/* ---------- boot ---------- */
	function setup( wrap ) {
		var src = wrap.querySelector( '.norvex-builder-src' );
		if ( ! src ) { return; }
		var cfg = {};
		try { cfg = JSON.parse( wrap.getAttribute( 'data-norvex-builder' ) || '{}' ); } catch ( e ) { cfg = {}; }
		var kind = cfg.kind || 'lines';
		var codec = CODECS[ kind ];
		if ( ! codec || ! RENDER[ kind ] ) { return; }

		var model = codec.parse( src.value );
		src.style.display = 'none';
		var ui = el( 'div', { class: 'norvex-ui norvex-ui--' + kind } );
		wrap.insertBefore( ui, src );

		function sync() { src.value = codec.serialize( model ); }
		function rerender() { ui.innerHTML = ''; RENDER[ kind ]( ui, model, cfg, sync, rerender ); sync(); }
		rerender();

		var toggle = el( 'button', { type: 'button', class: 'button-link norvex-b-toggle', text: t( 'raw', 'Edit as raw text' ), onClick: function () {
			if ( 'none' === src.style.display ) {
				src.style.display = '';
				ui.style.display = 'none';
				toggle.textContent = t( 'visual', 'Back to the visual editor' );
			} else {
				model = codec.parse( src.value );
				rerender();
				src.style.display = 'none';
				ui.style.display = '';
				toggle.textContent = t( 'raw', 'Edit as raw text' );
			}
		} } );
		wrap.appendChild( toggle );
	}

	// Visual icon library for the single-value CPT "icon" field.
	function initIconField( wrap ) {
		var input = wrap.querySelector( '.norvex-icon-value' );
		if ( ! input ) { return; }
		var groups = window.norvexBuilderIcons || [];
		var open = false;

		function findIcon( v ) {
			for ( var a = 0; a < groups.length; a++ ) {
				for ( var b = 0; b < groups[ a ].icons.length; b++ ) {
					if ( groups[ a ].icons[ b ].value === v ) { return groups[ a ].icons[ b ]; }
				}
			}
			return null;
		}

		var ui = document.createElement( 'div' );
		wrap.appendChild( ui );

		function render() {
			ui.innerHTML = '';
			var current = input.value || '';
			var isCustom = '<' === current.charAt( 0 );
			var match = ( ! isCustom && current ) ? findIcon( current ) : null;
			var isText = ! isCustom && current && ! match;

			// Summary bar: preview + "Choose icon" toggle + a number/letter input.
			var bar = document.createElement( 'div' );
			bar.className = 'norvex-icon-bar';

			var preview = document.createElement( 'span' );
			preview.className = 'norvex-icon-preview';
			if ( match ) { preview.innerHTML = match.svg; }
			else if ( isText ) { preview.textContent = current; }
			else if ( isCustom ) { preview.textContent = 'SVG'; }
			else { preview.textContent = '—'; }
			bar.appendChild( preview );

			var toggle = document.createElement( 'button' );
			toggle.type = 'button';
			toggle.className = 'button norvex-icon-toggle';
			toggle.textContent = open ? t( 'closeicons', 'Close' ) : t( 'chooseicon', 'Choose icon' );
			toggle.addEventListener( 'click', function () { open = ! open; render(); } );
			bar.appendChild( toggle );

			var num = document.createElement( 'input' );
			num.type = 'text';
			num.className = 'norvex-icon-num';
			num.placeholder = t( 'ornumber', 'or a number / letter' );
			num.value = isText ? current : '';
			// Update value without a full re-render so the field keeps focus.
			num.addEventListener( 'input', function () {
				var v = num.value.trim();
				input.value = v;
				preview.innerHTML = '';
				preview.textContent = v || '—';
			} );
			bar.appendChild( num );
			ui.appendChild( bar );

			if ( ! open ) { return; }

			var none = document.createElement( 'button' );
			none.type = 'button';
			none.className = 'button norvex-icon-none' + ( current ? '' : ' button-primary' );
			none.textContent = t( 'noicon', 'No icon' );
			none.addEventListener( 'click', function () { input.value = ''; open = false; render(); } );

			var lib = document.createElement( 'div' );
			lib.className = 'norvex-iconlib';
			lib.appendChild( none );

			groups.forEach( function ( g ) {
				var cat = document.createElement( 'p' );
				cat.className = 'norvex-iconlib__cat';
				cat.textContent = g.label;
				lib.appendChild( cat );
				var grid = document.createElement( 'div' );
				grid.className = 'norvex-iconlib__grid';
				g.icons.forEach( function ( ic ) {
					var b = document.createElement( 'button' );
					b.type = 'button';
					b.title = ic.label;
					b.className = 'norvex-iconlib__btn' + ( match && current === ic.value ? ' is-selected' : '' );
					b.innerHTML = ic.svg;
					b.addEventListener( 'click', function () { input.value = ic.value; open = false; render(); } );
					grid.appendChild( b );
				} );
				lib.appendChild( grid );
			} );
			ui.appendChild( lib );

			var wrapc = document.createElement( 'div' );
			wrapc.className = 'norvex-icon-customwrap';
			var lbl = document.createElement( 'label' );
			lbl.className = 'norvex-b-label';
			lbl.textContent = t( 'customsvg', 'Custom SVG' );
			var ta = document.createElement( 'textarea' );
			ta.className = 'norvex-icon-custom';
			ta.rows = 3;
			ta.placeholder = '<svg ...>…</svg>';
			ta.value = isCustom ? current : '';
			ta.addEventListener( 'input', function () { input.value = ta.value.trim(); } );
			var hint = document.createElement( 'p' );
			hint.className = 'norvex-icon-hint';
			hint.textContent = t( 'svghint', 'Paste an SVG to use your own icon. Scripts are removed for safety.' );
			wrapc.appendChild( lbl );
			wrapc.appendChild( ta );
			wrapc.appendChild( hint );
			ui.appendChild( wrapc );
		}
		render();
	}

	document.addEventListener( 'DOMContentLoaded', function () {
		var nodes = document.querySelectorAll( '.norvex-builder' );
		for ( var i = 0; i < nodes.length; i++ ) {
			setup( nodes[ i ] );
		}
		var iconFields = document.querySelectorAll( '.norvex-icon-field' );
		for ( var j = 0; j < iconFields.length; j++ ) {
			initIconField( iconFields[ j ] );
		}
	} );

	// Exposed for extensibility / testing; not used by the UI itself.
	if ( typeof window !== 'undefined' ) {
		window.norvexBuilderCodecs = CODECS;
	}
} )();

