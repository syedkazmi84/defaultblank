/* Norvex theme scripts */
(function () {
	'use strict';

	document.addEventListener('DOMContentLoaded', function () {

		/* ---- Mobile navigation toggle ---- */
		var toggle = document.querySelector('.norvex-nav-toggle');
		var nav = document.getElementById('norvex-primary-nav');

		if (toggle && nav) {
			toggle.addEventListener('click', function () {
				var open = nav.classList.toggle('is-open');
				toggle.setAttribute('aria-expanded', open ? 'true' : 'false');
			});

			/* Close menu when a real link (not a parent toggle) is tapped */
			nav.querySelectorAll('a').forEach(function (link) {
				link.addEventListener('click', function () {
					if (window.innerWidth <= 760 && !link.parentElement.classList.contains('menu-item-has-children')) {
						nav.classList.remove('is-open');
						toggle.setAttribute('aria-expanded', 'false');
					}
				});
			});
		}

		/* ---- Cookie consent (GDPR) ---- */
		var cookieBar = document.getElementById('norvex-cookie');
		if (cookieBar) {
			var readConsent = function () {
				var m = document.cookie.match(/(?:^|;\s*)norvex_cookie_consent=([^;]+)/);
				return m ? m[1] : '';
			};
			if (readConsent()) {
				/* A cached page served the pre-consent bar after a choice was made. */
				if (cookieBar.parentNode) { cookieBar.parentNode.removeChild(cookieBar); }
			} else {
				var storeConsent = function (value) {
					var d = new Date();
					d.setTime(d.getTime() + 183 * 24 * 60 * 60 * 1000); // ~6 months.
					var secure = location.protocol === 'https:' ? '; Secure' : '';
					document.cookie = 'norvex_cookie_consent=' + value + '; expires=' + d.toUTCString() + '; path=/; SameSite=Lax' + secure;
				};
				cookieBar.querySelectorAll('[data-norvex-cookie]').forEach(function (btn) {
					btn.addEventListener('click', function () {
						var choice = btn.getAttribute('data-norvex-cookie') === 'accept' ? 'accept' : 'decline';
						storeConsent(choice);
						cookieBar.classList.add('is-hidden');
						window.setTimeout(function () {
							if (cookieBar.parentNode) { cookieBar.parentNode.removeChild(cookieBar); }
						}, 300);
						document.dispatchEvent(new CustomEvent('norvex:cookie-consent', { detail: choice }));
					});
				});
			}
		}

		/* ---- Google Ads click id (GCLID) capture ---- */
		(function () {
			/* Respect a "decline" cookie-consent choice — store nothing. */
			var consent = (document.cookie.match(/(?:^|;\s*)norvex_cookie_consent=([^;]+)/) || [])[1];
			if (consent === 'decline') { return; }
			var params = new URLSearchParams(location.search);
			var fromUrl = params.get('gclid') || params.get('gbraid') || params.get('wbraid') || '';
			if (fromUrl) {
				fromUrl = fromUrl.replace(/[^A-Za-z0-9._-]/g, '').slice(0, 200);
				var d = new Date();
				d.setTime(d.getTime() + 90 * 24 * 60 * 60 * 1000); // 90 days.
				var secure = location.protocol === 'https:' ? '; Secure' : '';
				document.cookie = 'norvex_gclid=' + fromUrl + '; expires=' + d.toUTCString() + '; path=/; SameSite=Lax' + secure;
			}
			var stored = fromUrl || (document.cookie.match(/(?:^|;\s*)norvex_gclid=([^;]+)/) || [])[1] || '';
			if (stored) {
				document.querySelectorAll('input[data-norvex-gclid]').forEach(function (input) {
					input.value = stored;
				});
			}
		})();

		/* ---- Lightweight count-up for stat numbers ---- */
		var counters = document.querySelectorAll('[data-count]');
		if (counters.length && 'IntersectionObserver' in window) {
			var io = new IntersectionObserver(function (entries) {
				entries.forEach(function (entry) {
					if (!entry.isIntersecting) return;
					var el = entry.target;
					var target = parseFloat(el.getAttribute('data-count'));
					var suffix = el.getAttribute('data-suffix') || '';
					var dur = 1400, start = null;
					function step(ts) {
						if (!start) start = ts;
						var p = Math.min((ts - start) / dur, 1);
						var val = Math.floor(p * target);
						el.textContent = val.toLocaleString() + suffix;
						if (p < 1) requestAnimationFrame(step);
						else el.textContent = target.toLocaleString() + suffix;
					}
					requestAnimationFrame(step);
					io.unobserve(el);
				});
			}, { threshold: 0.4 });
			counters.forEach(function (c) { io.observe(c); });
		}

		/* ---- Footer newsletter: submit without reloading ----
		   The form posts for real (PHP handles it and redirects back to the
		   #norvex-news anchor for no-JS visitors). When JS and fetch are available we
		   intercept the submit, post it in the background and show the result
		   inline — so subscribing no longer scrolls the page down to the footer. */
		var newsCfg = window.norvexNews;
		if (newsCfg && newsCfg.ajaxUrl && window.fetch && window.FormData) {
			document.querySelectorAll('form.norvex-newsletter').forEach(function (form) {
				form.addEventListener('submit', function (e) {
					e.preventDefault();

					var btn = form.querySelector('button[type="submit"]');
					var data = new FormData(form);
					data.append('action', 'norvex_newsletter');

					if (btn) { btn.disabled = true; }

					fetch(newsCfg.ajaxUrl, {
						method: 'POST',
						body: data,
						credentials: 'same-origin'
					})
						.then(function (res) { return res.json(); })
						.then(function (payload) {
							showNewsletterNote(form, payload.status, payload.message);
							if (payload.status === 'ok') {
								form.reset();
								// Fire the lead conversion (GA4 / Meta / dataLayer). The
								// no-JS path fires server-side; this covers the AJAX submit.
								if (window.norvexTrackConversion) { window.norvexTrackConversion('newsletter'); }
							}
							if (btn) { btn.disabled = false; }
						})
						.catch(function () {
							// Network/parse failure: fall back to a normal submit.
							if (btn) { btn.disabled = false; }
							form.submit();
						});
				});
			});
		}

		function showNewsletterNote(form, status, message) {
			var parent = form.parentNode;
			var note = parent.querySelector('.norvex-form__note');
			if (!note) {
				note = document.createElement('p');
				note.className = 'norvex-form__note';
				note.style.fontSize = '.85rem';
				note.style.marginTop = '10px';
				parent.insertBefore(note, form.nextSibling);
			}
			note.className = 'norvex-form__note norvex-form__note--' + status;
			note.style.color = status === 'ok' ? 'var(--norvex-gold)' : 'var(--norvex-burgundy)';
			note.textContent = message;
			note.style.display = 'block';
		}

		/* ---- Header: add a shadow once the page is scrolled ---- */
		var header = document.querySelector('.norvex-header');
		if (header) {
			var onScroll = function () {
				header.classList.toggle('is-stuck', (window.pageYOffset || document.documentElement.scrollTop) > 40);
			};
			onScroll();
			window.addEventListener('scroll', onScroll, { passive: true });
		}

		/* ---- Estimate / quote calculator ---- */
		document.querySelectorAll('.norvex-estimate').forEach(function (widget) {
			var currency = widget.getAttribute('data-currency') || '$';
			var wordsInput = widget.querySelector('.norvex-estimate__words');
			var toggles = widget.querySelectorAll('.norvex-estimate__toggle');
			var totalEl = widget.querySelector('.norvex-estimate__total');
			var rangeEl = widget.querySelector('.norvex-estimate__range');
			if (!totalEl || !toggles.length) return;

			function money(n) {
				return currency + Math.round(n).toLocaleString();
			}

			function recalc() {
				var words = Math.max(0, parseInt(wordsInput && wordsInput.value, 10) || 0);
				var total = 0;
				var any = false;
				toggles.forEach(function (t) {
					if (!t.checked) return;
					any = true;
					var price = parseFloat(t.getAttribute('data-price')) || 0;
					total += t.getAttribute('data-type') === 'word' ? price * words : price;
				});

				if (!any || total <= 0) {
					totalEl.textContent = totalEl.getAttribute('data-empty') || (currency + '0');
					if (rangeEl) rangeEl.textContent = '';
					return;
				}

				totalEl.textContent = money(total);
				/* Communicate that it's a ballpark by showing a +/-15% range. */
				if (rangeEl) {
					rangeEl.textContent = money(total * 0.85) + ' – ' + money(total * 1.15);
				}
			}

			toggles.forEach(function (t) { t.addEventListener('change', recalc); });
			if (wordsInput) {
				wordsInput.addEventListener('input', recalc);
				wordsInput.addEventListener('change', recalc);
			}
			recalc();
		});

		/* ---- Continuous logo marquee (duplicate items for a seamless loop) ---- */
		var logos = document.querySelector('.norvex-logos');
		if (logos) {
			var track = logos.querySelector('ul');
			if (track && track.children.length > 1) {
				logos.classList.add('norvex-logos--marquee');
				var frag = document.createDocumentFragment();
				[].forEach.call(track.children, function (li) {
					var clone = li.cloneNode(true);
					clone.setAttribute('aria-hidden', 'true');
					frag.appendChild(clone);
				});
				track.appendChild(frag);
			}
		}

		/* ---- Journal category filter tabs ---- */
		document.querySelectorAll('.norvex-filter').forEach(function (bar) {
			var scope = bar.closest('.norvex-wrap') || document;
			var cards = scope.querySelectorAll('.norvex-jcard, .norvex-result');
			var empty = scope.querySelector('.norvex-filter__empty');
			var tabs = bar.querySelectorAll('.norvex-filter__tab');

			bar.addEventListener('click', function (e) {
				var tab = e.target.closest('.norvex-filter__tab');
				if (!tab) return;

				tabs.forEach(function (t) { t.classList.remove('is-active'); });
				tab.classList.add('is-active');

				var filter = tab.getAttribute('data-filter');
				var shown = 0;
				cards.forEach(function (card) {
					var cats = (card.getAttribute('data-cats') || '').split(/\s+/);
					var match = (filter === '*') || cats.indexOf(filter) !== -1;
					card.hidden = !match;
					if (match) shown++;
				});
				if (empty) { empty.hidden = shown !== 0; }
			});
		});

		/* ---- Copy-link button (single post share rail) ---- */
		document.querySelectorAll('.norvex-share__copy').forEach(function (btn) {
			btn.addEventListener('click', function () {
				var url = btn.getAttribute('data-url') || window.location.href;
				var done = function () {
					btn.classList.add('is-copied');
					setTimeout(function () { btn.classList.remove('is-copied'); }, 1600);
				};
				if (navigator.clipboard && navigator.clipboard.writeText) {
					navigator.clipboard.writeText(url).then(done).catch(done);
				} else {
					var t = document.createElement('textarea');
					t.value = url; document.body.appendChild(t); t.select();
					try { document.execCommand('copy'); } catch (e) {}
					document.body.removeChild(t); done();
				}
			});
		});

		/* ---- Scroll-reveal: fade/slide sections in as they enter the viewport ---- */
		var reduce = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;
		if (!reduce && 'IntersectionObserver' in window) {
			var revealSel = '.norvex-section-head, .norvex-card, .norvex-pstep, .norvex-plan, .norvex-book, .norvex-member, .norvex-quote, .norvex-article, .norvex-split > *, .norvex-feature, .norvex-cta, .norvex-consult__text, .norvex-consult__actions, .norvex-stat-lg, .norvex-faq details';
			var vh = window.innerHeight || document.documentElement.clientHeight || 800;
			var counts = {};
			var gid = 0;
			var revObs = new IntersectionObserver(function (entries) {
				entries.forEach(function (e) {
					if (e.isIntersecting) {
						e.target.classList.add('is-visible');
						revObs.unobserve(e.target);
					}
				});
			}, { threshold: 0.12, rootMargin: '0px 0px -6% 0px' });

			[].forEach.call(document.querySelectorAll(revealSel), function (el) {
				if (el.closest && el.closest('.norvex-hero')) { return; } // hero has its own entrance
				if (el.closest && el.closest('[data-norvex-carousel]')) { return; } // carousel items stay visible (no entrance fade)
				var rect = el.getBoundingClientRect();
				if (rect.top < vh * 0.85) { return; }                // already visible on load — no flash
				var parent = el.parentNode;
				if (!parent.__norvexId) { parent.__norvexId = ++gid; }
				var key = parent.__norvexId;
				var n = counts[key] || 0;
				counts[key] = n + 1;
				el.style.transitionDelay = Math.min(n * 70, 350) + 'ms';
				el.classList.add('norvex-reveal');
				revObs.observe(el);
			});
		}

		/* ---- Carousel: turn any grid marked data-norvex-carousel into a slider ---- */
		var CAROUSEL_ARROW = '<svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M5 12h14"/><path d="m12 5 7 7-7 7"/></svg>';

		Array.prototype.forEach.call(document.querySelectorAll('[data-norvex-carousel]'), function (track) {
			if (track.getAttribute('data-norvex-init') || track.children.length === 0) { return; }
			track.setAttribute('data-norvex-init', '1');

			var wrap = document.createElement('div');
			wrap.className = 'norvex-carousel';
			track.parentNode.insertBefore(wrap, track);
			wrap.appendChild(track);

			function mkBtn(cls, label) {
				var b = document.createElement('button');
				b.type = 'button';
				b.className = 'norvex-carousel__btn ' + cls;
				b.setAttribute('aria-label', label);
				b.innerHTML = CAROUSEL_ARROW;
				return b;
			}
			var prev = mkBtn('norvex-carousel__prev', 'Previous');
			var next = mkBtn('norvex-carousel__next', 'Next');
			var dots = document.createElement('div');
			dots.className = 'norvex-carousel__dots';
			wrap.appendChild(prev);
			wrap.appendChild(next);
			wrap.appendChild(dots);

			function step() {
				var first = track.children[0];
				if (!first) { return track.clientWidth; }
				var cs = getComputedStyle(track);
				var gap = parseFloat(cs.columnGap || cs.gap || '0') || 0;
				return first.getBoundingClientRect().width + gap;
			}
			function perView() { return Math.max(1, Math.round(track.clientWidth / step())); }

			prev.addEventListener('click', function () { track.scrollBy({ left: -step() * perView(), behavior: 'smooth' }); });
			next.addEventListener('click', function () { track.scrollBy({ left: step() * perView(), behavior: 'smooth' }); });

			function update() {
				var pv = perView();
				var idx = Math.round(track.scrollLeft / (step() * pv));
				Array.prototype.forEach.call(dots.children, function (d, i) { d.classList.toggle('is-active', i === idx); });
				prev.disabled = track.scrollLeft <= 2;
				next.disabled = track.scrollLeft + track.clientWidth >= track.scrollWidth - 2;
			}
			function build() {
				dots.innerHTML = '';
				var pages = Math.max(1, Math.ceil(track.children.length / perView()));
				for (var i = 0; i < pages; i++) {
					(function (i) {
						var d = document.createElement('button');
						d.type = 'button';
						d.className = 'norvex-carousel__dot';
						d.setAttribute('aria-label', 'Go to slide ' + (i + 1));
						d.addEventListener('click', function () { track.scrollTo({ left: i * perView() * step(), behavior: 'smooth' }); });
						dots.appendChild(d);
					})(i);
				}
				update();
			}
			var raf;
			track.addEventListener('scroll', function () { window.cancelAnimationFrame(raf); raf = window.requestAnimationFrame(update); });
			var rt;
			window.addEventListener('resize', function () { clearTimeout(rt); rt = setTimeout(build, 150); });
			build();
		});

		/* ---- Tabs: click / keyboard switching for the Norvex Tabs block ---- */
		Array.prototype.forEach.call(document.querySelectorAll('[data-norvex-tabs]'), function (root) {
			var tabs = [].slice.call(root.querySelectorAll('.norvex-tabs__tab'));
			var panels = [].slice.call(root.querySelectorAll('.norvex-tabs__panel'));
			if (!tabs.length) { return; }
			function activate(idx, focus) {
				tabs.forEach(function (tab, i) {
					var on = i === idx;
					tab.classList.toggle('is-active', on);
					tab.setAttribute('aria-selected', on ? 'true' : 'false');
					tab.setAttribute('tabindex', on ? '0' : '-1');
					if (on && focus) { tab.focus(); }
				});
				panels.forEach(function (panel, i) {
					var on = i === idx;
					panel.classList.toggle('is-active', on);
					if (on) { panel.removeAttribute('hidden'); } else { panel.setAttribute('hidden', ''); }
				});
			}
			tabs.forEach(function (tab, i) {
				tab.addEventListener('click', function () { activate(i, false); });
				tab.addEventListener('keydown', function (e) {
					var idx = -1;
					if (e.key === 'ArrowRight' || e.key === 'ArrowDown') { idx = (i + 1) % tabs.length; }
					else if (e.key === 'ArrowLeft' || e.key === 'ArrowUp') { idx = (i - 1 + tabs.length) % tabs.length; }
					else if (e.key === 'Home') { idx = 0; }
					else if (e.key === 'End') { idx = tabs.length - 1; }
					if (idx > -1) { e.preventDefault(); activate(idx, true); }
				});
			});
		});

	});
})();
