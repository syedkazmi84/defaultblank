<?php
/**
 * Template Name: Portfolio Page
 *
 * Renders the book portfolio (the `book` post type) as a grid on any Page this
 * template is assigned to. The page's own title and excerpt drive the hero, so
 * no extra custom fields are required. If no projects exist yet, a set of
 * sample covers is shown so the layout still reads.
 *
 * @package Norvex
 */

get_header();

$norvex_lead = has_excerpt() ? get_the_excerpt() : __( 'A selection of the books we’ve written, edited, designed, published and marketed with our authors.', 'norvex' );
?>
<section class="norvex-page-hero">
	<div class="norvex-wrap">
		<?php norvex_breadcrumb(); ?>
		<h1><?php norvex_hero_title( get_the_title() ); ?></h1>
		<p><?php echo esc_html( $norvex_lead ); ?></p>
	</div>
</section>

<section class="norvex-section">
	<div class="norvex-wrap">

		<?php
		// Category filter row (portfolio genres).
		$norvex_genres = get_terms( array( 'taxonomy' => 'genre', 'hide_empty' => true ) );
		if ( $norvex_genres && ! is_wp_error( $norvex_genres ) ) :
			?>
			<div class="norvex-center" style="margin-bottom:44px;display:flex;gap:10px;flex-wrap:wrap;justify-content:center;">
				<a class="norvex-badge-soft" href="<?php echo esc_url( get_post_type_archive_link( 'book' ) ); ?>"><?php esc_html_e( 'All', 'norvex' ); ?></a>
				<?php foreach ( $norvex_genres as $norvex_g ) : ?>
					<a class="norvex-badge-soft" href="<?php echo esc_url( get_term_link( $norvex_g ) ); ?>"><?php echo esc_html( $norvex_g->name ); ?></a>
				<?php endforeach; ?>
			</div>
		<?php endif; ?>

		<div class="norvex-books">
			<?php
			$norvex_books = new WP_Query(
				array(
					'post_type'      => 'book',
					'posts_per_page' => 12,
					'orderby'        => 'menu_order',
					'order'          => 'ASC',
				)
			);
			if ( $norvex_books->have_posts() ) :
				while ( $norvex_books->have_posts() ) :
					$norvex_books->the_post();
					get_template_part( 'template-parts/book', 'card' );
				endwhile;
				wp_reset_postdata();
			else :
				// Static fallback covers so the page still reads before any projects exist.
				for ( $norvex_i = 1; $norvex_i <= 6; $norvex_i++ ) {
					echo '<article class="norvex-book"><div class="norvex-book__cover"><img src="' . norvex_img( 'cover-' . $norvex_i . '.svg' ) . '" alt="" loading="lazy" /></div><h3>' . esc_html__( 'Sample Title', 'norvex' ) . '</h3><p class="norvex-book__author">' . esc_html__( 'Author Name', 'norvex' ) . '</p></article>';
				}
			endif;
			?>
		</div>
	</div>
</section>

<?php
get_template_part( 'template-parts/cta' );
get_footer();
