<?php
/**
 * Category archive — Journal-style layout (see template-parts/term-archive.php).
 *
 * @package Norvex
 */

get_header();
get_template_part( 'template-parts/term-archive', null, array( 'badge' => __( 'Category', 'norvex' ) ) );
get_footer();
