<?php
/**
 * Search form.
 *
 * @package Norvex
 */

?>
<form role="search" method="get" class="norvex-searchform" action="<?php echo esc_url( home_url( '/' ) ); ?>">
	<label class="screen-reader-text" for="norvex-s"><?php esc_html_e( 'Search for:', 'norvex' ); ?></label>
	<div style="display:flex;gap:8px;">
		<input type="search" id="norvex-s" class="norvex-input" placeholder="<?php esc_attr_e( 'Search…', 'norvex' ); ?>" value="<?php echo get_search_query(); ?>" name="s" />
		<button type="submit" class="norvex-btn norvex-btn--primary" aria-label="<?php esc_attr_e( 'Search', 'norvex' ); ?>"><?php norvex_icon( 'search' ); ?></button>
	</div>
</form>
