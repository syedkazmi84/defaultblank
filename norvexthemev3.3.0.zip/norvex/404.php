<?php
/**
 * 404 template.
 *
 * @package Norvex
 */

get_header();
?>
<section class="norvex-page-hero">
	<div class="norvex-wrap">
		<h1><?php esc_html_e( '404', 'norvex' ); ?></h1>
		<p><?php esc_html_e( 'This page has wandered off the shelf.', 'norvex' ); ?></p>
	</div>
</section>

<section class="norvex-section">
	<div class="norvex-wrap norvex-center">
		<p class="norvex-lead" style="margin:0 auto 26px;"><?php esc_html_e( 'The page you’re looking for doesn’t exist or has moved. Try a search, or head back to safe ground.', 'norvex' ); ?></p>
		<div style="max-width:460px;margin:0 auto 30px;"><?php get_search_form(); ?></div>
		<a class="norvex-btn norvex-btn--primary" href="<?php echo esc_url( home_url( '/' ) ); ?>"><?php esc_html_e( 'Back to home', 'norvex' ); ?></a>
	</div>
</section>
<?php
get_footer();
