<?php
/**
 * Front page.
 *
 * The homepage is built from editable Norvex blocks stored in a static
 * "Home" page (created by the demo importer, or by you). When a static page is
 * set as the site's front page we simply render its block content inside the
 * site chrome.
 *
 * On a fresh install — before the demo is imported and with no static front
 * page configured — we do NOT invent a homepage. We fall back to the standard
 * blog index so the site behaves like a normal, empty WordPress install until
 * you import the demo or build your own front page.
 *
 * @package Norvex
 */

// No static front page configured yet: behave like the blog index.
if ( 'page' !== get_option( 'show_on_front' ) || ! get_option( 'page_on_front' ) ) {
	get_template_part( 'index' );
	return;
}

get_header();

while ( have_posts() ) :
	the_post();
	do_action( 'norvex_before_entry_content' );
	$norvex_content = get_the_content();
	if ( '' !== trim( $norvex_content ) ) {
		the_content();
	} else {
		// A static Home page exists but is empty — render the default section
		// blocks so the front page is never blank.
		echo do_blocks( norvex_default_homepage_blocks() ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
	}
	do_action( 'norvex_after_entry_content' );
endwhile;

get_footer();
