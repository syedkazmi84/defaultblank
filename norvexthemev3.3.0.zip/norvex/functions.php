<?php
/**
 * Norvex functions and definitions.
 *
 * @package Norvex
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'NORVEX_VERSION', '3.3.0' );
// Bump this when the bundled demo content changes so existing sites refresh it.
define( 'NORVEX_CONTENT_VERSION', '15' );
define( 'NORVEX_DIR', get_template_directory() );
define( 'NORVEX_URI', get_template_directory_uri() );

/**
 * Theme setup.
 */
function norvex_setup() {
	load_theme_textdomain( 'norvex', NORVEX_DIR . '/languages' );

	add_theme_support( 'automatic-feed-links' );
	add_theme_support( 'title-tag' );
	add_theme_support( 'post-thumbnails' );
	add_theme_support( 'customize-selective-refresh-widgets' );
	add_theme_support( 'responsive-embeds' );
	add_theme_support( 'align-wide' );
	add_theme_support( 'editor-styles' );
	add_editor_style( array( 'assets/css/fonts.css', 'assets/css/theme.css', 'assets/css/editor-style.css' ) );

	add_theme_support(
		'html5',
		array( 'search-form', 'comment-form', 'comment-list', 'gallery', 'caption', 'style', 'script', 'navigation-widgets' )
	);

	add_theme_support(
		'custom-logo',
		array(
			'height'      => 60,
			'width'       => 220,
			'flex-height' => true,
			'flex-width'  => true,
		)
	);

	add_theme_support(
		'custom-background',
		array( 'default-color' => 'E9E1CE' )
	);

	// Custom image sizes for the catalog and blog.
	add_image_size( 'norvex-cover', 480, 700, true );
	add_image_size( 'norvex-card', 720, 405, true );

	register_nav_menus(
		array(
			'primary' => __( 'Primary Menu', 'norvex' ),
			'footer'  => __( 'Footer Menu', 'norvex' ),
		)
	);
}
add_action( 'after_setup_theme', 'norvex_setup' );

/**
 * Content width.
 */
function norvex_content_width() {
	$GLOBALS['content_width'] = apply_filters( 'norvex_content_width', 1160 );
}
add_action( 'after_setup_theme', 'norvex_content_width', 0 );

/**
 * Enqueue styles and scripts.
 */
function norvex_assets() {
	// Self-hosted webfonts (Playfair Display + Inter). Bundled locally instead
	// of loading from Google's servers at runtime — better privacy (GDPR) and
	// no render-blocking third-party request. System fonts are the CSS fallback.
	wp_enqueue_style( 'norvex-fonts', NORVEX_URI . '/assets/css/fonts.css', array(), NORVEX_VERSION );

	wp_enqueue_style( 'norvex-base', get_stylesheet_uri(), array( 'norvex-fonts' ), NORVEX_VERSION );
	wp_enqueue_style( 'norvex-theme', NORVEX_URI . '/assets/css/theme.css', array( 'norvex-base' ), NORVEX_VERSION );

	wp_enqueue_script( 'norvex-theme', NORVEX_URI . '/assets/js/theme.js', array(), NORVEX_VERSION, true );

	// Endpoint for the footer newsletter form's AJAX submit (keeps the page from
	// jumping to the footer anchor on subscribe).
	wp_localize_script(
		'norvex-theme',
		'norvexNews',
		array( 'ajaxUrl' => admin_url( 'admin-ajax.php' ) )
	);

	if ( is_singular() && comments_open() && get_option( 'thread_comments' ) ) {
		wp_enqueue_script( 'comment-reply' );
	}
}
add_action( 'wp_enqueue_scripts', 'norvex_assets' );

/**
 * Register widget areas.
 */
function norvex_widgets_init() {
	register_sidebar(
		array(
			'name'          => __( 'Blog Sidebar', 'norvex' ),
			'id'            => 'sidebar-1',
			'description'   => __( 'Widgets shown alongside blog posts and archives.', 'norvex' ),
			'before_widget' => '<section id="%1$s" class="widget %2$s">',
			'after_widget'  => '</section>',
			'before_title'  => '<h3 class="widget-title">',
			'after_title'   => '</h3>',
		)
	);

	register_sidebar(
		array(
			'name'          => __( 'Article Sidebar', 'norvex' ),
			'id'            => 'article-sidebar',
			'description'   => __( 'Widgets shown in the single post sidebar, below the “In this article” list. Leave empty to show the default “Ready to publish?” call-to-action.', 'norvex' ),
			'before_widget' => '<section id="%1$s" class="widget norvex-post-widget %2$s">',
			'after_widget'  => '</section>',
			'before_title'  => '<h3 class="norvex-post-widget__title">',
			'after_title'   => '</h3>',
		)
	);

	for ( $i = 1; $i <= 4; $i++ ) {
		register_sidebar(
			array(
				/* translators: %d: footer column number. */
				'name'          => sprintf( __( 'Footer Column %d', 'norvex' ), $i ),
				'id'            => 'footer-' . $i,
				'description'   => __( 'Optional footer widget column.', 'norvex' ),
				'before_widget' => '<section id="%1$s" class="widget %2$s">',
				'after_widget'  => '</section>',
				'before_title'  => '<h4 class="widget-title">',
				'after_title'   => '</h4>',
			)
		);
	}
}
add_action( 'widgets_init', 'norvex_widgets_init' );

/**
 * Body classes.
 */
function norvex_body_classes( $classes ) {
	if ( ! is_singular() ) {
		$classes[] = 'norvex-archive-view';
	}
	if ( is_page_template() ) {
		$classes[] = 'norvex-has-template';
	}
	return $classes;
}
add_filter( 'body_class', 'norvex_body_classes' );

/**
 * Custom excerpt length & more string.
 */
function norvex_excerpt_length( $length ) {
	return 26;
}
add_filter( 'excerpt_length', 'norvex_excerpt_length' );

function norvex_excerpt_more( $more ) {
	return '&hellip;';
}
add_filter( 'excerpt_more', 'norvex_excerpt_more' );

/**
 * Includes.
 */
require NORVEX_DIR . '/inc/template-tags.php';
require NORVEX_DIR . '/inc/hooks.php';
require NORVEX_DIR . '/inc/seo.php';
require NORVEX_DIR . '/inc/content-types.php';
require NORVEX_DIR . '/inc/cpt-book.php';
require NORVEX_DIR . '/inc/blocks.php';
require NORVEX_DIR . '/inc/building-blocks.php';
require NORVEX_DIR . '/inc/elements.php';
if ( is_admin() ) {
	require NORVEX_DIR . '/inc/admin-menu.php';
}
require NORVEX_DIR . '/inc/customizer.php';
require NORVEX_DIR . '/inc/customizer-design.php';
require NORVEX_DIR . '/inc/contact-form.php';
require NORVEX_DIR . '/inc/leads.php';
require NORVEX_DIR . '/inc/newsletter.php';
require NORVEX_DIR . '/inc/smtp.php';
require NORVEX_DIR . '/inc/cookie-consent.php';
require NORVEX_DIR . '/inc/gclid.php';
require NORVEX_DIR . '/inc/marketing.php';
require NORVEX_DIR . '/inc/sitemap.php';
require NORVEX_DIR . '/inc/footer-settings.php';
require NORVEX_DIR . '/inc/demo-content.php';
require NORVEX_DIR . '/inc/demo-blocks.php';
require NORVEX_DIR . '/inc/patterns.php';
