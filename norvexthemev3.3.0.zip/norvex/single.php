<?php
/**
 * Single blog post — the Journal article layout: a dark hero with the
 * category, title, dek and author byline; an overlapping featured image; the
 * article body flanked by a share rail and an "In this article" + CTA sidebar;
 * tags, an author bio and a "Keep reading" related-posts row.
 *
 * @package Norvex
 */

get_header();

while ( have_posts() ) :
	the_post();

	$norvex_cats        = get_the_category();
	$norvex_cat         = $norvex_cats ? $norvex_cats[0] : null;
	$norvex_author      = get_the_author();
	$norvex_author_id   = (int) get_the_author_meta( 'ID' );
	$norvex_contact     = esc_url( get_permalink( get_page_by_path( 'contact' ) ) );
	$norvex_posts_page  = get_option( 'page_for_posts' );
	$norvex_journal_url = $norvex_posts_page ? get_permalink( $norvex_posts_page ) : home_url( '/' );
	$norvex_permalink   = get_permalink();
	$norvex_share_title = rawurlencode( get_the_title() );
	$norvex_share_url   = rawurlencode( $norvex_permalink );

	// Add heading anchors and collect a table of contents from the content.
	$norvex_toc = norvex_post_toc( apply_filters( 'the_content', get_the_content() ) );
	?>

	<!-- Article hero -->
	<section class="norvex-page-hero norvex-post-hero">
		<div class="norvex-wrap norvex-post-hero__inner">
			<?php norvex_breadcrumb(); ?>
			<div class="norvex-post-hero__meta">
				<?php if ( $norvex_cat ) : ?>
					<a class="norvex-article__cat" href="<?php echo esc_url( get_category_link( $norvex_cat->term_id ) ); ?>"><?php echo esc_html( $norvex_cat->name ); ?></a>
				<?php endif; ?>
				<span><?php echo esc_html( norvex_reading_time() ); ?></span>
			</div>
			<h1><?php norvex_hero_title( get_the_title() ); ?></h1>
			<?php if ( has_excerpt() ) : ?>
				<p class="norvex-post-hero__dek"><?php echo esc_html( get_the_excerpt() ); ?></p>
			<?php endif; ?>
			<div class="norvex-post-byline">
				<?php echo get_avatar( $norvex_author_id, 44, '', $norvex_author, array( 'class' => 'norvex-post-byline__avatar' ) ); ?>
				<div class="norvex-post-byline__who">
					<strong><?php echo esc_html( $norvex_author ); ?></strong>
					<span><?php echo esc_html( get_the_date() ); ?></span>
				</div>
			</div>
		</div>
	</section>

	<?php if ( has_post_thumbnail() ) : ?>
		<div class="norvex-wrap">
			<figure class="norvex-post-figure"><?php the_post_thumbnail( 'large' ); ?></figure>
		</div>
	<?php endif; ?>

	<section class="norvex-section norvex-section--tight">
		<div class="norvex-wrap">
			<div class="norvex-post-layout<?php echo has_post_thumbnail() ? '' : ' norvex-post-layout--nofig'; ?>">

				<!-- Share rail -->
				<aside class="norvex-share" aria-label="<?php esc_attr_e( 'Share this article', 'norvex' ); ?>">
					<a class="norvex-share__link" href="https://twitter.com/intent/tweet?text=<?php echo $norvex_share_title; ?>&amp;url=<?php echo $norvex_share_url; ?>" target="_blank" rel="noopener noreferrer" aria-label="<?php esc_attr_e( 'Share on X', 'norvex' ); ?>"><?php norvex_icon( 'twitter' ); ?></a>
					<a class="norvex-share__link" href="https://www.linkedin.com/sharing/share-offsite/?url=<?php echo $norvex_share_url; ?>" target="_blank" rel="noopener noreferrer" aria-label="<?php esc_attr_e( 'Share on LinkedIn', 'norvex' ); ?>"><?php norvex_icon( 'linkedin' ); ?></a>
					<a class="norvex-share__link" href="https://www.facebook.com/sharer/sharer.php?u=<?php echo $norvex_share_url; ?>" target="_blank" rel="noopener noreferrer" aria-label="<?php esc_attr_e( 'Share on Facebook', 'norvex' ); ?>"><?php norvex_icon( 'facebook' ); ?></a>
					<button class="norvex-share__link norvex-share__copy" type="button" data-url="<?php echo esc_url( $norvex_permalink ); ?>" aria-label="<?php esc_attr_e( 'Copy link', 'norvex' ); ?>"><?php norvex_icon( 'link' ); ?></button>
				</aside>

				<!-- Article body -->
				<article <?php post_class( 'norvex-post' ); ?>>
					<div class="norvex-entry">
						<?php
						echo $norvex_toc['html']; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- filtered post content.
						wp_link_pages(
							array(
								'before' => '<div class="norvex-pagelinks">' . esc_html__( 'Pages:', 'norvex' ),
								'after'  => '</div>',
							)
						);
						?>
					</div>

					<?php
					// Topic pills: the post's tags, or its categories as a fallback
					// so there is always a set of topics to explore.
					if ( has_tag() ) {
						echo '<div class="norvex-tags">';
						the_tags( '', '' );
						echo '</div>';
					} elseif ( $norvex_cats ) {
						echo '<div class="norvex-tags">';
						foreach ( $norvex_cats as $norvex_c ) {
							echo '<a href="' . esc_url( get_category_link( $norvex_c->term_id ) ) . '">' . esc_html( $norvex_c->name ) . '</a>';
						}
						echo '</div>';
					}
					?>

					<?php
					// Author byline box. Always shown; falls back to a short line
					// when the author has not written a bio yet.
					$norvex_bio = get_the_author_meta( 'description' );
					if ( '' === trim( (string) $norvex_bio ) ) {
						/* translators: %s: site name. */
						$norvex_bio = sprintf( __( 'Part of the team at %s, writing about the craft and business of publishing.', 'norvex' ), get_bloginfo( 'name' ) );
					}
					?>
					<div class="norvex-author">
						<?php echo get_avatar( $norvex_author_id, 64, '', $norvex_author, array( 'class' => 'norvex-author__avatar' ) ); ?>
						<div>
							<span class="norvex-eyebrow"><?php esc_html_e( 'Written by', 'norvex' ); ?></span>
							<strong class="norvex-author__name"><?php echo esc_html( $norvex_author ); ?></strong>
							<p><?php echo esc_html( $norvex_bio ); ?></p>
						</div>
					</div>

					<?php
					$norvex_prev = get_previous_post();
					$norvex_next = get_next_post();
					if ( $norvex_prev || $norvex_next ) :
						?>
						<nav class="norvex-postnav" aria-label="<?php esc_attr_e( 'More articles', 'norvex' ); ?>">
							<?php if ( $norvex_prev ) : ?>
								<a class="norvex-postnav__link norvex-postnav__link--prev" href="<?php echo esc_url( get_permalink( $norvex_prev ) ); ?>">
									<span class="norvex-eyebrow"><?php esc_html_e( 'Previous', 'norvex' ); ?></span>
									<strong><?php echo esc_html( get_the_title( $norvex_prev ) ); ?></strong>
								</a>
							<?php else : ?>
								<span></span>
							<?php endif; ?>
							<?php if ( $norvex_next ) : ?>
								<a class="norvex-postnav__link norvex-postnav__link--next" href="<?php echo esc_url( get_permalink( $norvex_next ) ); ?>">
									<span class="norvex-eyebrow"><?php esc_html_e( 'Next', 'norvex' ); ?></span>
									<strong><?php echo esc_html( get_the_title( $norvex_next ) ); ?></strong>
								</a>
							<?php endif; ?>
						</nav>
					<?php endif; ?>

					<?php
					if ( comments_open() || get_comments_number() ) {
						comments_template();
					}
					?>
				</article>

				<!-- Sidebar -->
				<aside class="norvex-post-aside">
					<div class="norvex-post-aside__sticky">
						<?php if ( count( $norvex_toc['items'] ) > 1 ) : ?>
							<nav class="norvex-toc" aria-label="<?php esc_attr_e( 'In this article', 'norvex' ); ?>">
								<span class="norvex-eyebrow"><?php esc_html_e( 'In this article', 'norvex' ); ?></span>
								<ol>
									<?php foreach ( $norvex_toc['items'] as $norvex_item ) : ?>
										<li><a href="#<?php echo esc_attr( $norvex_item['id'] ); ?>"><?php echo esc_html( $norvex_item['title'] ); ?></a></li>
									<?php endforeach; ?>
								</ol>
							</nav>
						<?php endif; ?>

						<?php if ( is_active_sidebar( 'article-sidebar' ) ) : ?>
							<div class="norvex-post-widgets"><?php dynamic_sidebar( 'article-sidebar' ); ?></div>
						<?php else : ?>
							<div class="norvex-post-cta">
								<h3><?php esc_html_e( 'Ready to publish?', 'norvex' ); ?></h3>
								<p><?php esc_html_e( 'Book a free consultation and we’ll map out the right plan for your book.', 'norvex' ); ?></p>
								<a class="norvex-btn norvex-btn--primary" href="<?php echo $norvex_contact; ?>"><?php esc_html_e( 'Book a free consult', 'norvex' ); ?></a>
							</div>
						<?php endif; ?>
					</div>
				</aside>

			</div>
		</div>
	</section>

	<?php
	// Keep reading — related posts in the same category, topped up with recent.
	$norvex_related = new WP_Query(
		array(
			'post_type'           => 'post',
			'posts_per_page'      => 3,
			'post__not_in'        => array( get_the_ID() ),
			'ignore_sticky_posts' => true,
			'no_found_rows'       => true,
			'cat'                 => $norvex_cat ? $norvex_cat->term_id : 0,
		)
	);
	if ( $norvex_related->post_count < 3 ) {
		$norvex_related = new WP_Query(
			array(
				'post_type'           => 'post',
				'posts_per_page'      => 3,
				'post__not_in'        => array( get_the_ID() ),
				'ignore_sticky_posts' => true,
				'no_found_rows'       => true,
			)
		);
	}
	if ( $norvex_related->have_posts() ) :
		?>
		<section class="norvex-section norvex-section--sand">
			<div class="norvex-wrap">
				<div class="norvex-section-head norvex-section-head--row">
					<h2><?php esc_html_e( 'Keep reading', 'norvex' ); ?></h2>
					<a class="norvex-readmore" href="<?php echo esc_url( $norvex_journal_url ); ?>"><?php esc_html_e( 'All articles', 'norvex' ); ?> <?php norvex_icon( 'arrow' ); ?></a>
				</div>
				<div class="norvex-cards">
					<?php
					while ( $norvex_related->have_posts() ) :
						$norvex_related->the_post();
						?>
						<article class="norvex-article norvex-lift">
							<a href="<?php the_permalink(); ?>" class="norvex-article__thumb"><?php norvex_thumbnail(); ?></a>
							<div class="norvex-article__body">
								<div class="norvex-article__meta"><?php norvex_post_meta(); ?></div>
								<h2 style="font-size:1.2rem;"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>
								<p class="norvex-article__excerpt"><?php echo esc_html( wp_trim_words( get_the_excerpt(), 18 ) ); ?></p>
								<a class="norvex-readmore" href="<?php the_permalink(); ?>"><?php esc_html_e( 'Read article', 'norvex' ); ?> <?php norvex_icon( 'arrow' ); ?></a>
							</div>
						</article>
						<?php
					endwhile;
					wp_reset_postdata();
					?>
				</div>
			</div>
		</section>
		<?php
	endif;

endwhile;

get_footer();
