<?php
/**
 * Portfolio archive.
 *
 * @package Norvex
 */

get_header();
?>
<section class="norvex-page-hero">
	<div class="norvex-wrap">
		<?php norvex_breadcrumb(); ?>
		<h1><?php norvex_hero_title( __( 'Our Portfolio', 'norvex' ) ); ?></h1>
		<p><?php esc_html_e( 'A selection of the books we’ve written, edited, designed, published and marketed with our authors.', 'norvex' ); ?></p>
	</div>
</section>

<section class="norvex-section">
	<div class="norvex-wrap">

		<?php
		// Genre filter row.
		$genres = get_terms( array( 'taxonomy' => 'genre', 'hide_empty' => true ) );
		if ( $genres && ! is_wp_error( $genres ) ) :
			?>
			<div class="norvex-center" style="margin-bottom:44px;display:flex;gap:10px;flex-wrap:wrap;justify-content:center;">
				<a class="norvex-badge-soft" href="<?php echo esc_url( get_post_type_archive_link( 'book' ) ); ?>"><?php esc_html_e( 'All', 'norvex' ); ?></a>
				<?php foreach ( $genres as $g ) : ?>
					<a class="norvex-badge-soft" href="<?php echo esc_url( get_term_link( $g ) ); ?>"><?php echo esc_html( $g->name ); ?></a>
				<?php endforeach; ?>
			</div>
		<?php endif; ?>

		<div class="norvex-books">
			<?php
			if ( have_posts() ) :
				while ( have_posts() ) :
					the_post();
					get_template_part( 'template-parts/book', 'card' );
				endwhile;
			else :
				esc_html_e( 'No books have been added yet.', 'norvex' );
			endif;
			?>
		</div>

		<?php norvex_pagination(); ?>
	</div>
</section>

<?php get_template_part( 'template-parts/cta' ); ?>
<?php
get_footer();
