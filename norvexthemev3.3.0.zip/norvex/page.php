<?php
/**
 * Default page template.
 *
 * @package Norvex
 */

get_header();

while ( have_posts() ) :
	the_post();

	// Pages built with Norvex section blocks (Page hero, About story, Pricing,
	// Contact, etc.) are full-width by design. Render their content edge-to-edge —
	// exactly like the homepage and the template-driven pages — instead of boxing
	// it inside the narrow prose container used for ordinary text pages. Add a
	// "Norvex: Page hero" block for the title/breadcrumb, as the demo pages do.
	if ( false !== strpos( (string) get_the_content(), '<!-- wp:norvex/' ) ) {
		the_content();
		continue;
	}
	?>
	<section class="norvex-page-hero">
		<div class="norvex-wrap">
			<?php norvex_breadcrumb(); ?>
			<h1><?php norvex_hero_title( get_the_title() ); ?></h1>
		</div>
	</section>

	<section class="norvex-section">
		<div class="norvex-wrap">
			<article <?php post_class(); ?>>
				<?php if ( has_post_thumbnail() ) : ?>
					<div class="norvex-single__hero" style="border-radius:var(--norvex-radius);overflow:hidden;margin-bottom:34px;"><?php the_post_thumbnail( 'full' ); ?></div>
				<?php endif; ?>
				<?php do_action( 'norvex_before_entry_content' ); ?>
				<div class="norvex-entry">
					<?php
					the_content();
					wp_link_pages(
						array(
							'before' => '<div class="norvex-pagelinks">' . esc_html__( 'Pages:', 'norvex' ),
							'after'  => '</div>',
						)
					);
					?>
				</div>
				<?php do_action( 'norvex_after_entry_content' ); ?>
			</article>

			<?php
			if ( comments_open() || get_comments_number() ) {
				comments_template();
			}
			?>
		</div>
	</section>
	<?php
endwhile;

get_footer();
