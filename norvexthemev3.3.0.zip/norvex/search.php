<?php
/**
 * Search results — dark hero with the search box and result count, type
 * filter tabs, and a list of result rows (each with a thumbnail/icon, a type
 * badge, the title with the query highlighted, and an excerpt).
 *
 * @package Norvex
 */

get_header();

$norvex_query = get_search_query();
global $wp_query;
$norvex_found = (int) $wp_query->found_posts;

// Human labels + icons for the searchable post types.
$norvex_type_meta = array(
	'post'       => array( __( 'Article', 'norvex' ), 'edit' ),
	'page'       => array( __( 'Page', 'norvex' ), 'book' ),
	'norvex_service' => array( __( 'Service', 'norvex' ), 'sparkle' ),
	'book'       => array( __( 'Book', 'norvex' ), 'book' ),
);

// Which types appear on this page (for the filter tabs).
$norvex_types_present = array();
if ( have_posts() ) {
	foreach ( $wp_query->posts as $norvex_p ) {
		$norvex_types_present[ $norvex_p->post_type ] = true;
	}
}
?>

<section class="norvex-page-hero norvex-search-hero">
	<div class="norvex-wrap">
		<?php norvex_breadcrumb(); ?>
		<h1><?php esc_html_e( 'Search', 'norvex' ); ?></h1>
		<form class="norvex-search-form" role="search" method="get" action="<?php echo esc_url( home_url( '/' ) ); ?>">
			<span class="norvex-search-form__icon"><?php norvex_icon( 'search' ); ?></span>
			<label class="screen-reader-text" for="norvex-s"><?php esc_html_e( 'Search for:', 'norvex' ); ?></label>
			<input id="norvex-s" type="search" name="s" value="<?php echo esc_attr( $norvex_query ); ?>" placeholder="<?php esc_attr_e( 'Search articles, services, books…', 'norvex' ); ?>" />
			<button class="norvex-btn norvex-btn--primary" type="submit"><?php esc_html_e( 'Search', 'norvex' ); ?></button>
		</form>
		<?php if ( '' !== $norvex_query ) : ?>
			<p class="norvex-post-count">
				<?php
				printf(
					/* translators: 1: number of results, 2: search query. */
					esc_html( _n( 'Showing %1$s result for “%2$s”', 'Showing %1$s results for “%2$s”', $norvex_found, 'norvex' ) ),
					esc_html( number_format_i18n( $norvex_found ) ),
					esc_html( $norvex_query )
				);
				?>
			</p>
		<?php endif; ?>
	</div>
</section>

<section class="norvex-section">
	<div class="norvex-wrap norvex-search-wrap">
		<?php if ( have_posts() ) : ?>

			<?php if ( count( $norvex_types_present ) > 1 ) : ?>
				<div class="norvex-filter" aria-label="<?php esc_attr_e( 'Filter results by type', 'norvex' ); ?>">
					<button class="norvex-filter__tab is-active" type="button" data-filter="*"><?php esc_html_e( 'All', 'norvex' ); ?></button>
					<?php foreach ( array_keys( $norvex_type_meta ) as $norvex_t ) : ?>
						<?php if ( ! empty( $norvex_types_present[ $norvex_t ] ) ) : ?>
							<button class="norvex-filter__tab" type="button" data-filter="<?php echo esc_attr( $norvex_t ); ?>"><?php echo esc_html( $norvex_type_meta[ $norvex_t ][0] . 's' ); ?></button>
						<?php endif; ?>
					<?php endforeach; ?>
				</div>
			<?php endif; ?>

			<div class="norvex-searchlist">
				<?php
				while ( have_posts() ) :
					the_post();
					$norvex_pt    = get_post_type();
					$norvex_label = isset( $norvex_type_meta[ $norvex_pt ] ) ? $norvex_type_meta[ $norvex_pt ][0] : $norvex_pt;
					$norvex_icon  = isset( $norvex_type_meta[ $norvex_pt ] ) ? $norvex_type_meta[ $norvex_pt ][1] : 'book';

					// Highlight the query inside the (escaped) title.
					$norvex_title = esc_html( get_the_title() );
					if ( '' !== $norvex_query ) {
						$norvex_title = preg_replace( '/(' . preg_quote( $norvex_query, '/' ) . ')/i', '<mark>$1</mark>', $norvex_title );
					}
					?>
					<a class="norvex-result" data-cats="<?php echo esc_attr( $norvex_pt ); ?>" href="<?php the_permalink(); ?>">
						<span class="norvex-result__thumb">
							<?php if ( has_post_thumbnail() ) : ?>
								<?php the_post_thumbnail( 'thumbnail', array( 'loading' => 'lazy', 'alt' => '' ) ); ?>
							<?php else : ?>
								<?php norvex_icon( $norvex_icon ); ?>
							<?php endif; ?>
						</span>
						<span class="norvex-result__body">
							<span class="norvex-result__meta">
								<span class="norvex-article__cat"><?php echo esc_html( $norvex_label ); ?></span>
								<?php if ( 'post' === $norvex_pt ) : ?>
									<span><?php echo esc_html( get_the_date() ); ?></span>
								<?php endif; ?>
							</span>
							<span class="norvex-result__title"><?php echo wp_kses_post( $norvex_title ); ?></span>
							<span class="norvex-result__excerpt"><?php echo esc_html( wp_trim_words( get_the_excerpt(), 26 ) ); ?></span>
						</span>
						<span class="norvex-result__arrow"><?php norvex_icon( 'arrow' ); ?></span>
					</a>
					<?php
				endwhile;
				?>
			</div>
			<p class="norvex-filter__empty" hidden><?php esc_html_e( 'No results of this type.', 'norvex' ); ?></p>

			<?php norvex_pagination(); ?>

		<?php else : ?>

			<div class="norvex-card norvex-center" style="max-width:560px;margin:0 auto;">
				<h2><?php esc_html_e( 'No matches found', 'norvex' ); ?></h2>
				<p><?php esc_html_e( 'Try different keywords, or browse the Journal for writing and publishing guides.', 'norvex' ); ?></p>
			</div>

		<?php endif; ?>
	</div>
</section>

<?php
get_footer();
