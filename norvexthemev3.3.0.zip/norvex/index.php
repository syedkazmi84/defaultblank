<?php
/**
 * Main template — blog index (the Journal) & fallback.
 *
 * On the blog home we render the full "Journal" layout: a featured lead
 * article, category filter tabs, a card grid and a newsletter band. Other
 * contexts that fall through to index.php (e.g. a bare search) get a simple,
 * dependable list.
 *
 * @package Norvex
 */

get_header();

$norvex_is_journal = ( is_home() && ! is_paged() );
?>

<section class="norvex-page-hero">
	<div class="norvex-wrap">
		<?php norvex_breadcrumb(); ?>
		<h1>
			<?php
			if ( is_home() && ! is_front_page() ) {
				norvex_hero_title( single_post_title( '', false ) );
			} elseif ( is_search() ) {
				/* translators: %s: search query. */
				printf( esc_html__( 'Search: %s', 'norvex' ), '<span>' . esc_html( get_search_query() ) . '</span>' );
			} else {
				norvex_hero_title( __( 'The Journal', 'norvex' ) );
			}
			?>
		</h1>
		<p><?php esc_html_e( 'Practical guides on writing, editing, design, publishing and marketing your book — from the team behind hundreds of published titles.', 'norvex' ); ?></p>
	</div>
</section>

<?php if ( ! have_posts() ) : ?>

	<section class="norvex-section">
		<div class="norvex-wrap">
			<div class="norvex-card norvex-center">
				<h2><?php esc_html_e( 'Nothing here yet', 'norvex' ); ?></h2>
				<p><?php esc_html_e( 'No posts were found. Try a different search or check back soon.', 'norvex' ); ?></p>
				<?php get_search_form(); ?>
			</div>
		</div>
	</section>

<?php elseif ( $norvex_is_journal ) : ?>

	<?php
	// Split the queried posts into a featured lead + the rest for the grid.
	$norvex_posts    = $GLOBALS['wp_query']->posts;
	$norvex_featured = array_shift( $norvex_posts );

	// Category tabs — only categories that actually have posts.
	$norvex_cats = get_categories( array( 'hide_empty' => true, 'number' => 8 ) );
	?>

	<!-- Featured lead article -->
	<section class="norvex-section norvex-section--tight">
		<div class="norvex-wrap">
			<?php
			$GLOBALS['post'] = $norvex_featured; // phpcs:ignore WordPress.WP.GlobalVariablesOverride
			setup_postdata( $norvex_featured );
			?>
			<article class="norvex-jfeature norvex-lift">
				<a class="norvex-jfeature__thumb" href="<?php the_permalink(); ?>"><?php norvex_thumbnail(); ?></a>
				<div class="norvex-jfeature__body">
					<span class="norvex-eyebrow"><?php esc_html_e( 'Featured', 'norvex' ); ?></span>
					<div class="norvex-article__meta"><?php norvex_post_meta(); ?></div>
					<h2><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>
					<p class="norvex-jfeature__excerpt"><?php echo esc_html( wp_trim_words( get_the_excerpt(), 34 ) ); ?></p>
					<a class="norvex-readmore" href="<?php the_permalink(); ?>"><?php esc_html_e( 'Read article', 'norvex' ); ?> <?php norvex_icon( 'arrow' ); ?></a>
				</div>
			</article>
			<?php wp_reset_postdata(); ?>
		</div>
	</section>

	<!-- Category filter + article grid -->
	<section class="norvex-section" style="padding-top:0;">
		<div class="norvex-wrap">
			<?php if ( $norvex_cats ) : ?>
				<div class="norvex-filter" aria-label="<?php esc_attr_e( 'Filter articles by category', 'norvex' ); ?>">
					<button class="norvex-filter__tab is-active" type="button" data-filter="*"><?php esc_html_e( 'All', 'norvex' ); ?></button>
					<?php foreach ( $norvex_cats as $norvex_cat ) : ?>
						<button class="norvex-filter__tab" type="button" data-filter="<?php echo esc_attr( $norvex_cat->slug ); ?>"><?php echo esc_html( $norvex_cat->name ); ?></button>
					<?php endforeach; ?>
				</div>
			<?php endif; ?>

			<?php if ( $norvex_posts ) : ?>
				<div class="norvex-cards norvex-journal-grid">
					<?php
					foreach ( $norvex_posts as $norvex_grid_post ) :
						$GLOBALS['post'] = $norvex_grid_post; // phpcs:ignore WordPress.WP.GlobalVariablesOverride
						setup_postdata( $norvex_grid_post );
						$norvex_slugs = implode( ' ', wp_list_pluck( get_the_category(), 'slug' ) );
						?>
						<article class="norvex-article norvex-jcard norvex-lift" data-cats="<?php echo esc_attr( $norvex_slugs ); ?>">
							<a href="<?php the_permalink(); ?>" class="norvex-article__thumb"><?php norvex_thumbnail(); ?></a>
							<div class="norvex-article__body">
								<div class="norvex-article__meta"><?php norvex_post_meta(); ?></div>
								<h2 style="font-size:1.2rem;"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>
								<p class="norvex-article__excerpt"><?php echo esc_html( wp_trim_words( get_the_excerpt(), 20 ) ); ?></p>
								<a class="norvex-readmore" href="<?php the_permalink(); ?>"><?php esc_html_e( 'Read article', 'norvex' ); ?> <?php norvex_icon( 'arrow' ); ?></a>
							</div>
						</article>
						<?php
					endforeach;
					wp_reset_postdata();
					?>
				</div>
				<p class="norvex-filter__empty" hidden><?php esc_html_e( 'No articles in this category yet.', 'norvex' ); ?></p>
			<?php endif; ?>

			<?php norvex_pagination(); ?>
		</div>
	</section>

	<?php get_template_part( 'template-parts/newsletter' ); ?>

<?php else : ?>

	<section class="norvex-section">
		<div class="norvex-wrap">
			<div class="norvex-content-grid">
				<div class="norvex-content-main">
					<?php
					while ( have_posts() ) :
						the_post();
						?>
						<article <?php post_class( 'norvex-article norvex-lift' ); ?>>
							<a href="<?php the_permalink(); ?>" class="norvex-article__thumb"><?php norvex_thumbnail(); ?></a>
							<div class="norvex-article__body">
								<div class="norvex-article__meta"><?php norvex_post_meta(); ?></div>
								<h2><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>
								<p class="norvex-article__excerpt"><?php echo esc_html( wp_trim_words( get_the_excerpt(), 30 ) ); ?></p>
								<a class="norvex-readmore" href="<?php the_permalink(); ?>"><?php esc_html_e( 'Continue reading', 'norvex' ); ?> <?php norvex_icon( 'arrow' ); ?></a>
							</div>
						</article>
						<?php
					endwhile;
					norvex_pagination();
					?>
				</div>
				<?php get_sidebar(); ?>
			</div>
		</div>
	</section>

<?php endif; ?>

<?php
get_footer();
