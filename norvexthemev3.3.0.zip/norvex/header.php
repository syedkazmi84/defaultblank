<?php
/**
 * Header template.
 *
 * @package Norvex
 */

?>
<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="profile" href="https://gmpg.org/xfn/11">
	<?php wp_head(); ?>
</head>

<body <?php body_class(); ?>>
<?php wp_body_open(); ?>
<a class="norvex-skip-link screen-reader-text" href="#norvex-main"><?php esc_html_e( 'Skip to content', 'norvex' ); ?></a>

<div id="page" class="norvex-site">

<?php do_action( 'norvex_before_header' ); ?>

	<!-- Top bar -->
	<div class="norvex-topbar">
		<div class="norvex-wrap">
			<div class="norvex-topbar__meta">
				<span><?php norvex_icon( 'mail' ); ?> <a href="mailto:<?php echo esc_attr( norvex_option( 'norvex_email', 'hello@norvexpublishingservices.com' ) ); ?>"><?php echo esc_html( norvex_option( 'norvex_email', 'hello@norvexpublishingservices.com' ) ); ?></a></span>
				<span><?php norvex_icon( 'clock' ); ?> <?php echo esc_html( norvex_option( 'norvex_hours', 'Mon–Fri · 9:00 AM – 6:00 PM' ) ); ?></span>
				<span class="norvex-topbar__phone"><?php norvex_icon( 'phone' ); ?> <a href="tel:<?php echo esc_attr( norvex_option( 'norvex_phone', '+1 (732) 454-6871' ) ); ?>"><?php echo esc_html( norvex_option( 'norvex_phone', '+1 (732) 454-6871' ) ); ?></a></span>
			</div>
			<div class="norvex-topbar__social">
				<a href="<?php echo esc_url( norvex_option( 'norvex_social_tw', '#' ) ); ?>" aria-label="Twitter"><?php norvex_icon( 'twitter' ); ?></a>
				<a href="<?php echo esc_url( norvex_option( 'norvex_social_ig', '#' ) ); ?>" aria-label="Instagram"><?php norvex_icon( 'instagram' ); ?></a>
				<a href="<?php echo esc_url( norvex_option( 'norvex_social_fb', '#' ) ); ?>" aria-label="Facebook"><?php norvex_icon( 'facebook' ); ?></a>
				<a href="<?php echo esc_url( norvex_option( 'norvex_social_in', '#' ) ); ?>" aria-label="LinkedIn"><?php norvex_icon( 'linkedin' ); ?></a>
				<?php do_action( 'norvex_topbar_end' ); ?>
			</div>
		</div>
	</div>

	<!-- Header -->
	<header class="norvex-header">
		<div class="norvex-wrap">
			<?php
			$norvex_hide_title = (bool) get_theme_mod( 'norvex_hide_site_title', false );
			$norvex_hide_tag   = (bool) get_theme_mod( 'norvex_hide_tagline', false );
			$norvex_logo_w     = absint( get_theme_mod( 'norvex_logo_width', 44 ) );
			$norvex_logo_w     = $norvex_logo_w > 0 ? $norvex_logo_w : 44;
			?>
			<div class="norvex-brand" style="--norvex-logo-w:<?php echo esc_attr( $norvex_logo_w ); ?>px;">
				<?php if ( has_custom_logo() ) : ?>
					<?php the_custom_logo(); ?>
				<?php else : ?>
					<a href="<?php echo esc_url( home_url( '/' ) ); ?>" class="norvex-brand__link" aria-label="<?php echo esc_attr( get_bloginfo( 'name' ) ); ?>">
						<img src="<?php echo norvex_img( 'logo.svg' ); ?>" alt="<?php echo esc_attr( get_bloginfo( 'name' ) ); ?>" width="44" height="44" />
						<?php if ( ! $norvex_hide_title || ! $norvex_hide_tag ) : ?>
							<span class="norvex-brand__text">
								<?php if ( ! $norvex_hide_title ) : ?>
									<span class="norvex-brand__name"><?php bloginfo( 'name' ); ?></span>
								<?php endif; ?>
								<?php if ( ! $norvex_hide_tag ) : ?>
									<span class="norvex-brand__tag"><?php echo esc_html( norvex_option( 'norvex_tagline', 'Publishing Services' ) ); ?></span>
								<?php endif; ?>
							</span>
						<?php endif; ?>
					</a>
				<?php endif; ?>
			</div>

			<button class="norvex-nav-toggle" aria-controls="norvex-primary-nav" aria-expanded="false">
				<span class="screen-reader-text"><?php esc_html_e( 'Toggle menu', 'norvex' ); ?></span>
				<span></span><span></span><span></span>
			</button>

			<nav id="norvex-primary-nav" class="norvex-nav" aria-label="<?php esc_attr_e( 'Primary', 'norvex' ); ?>">
				<?php
				if ( has_nav_menu( 'primary' ) ) {
					wp_nav_menu(
						array(
							'theme_location' => 'primary',
							'container'      => false,
							'menu_class'     => 'norvex-menu',
							'depth'          => 2,
							'fallback_cb'    => false,
						)
					);
				} else {
					echo '<ul class="norvex-menu">';
					wp_list_pages( array( 'title_li' => '', 'depth' => 1 ) );
					echo '</ul>';
				}
				?>
				<?php do_action( 'norvex_nav_end' ); ?>
				<?php
				if ( ! (bool) get_theme_mod( 'norvex_cta_hide', false ) ) :
					$norvex_cta_text = norvex_option( 'norvex_cta_text', __( 'Get a quote', 'norvex' ) );
					$norvex_cta_url  = norvex_option( 'norvex_cta_url', '' );
					if ( '' === $norvex_cta_url ) {
						$norvex_contact_page = get_page_by_path( 'contact' );
						$norvex_cta_url      = $norvex_contact_page ? get_permalink( $norvex_contact_page ) : home_url( '/' );
					}
					?>
					<a class="norvex-btn norvex-btn--primary norvex-header__cta" href="<?php echo esc_url( $norvex_cta_url ); ?>">
						<?php echo esc_html( $norvex_cta_text ); ?>
					</a>
				<?php endif; ?>
			</nav>
		</div>
	</header>

	<?php do_action( 'norvex_after_header' ); ?>

	<main id="norvex-main" class="norvex-main">
	<?php do_action( 'norvex_before_main' ); ?>
