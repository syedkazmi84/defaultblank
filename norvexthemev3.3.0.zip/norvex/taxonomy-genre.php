<?php
/**
 * Category archive — shows portfolio projects in a grid.
 *
 * @package Norvex
 */

get_header();
$term = get_queried_object();
?>
<section class="norvex-page-hero">
	<div class="norvex-wrap">
		<?php norvex_breadcrumb(); ?>
		<h1><?php norvex_hero_title( $term ? $term->name : __( 'Category', 'norvex' ) ); ?></h1>
		<p><?php echo esc_html( $term && $term->description ? $term->description : __( 'Projects in this category from our portfolio.', 'norvex' ) ); ?></p>
	</div>
</section>

<section class="norvex-section">
	<div class="norvex-wrap">
		<div class="norvex-center" style="margin-bottom:44px;display:flex;gap:10px;flex-wrap:wrap;justify-content:center;">
			<a class="norvex-badge-soft" href="<?php echo esc_url( get_post_type_archive_link( 'book' ) ); ?>"><?php esc_html_e( 'All work', 'norvex' ); ?></a>
			<?php
			$genres = get_terms( array( 'taxonomy' => 'genre', 'hide_empty' => true ) );
			if ( $genres && ! is_wp_error( $genres ) ) {
				foreach ( $genres as $g ) {
					echo '<a class="norvex-badge-soft" href="' . esc_url( get_term_link( $g ) ) . '">' . esc_html( $g->name ) . '</a>';
				}
			}
			?>
		</div>

		<div class="norvex-books">
			<?php
			if ( have_posts() ) :
				while ( have_posts() ) :
					the_post();
					get_template_part( 'template-parts/book', 'card' );
				endwhile;
			else :
				esc_html_e( 'No books in this genre yet.', 'norvex' );
			endif;
			?>
		</div>

		<?php norvex_pagination(); ?>
	</div>
</section>

<?php
get_template_part( 'template-parts/cta' );
get_footer();
