<?php
/**
 * Native contact form handler.
 *
 * Powers the built-in consultation form on the Contact template when no form
 * plugin (Contact Form 7 / WPForms / Gravity Forms) shortcode is present on the
 * page. Validates a nonce and honeypot, then emails the submission to the
 * address set in Customizer → Norvex · Contact & Social (norvex_email).
 *
 * @package Norvex
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Process a submission of the built-in contact form.
 *
 * Runs once per request, the first time the template asks for its state. Returns
 * an associative array describing the outcome so the template can render the
 * right message and re-populate fields on error.
 *
 * @return array{submitted:bool,sent:bool,errors:array<string,string>,values:array<string,string>}
 */
function norvex_contact_form_state() {
	static $state = null;
	if ( null !== $state ) {
		return $state;
	}

	$state = array(
		'submitted' => false,
		'sent'      => false,
		'errors'    => array(),
		'values'    => array(
			'name'    => '',
			'email'   => '',
			'service' => '',
			'message' => '',
		),
	);

	if ( 'POST' !== ( isset( $_SERVER['REQUEST_METHOD'] ) ? strtoupper( sanitize_text_field( wp_unslash( $_SERVER['REQUEST_METHOD'] ) ) ) : '' ) ) {
		return $state;
	}
	if ( ! isset( $_POST['norvex_contact_nonce'] ) ) {
		return $state;
	}

	$state['submitted'] = true;

	// Nonce check.
	if ( ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['norvex_contact_nonce'] ) ), 'norvex_contact' ) ) {
		$state['errors']['general'] = __( 'Your session expired. Please reload the page and try again.', 'norvex' );
		return $state;
	}

	// Honeypot: a real user leaves this empty; bots fill it.
	if ( ! empty( $_POST['norvex_website'] ) ) {
		// Silently pretend success so bots get no signal.
		$state['sent'] = true;
		return $state;
	}

	// NB: the field is posted as `norvex_name`, not `name` — `name` is a WordPress
	// reserved query var, and posting it makes WP resolve the page to a 404.
	$name    = isset( $_POST['norvex_name'] ) ? sanitize_text_field( wp_unslash( $_POST['norvex_name'] ) ) : '';
	$email   = isset( $_POST['email'] ) ? sanitize_email( wp_unslash( $_POST['email'] ) ) : '';
	$service = isset( $_POST['service'] ) ? sanitize_text_field( wp_unslash( $_POST['service'] ) ) : '';
	$message = isset( $_POST['message'] ) ? sanitize_textarea_field( wp_unslash( $_POST['message'] ) ) : '';

	$state['values'] = array(
		'name'    => $name,
		'email'   => $email,
		'service' => $service,
		'message' => $message,
	);

	if ( '' === $name ) {
		$state['errors']['name'] = __( 'Please tell us your name.', 'norvex' );
	}
	if ( '' === $email || ! is_email( $email ) ) {
		$state['errors']['email'] = __( 'Please enter a valid email address.', 'norvex' );
	}
	if ( '' === $message ) {
		$state['errors']['message'] = __( 'Please tell us a little about your book.', 'norvex' );
	}

	if ( ! empty( $state['errors'] ) ) {
		return $state;
	}

	// Store the lead first — so the enquiry is captured even if the email below
	// fails to send (bad SMTP, host with no mail transport, spam-filtered, …).
	if ( function_exists( 'norvex_store_lead' ) ) {
		norvex_store_lead(
			array(
				'name'    => $name,
				'email'   => $email,
				'service' => $service,
				'message' => $message,
				'gclid'   => norvex_gclid_from_request(),
				'source'  => wp_get_referer() ? wp_get_referer() : '',
			)
		);
	}

	$to = norvex_option( 'norvex_email', get_option( 'admin_email' ) );
	if ( ! is_email( $to ) ) {
		$to = get_option( 'admin_email' );
	}

	$site    = wp_specialchars_decode( get_bloginfo( 'name' ), ENT_QUOTES );
	/* translators: %s: site name. */
	$subject = sprintf( __( '[%s] New consultation request', 'norvex' ), $site );

	$lines = array(
		/* translators: %s: sender name. */
		sprintf( __( 'Name: %s', 'norvex' ), $name ),
		/* translators: %s: sender email. */
		sprintf( __( 'Email: %s', 'norvex' ), $email ),
	);
	if ( '' !== $service ) {
		/* translators: %s: selected service. */
		$lines[] = sprintf( __( 'Service: %s', 'norvex' ), $service );
	}
	$norvex_gclid = norvex_gclid_from_request();
	if ( '' !== $norvex_gclid ) {
		/* translators: %s: Google Ads click id. */
		$lines[] = sprintf( __( 'Google Ads click ID (GCLID): %s', 'norvex' ), $norvex_gclid );
	}
	$lines[] = '';
	$lines[] = __( 'Message:', 'norvex' );
	$lines[] = $message;

	$body    = implode( "\n", $lines );
	$headers = array(
		'Content-Type: text/plain; charset=UTF-8',
		sprintf( 'Reply-To: %s <%s>', $name, $email ),
	);

	$state['sent'] = (bool) wp_mail( $to, $subject, $body, $headers );

	if ( ! $state['sent'] ) {
		$state['errors']['general'] = __( 'Sorry — the message could not be sent. Please email us directly.', 'norvex' );
	}

	return $state;
}
