<?php
/**
 * Newsletter signup handler.
 *
 * Turns the footer newsletter form from a demo placeholder into a working
 * signup: it validates a nonce and honeypot, stores each subscriber as a
 * private "Subscriber" post (visible under Norvex → Subscribers) and emails
 * a notification to the site's Norvex contact address. No third-party
 * service required — though a mailing-list plugin can still take over the form
 * by hooking `norvex_newsletter_subscribed`.
 *
 * @package Norvex
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Register the Subscriber post type (private, under the Norvex hub).
 */
function norvex_register_subscriber_cpt() {
	$labels = array(
		'name'               => esc_html__( 'Subscribers', 'norvex' ),
		'singular_name'      => esc_html__( 'Subscriber', 'norvex' ),
		'add_new'            => esc_html__( 'Add New', 'norvex' ),
		'add_new_item'       => esc_html__( 'Add Subscriber', 'norvex' ),
		'edit_item'          => esc_html__( 'Edit Subscriber', 'norvex' ),
		'new_item'           => esc_html__( 'New Subscriber', 'norvex' ),
		'view_item'          => esc_html__( 'View Subscriber', 'norvex' ),
		'search_items'       => esc_html__( 'Search Subscribers', 'norvex' ),
		'not_found'          => esc_html__( 'No subscribers yet.', 'norvex' ),
		'not_found_in_trash' => esc_html__( 'No subscribers found in Trash.', 'norvex' ),
		'all_items'          => esc_html__( 'Subscribers', 'norvex' ),
		'menu_name'          => esc_html__( 'Subscribers', 'norvex' ),
	);

	register_post_type(
		'norvex_subscriber',
		array(
			'labels'          => $labels,
			'public'          => false,
			'show_ui'         => true,
			'show_in_menu'    => 'norvex-hub',
			'show_in_rest'    => false,
			'menu_icon'       => 'dashicons-email',
			'supports'        => array( 'title' ),
			'capability_type' => 'post',
			'map_meta_cap'    => true,
			'rewrite'         => false,
			'query_var'       => false,
		)
	);
}
add_action( 'init', 'norvex_register_subscriber_cpt' );

/**
 * Subscribers list: show Email + a clean, sortable "Subscribed" date.
 *
 * @param array $cols Existing columns.
 * @return array
 */
function norvex_subscriber_columns( $cols ) {
	$new             = array();
	$new['cb']       = isset( $cols['cb'] ) ? $cols['cb'] : '';
	$new['title']    = __( 'Email', 'norvex' );
	$new['norvex_sub_date'] = __( 'Subscribed', 'norvex' );
	return $new;
}
add_filter( 'manage_norvex_subscriber_posts_columns', 'norvex_subscriber_columns' );

/**
 * Render the "Subscribed" date column.
 *
 * @param string $column  Column key.
 * @param int    $post_id Subscriber ID.
 */
function norvex_subscriber_column_content( $column, $post_id ) {
	if ( 'norvex_sub_date' === $column ) {
		echo esc_html( get_the_date( '', $post_id ) . ' · ' . get_the_time( '', $post_id ) );
	}
}
add_action( 'manage_norvex_subscriber_posts_custom_column', 'norvex_subscriber_column_content', 10, 2 );

/**
 * Make the Subscribed column sortable (by post date).
 *
 * @param array $cols Sortable columns.
 * @return array
 */
function norvex_subscriber_sortable_columns( $cols ) {
	$cols['norvex_sub_date'] = 'date';
	return $cols;
}
add_filter( 'manage_edit-norvex_subscriber_sortable_columns', 'norvex_subscriber_sortable_columns' );

/**
 * Hide the "Private" post-state label on subscribers (they are all private).
 *
 * @param string[] $states Post states.
 * @param WP_Post  $post   The post.
 * @return string[]
 */
function norvex_subscriber_hide_states( $states, $post ) {
	if ( $post instanceof WP_Post && 'norvex_subscriber' === $post->post_type ) {
		return array();
	}
	return $states;
}
add_filter( 'display_post_states', 'norvex_subscriber_hide_states', 10, 2 );

/**
 * Handle a footer newsletter submission.
 *
 * Runs early on the front end, before output, so a successful signup can
 * redirect back to the same page with a status flag (Post/Redirect/Get) — that
 * avoids a duplicate signup if the visitor refreshes.
 */
function norvex_handle_newsletter() {
	if ( is_admin() || 'POST' !== ( isset( $_SERVER['REQUEST_METHOD'] ) ? strtoupper( sanitize_text_field( wp_unslash( $_SERVER['REQUEST_METHOD'] ) ) ) : '' ) ) {
		return;
	}
	if ( ! isset( $_POST['norvex_news_nonce'] ) ) {
		return;
	}

	$redirect = wp_get_referer();
	if ( ! $redirect ) {
		$redirect = home_url( '/' );
	}
	$redirect = remove_query_arg( array( 'norvex_sub' ), $redirect );

	// Nonce check.
	if ( ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['norvex_news_nonce'] ) ), 'norvex_newsletter' ) ) {
		wp_safe_redirect( add_query_arg( 'norvex_sub', 'err', $redirect ) . '#norvex-news' );
		exit;
	}

	// Honeypot: bots fill this; real users leave it empty. Feign success.
	if ( ! empty( $_POST['norvex_website'] ) ) {
		wp_safe_redirect( add_query_arg( 'norvex_sub', 'ok', $redirect ) . '#norvex-news' );
		exit;
	}

	$email  = isset( $_POST['norvex_news_email'] ) ? sanitize_email( wp_unslash( $_POST['norvex_news_email'] ) ) : '';
	$status = norvex_save_subscriber( $email );

	wp_safe_redirect( add_query_arg( 'norvex_sub', $status, $redirect ) . '#norvex-news' );
	exit;
}
add_action( 'template_redirect', 'norvex_handle_newsletter' );

/**
 * Store a subscriber and notify the site contact.
 *
 * Shared by the no-JS form handler (template_redirect) and the AJAX endpoint so
 * both paths validate, de-duplicate and notify identically.
 *
 * @param string $email Candidate subscriber email address.
 * @return string 'ok' on success (or already subscribed), 'err' if invalid.
 */
function norvex_save_subscriber( $email ) {
	if ( '' === $email || ! is_email( $email ) ) {
		return 'err';
	}

	// Already subscribed? Treat as success, don't duplicate.
	$existing = get_posts(
		array(
			'post_type'        => 'norvex_subscriber',
			'post_status'      => array( 'publish', 'private' ),
			'title'            => $email,
			'numberposts'      => 1,
			'fields'           => 'ids',
			'suppress_filters' => false,
		)
	);

	if ( empty( $existing ) ) {
		$subscriber_id = wp_insert_post(
			array(
				'post_type'   => 'norvex_subscriber',
				'post_status' => 'private',
				'post_title'  => $email,
			),
			true
		);

		if ( ! is_wp_error( $subscriber_id ) ) {
			// Remember the Google Ads click id (if this subscriber arrived from a
			// tracked ad click) on the subscriber record.
			$norvex_gclid = norvex_gclid_from_request();
			if ( '' !== $norvex_gclid ) {
				update_post_meta( $subscriber_id, '_norvex_gclid', $norvex_gclid );
			}

			// Notify the site's Norvex contact address.
			$to = norvex_option( 'norvex_email', get_option( 'admin_email' ) );
			if ( ! is_email( $to ) ) {
				$to = get_option( 'admin_email' );
			}
			$site = wp_specialchars_decode( get_bloginfo( 'name' ), ENT_QUOTES );
			/* translators: %s: site name. */
			$subject = sprintf( __( '[%s] New newsletter subscriber', 'norvex' ), $site );
			/* translators: %s: subscriber email. */
			$body    = sprintf( __( 'New subscriber: %s', 'norvex' ), $email );
			if ( '' !== $norvex_gclid ) {
				/* translators: %s: Google Ads click id. */
				$body .= "\n" . sprintf( __( 'Google Ads click ID (GCLID): %s', 'norvex' ), $norvex_gclid );
			}
			wp_mail( $to, $subject, $body, array( 'Content-Type: text/plain; charset=UTF-8' ) );

			/**
			 * Fires when a new newsletter subscriber is stored. Hook a
			 * mailing-list integration (Mailchimp, etc.) here.
			 *
			 * @param string $email Subscriber email address.
			 */
			do_action( 'norvex_newsletter_subscribed', $email );
		}
	}

	return 'ok';
}

/**
 * AJAX handler for the footer newsletter form.
 *
 * Lets the form submit without a full page reload, so the visitor stays exactly
 * where they are and the confirmation appears inline — no jump down to the
 * footer anchor. theme.js posts here; without JS the form falls back to the
 * Post/Redirect/Get handler above.
 */
function norvex_ajax_newsletter() {
	$nonce = isset( $_POST['norvex_news_nonce'] ) ? sanitize_text_field( wp_unslash( $_POST['norvex_news_nonce'] ) ) : '';
	if ( ! wp_verify_nonce( $nonce, 'norvex_newsletter' ) ) {
		wp_send_json( norvex_newsletter_message( 'err' ) );
	}

	// Honeypot: bots fill this; real users leave it empty. Feign success.
	if ( ! empty( $_POST['norvex_website'] ) ) {
		wp_send_json( norvex_newsletter_message( 'ok' ) );
	}

	$email  = isset( $_POST['norvex_news_email'] ) ? sanitize_email( wp_unslash( $_POST['norvex_news_email'] ) ) : '';
	$status = norvex_save_subscriber( $email );

	wp_send_json( norvex_newsletter_message( $status ) );
}
add_action( 'wp_ajax_norvex_newsletter', 'norvex_ajax_newsletter' );
add_action( 'wp_ajax_nopriv_norvex_newsletter', 'norvex_ajax_newsletter' );

/**
 * Build the status/message pair for a newsletter result.
 *
 * Single source of truth for the copy shown by both the server-rendered notice
 * and the AJAX response.
 *
 * @param string $status 'ok' or 'err'.
 * @return array{status:string,message:string}
 */
function norvex_newsletter_message( $status ) {
	if ( 'ok' === $status ) {
		return array(
			'status'  => 'ok',
			'message' => __( 'Thanks for subscribing! Please check your inbox.', 'norvex' ),
		);
	}
	return array(
		'status'  => 'err',
		'message' => __( 'Please enter a valid email address and try again.', 'norvex' ),
	);
}

/**
 * The status message to show after a newsletter submission, or '' if none.
 *
 * @return array{status:string,message:string}|array{}
 */
function norvex_newsletter_notice() {
	if ( ! isset( $_GET['norvex_sub'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- read-only status flag, no state change.
		return array();
	}
	$flag = sanitize_key( wp_unslash( $_GET['norvex_sub'] ) ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended

	return norvex_newsletter_message( 'ok' === $flag ? 'ok' : 'err' );
}
