<?php
/**
 * One-click demo content.
 *
 * The demo content is NOT created automatically when the theme is activated.
 * Activating Norvex leaves your site untouched — no pages, posts, menus or
 * sample items are inserted. Instead, an "Import demo content" button on the
 * Norvex → Overview screen imports the whole starter site on demand: the
 * core pages (assigned to their page templates), a Journal posts page, the
 * primary & footer menus, sample journal posts, a full sample portfolio and the
 * editable components (services, testimonials, team, pricing plans).
 *
 * @package Norvex
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * On theme activation, only refresh permalinks. No content is created — the
 * site stays exactly as it is until the demo is imported from the dashboard.
 */
function norvex_after_switch_theme() {
	flush_rewrite_rules();
}
add_action( 'after_switch_theme', 'norvex_after_switch_theme' );

/**
 * Apply the Norvex Publishing Services brand identity as part of the demo import:
 * site title, tagline and the contact/social details that surface in the
 * top bar, header, footer and contact page. Every value is a Customizer field
 * the user can override afterwards.
 */
function norvex_apply_brand_defaults() {
	// Site identity (only set if still on a default/blank name, so we never
	// clobber a title the user has deliberately chosen).
	$name = get_option( 'blogname' );
	if ( '' === $name || in_array( $name, array( 'My Site', 'My WordPress Site', 'Just another WordPress site', 'Norvex Test' ), true ) ) {
		update_option( 'blogname', 'Norvex' );
	}
	update_option( 'blogdescription', 'Book Publishing Services for Authors Who Keep 100% of Their Rights' );

	$mods = array(
		'norvex_tagline'    => 'Publishing Services',
		'norvex_email'      => 'hello@norvexpublishingservices.com',
		'norvex_phone'      => '+1 (732) 454-6871',
		'norvex_hours'      => 'Mon–Fri · 9:00 AM – 6:00 PM',
		'norvex_address'    => '1102 Glenwood Road, F4, Brooklyn, NY 11230',
		'norvex_footer_txt' => 'Norvex LLC is a New York–registered book publishing services company. We help authors write, edit, design, publish and market their books on a flat fee — and you keep 100% of your rights and royalties.',
		'norvex_social_fb'  => 'https://facebook.com/norvex',
		'norvex_social_ig'  => 'https://instagram.com/norvex',
		'norvex_social_in'  => 'https://linkedin.com/company/norvex',
		'norvex_social_tw'  => 'https://youtube.com/@norvex',
	);
	foreach ( $mods as $key => $value ) {
		set_theme_mod( $key, $value );
	}
}

/**
 * Import the full demo content. Runs only when triggered from the "Import demo
 * content" button (see norvex_handle_demo_import), never on activation.
 * Guarded so it imports once; individual seeders are idempotent.
 */
function norvex_import_demo() {
	if ( get_option( 'norvex_demo_imported' ) ) {
		return;
	}

	norvex_apply_brand_defaults();
	$pages = norvex_create_pages();
	norvex_configure_front_page( $pages );
	norvex_create_posts();
	norvex_build_menus( $pages );

	update_option( 'norvex_demo_imported', NORVEX_VERSION );
	update_option( 'norvex_content_version', NORVEX_CONTENT_VERSION );
	// Flush so the /books/ archive and permalinks work immediately.
	flush_rewrite_rules();
}

/**
 * True once the demo content has been imported from the dashboard.
 */
function norvex_demo_is_imported() {
	return (bool) get_option( 'norvex_demo_imported' );
}

/**
 * Handle the "Import demo content" button on the Norvex → Overview screen.
 */
function norvex_handle_demo_import() {
	if ( ! current_user_can( 'manage_options' ) ) {
		wp_die( esc_html__( 'You are not allowed to import demo content.', 'norvex' ) );
	}
	check_admin_referer( 'norvex_import_demo' );

	norvex_import_demo();

	wp_safe_redirect(
		add_query_arg(
			array(
				'page'        => 'norvex-hub',
				'norvex_imported' => '1',
			),
			admin_url( 'admin.php' )
		)
	);
	exit;
}
add_action( 'admin_post_norvex_import_demo', 'norvex_handle_demo_import' );

/**
 * Delete the theme's demo content and re-import it fresh.
 *
 * Only removes content the importer creates: the seven demo pages (by slug),
 * the showcase/component post types (which exist solely for the demo), the
 * sample journal posts (matched by their known titles so hand-written posts are
 * safe) and the Primary Navigation menu. Newsletter subscribers and any other
 * pages or posts are left alone. It then clears the one-time guards and runs a
 * full import again.
 */
function norvex_reset_demo() {
	// 2. The main demo pages, plus each service's own page, matched by slug only.
	$page_slugs = array( 'home', 'about', 'services', 'how-it-works', 'pricing', 'portfolio', 'contact', 'journal', 'privacy-policy', 'terms' );
	foreach ( norvex_default_services() as $s ) {
		$page_slugs[] = isset( $s['slug'] ) ? $s['slug'] : sanitize_title( $s['title'] );
	}
	foreach ( $page_slugs as $slug ) {
		$page = get_page_by_path( $slug );
		if ( $page ) {
			wp_delete_post( $page->ID, true );
		}
	}

	// 3. Sample journal posts, matched by their known demo titles so any posts
	// the user wrote themselves are never touched.
	$demo_titles = array(
		'Self-Publishing vs. Traditional: Which Path Fits Your Book?',
		'Anatomy of a Cover That Sells',
		'Your Launch Week Marketing Checklist',
		'How to Find (and Keep) the Right Editor',
	);
	foreach ( $demo_titles as $title ) {
		$match = get_posts(
			array(
				'post_type'        => 'post',
				'post_status'      => 'any',
				'title'            => $title,
				'numberposts'      => 1,
				'fields'           => 'ids',
				'suppress_filters' => false,
			)
		);
		if ( ! empty( $match ) ) {
			wp_delete_post( $match[0], true );
		}
	}

	// 4. The Primary Navigation and Footer menus (rebuilt on import).
	foreach ( array( 'Primary Navigation', 'Footer Menu' ) as $menu_name ) {
		$menu = wp_get_nav_menu_object( $menu_name );
		if ( $menu ) {
			wp_delete_nav_menu( $menu->term_id );
		}
	}

	// 5. Clear the one-time guards so a fresh import runs.
	delete_option( 'norvex_demo_imported' );
	delete_option( 'norvex_posts_created' );
	delete_option( 'norvex_content_version' );

	// 6. Re-import everything.
	norvex_import_demo();
}

/**
 * Handle the "Reset & re-import demo content" button on the Overview screen.
 */
function norvex_handle_demo_reset() {
	if ( ! current_user_can( 'manage_options' ) ) {
		wp_die( esc_html__( 'You are not allowed to reset demo content.', 'norvex' ) );
	}
	check_admin_referer( 'norvex_reset_demo' );

	norvex_reset_demo();

	wp_safe_redirect(
		add_query_arg(
			array(
				'page'     => 'norvex-hub',
				'norvex_reset' => '1',
			),
			admin_url( 'admin.php' )
		)
	);
	exit;
}
add_action( 'admin_post_norvex_reset_demo', 'norvex_handle_demo_reset' );


/*
 * Note: Norvex no longer auto-creates or auto-refreshes demo content on
 * admin load. Content only appears when you click "Import demo content" on the
 * Norvex → Overview screen, and it is never silently changed afterwards.
 */

/**
 * Create (or find) a page by slug, optionally with a template.
 */
/**
 * Convert a service's packages into the Pricing block's plans JSON.
 *
 * @param array $packages Service packages.
 * @return string JSON for the pricing block's `custom` attribute.
 */
function norvex_packages_to_plans_json( $packages ) {
	$out = array();
	foreach ( (array) $packages as $pk ) {
		$out[] = array(
			'name'     => isset( $pk['name'] ) ? $pk['name'] : '',
			'price'    => isset( $pk['price'] ) ? $pk['price'] : '',
			'was'      => isset( $pk['was'] ) ? $pk['was'] : '',
			'per'      => isset( $pk['period'] ) ? $pk['period'] : '',
			'desc'     => isset( $pk['desc'] ) ? $pk['desc'] : '',
			'featured' => ! empty( $pk['featured'] ),
			'features' => implode( "\n", (array) ( isset( $pk['features'] ) ? $pk['features'] : array() ) ),
		);
	}
	return wp_json_encode( $out );
}

/**
 * Convert a service's FAQ pairs into the FAQ block's "Question | Answer" lines.
 *
 * @param array $faqs Array of array( question, answer ).
 * @return string
 */
function norvex_faqs_to_pairs( $faqs ) {
	$lines = array();
	foreach ( (array) $faqs as $f ) {
		$q = isset( $f[0] ) ? $f[0] : '';
		$a = isset( $f[1] ) ? $f[1] : '';
		if ( '' !== trim( $q ) ) {
			$lines[] = $q . ' | ' . $a;
		}
	}
	return implode( "\n", $lines );
}

/**
 * Block content for a single service page (overview, its own pricing, FAQ, CTA).
 *
 * @param array $s One entry from norvex_default_services().
 * @return string
 */
function norvex_build_service_page( $s ) {
	$body     = isset( $s['body'] ) ? (array) $s['body'] : array();
	$features = implode( "\n", (array) ( isset( $s['features'] ) ? $s['features'] : array() ) );
	$blocks   = array(
		norvex_block_markup(
			'page-hero',
			array(
				'title' => $s['title'],
				'lead'  => isset( $s['intro'] ) ? $s['intro'] : '',
			)
		),
		norvex_block_markup(
			'about-story',
			array(
				'eyebrow' => __( 'Overview', 'norvex' ),
				/* translators: %s: service name. */
				'title'   => sprintf( __( 'What %s includes', 'norvex' ), $s['title'] ),
				'para1'   => isset( $body[0] ) ? $body[0] : '',
				'para2'   => isset( $body[1] ) ? $body[1] : '',
				'list'    => $features,
				'image'   => norvex_img( isset( $s['image'] ) ? $s['image'] : 'about.svg' ),
			)
		),
		norvex_block_markup(
			'pricing',
			array(
				'eyebrow' => $s['title'],
				'heading' => __( 'Pricing for this service', 'norvex' ),
				'lead'    => __( 'Clear, itemised pricing — tailored to your book after a free consultation.', 'norvex' ),
				'custom'  => norvex_packages_to_plans_json( isset( $s['packages'] ) ? $s['packages'] : array() ),
			)
		),
		norvex_block_markup(
			'faq',
			array(
				'eyebrow' => __( 'Good to know', 'norvex' ),
				'title'   => __( 'Frequently asked questions', 'norvex' ),
				'items'   => norvex_faqs_to_pairs( isset( $s['faqs'] ) ? $s['faqs'] : array() ),
			)
		),
		norvex_block_markup( 'cta' ),
	);
	return norvex_blocks_to_content( $blocks );
}

/**
 * Grid-cards JSON for the services grid — one card per service, linked to its page.
 *
 * @param array $cards Prepared card rows.
 * @return string
 */
function norvex_service_cards_json( $cards ) {
	return wp_json_encode( $cards );
}

/**
 * Home page, built entirely from blocks. Services use the Grid-cards block with
 * links to each service's own page.
 */
function norvex_build_home_page( $cards_json ) {
	$blocks = array(
		norvex_block_markup( 'hero' ),
		norvex_block_markup( 'logos' ),
		norvex_block_markup(
			'cards',
			array(
				'eyebrow' => __( 'What we do', 'norvex' ),
				'heading' => __( 'Everything your book needs, in one place', 'norvex' ),
				'lead'    => __( 'From writing to marketing, our team handles the hard parts of publishing so you can focus on your story.', 'norvex' ),
				'cols'    => '3',
				'cards'   => $cards_json,
			)
		),
		norvex_block_markup( 'feature-split' ),
		norvex_block_markup( 'process' ),
		norvex_block_markup( 'consult' ),
		norvex_block_markup(
			'pricing',
			array(
				'eyebrow' => __( 'Pricing', 'norvex' ),
				'heading' => __( 'Packages that fit your book', 'norvex' ),
				'lead'    => __( 'Start with a package or build your own — every plan is tailored after your free consultation.', 'norvex' ),
			)
		),
		norvex_block_markup( 'featured-books' ),
		norvex_block_markup( 'stats' ),
		// Core Gutenberg blocks: a three-up "commitments" row (wp:columns + wp:image).
		norvex_core_columns(
			array(
				'eyebrow' => __( 'What you can count on', 'norvex' ),
				'heading' => __( 'Three promises we build every project on', 'norvex' ),
				'lead'    => __( 'The details change from book to book — these never do.', 'norvex' ),
			),
			array(
				array( 'image' => 'service-quill.svg', 'title' => __( 'You keep 100% of your rights', 'norvex' ), 'text' => __( 'Copyright stays in your name, every retailer account is opened for you, and each store pays you directly. We charge a flat fee — never a royalty share.', 'norvex' ) ),
				array( 'image' => 'service-edit.svg', 'title' => __( 'A specialist at every stage', 'norvex' ), 'text' => __( 'Editing, design, production and marketing are handled by people who do that one thing well — not one generalist stretched across all of it.', 'norvex' ) ),
				array( 'image' => 'service-megaphone.svg', 'title' => __( 'Transparent, itemised pricing', 'norvex' ), 'text' => __( 'Every price is on the page and agreed in writing before work starts. The scope sets the number, and the number is the number.', 'norvex' ) ),
			)
		),
		norvex_block_markup( 'testimonials' ),
		norvex_block_markup( 'journal' ),
		norvex_block_markup( 'faq' ),
		norvex_block_markup( 'cta' ),
	);
	return norvex_blocks_to_content( $blocks );
}

/**
 * Services page, built from blocks: hero + Grid-cards (linked to service pages).
 */
function norvex_build_services_page( $cards_json ) {
	$blocks = array(
		norvex_block_markup(
			'page-hero',
			array(
				'title' => __( 'Our services', 'norvex' ),
				'lead'  => __( 'A finished book is really six jobs, not one. Take all six as a single package — or any one on its own. Every price is printed next to it.', 'norvex' ),
			)
		),
		norvex_block_markup( 'services-list' ),
		norvex_block_markup(
			'cards',
			array(
				'eyebrow' => __( 'Explore each service', 'norvex' ),
				'heading' => __( 'Every service has its own page', 'norvex' ),
				'lead'    => __( 'Open any service to see exactly what’s included, how it works and what it costs.', 'norvex' ),
				'cols'    => '3',
				'cards'   => $cards_json,
			)
		),
		norvex_block_markup( 'data-columns' ),
		norvex_block_markup( 'steps-media' ),
		norvex_block_markup( 'faq' ),
		norvex_block_markup( 'cta' ),
	);
	return norvex_blocks_to_content( $blocks );
}

/**
 * About page, built from blocks.
 */
function norvex_build_about_page() {
	$blocks = array(
		norvex_block_markup(
			'page-hero',
			array(
				'title' => __( 'About Norvex', 'norvex' ),
				'lead'  => __( 'We help authors publish professionally — and keep 100% of their rights and royalties.', 'norvex' ),
			)
		),
		norvex_block_markup( 'about-story' ),
		// Core Gutenberg block: image + text (wp:media-text) with the studio illustration.
		norvex_core_media_text(
			array(
				'eyebrow' => __( 'How we work', 'norvex' ),
				'heading' => __( 'One team, from first draft to first sale', 'norvex' ),
				'body'    => array(
					__( 'We built Norvex so authors would never have to juggle a freelance editor, a separate designer, a distributor and a marketer who never speak to each other. One team carries your book the whole way, and one person stays your point of contact throughout.', 'norvex' ),
					__( 'It means fewer handoffs, a schedule that actually holds, and a finished book that feels considered from cover to final page — while you stay the author and owner at every step.', 'norvex' ),
				),
				'btn'     => __( 'Meet the team', 'norvex' ),
				'btnurl'  => '#norvex-team',
				'image'   => 'about.svg',
				'imgalt'  => __( 'The Norvex team at work', 'norvex' ),
				'side'    => 'left',
			)
		),
		norvex_block_markup( 'showcase' ),
		norvex_block_markup( 'why-us' ),
		norvex_block_markup( 'stats' ),
		// Core Gutenberg block: a mission pull-quote (wp:quote).
		norvex_core_quote(
			__( 'A book is the most personal thing most people ever make. Our whole job is to treat it that way — and to hand it back entirely yours.', 'norvex' ),
			__( 'The Norvex founding promise', 'norvex' )
		),
		norvex_block_markup( 'team' ),
		norvex_block_markup( 'highlights' ),
		norvex_block_markup( 'testimonials' ),
		norvex_block_markup( 'cta' ),
	);
	return norvex_blocks_to_content( $blocks );
}

/**
 * Pricing page, built from blocks.
 */
function norvex_build_pricing_page() {
	$blocks = array(
		norvex_block_markup(
			'page-hero',
			array(
				'title' => __( 'Pricing', 'norvex' ),
				'lead'  => __( 'Simple, transparent pricing with no hidden fees. Every book is different, so we tailor a quote to exactly what you need.', 'norvex' ),
			)
		),
		norvex_block_markup( 'broadsheet' ),
		norvex_block_markup(
			'pricing',
			array(
				'eyebrow' => __( 'Packages', 'norvex' ),
				'heading' => __( 'Simple, transparent pricing', 'norvex' ),
				'lead'    => __( 'Flexible packages tailored to your book after a free consultation.', 'norvex' ),
			)
		),
		norvex_block_markup( 'marginalia' ),
		norvex_block_markup( 'faq' ),
		norvex_block_markup( 'cta' ),
	);
	return norvex_blocks_to_content( $blocks );
}

/**
 * "How it works" page — the process & education sections (zig-zag steps,
 * horizontal marketing timeline and the chapters index), built from blocks.
 */
function norvex_build_process_page() {
	$blocks = array(
		norvex_block_markup(
			'page-hero',
			array(
				'title' => __( 'How it works', 'norvex' ),
				'lead'  => __( 'A clear, documented path from first conversation to launch day — with a named deliverable and your sign-off at every step.', 'norvex' ),
			)
		),
		norvex_block_markup( 'zigzag' ),
		norvex_block_markup( 'timeline-h' ),
		norvex_block_markup( 'chapters-index' ),
		norvex_block_markup( 'consult' ),
		norvex_block_markup( 'cta' ),
	);
	return norvex_blocks_to_content( $blocks );
}

/**
 * Portfolio page, built from blocks.
 */
function norvex_build_portfolio_page() {
	$blocks = array(
		norvex_block_markup(
			'page-hero',
			array(
				'title' => __( 'Portfolio', 'norvex' ),
				'lead'  => __( 'A selection of books we have helped bring to life — written, edited, designed and launched.', 'norvex' ),
			)
		),
		norvex_block_markup( 'featured-books' ),
		// Core Gutenberg block: a cover gallery (wp:gallery + wp:image).
		norvex_core_gallery(
			array(
				'eyebrow' => __( 'Recent covers', 'norvex' ),
				'heading' => __( 'A shelf of books we’ve published', 'norvex' ),
				'lead'    => __( 'Every one designed for its genre, produced to print standard, and released with the author keeping all rights.', 'norvex' ),
			),
			array(
				array( 'cover-1.svg', __( 'The Founder’s Compass', 'norvex' ) ),
				array( 'cover-2.svg', __( 'Quiet Wealth', 'norvex' ) ),
				array( 'cover-3.svg', __( 'Saltwater Girlhood', 'norvex' ) ),
				array( 'cover-4.svg', __( 'The Clockwork Garden', 'norvex' ) ),
				array( 'cover-5.svg', __( 'Field Notes on Wonder', 'norvex' ) ),
				array( 'cover-6.svg', __( 'Signal & Noise', 'norvex' ) ),
			)
		),
		norvex_block_markup( 'cta' ),
	);
	return norvex_blocks_to_content( $blocks );
}

/**
 * Contact page, built from blocks.
 */
function norvex_build_contact_page() {
	$blocks = array(
		norvex_block_markup(
			'page-hero',
			array(
				'title' => __( 'Contact us', 'norvex' ),
				'lead'  => __( 'Tell us about your book and we will be in touch to set up your free consultation.', 'norvex' ),
			)
		),
		norvex_block_markup( 'contact' ),
	);
	return norvex_blocks_to_content( $blocks );
}

/**
 * Turn a list of [ heading, array( paragraph|['ul', items...] ) ] sections into
 * core Gutenberg block markup (heading / paragraph / list), wrapped in a
 * constrained, readable prose group. Used for the legal pages so they are real,
 * editable core blocks — not a theme shortcode.
 *
 * @param string $intro    Intro paragraph shown before the first heading.
 * @param array  $sections Sections: array( array( 'Heading', array( 'para', array( 'ul', 'item', 'item' ) ) ) ).
 * @return string
 */
function norvex_legal_blocks( $intro, $sections ) {
	$out = '';

	if ( '' !== trim( (string) $intro ) ) {
		$out .= '<!-- wp:paragraph {"className":"norvex-prose__lead"} --><p class="norvex-prose__lead">' . esc_html( $intro ) . '</p><!-- /wp:paragraph -->';
	}

	foreach ( $sections as $section ) {
		$heading = isset( $section[0] ) ? $section[0] : '';
		$blocks  = isset( $section[1] ) ? (array) $section[1] : array();

		if ( '' !== trim( (string) $heading ) ) {
			$out .= '<!-- wp:heading --><h2 class="wp-block-heading">' . esc_html( $heading ) . '</h2><!-- /wp:heading -->';
		}

		foreach ( $blocks as $block ) {
			if ( is_array( $block ) && isset( $block[0] ) && 'ul' === $block[0] ) {
				$items = array_slice( $block, 1 );
				$li    = '';
				foreach ( $items as $item ) {
					$li .= '<!-- wp:list-item --><li>' . esc_html( $item ) . '</li><!-- /wp:list-item -->';
				}
				$out .= '<!-- wp:list --><ul class="wp-block-list">' . $li . '</ul><!-- /wp:list -->';
			} else {
				$out .= '<!-- wp:paragraph --><p>' . esc_html( (string) $block ) . '</p><!-- /wp:paragraph -->';
			}
		}
	}

	return '<!-- wp:group {"className":"norvex-prose"} --><div class="wp-block-group norvex-prose">' . $out . '</div><!-- /wp:group -->';
}

/**
 * Core Gutenberg "image + text" band (wp:media-text) — a themed illustration
 * beside a heading, copy and a button. Used to give the demo pages real core
 * blocks alongside the theme's own sections.
 *
 * @param array $a eyebrow, heading, body (array of paragraphs), btn, btnurl, image, imgalt, side ('left'|'right').
 * @return string
 */
function norvex_core_media_text( $a ) {
	$a       = wp_parse_args(
		$a,
		array( 'eyebrow' => '', 'heading' => '', 'body' => array(), 'btn' => '', 'btnurl' => '', 'image' => 'about.svg', 'imgalt' => '', 'side' => 'left' )
	);
	$img     = norvex_img( $a['image'] );
	$is_right = ( 'right' === $a['side'] );
	$classes = 'wp-block-media-text is-stacked-on-mobile norvex-mt' . ( $is_right ? ' has-media-on-the-right' : '' );
	$attrs   = $is_right ? '{"align":"wide","mediaPosition":"right","mediaType":"image","className":"norvex-mt"}' : '{"align":"wide","mediaType":"image","className":"norvex-mt"}';

	$content = '';
	if ( '' !== $a['eyebrow'] ) {
		$content .= '<!-- wp:paragraph {"className":"norvex-eyebrow"} --><p class="norvex-eyebrow">' . esc_html( $a['eyebrow'] ) . '</p><!-- /wp:paragraph -->';
	}
	if ( '' !== $a['heading'] ) {
		$content .= '<!-- wp:heading --><h2 class="wp-block-heading">' . esc_html( $a['heading'] ) . '</h2><!-- /wp:heading -->';
	}
	foreach ( (array) $a['body'] as $para ) {
		$content .= '<!-- wp:paragraph --><p>' . esc_html( $para ) . '</p><!-- /wp:paragraph -->';
	}
	if ( '' !== $a['btn'] ) {
		$url      = $a['btnurl'] ? $a['btnurl'] : '#';
		$content .= '<!-- wp:buttons --><div class="wp-block-buttons"><!-- wp:button --><div class="wp-block-button"><a class="wp-block-button__link wp-element-button" href="' . esc_url( $url ) . '">' . esc_html( $a['btn'] ) . '</a></div><!-- /wp:button --></div><!-- /wp:buttons -->';
	}

	$media = '<figure class="wp-block-media-text__media"><img src="' . esc_url( $img ) . '" alt="' . esc_attr( $a['imgalt'] ) . '"/></figure>';
	$inner = '<div class="wp-block-media-text__content">' . $content . '</div>';
	$html  = $is_right
		? '<div class="' . esc_attr( $classes ) . '">' . $inner . $media . '</div>'
		: '<div class="' . esc_attr( $classes ) . '">' . $media . $inner . '</div>';

	$block = '<!-- wp:media-text ' . $attrs . ' -->' . $html . '<!-- /wp:media-text -->';

	// Wrap in a themed band so it gets the same vertical rhythm as the other sections.
	return '<!-- wp:group {"className":"norvex-coreband"} --><div class="wp-block-group norvex-coreband">' . $block . '</div><!-- /wp:group -->';
}

/**
 * Core Gutenberg pull-quote band (wp:group > wp:quote).
 *
 * @param string $quote The quotation.
 * @param string $cite  Attribution.
 * @return string
 */
function norvex_core_quote( $quote, $cite ) {
	$q = '<!-- wp:quote {"className":"norvex-quote"} --><blockquote class="wp-block-quote norvex-quote"><!-- wp:paragraph --><p>' . esc_html( $quote ) . '</p><!-- /wp:paragraph --><cite>' . esc_html( $cite ) . '</cite></blockquote><!-- /wp:quote -->';
	return '<!-- wp:group {"className":"norvex-coreband"} --><div class="wp-block-group norvex-coreband">' . $q . '</div><!-- /wp:group -->';
}

/**
 * Core Gutenberg three-up feature columns (wp:columns > wp:column > image/heading/paragraph),
 * wrapped in a themed band with an optional heading.
 *
 * @param array $head  eyebrow, heading, lead.
 * @param array $cols  Each: array( 'image' => file, 'title' => '', 'text' => '' ).
 * @return string
 */
function norvex_core_columns( $head, $cols ) {
	$head   = wp_parse_args( $head, array( 'eyebrow' => '', 'heading' => '', 'lead' => '' ) );
	$header = '<div class="norvex-band-head norvex-center">';
	if ( '' !== $head['eyebrow'] ) {
		$header .= '<!-- wp:paragraph {"className":"norvex-eyebrow"} --><p class="norvex-eyebrow">' . esc_html( $head['eyebrow'] ) . '</p><!-- /wp:paragraph -->';
	}
	if ( '' !== $head['heading'] ) {
		$header .= '<!-- wp:heading {"textAlign":"center"} --><h2 class="wp-block-heading has-text-align-center">' . esc_html( $head['heading'] ) . '</h2><!-- /wp:heading -->';
	}
	if ( '' !== $head['lead'] ) {
		$header .= '<!-- wp:paragraph {"align":"center","className":"norvex-lead"} --><p class="has-text-align-center norvex-lead">' . esc_html( $head['lead'] ) . '</p><!-- /wp:paragraph -->';
	}
	$header .= '</div>';

	$columns = '';
	foreach ( $cols as $c ) {
		$img      = norvex_img( isset( $c['image'] ) ? $c['image'] : '' );
		$columns .= '<!-- wp:column --><div class="wp-block-column">'
			. '<!-- wp:image {"width":"54px","sizeSlug":"large"} --><figure class="wp-block-image is-resized"><img src="' . esc_url( $img ) . '" alt=""/></figure><!-- /wp:image -->'
			. '<!-- wp:heading {"level":3} --><h3 class="wp-block-heading">' . esc_html( isset( $c['title'] ) ? $c['title'] : '' ) . '</h3><!-- /wp:heading -->'
			. '<!-- wp:paragraph --><p>' . esc_html( isset( $c['text'] ) ? $c['text'] : '' ) . '</p><!-- /wp:paragraph -->'
			. '</div><!-- /wp:column -->';
	}

	return '<!-- wp:group {"className":"norvex-coreband"} --><div class="wp-block-group norvex-coreband">'
		. $header
		. '<!-- wp:columns {"className":"norvex-cols"} --><div class="wp-block-columns norvex-cols">' . $columns . '</div><!-- /wp:columns -->'
		. '</div><!-- /wp:group -->';
}

/**
 * Core Gutenberg gallery of book covers (wp:gallery > wp:image), wrapped in a
 * themed band with a heading.
 *
 * @param array $head    eyebrow, heading, lead.
 * @param array $covers  Array of array( file, alt ).
 * @return string
 */
function norvex_core_gallery( $head, $covers ) {
	$head   = wp_parse_args( $head, array( 'eyebrow' => '', 'heading' => '', 'lead' => '' ) );
	$header = '<div class="norvex-band-head norvex-center">';
	if ( '' !== $head['eyebrow'] ) {
		$header .= '<!-- wp:paragraph {"className":"norvex-eyebrow"} --><p class="norvex-eyebrow">' . esc_html( $head['eyebrow'] ) . '</p><!-- /wp:paragraph -->';
	}
	if ( '' !== $head['heading'] ) {
		$header .= '<!-- wp:heading {"textAlign":"center"} --><h2 class="wp-block-heading has-text-align-center">' . esc_html( $head['heading'] ) . '</h2><!-- /wp:heading -->';
	}
	if ( '' !== $head['lead'] ) {
		$header .= '<!-- wp:paragraph {"align":"center","className":"norvex-lead"} --><p class="has-text-align-center norvex-lead">' . esc_html( $head['lead'] ) . '</p><!-- /wp:paragraph -->';
	}
	$header .= '</div>';

	$images = '';
	foreach ( $covers as $c ) {
		$file    = isset( $c[0] ) ? $c[0] : '';
		$alt     = isset( $c[1] ) ? $c[1] : '';
		$images .= '<!-- wp:image {"sizeSlug":"large"} --><figure class="wp-block-image size-large"><img src="' . esc_url( norvex_img( $file ) ) . '" alt="' . esc_attr( $alt ) . '"/></figure><!-- /wp:image -->';
	}

	return '<!-- wp:group {"className":"norvex-coreband"} --><div class="wp-block-group norvex-coreband">'
		. $header
		. '<!-- wp:gallery {"columns":3,"linkTo":"none","className":"norvex-gallery"} --><figure class="wp-block-gallery has-nested-images columns-3 is-cropped norvex-gallery">' . $images . '</figure><!-- /wp:gallery -->'
		. '</div><!-- /wp:group -->';
}

/**
 * Privacy Policy page — page-hero + core-block legal copy.
 */
function norvex_build_privacy_page() {
	$updated = gmdate( 'F Y' );
	$blocks  = array(
		norvex_block_markup(
			'page-hero',
			array(
				'title' => __( 'Privacy Policy', 'norvex' ),
				/* translators: %s: month and year the policy was last updated. */
				'lead'  => sprintf( __( 'How Norvex collects, uses and protects your information. Last updated %s.', 'norvex' ), $updated ),
			)
		),
		norvex_legal_blocks(
			__( 'This Privacy Policy explains what information Norvex Publishing Services (“Norvex”, “we”, “us”) collects when you use our website or engage our services, how we use it, and the choices you have. We keep data collection to what we genuinely need to help you publish your book.', 'norvex' ),
			array(
				array(
					__( 'Information we collect', 'norvex' ),
					array(
						__( 'We collect information you give us directly and a limited amount collected automatically as you browse:', 'norvex' ),
						array( 'ul',
							__( 'Contact details you submit — name, email, phone and the message or project details you share when you request a consultation or quote.', 'norvex' ),
							__( 'Project information — manuscripts, files and briefs you send us so we can scope and deliver your work.', 'norvex' ),
							__( 'Usage data — pages visited, referring links and general device information, gathered through privacy-respecting analytics.', 'norvex' ),
						),
					),
				),
				array(
					__( 'How we use your information', 'norvex' ),
					array(
						__( 'We use the information above to respond to your enquiries, prepare quotes, deliver the services you engage us for, send project updates, and — only if you opt in — share occasional publishing tips and news. We do not sell your personal information to anyone.', 'norvex' ),
					),
				),
				array(
					__( 'Cookies', 'norvex' ),
					array(
						__( 'Our site uses a small number of cookies to remember your preferences and understand how the site is used. You can control or disable cookies in your browser settings; essential cookies are required for the site to function.', 'norvex' ),
					),
				),
				array(
					__( 'Sharing and third parties', 'norvex' ),
					array(
						__( 'We share information only with the trusted providers that help us operate — for example email, payment and file-storage services — and only to the extent needed to deliver your project. Each is bound to protect your data. When we set up retailer and distribution accounts, they are opened in your name and governed by their own terms.', 'norvex' ),
					),
				),
				array(
					__( 'Your rights and choices', 'norvex' ),
					array(
						__( 'You can ask us to access, correct or delete the personal information we hold about you, and you can unsubscribe from marketing email at any time using the link in every message. To make a request, contact us using the details below.', 'norvex' ),
					),
				),
				array(
					__( 'Data retention and security', 'norvex' ),
					array(
						__( 'We keep your information only as long as needed to provide our services and meet legal obligations, then delete or anonymise it. We use appropriate technical and organisational measures to protect it, though no method of transmission over the internet is ever completely secure.', 'norvex' ),
					),
				),
				array(
					__( 'Changes to this policy', 'norvex' ),
					array(
						__( 'We may update this policy from time to time. When we do, we will revise the “last updated” date above and, where appropriate, notify you.', 'norvex' ),
					),
				),
				array(
					__( 'Contact us', 'norvex' ),
					array(
						__( 'Questions about this policy or your data? Email hello@norvexpublishingservices.com or write to Norvex LLC, 1102 Glenwood Road, F4, Brooklyn, NY 11230.', 'norvex' ),
					),
				),
			)
		),
		norvex_block_markup( 'cta' ),
	);
	return norvex_blocks_to_content( $blocks );
}

/**
 * Terms of Service page — page-hero + core-block legal copy.
 */
function norvex_build_terms_page() {
	$updated = gmdate( 'F Y' );
	$blocks  = array(
		norvex_block_markup(
			'page-hero',
			array(
				'title' => __( 'Terms of Service', 'norvex' ),
				/* translators: %s: month and year the terms were last updated. */
				'lead'  => sprintf( __( 'The terms that govern our website and the services we provide. Last updated %s.', 'norvex' ), $updated ),
			)
		),
		norvex_legal_blocks(
			__( 'These Terms of Service govern your use of the Norvex website and the publishing services we provide. By engaging us or using this site, you agree to these terms. Specific projects are also covered by the written proposal and scope we agree with you.', 'norvex' ),
			array(
				array(
					__( 'Our services', 'norvex' ),
					array(
						__( 'Norvex provides ghostwriting, editing, design, publishing and marketing services for authors. Each engagement is defined by a written proposal that sets out the scope, deliverables, timeline and price agreed before work begins.', 'norvex' ),
					),
				),
				array(
					__( 'You keep your rights', 'norvex' ),
					array(
						__( 'This is central to how we work: you remain the sole author and rights-holder of your book. Copyright stays in your name, distribution and retailer accounts are set up in your name, and each retailer pays you directly. We take a flat fee for the work — never a share of your royalties or a claim on your rights.', 'norvex' ),
					),
				),
				array(
					__( 'Payments and refunds', 'norvex' ),
					array(
						__( 'Fees, deposits and payment schedules are set out in your proposal. Because our work is bespoke and begins as soon as a project is booked, deposits are non-refundable once work has started, though we will always discuss any concerns and work fairly to resolve them.', 'norvex' ),
					),
				),
				array(
					__( 'Your responsibilities', 'norvex' ),
					array(
						__( 'To deliver your project well, we ask that you:', 'norvex' ),
						array( 'ul',
							__( 'Provide accurate information and the materials we need on time.', 'norvex' ),
							__( 'Confirm that content you supply is your own or properly licensed.', 'norvex' ),
							__( 'Review proofs and give feedback within the agreed windows so the schedule holds.', 'norvex' ),
						),
					),
				),
				array(
					__( 'Revisions and approval', 'norvex' ),
					array(
						__( 'Each service includes the rounds of revision described in your proposal. You approve key milestones — such as edits, cover concepts and final proofs — before we proceed, so nothing goes to print or publication without your sign-off.', 'norvex' ),
					),
				),
				array(
					__( 'Confidentiality', 'norvex' ),
					array(
						__( 'We treat your manuscript and project details as confidential and share them only with the team members and providers working on your book. We are happy to sign a mutual non-disclosure agreement on request.', 'norvex' ),
					),
				),
				array(
					__( 'Limitation of liability', 'norvex' ),
					array(
						__( 'We deliver our services with professional care, but we cannot guarantee particular sales, rankings or commercial outcomes, which depend on many factors beyond our control. To the extent permitted by law, our liability for any claim is limited to the fees paid for the affected service.', 'norvex' ),
					),
				),
				array(
					__( 'Governing law', 'norvex' ),
					array(
						__( 'These terms are governed by the laws of the State of New York, and any dispute will be handled by the courts of that jurisdiction.', 'norvex' ),
					),
				),
				array(
					__( 'Contact us', 'norvex' ),
					array(
						__( 'Questions about these terms? Email hello@norvexpublishingservices.com or write to Norvex LLC, 1102 Glenwood Road, F4, Brooklyn, NY 11230.', 'norvex' ),
					),
				),
			)
		),
		norvex_block_markup( 'cta' ),
	);
	return norvex_blocks_to_content( $blocks );
}

function norvex_make_page( $title, $slug, $content = '', $template = '' ) {
	$existing = get_page_by_path( $slug );
	if ( $existing ) {
		if ( $template ) {
			update_post_meta( $existing->ID, '_wp_page_template', $template );
		}
		return $existing->ID;
	}

	$id = wp_insert_post(
		array(
			'post_title'   => $title,
			'post_name'    => $slug,
			// Slash so the block-comment JSON (escaped quotes and \n inside the
			// cards/plans attributes) survives — wp_insert_post unslashes on save.
			'post_content' => wp_slash( $content ),
			'post_status'  => 'publish',
			'post_type'    => 'page',
		)
	);

	if ( $id && ! is_wp_error( $id ) && $template ) {
		update_post_meta( $id, '_wp_page_template', $template );
	}
	return $id;
}

/**
 * Create all core pages and return a slug => ID map.
 */
function norvex_create_pages() {
	$map = array();

	// 1. A real, block-built Page for each service, and collect a linked card for
	// the services grid. No auto CPT pages — every single service page is a normal
	// WordPress page you can edit with blocks.
	$cards = array();
	foreach ( norvex_default_services() as $s ) {
		$slug = isset( $s['slug'] ) ? $s['slug'] : sanitize_title( $s['title'] );
		$sid  = norvex_make_page( $s['title'], $slug, norvex_build_service_page( $s ) );
		$map[ 'service-' . $slug ] = $sid;
		$url = ( $sid && ! is_wp_error( $sid ) ) ? get_permalink( $sid ) : '';
		$cards[] = array(
			'icon'      => isset( $s['icon'] ) ? $s['icon'] : '',
			'image'     => '',
			'title'     => $s['title'],
			'text'      => isset( $s['excerpt'] ) ? $s['excerpt'] : '',
			'url'       => $url,
			'linklabel' => __( 'Learn more', 'norvex' ),
			'price'     => '',
			'note'      => '',
			'caption'   => '',
			'bside'     => '',
			'bcolor'    => '',
			'bwidth'    => '',
		);
	}
	$cards_json = norvex_service_cards_json( $cards );

	// 2. Every main page, built entirely from blocks (no page templates).
	$map['home']      = norvex_make_page( __( 'Home', 'norvex' ), 'home', norvex_build_home_page( $cards_json ) );
	$map['about']     = norvex_make_page( __( 'About', 'norvex' ), 'about', norvex_build_about_page() );
	$map['services']  = norvex_make_page( __( 'Services', 'norvex' ), 'services', norvex_build_services_page( $cards_json ) );
	$map['process']   = norvex_make_page( __( 'How It Works', 'norvex' ), 'how-it-works', norvex_build_process_page() );
	$map['pricing']   = norvex_make_page( __( 'Pricing', 'norvex' ), 'pricing', norvex_build_pricing_page() );
	$map['portfolio'] = norvex_make_page( __( 'Portfolio', 'norvex' ), 'portfolio', norvex_build_portfolio_page() );
	$map['contact']   = norvex_make_page( __( 'Contact', 'norvex' ), 'contact', norvex_build_contact_page() );
	$map['blog']      = norvex_make_page( __( 'Journal', 'norvex' ), 'journal', '' );
	$map['privacy']   = norvex_make_page( __( 'Privacy Policy', 'norvex' ), 'privacy-policy', norvex_build_privacy_page() );
	$map['terms']     = norvex_make_page( __( 'Terms of Service', 'norvex' ), 'terms', norvex_build_terms_page() );

	// Register the Privacy Policy page with WordPress so the core privacy tools
	// and the login/footer privacy link point at it.
	if ( ! empty( $map['privacy'] ) && ! is_wp_error( $map['privacy'] ) ) {
		update_option( 'wp_page_for_privacy_policy', $map['privacy'] );
	}

	return $map;
}

/**
 * Set the static front page and posts page.
 */
function norvex_configure_front_page( $pages ) {
	if ( ! empty( $pages['home'] ) ) {
		update_option( 'show_on_front', 'page' );
		update_option( 'page_on_front', $pages['home'] );
	}
	if ( ! empty( $pages['blog'] ) ) {
		update_option( 'page_for_posts', $pages['blog'] );
	}
}

/**
 * Sample journal posts.
 */
function norvex_create_posts() {
	if ( get_option( 'norvex_posts_created' ) ) {
		return;
	}

	// Ensure categories exist.
	$cats = array( 'Publishing', 'Writing Craft', 'Book Marketing', 'Design' );
	foreach ( $cats as $c ) {
		if ( ! term_exists( $c, 'category' ) ) {
			wp_insert_term( $c, 'category' );
		}
	}

	$posts = array(
		array(
			'title'   => 'Self-Publishing vs. Traditional: Which Path Fits Your Book?',
			'cat'     => 'Publishing',
			'tags'    => array( 'Publishing', 'First-Time Authors', 'Self-Publishing', 'Book Launch' ),
			'excerpt' => 'Royalties, control, timelines and reach — a clear-eyed comparison to help you choose the publishing route that serves your goals.',
			'body'    => "<p>Every author eventually faces the same fork in the road: pursue a traditional publishing deal, or take the reins and self-publish. Neither path is objectively better — they simply optimise for different things.</p><h2>The case for traditional publishing</h2><p>A traditional deal brings an advance, an established distribution network, and the credibility of a recognised imprint. In exchange, you give up a large share of royalties and most creative control, and you wait — often 18 to 24 months from contract to shelf.</p><h2>The case for self-publishing</h2><p>Self-publishing hands you the wheel. You keep up to 70% of royalties, set your own timeline, and retain final say on cover, price and marketing. The trade-off is that every decision — and every cost — is yours.</p><blockquote>The best book is the one that actually reaches readers. Choose the path that gets yours into their hands.</blockquote><h2>How we help either way</h2><p>At Norvex we prepare manuscripts to a professional standard regardless of route — so whether an agent or an algorithm is your gatekeeper, your book is ready.</p><ul><li>Editorial assessment and developmental editing</li><li>Query letters and submission packages for agents</li><li>Full self-publishing setup across Amazon KDP, IngramSpark and Apple Books</li></ul>",
		),
		array(
			'title'   => 'Anatomy of a Cover That Sells',
			'cat'     => 'Design',
			'tags'    => array( 'Cover Design', 'Book Design', 'Marketing' ),
			'excerpt' => 'A great cover does a specific job in a fraction of a second. Here is what separates covers that convert from covers that get scrolled past.',
			'body'    => "<p>Readers really do judge a book by its cover — and they do it in about a tenth of a second on a thumbnail-sized image. Your cover has one job in that instant: signal genre and promise.</p><h2>1. Genre legibility</h2><p>The single biggest mistake is a cover that fights its own genre. A cosy mystery should not look like literary fiction. Study the top 50 in your category and speak the visual language readers already trust.</p><h2>2. Typographic hierarchy</h2><p>Title, then author, then everything else. At thumbnail scale the title must remain readable. If it disappears, the cover has failed.</p><h2>3. A single focal idea</h2><p>The strongest covers commit to one image, one mood, one hook. Clutter reads as amateur.</p><p>Our design team creates three distinct concepts for every book, then refines the winner across print and ebook formats.</p>",
		),
		array(
			'title'   => 'Your Launch Week Marketing Checklist',
			'cat'     => 'Book Marketing',
			'tags'    => array( 'Book Launch', 'Marketing', 'Amazon' ),
			'excerpt' => 'The seven days around your release matter more than any other. Use this checklist to make launch week count.',
			'body'    => "<p>Momentum in the first week feeds the algorithms that decide who else sees your book. Preparation is everything.</p><h2>Two weeks before</h2><ul><li>Finalise your book description and keywords</li><li>Line up newsletter swaps and podcast guest spots</li><li>Schedule your email sequence</li></ul><h2>Launch day</h2><ul><li>Email your list first — they are your most likely buyers</li><li>Post to every platform with a clear call to action</li><li>Ask early readers to leave honest reviews</li></ul><h2>The week after</h2><p>Keep the drumbeat going with reader questions, behind-the-scenes content and a small paid push once you have a handful of reviews.</p>",
		),
		array(
			'title'   => 'How to Find (and Keep) the Right Editor',
			'cat'     => 'Writing Craft',
			'tags'    => array( 'Editing', 'Writing Craft', 'First-Time Authors' ),
			'excerpt' => 'A good editor makes your book unmistakably yours — only sharper. Here is how to find the right fit and build a lasting partnership.',
			'body'    => "<p>Editing is not about imposing a house style on your voice. The right editor amplifies what already works and gently fixes what does not.</p><h2>Know which edit you need</h2><p>Developmental editing shapes structure and story. Line editing refines prose. Copyediting fixes grammar and consistency. Proofreading is the final polish. Ordering them out of sequence wastes money.</p><h2>Ask for a sample</h2><p>Any editor worth hiring will edit a few pages so you can feel the collaboration before committing.</p><p>Every Norvex project pairs you with a dedicated editor and a clear, milestone-based schedule — no surprises, no ghosting.</p>",
		),
	);

	foreach ( $posts as $p ) {
		$term  = get_term_by( 'name', $p['cat'], 'category' );
		$id = wp_insert_post(
			array(
				'post_title'   => $p['title'],
				'post_content' => $p['body'],
				'post_excerpt' => $p['excerpt'],
				'post_status'  => 'publish',
				'post_type'    => 'post',
				'post_category' => $term ? array( $term->term_id ) : array(),
			)
		);
		if ( $id && ! is_wp_error( $id ) && ! empty( $p['tags'] ) ) {
			wp_set_post_tags( $id, $p['tags'], false );
		}
	}

	update_option( 'norvex_posts_created', 1 );
}


/**
 * Add a list of page menu items to a menu.
 *
 * @param int   $menu_id Menu term ID.
 * @param array $items   Array of array( 'Label', $page_id ).
 */
function norvex_add_menu_items( $menu_id, $items ) {
	foreach ( $items as $item ) {
		if ( empty( $item[1] ) ) {
			continue;
		}
		wp_update_nav_menu_item(
			$menu_id,
			0,
			array(
				'menu-item-title'     => $item[0],
				'menu-item-object'    => 'page',
				'menu-item-object-id' => $item[1],
				'menu-item-type'      => 'post_type',
				'menu-item-status'    => 'publish',
			)
		);
	}
}

/**
 * Build the primary and (separate) footer menus and assign them to locations.
 *
 * The footer menu is its own menu — the main pages plus the legal pages — so the
 * footer's "Company" column shows a proper, complete set of links (including
 * Privacy Policy and Terms) rather than mirroring the top navigation.
 */
function norvex_build_menus( $pages ) {
	// Primary navigation.
	if ( ! wp_get_nav_menu_object( 'Primary Navigation' ) ) {
		$menu_id = wp_create_nav_menu( 'Primary Navigation' );
		norvex_add_menu_items(
			$menu_id,
			array(
				array( 'Home', $pages['home'] ),
				array( 'About', $pages['about'] ),
				array( 'Services', $pages['services'] ),
				array( 'How It Works', $pages['process'] ),
				array( 'Pricing', $pages['pricing'] ),
				array( 'Portfolio', $pages['portfolio'] ),
				array( 'Journal', $pages['blog'] ),
				array( 'Contact', $pages['contact'] ),
			)
		);

		$locations            = get_theme_mod( 'nav_menu_locations', array() );
		$locations['primary'] = $menu_id;
		set_theme_mod( 'nav_menu_locations', $locations );
	}

	// Footer menu — company links plus legal pages.
	if ( ! wp_get_nav_menu_object( 'Footer Menu' ) ) {
		$footer_id = wp_create_nav_menu( 'Footer Menu' );
		norvex_add_menu_items(
			$footer_id,
			array(
				array( 'About', $pages['about'] ),
				array( 'Services', $pages['services'] ),
				array( 'Pricing', $pages['pricing'] ),
				array( 'Journal', $pages['blog'] ),
				array( 'Contact', $pages['contact'] ),
				array( 'Privacy Policy', $pages['privacy'] ),
				array( 'Terms of Service', $pages['terms'] ),
			)
		);

		$locations           = get_theme_mod( 'nav_menu_locations', array() );
		$locations['footer'] = $footer_id;
		set_theme_mod( 'nav_menu_locations', $locations );
	}
}
