<?php
/**
 * SEO output for Norvex — social meta + structured data.
 *
 * Adds the meta the theme was missing: a page description, Open Graph and
 * Twitter Card tags for rich link previews, and schema.org JSON-LD for the
 * Organization, the current post (Article), services (Service), portfolio
 * books (Book) and every FAQ accordion on the page (FAQPage).
 *
 * All output is skipped automatically when a dedicated SEO plugin is active
 * (Yoast, Rank Math, SEOPress, All in One SEO), so the theme never fights a
 * plugin for the same tags. Everything is filterable and can be turned off
 * with the `norvex_seo_output` / `norvex_seo_faq_schema` filters.
 *
 * @package Norvex
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Whether a third-party SEO plugin is handling meta output already.
 *
 * @return bool
 */
function norvex_seo_plugin_active() {
	return (
		defined( 'WPSEO_VERSION' )            // Yoast SEO.
		|| class_exists( 'RankMath' )         // Rank Math.
		|| defined( 'SEOPRESS_VERSION' )      // SEOPress.
		|| defined( 'AIOSEO_VERSION' )        // All in One SEO.
	);
}

/**
 * Master switch for the theme's meta + entity JSON-LD output.
 *
 * @return bool
 */
function norvex_seo_enabled() {
	/**
	 * Filter whether Norvex outputs its own SEO meta and entity schema.
	 *
	 * @param bool $enabled Defaults to true unless an SEO plugin is active.
	 */
	return (bool) apply_filters( 'norvex_seo_output', ! norvex_seo_plugin_active() );
}

/**
 * Best available image URL for the current view (for OG / Twitter / schema).
 *
 * @return string
 */
function norvex_seo_image() {
	$image = '';

	if ( is_singular() && has_post_thumbnail() ) {
		$src = wp_get_attachment_image_src( get_post_thumbnail_id(), 'large' );
		if ( $src ) {
			$image = $src[0];
		}
	}

	if ( ! $image ) {
		// Custom logo, else the bundled hero illustration.
		$logo_id = get_theme_mod( 'custom_logo' );
		if ( $logo_id ) {
			$src = wp_get_attachment_image_src( $logo_id, 'full' );
			if ( $src ) {
				$image = $src[0];
			}
		}
	}

	if ( ! $image ) {
		$image = NORVEX_URI . '/assets/images/hero.svg';
	}

	return apply_filters( 'norvex_seo_image', $image );
}

/**
 * A trimmed, tag-free description for the current view.
 *
 * @return string
 */
function norvex_seo_description() {
	$desc = '';

	if ( is_singular() ) {
		$post = get_queried_object();
		if ( $post instanceof WP_Post ) {
			$custom = get_post_meta( $post->ID, '_norvex_seo_desc', true );
			if ( '' !== trim( (string) $custom ) ) {
				$desc = $custom; // Editor-provided SEO description wins.
			} elseif ( has_excerpt( $post ) ) {
				$desc = get_the_excerpt( $post );
			} else {
				// Service intro, else the content.
				$intro = get_post_meta( $post->ID, '_norvex_intro', true );
				$desc  = $intro ? $intro : wp_strip_all_tags( strip_shortcodes( $post->post_content ) );
			}
		}
	} elseif ( is_category() || is_tag() || is_tax() ) {
		$desc = term_description();
	}

	if ( ! $desc ) {
		$desc = get_bloginfo( 'description' );
	}

	$desc = wp_strip_all_tags( (string) $desc );
	$desc = trim( preg_replace( '/\s+/', ' ', $desc ) );

	if ( function_exists( 'mb_substr' ) && mb_strlen( $desc ) > 160 ) {
		$desc = rtrim( mb_substr( $desc, 0, 157 ) ) . '…';
	} elseif ( strlen( $desc ) > 160 ) {
		$desc = rtrim( substr( $desc, 0, 157 ) ) . '…';
	}

	return $desc;
}

/**
 * The canonical URL for the current view.
 *
 * @return string
 */
function norvex_seo_url() {
	if ( is_singular() ) {
		return get_permalink();
	}
	if ( is_front_page() ) {
		return home_url( '/' );
	}
	if ( is_category() || is_tag() || is_tax() ) {
		$link = get_term_link( get_queried_object() );
		return is_wp_error( $link ) ? home_url( add_query_arg( array() ) ) : $link;
	}
	return home_url( add_query_arg( array() ) );
}

/**
 * The social profile URLs configured in the Customizer (for sameAs).
 *
 * @return array
 */
function norvex_seo_social_profiles() {
	$profiles = array();
	foreach ( array( 'norvex_social_tw', 'norvex_social_ig', 'norvex_social_fb', 'norvex_social_in' ) as $key ) {
		$url = get_theme_mod( $key );
		if ( $url && '#' !== $url ) {
			$profiles[] = $url;
		}
	}
	return $profiles;
}

/**
 * Output the description + Open Graph + Twitter Card meta tags.
 */
function norvex_seo_meta_tags() {
	if ( ! norvex_seo_enabled() || is_404() ) {
		return;
	}

	$desc  = norvex_seo_description();
	$url   = norvex_seo_url();
	$image = norvex_seo_image();
	$site  = get_bloginfo( 'name' );

	if ( is_front_page() ) {
		$title = get_bloginfo( 'name' );
		$tag   = get_bloginfo( 'description' );
		if ( $tag ) {
			$title .= ' — ' . $tag;
		}
	} else {
		$title = wp_get_document_title();
	}

	$type = ( is_singular( 'post' ) ) ? 'article' : ( is_singular() ? 'website' : 'website' );

	echo "\n<!-- Norvex SEO -->\n";

	if ( $desc ) {
		printf( '<meta name="description" content="%s" />' . "\n", esc_attr( $desc ) );
	}

	// Canonical — only where WordPress core doesn't already output one. Core's
	// rel_canonical() covers singular views, so adding our own there would
	// duplicate the tag; we only fill the gap on the front page and archives.
	if ( ! is_singular() ) {
		printf( '<link rel="canonical" href="%s" />' . "\n", esc_url( $url ) );
	}

	// Open Graph.
	printf( '<meta property="og:locale" content="%s" />' . "\n", esc_attr( get_locale() ) );
	printf( '<meta property="og:type" content="%s" />' . "\n", esc_attr( $type ) );
	printf( '<meta property="og:site_name" content="%s" />' . "\n", esc_attr( $site ) );
	printf( '<meta property="og:title" content="%s" />' . "\n", esc_attr( $title ) );
	if ( $desc ) {
		printf( '<meta property="og:description" content="%s" />' . "\n", esc_attr( $desc ) );
	}
	printf( '<meta property="og:url" content="%s" />' . "\n", esc_url( $url ) );
	if ( $image ) {
		printf( '<meta property="og:image" content="%s" />' . "\n", esc_url( $image ) );
	}

	if ( 'article' === $type ) {
		$published = get_the_date( DATE_W3C );
		$modified  = get_the_modified_date( DATE_W3C );
		if ( $published ) {
			printf( '<meta property="article:published_time" content="%s" />' . "\n", esc_attr( $published ) );
		}
		if ( $modified ) {
			printf( '<meta property="article:modified_time" content="%s" />' . "\n", esc_attr( $modified ) );
		}
	}

	// Twitter Card.
	printf( '<meta name="twitter:card" content="%s" />' . "\n", $image ? 'summary_large_image' : 'summary' );
	printf( '<meta name="twitter:title" content="%s" />' . "\n", esc_attr( $title ) );
	if ( $desc ) {
		printf( '<meta name="twitter:description" content="%s" />' . "\n", esc_attr( $desc ) );
	}
	if ( $image ) {
		printf( '<meta name="twitter:image" content="%s" />' . "\n", esc_url( $image ) );
	}

	echo "<!-- /Norvex SEO -->\n\n";
}
add_action( 'wp_head', 'norvex_seo_meta_tags', 5 );

/**
 * Lowest and highest headline price across the Pricing Plans.
 *
 * Used to advertise a schema.org `priceRange` on the business entity. Only the
 * Pricing Plans (_norvex_price) are used — they are the site's canonical package
 * prices. Per-unit service rates (e.g. "$0.011/word") are deliberately excluded
 * so the range stays meaningful. Currency symbols / separators are stripped to a
 * number, and anything below $1 is ignored (covers "Custom"/"Free" entries).
 *
 * @return array{low:float,high:float}|null Null when no numeric prices exist.
 */
function norvex_seo_price_range() {
	$prices = array();

	$plans = get_posts(
		array(
			'post_type'        => 'norvex_plan',
			'numberposts'      => -1,
			'post_status'      => 'publish',
			'fields'           => 'ids',
			'suppress_filters' => false,
		)
	);
	foreach ( $plans as $plan_id ) {
		$num = (float) preg_replace( '/[^0-9.]/', '', (string) get_post_meta( $plan_id, '_norvex_price', true ) );
		if ( $num >= 1 ) {
			$prices[] = $num;
		}
	}

	if ( empty( $prices ) ) {
		return null;
	}

	return array(
		'low'  => min( $prices ),
		'high' => max( $prices ),
	);
}

/**
 * Aggregate rating + a sample of Review entities built from the testimonials.
 *
 * Only testimonials that carry a 1–5 star rating (_norvex_rating) are counted,
 * so the average and review count reflect real ratings the site owner entered.
 * The testimonial title is the reviewer's name and the body is the quote.
 *
 * @return array{average:float,count:int,reviews:array}|null Null when nothing is rated.
 */
function norvex_seo_review_data() {
	$testimonials = get_posts(
		array(
			'post_type'        => 'norvex_testimonial',
			'numberposts'      => -1,
			'post_status'      => 'publish',
			'suppress_filters' => false,
		)
	);

	$ratings = array();
	$reviews = array();

	foreach ( $testimonials as $t ) {
		$rating = (float) get_post_meta( $t->ID, '_norvex_rating', true );
		if ( $rating < 1 || $rating > 5 ) {
			continue; // Unrated testimonials don't contribute to the aggregate.
		}
		$ratings[] = $rating;

		if ( count( $reviews ) < 8 ) {
			$name   = trim( wp_strip_all_tags( get_the_title( $t ) ) );
			$body   = trim( wp_strip_all_tags( (string) $t->post_content ) );
			$review = array(
				'@type'        => 'Review',
				'author'       => array(
					'@type' => 'Person',
					'name'  => '' !== $name ? $name : __( 'Verified client', 'norvex' ),
				),
				'reviewRating' => array(
					'@type'       => 'Rating',
					'ratingValue' => (string) $rating,
					'bestRating'  => '5',
					'worstRating' => '1',
				),
			);
			if ( '' !== $body ) {
				$review['reviewBody'] = $body;
			}
			$reviews[] = $review;
		}
	}

	if ( empty( $ratings ) ) {
		return null;
	}

	return array(
		'average' => round( array_sum( $ratings ) / count( $ratings ), 1 ),
		'count'   => count( $ratings ),
		'reviews' => $reviews,
	);
}

/**
 * Print a JSON-LD script block from a data array.
 *
 * @param array $data Schema.org structured-data array.
 */
function norvex_seo_print_jsonld( $data ) {
	if ( empty( $data ) ) {
		return;
	}
	echo "\n" . '<script type="application/ld+json">' .
		wp_json_encode( $data, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE ) .
		'</script>' . "\n";
}

/**
 * Output entity structured data (Organization / Article / Service / Book).
 */
function norvex_seo_entity_schema() {
	if ( ! norvex_seo_enabled() || is_404() ) {
		return;
	}

	// Business entity — on the front page (site-wide identity). Emitted as a
	// LocalBusiness so the address, price range, star rating and reviews below can
	// power rich results; the specific type is filterable.
	if ( is_front_page() ) {
		$business_type = apply_filters( 'norvex_seo_business_type', 'LocalBusiness' );

		$org = array(
			'@context' => 'https://schema.org',
			'@type'    => $business_type,
			'@id'      => home_url( '/#business' ),
			'name'     => get_bloginfo( 'name' ),
			'url'      => home_url( '/' ),
		);

		$tagline = get_bloginfo( 'description' );
		if ( $tagline ) {
			$org['description'] = $tagline;
		}

		$logo_id = get_theme_mod( 'custom_logo' );
		if ( $logo_id ) {
			$src = wp_get_attachment_image_src( $logo_id, 'full' );
			if ( $src ) {
				$org['logo']  = $src[0];
				$org['image'] = $src[0];
			}
		}
		if ( empty( $org['image'] ) ) {
			$org['image'] = NORVEX_URI . '/assets/images/hero.svg';
		}

		$phone = norvex_option( 'norvex_phone', '' );
		$email = norvex_option( 'norvex_email', '' );
		if ( $phone ) {
			$org['telephone'] = $phone;
		}
		if ( $email ) {
			$org['email'] = $email;
		}

		$address = norvex_option( 'norvex_address', '' );
		if ( $address ) {
			$org['address'] = array(
				'@type'         => 'PostalAddress',
				'streetAddress' => $address,
			);
		}

		$org['areaServed'] = 'Worldwide';

		// priceRange — advertised from the lowest to the highest package price.
		$range = norvex_seo_price_range();
		if ( $range ) {
			$org['priceRange'] = ( $range['low'] === $range['high'] )
				? '$' . number_format( $range['low'] )
				: '$' . number_format( $range['low'] ) . '–$' . number_format( $range['high'] );
		}

		if ( $phone || $email ) {
			$org['contactPoint'] = array_filter(
				array(
					'@type'       => 'ContactPoint',
					'contactType' => 'customer service',
					'telephone'   => $phone ? $phone : null,
					'email'       => $email ? $email : null,
				)
			);
		}

		$social = norvex_seo_social_profiles();
		if ( $social ) {
			$org['sameAs'] = $social;
		}

		// aggregateRating + review — built from rated testimonials.
		$review_data = norvex_seo_review_data();
		if ( $review_data ) {
			$org['aggregateRating'] = array(
				'@type'       => 'AggregateRating',
				'ratingValue' => (string) $review_data['average'],
				'reviewCount' => (string) $review_data['count'],
				'bestRating'  => '5',
				'worstRating' => '1',
			);
			if ( ! empty( $review_data['reviews'] ) ) {
				$org['review'] = $review_data['reviews'];
			}
		}

		/**
		 * Filter the front-page business JSON-LD before it is printed.
		 *
		 * @param array $org The assembled schema.org business entity.
		 */
		$org = apply_filters( 'norvex_seo_business_schema', $org );

		norvex_seo_print_jsonld( $org );
	}

	if ( ! is_singular() ) {
		return;
	}

	$post = get_queried_object();
	if ( ! ( $post instanceof WP_Post ) ) {
		return;
	}

	// Article — blog posts.
	if ( is_singular( 'post' ) ) {
		$article = array(
			'@context'      => 'https://schema.org',
			'@type'         => 'Article',
			'headline'      => get_the_title(),
			'datePublished' => get_the_date( DATE_W3C ),
			'dateModified'  => get_the_modified_date( DATE_W3C ),
			'author'        => array(
				'@type' => 'Person',
				'name'  => get_the_author_meta( 'display_name', $post->post_author ),
			),
			'publisher'     => array(
				'@type' => 'Organization',
				'name'  => get_bloginfo( 'name' ),
			),
			'mainEntityOfPage' => get_permalink(),
			'description'   => norvex_seo_description(),
		);
		$img = norvex_seo_image();
		if ( $img ) {
			$article['image'] = $img;
		}
		norvex_seo_print_jsonld( $article );
	}

	// Service — individual service pages.
	if ( is_singular( 'norvex_service' ) ) {
		$intro   = get_post_meta( $post->ID, '_norvex_intro', true );
		$service = array(
			'@context'    => 'https://schema.org',
			'@type'       => 'Service',
			'name'        => get_the_title(),
			'description' => $intro ? wp_strip_all_tags( $intro ) : norvex_seo_description(),
			'url'         => get_permalink(),
			'provider'    => array(
				'@type' => 'Organization',
				'name'  => get_bloginfo( 'name' ),
				'url'   => home_url( '/' ),
			),
			'areaServed'  => 'Worldwide',
		);

		// Package prices → an OfferCatalog, if any are defined.
		$packages = function_exists( 'norvex_parse_packages' )
			? norvex_parse_packages( get_post_meta( $post->ID, '_norvex_packages', true ) )
			: array();
		if ( $packages ) {
			$offers = array();
			foreach ( $packages as $p ) {
				$offers[] = array(
					'@type'       => 'Offer',
					'name'        => isset( $p['name'] ) ? $p['name'] : '',
					'price'       => isset( $p['price'] ) ? preg_replace( '/[^0-9.]/', '', $p['price'] ) : '',
					'priceCurrency' => 'USD',
				);
			}
			$service['hasOfferCatalog'] = array(
				'@type'           => 'OfferCatalog',
				'name'            => get_the_title() . ' packages',
				'itemListElement' => $offers,
			);
		}
		norvex_seo_print_jsonld( $service );
	}

	// Book — portfolio items.
	if ( is_singular( 'book' ) ) {
		$book = array(
			'@context' => 'https://schema.org',
			'@type'    => 'Book',
			'name'     => get_the_title(),
			'url'      => get_permalink(),
		);

		$author = get_post_meta( $post->ID, '_norvex_author', true );
		if ( $author ) {
			$book['author'] = array(
				'@type' => 'Person',
				'name'  => $author,
			);
		}

		$img = norvex_seo_image();
		if ( $img ) {
			$book['image'] = $img;
		}

		$desc = norvex_seo_description();
		if ( $desc ) {
			$book['description'] = $desc;
		}
		norvex_seo_print_jsonld( $book );
	}
}
add_action( 'wp_head', 'norvex_seo_entity_schema', 6 );

/* =========================================================================
   FAQ schema — collected from every FAQ accordion rendered on the page.

   norvex_faq_accordion() registers its questions/answers here as it runs
   (FAQ block, service pages, pricing page…). A single FAQPage JSON-LD block is
   then printed in the footer, so Google can surface FAQ rich results without
   the author touching any markup.
   ========================================================================= */

/**
 * Register a set of FAQ pairs for the page's FAQPage schema.
 *
 * @param array $items List of [ question, answer ] pairs.
 */
function norvex_seo_register_faqs( $items ) {
	if ( empty( $items ) || ! is_array( $items ) ) {
		return;
	}

	if ( ! isset( $GLOBALS['norvex_faq_schema'] ) || ! is_array( $GLOBALS['norvex_faq_schema'] ) ) {
		$GLOBALS['norvex_faq_schema'] = array();
	}

	foreach ( $items as $f ) {
		$question = isset( $f[0] ) ? trim( wp_strip_all_tags( $f[0] ) ) : '';
		$answer   = isset( $f[1] ) ? trim( wp_strip_all_tags( $f[1] ) ) : '';
		if ( '' !== $question && '' !== $answer ) {
			$GLOBALS['norvex_faq_schema'][ md5( $question ) ] = array( $question, $answer );
		}
	}
}

/**
 * Print a single FAQPage JSON-LD block for all FAQs collected on the page.
 */
function norvex_seo_faq_schema() {
	/**
	 * Filter whether FAQPage schema is emitted.
	 *
	 * @param bool $enabled Defaults to true.
	 */
	if ( ! apply_filters( 'norvex_seo_faq_schema', true ) ) {
		return;
	}

	if ( empty( $GLOBALS['norvex_faq_schema'] ) || ! is_array( $GLOBALS['norvex_faq_schema'] ) ) {
		return;
	}

	$entities = array();
	foreach ( $GLOBALS['norvex_faq_schema'] as $pair ) {
		$entities[] = array(
			'@type'          => 'Question',
			'name'           => $pair[0],
			'acceptedAnswer' => array(
				'@type' => 'Answer',
				'text'  => $pair[1],
			),
		);
	}

	norvex_seo_print_jsonld(
		array(
			'@context'   => 'https://schema.org',
			'@type'      => 'FAQPage',
			'mainEntity' => $entities,
		)
	);
}
add_action( 'wp_footer', 'norvex_seo_faq_schema', 20 );

/* -------------------------------------------------------------------------
 * Per-page SEO fields — a tiny built-in "SEO title & description" box.
 *
 * Gives every page/post/service an optional browser-tab title and meta
 * description, the way an SEO plugin would. Leave a field blank and the theme
 * falls back to the page title / an automatic description. The whole box (and
 * its title override) steps aside automatically when a real SEO plugin is
 * active, so nothing ever fights for the same tag.
 * ---------------------------------------------------------------------- */

/**
 * Post types that get the SEO box.
 *
 * @return string[]
 */
function norvex_seo_box_types() {
	return apply_filters( 'norvex_seo_box_post_types', array( 'post', 'page', 'norvex_service', 'book' ) );
}

/**
 * Register the meta box (hidden while an SEO plugin owns this job).
 */
function norvex_seo_add_metabox() {
	if ( norvex_seo_plugin_active() ) {
		return;
	}
	foreach ( norvex_seo_box_types() as $type ) {
		add_meta_box(
			'norvex_seo',
			__( 'Search engine (SEO)', 'norvex' ),
			'norvex_seo_metabox_html',
			$type,
			'normal',
			'low'
		);
	}
}
add_action( 'add_meta_boxes', 'norvex_seo_add_metabox' );

/**
 * Meta box markup.
 *
 * @param WP_Post $post Current post.
 */
function norvex_seo_metabox_html( $post ) {
	wp_nonce_field( 'norvex_seo_save', 'norvex_seo_nonce' );

	$seo_title = get_post_meta( $post->ID, '_norvex_seo_title', true );
	$seo_desc  = get_post_meta( $post->ID, '_norvex_seo_desc', true );

	echo '<p style="margin:0 0 12px;color:#50575e;">' . esc_html__( 'Control how this page looks in the browser tab and search results. Leave blank to use the page title and an automatic description.', 'norvex' ) . '</p>';

	echo '<p style="margin:0 0 4px;font-weight:600;"><label for="norvex_seo_title">' . esc_html__( 'SEO title (browser tab & search results)', 'norvex' ) . '</label></p>';
	echo '<input type="text" id="norvex_seo_title" name="_norvex_seo_title" value="' . esc_attr( $seo_title ) . '" style="width:100%;" placeholder="' . esc_attr( get_the_title( $post ) ) . '" />';
	echo '<p style="margin:4px 0 16px;color:#646970;font-size:12px;">' . esc_html__( 'Tip: keep it under ~60 characters. You can paste your page’s hero title here to use it as the browser title.', 'norvex' ) . '</p>';

	echo '<p style="margin:0 0 4px;font-weight:600;"><label for="norvex_seo_desc">' . esc_html__( 'Meta description', 'norvex' ) . '</label></p>';
	echo '<textarea id="norvex_seo_desc" name="_norvex_seo_desc" rows="3" style="width:100%;" placeholder="' . esc_attr__( 'A short summary shown under the title in search results.', 'norvex' ) . '">' . esc_textarea( $seo_desc ) . '</textarea>';
	echo '<p style="margin:4px 0 16px;color:#646970;font-size:12px;">' . esc_html__( 'Best around 150–160 characters.', 'norvex' ) . '</p>';

	$exclude = get_post_meta( $post->ID, '_norvex_sitemap_exclude', true );
	echo '<hr style="border:none;border-top:1px solid #eee;margin:0 0 12px;" />';
	echo '<p style="margin:0;"><label><input type="checkbox" name="_norvex_sitemap_exclude" value="1" ' . checked( '1', $exclude, false ) . ' /> ' . esc_html__( 'Exclude this page from the XML sitemap', 'norvex' ) . '</label></p>';
	echo '<p style="margin:4px 0 0;color:#646970;font-size:12px;">' . esc_html__( 'Keeps the page out of the sitemap search engines read. The page stays live and reachable.', 'norvex' ) . '</p>';
}

/**
 * Save the SEO fields.
 *
 * @param int $post_id Post ID.
 */
function norvex_seo_save_metabox( $post_id ) {
	if ( ! isset( $_POST['norvex_seo_nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['norvex_seo_nonce'] ) ), 'norvex_seo_save' ) ) {
		return;
	}
	if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
		return;
	}
	if ( ! current_user_can( 'edit_post', $post_id ) ) {
		return;
	}
	if ( isset( $_POST['_norvex_seo_title'] ) ) {
		update_post_meta( $post_id, '_norvex_seo_title', sanitize_text_field( wp_unslash( $_POST['_norvex_seo_title'] ) ) );
	}
	if ( isset( $_POST['_norvex_seo_desc'] ) ) {
		update_post_meta( $post_id, '_norvex_seo_desc', sanitize_textarea_field( wp_unslash( $_POST['_norvex_seo_desc'] ) ) );
	}
	// Sitemap exclusion (checkbox: absent when unchecked).
	if ( ! empty( $_POST['_norvex_sitemap_exclude'] ) ) {
		update_post_meta( $post_id, '_norvex_sitemap_exclude', '1' );
	} else {
		delete_post_meta( $post_id, '_norvex_sitemap_exclude' );
	}
}
add_action( 'save_post', 'norvex_seo_save_metabox' );

/**
 * Use the per-page SEO title for the browser <title> when one is set. Kept out
 * of the way when an SEO plugin is active (that plugin owns the title).
 *
 * @param array $parts Document title parts (title, page, tagline, site).
 * @return array
 */
function norvex_seo_document_title( $parts ) {
	if ( norvex_seo_plugin_active() || ! is_singular() ) {
		return $parts;
	}
	$custom = get_post_meta( get_queried_object_id(), '_norvex_seo_title', true );
	if ( '' !== trim( (string) $custom ) ) {
		$parts['title'] = $custom;
	}
	return $parts;
}
add_filter( 'document_title_parts', 'norvex_seo_document_title' );
