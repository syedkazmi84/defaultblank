<?php
/**
 * XML sitemap controls + IndexNow instant indexing.
 *
 * WordPress core generates the XML sitemap (/wp-sitemap.xml). This module adds
 * an on/off switch for it, a per-page "exclude from sitemap" option (surfaced in
 * the SEO meta box), and IndexNow support: when enabled, publishing or updating
 * public content instantly notifies participating search engines (Bing, Yandex,
 * Seznam, Naver…) so new URLs get discovered without waiting for a crawl.
 *
 * Note: Google does not consume IndexNow — it relies on the XML sitemap, which
 * is why both live here together.
 *
 * @package Norvex
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Sitemap / IndexNow settings, merged over defaults.
 *
 * @return array{sitemap_enabled:bool,indexnow_enabled:bool,indexnow_key:string}
 */
function norvex_sitemap_settings() {
	$defaults = array(
		'sitemap_enabled'  => true,
		'indexnow_enabled' => false,
		'indexnow_key'     => '',
	);
	$stored = get_option( 'norvex_sitemap', array() );
	if ( ! is_array( $stored ) ) {
		$stored = array();
	}
	$s                     = wp_parse_args( $stored, $defaults );
	$s['sitemap_enabled']  = ! empty( $s['sitemap_enabled'] );
	$s['indexnow_enabled'] = ! empty( $s['indexnow_enabled'] );
	$s['indexnow_key']     = (string) $s['indexnow_key'];
	return $s;
}

/**
 * The IndexNow API key, generating and persisting one on first use.
 *
 * @return string A 32-character key (letters + digits).
 */
function norvex_indexnow_key() {
	$s = norvex_sitemap_settings();
	if ( '' !== $s['indexnow_key'] ) {
		return $s['indexnow_key'];
	}
	$s['indexnow_key'] = wp_generate_password( 32, false );
	update_option( 'norvex_sitemap', $s );
	return $s['indexnow_key'];
}

/* -------------------------------------------------------------------------
 * XML sitemap: enable switch + per-page exclusion.
 * ---------------------------------------------------------------------- */

/**
 * Honour the "Enable XML sitemap" switch.
 *
 * @param bool $enabled Core default.
 * @return bool
 */
function norvex_sitemap_enabled( $enabled ) {
	$s = norvex_sitemap_settings();
	return $s['sitemap_enabled'] ? $enabled : false;
}
add_filter( 'wp_sitemaps_enabled', 'norvex_sitemap_enabled' );

/**
 * Drop pages/posts flagged "exclude from sitemap" out of the sitemap query.
 *
 * @param array  $args      WP_Query args for this sitemap sub-type.
 * @param string $post_type The post type being listed.
 * @return array
 */
function norvex_sitemap_exclude_query( $args, $post_type ) {
	$ids = get_posts(
		array(
			'post_type'        => $post_type,
			'post_status'      => 'publish',
			'fields'           => 'ids',
			'numberposts'      => -1,
			'meta_key'         => '_norvex_sitemap_exclude', // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_key -- bounded to flagged posts, sitemap is cached.
			'meta_value'       => '1', // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_value
			'suppress_filters' => false,
		)
	);
	if ( ! empty( $ids ) ) {
		$existing             = isset( $args['post__not_in'] ) ? (array) $args['post__not_in'] : array();
		$args['post__not_in'] = array_merge( $existing, $ids );
	}
	return $args;
}
add_filter( 'wp_sitemaps_posts_query_args', 'norvex_sitemap_exclude_query', 10, 2 );

/* -------------------------------------------------------------------------
 * IndexNow: key verification file + ping on publish.
 * ---------------------------------------------------------------------- */

/**
 * Serve the IndexNow key verification file at /{key}.txt.
 *
 * Search engines fetch this to confirm the site owns the key. Handled directly
 * (no rewrite rules) so it works on any permalink structure.
 */
function norvex_indexnow_serve_key() {
	if ( is_admin() ) {
		return;
	}
	$s = norvex_sitemap_settings();
	if ( ! $s['indexnow_enabled'] || '' === $s['indexnow_key'] ) {
		return;
	}
	$path = isset( $_SERVER['REQUEST_URI'] ) ? (string) wp_parse_url( wp_unslash( $_SERVER['REQUEST_URI'] ), PHP_URL_PATH ) : ''; // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- path compared to a known key, not stored/output as HTML.
	if ( ltrim( $path, '/' ) === $s['indexnow_key'] . '.txt' ) {
		header( 'Content-Type: text/plain; charset=UTF-8' );
		echo esc_html( $s['indexnow_key'] );
		exit;
	}
}
add_action( 'init', 'norvex_indexnow_serve_key' );

/**
 * Notify IndexNow when public content is published or updated.
 *
 * @param string  $new_status New post status.
 * @param string  $old_status Previous post status.
 * @param WP_Post $post       The post.
 */
function norvex_indexnow_on_transition( $new_status, $old_status, $post ) {
	if ( 'publish' !== $new_status ) {
		return;
	}
	if ( ! ( $post instanceof WP_Post ) || wp_is_post_revision( $post ) || wp_is_post_autosave( $post ) ) {
		return;
	}
	$type = get_post_type_object( $post->post_type );
	if ( ! $type || empty( $type->public ) ) {
		return; // Only public, indexable content.
	}
	$s = norvex_sitemap_settings();
	if ( ! $s['indexnow_enabled'] || '' === $s['indexnow_key'] ) {
		return;
	}
	$url = get_permalink( $post );
	if ( $url ) {
		norvex_indexnow_submit( $url );
	}
}
add_action( 'transition_post_status', 'norvex_indexnow_on_transition', 10, 3 );

/**
 * Submit a single URL to the IndexNow API and remember the last ping.
 *
 * @param string $url The URL to submit.
 */
function norvex_indexnow_submit( $url ) {
	$s   = norvex_sitemap_settings();
	$key = $s['indexnow_key'];
	if ( '' === $key ) {
		return;
	}

	$endpoint = add_query_arg(
		array(
			'url'         => rawurlencode( $url ),
			'key'         => rawurlencode( $key ),
			'keyLocation' => rawurlencode( home_url( '/' . $key . '.txt' ) ),
		),
		'https://api.indexnow.org/indexnow'
	);

	// Fire-and-forget so saving a post is never held up by the ping.
	wp_remote_get(
		$endpoint,
		array(
			'timeout'     => 5,
			'blocking'    => false,
			'redirection' => 2,
			'user-agent'  => 'Norvex/' . ( defined( 'NORVEX_VERSION' ) ? NORVEX_VERSION : '1.0' ),
		)
	);

	update_option(
		'norvex_indexnow_last',
		array(
			'url'  => $url,
			'time' => current_time( 'mysql' ),
		),
		false
	);
}

/* -------------------------------------------------------------------------
 * Admin: the "Search engine visibility" card, rendered on the Marketing page.
 * ---------------------------------------------------------------------- */

/**
 * Render the sitemap + IndexNow settings card (called from the Marketing page).
 */
function norvex_sitemap_render_card() {
	$s        = norvex_sitemap_settings();
	$last     = get_option( 'norvex_indexnow_last', array() );
	$site_url = home_url( '/wp-sitemap.xml' );
	?>
	<div style="max-width:1100px;margin-top:28px;background:#fff;border:1px solid #dcdcde;border-radius:8px;padding:22px 24px;box-shadow:0 1px 2px rgba(0,0,0,.04);">
		<h2 style="margin-top:0;display:flex;align-items:center;gap:8px;">
			<span class="dashicons dashicons-search" style="color:#c08a3e;"></span>
			<?php esc_html_e( 'Search engine visibility', 'norvex' ); ?>
		</h2>
		<p style="color:#50575e;max-width:760px;">
			<?php esc_html_e( 'Your XML sitemap helps search engines find every page. IndexNow goes further — it pings participating engines (Bing, Yandex and others) the moment you publish, so new content is discovered fast. Google doesn’t use IndexNow; it reads the sitemap.', 'norvex' ); ?>
		</p>

		<?php if ( isset( $_GET['norvex_sitemap_saved'] ) ) : // phpcs:ignore WordPress.Security.NonceVerification.Recommended ?>
			<div class="notice notice-success is-dismissible" style="margin:12px 0;"><p><?php esc_html_e( 'Sitemap settings saved.', 'norvex' ); ?></p></div>
		<?php endif; ?>

		<p style="margin:14px 0;">
			<span class="dashicons dashicons-media-code" style="color:#646970;"></span>
			<a href="<?php echo esc_url( $site_url ); ?>" target="_blank" rel="noopener"><?php echo esc_html( $site_url ); ?></a>
			<?php if ( ! $s['sitemap_enabled'] ) : ?>
				<em style="color:#b32d2e;">(<?php esc_html_e( 'currently disabled', 'norvex' ); ?>)</em>
			<?php endif; ?>
		</p>

		<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
			<input type="hidden" name="action" value="norvex_save_sitemap" />
			<?php wp_nonce_field( 'norvex_save_sitemap' ); ?>
			<table class="form-table" role="presentation">
				<tr>
					<th scope="row"><?php esc_html_e( 'XML sitemap', 'norvex' ); ?></th>
					<td>
						<label>
							<input type="checkbox" name="norvex_sitemap[sitemap_enabled]" value="1" <?php checked( $s['sitemap_enabled'] ); ?> />
							<?php esc_html_e( 'Generate the XML sitemap (recommended)', 'norvex' ); ?>
						</label>
						<p class="description"><?php esc_html_e( 'Exclude an individual page from the sitemap in that page’s “Search engine (SEO)” box.', 'norvex' ); ?></p>
					</td>
				</tr>
				<tr>
					<th scope="row"><?php esc_html_e( 'IndexNow', 'norvex' ); ?></th>
					<td>
						<label>
							<input type="checkbox" name="norvex_sitemap[indexnow_enabled]" value="1" <?php checked( $s['indexnow_enabled'] ); ?> />
							<?php esc_html_e( 'Instantly notify search engines when I publish or update content', 'norvex' ); ?>
						</label>
						<?php if ( $s['indexnow_enabled'] && '' !== $s['indexnow_key'] ) : ?>
							<p class="description" style="margin-top:8px;">
								<?php
								/* translators: %s: IndexNow key verification file URL. */
								echo esc_html( sprintf( __( 'Verification key file: %s', 'norvex' ), home_url( '/' . $s['indexnow_key'] . '.txt' ) ) );
								?>
							</p>
							<?php if ( is_array( $last ) && ! empty( $last['url'] ) ) : ?>
								<p class="description">
									<?php
									/* translators: 1: last submitted URL, 2: date/time. */
									echo esc_html( sprintf( __( 'Last notified: %1$s (%2$s)', 'norvex' ), $last['url'], $last['time'] ) );
									?>
								</p>
							<?php endif; ?>
						<?php endif; ?>
					</td>
				</tr>
			</table>
			<?php submit_button( __( 'Save sitemap settings', 'norvex' ) ); ?>
		</form>
	</div>
	<?php
}

/**
 * Persist the sitemap / IndexNow settings (admin-post handler).
 */
function norvex_sitemap_save() {
	if ( ! current_user_can( 'manage_options' ) ) {
		wp_die( esc_html__( 'You are not allowed to do that.', 'norvex' ) );
	}
	check_admin_referer( 'norvex_save_sitemap' );

	$in       = isset( $_POST['norvex_sitemap'] ) && is_array( $_POST['norvex_sitemap'] ) ? wp_unslash( $_POST['norvex_sitemap'] ) : array(); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- booleans handled below.
	$existing = norvex_sitemap_settings();

	$indexnow_enabled = ! empty( $in['indexnow_enabled'] );

	// Generate a key the first time IndexNow is switched on; keep it thereafter.
	$key = $existing['indexnow_key'];
	if ( $indexnow_enabled && '' === $key ) {
		$key = wp_generate_password( 32, false );
	}

	update_option(
		'norvex_sitemap',
		array(
			'sitemap_enabled'  => ! empty( $in['sitemap_enabled'] ),
			'indexnow_enabled' => $indexnow_enabled,
			'indexnow_key'     => $key,
		)
	);

	wp_safe_redirect( add_query_arg( 'norvex_sitemap_saved', '1', admin_url( 'admin.php?page=norvex-tracking' ) ) );
	exit;
}
add_action( 'admin_post_norvex_save_sitemap', 'norvex_sitemap_save' );
