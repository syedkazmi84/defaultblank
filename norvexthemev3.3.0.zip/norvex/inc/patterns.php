<?php
/**
 * Block patterns — the Norvex pattern library.
 *
 * Registers a set of fully-editable core-block PATTERNS: for each core section
 * there are five distinct, on-brand layouts (different structure, not just a
 * recolour). They live in the editor's Patterns tab under an "Norvex"
 * category, plus a per-section sub-category, and are built from core blocks so
 * they can be rearranged, restyled and nested freely.
 *
 * Additive: the custom Norvex blocks stay registered too. Patterns are
 * built with the core-block helpers in inc/demo-blocks.php (awb_*), with a few
 * pattern-only variant helpers (awp_*) below.
 *
 * @package Norvex
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/* =========================================================================
   Variant helpers — small builders for the layouts that the demo helpers
   don't already cover. All return core-block markup.
   ========================================================================= */

/** A single priced plan card (core column). */
function awp_plan_card( $u, $name, $price, $blurb, $features, $featured = false ) {
	$inner = '';
	if ( $featured ) {
		$inner .= awb_para( __( 'Most popular', 'norvex' ), array( 'align' => 'center', 'class' => 'aw-badge' ) );
	}
	$inner .= awb_heading( $name, 3, array( 'align' => 'center', 'size' => 'large' ) );
	$inner .= awb_heading( $price, 2, array( 'align' => 'center', 'class' => 'aw-price' ) );
	$inner .= awb_para( $blurb, array( 'align' => 'center', 'color' => 'muted', 'size' => 'small' ) );
	$inner .= awb_list( $features );
	$inner .= awb_buttons( array( array( __( 'Get started', 'norvex' ), $u['contact'], $featured ? 'fill' : 'outline' ) ), 'center' );
	return awb_column( $inner, array( 'bg' => 'paper', 'class' => 'aw-card aw-price-card' . ( $featured ? ' aw-card--feature' : '' ), 'pad' => '34px' ) );
}

/** A single testimonial quote card (core column). */
function awp_quote_card( $text, $cite ) {
	$inner = '<!-- wp:quote {"className":"aw-quote-card"} --><blockquote class="wp-block-quote aw-quote-card">'
		. awb_para( $text ) . '<cite>' . esc_html( $cite ) . '</cite></blockquote><!-- /wp:quote -->';
	return awb_column( $inner );
}

/** A set of stat columns, light or dark ground. $stats = array( array( number, label ) ). */
function awp_statcols( $stats, $dark = false, $cards = false ) {
	$cols = '';
	foreach ( $stats as $s ) {
		$cols .= awb_column(
			awb_heading( $s[0], 2, array( 'align' => 'center', 'class' => 'aw-snum' ) )
			. awb_para( $s[1], array( 'align' => 'center', 'class' => 'aw-slabel' ) )
		);
	}
	$cls = 'aw-statset' . ( $dark ? ' aw-statset--dark' : '' ) . ( $cards ? ' aw-statcards' : '' );
	return awb_columns( $cols, array( 'class' => $cls ) );
}

/** Details/accordion items. $items = array( array( q, a ) ). */
function awp_details( $items ) {
	$out = '';
	foreach ( $items as $it ) {
		$out .= '<!-- wp:details {"className":"aw-faq"} --><details class="wp-block-details aw-faq"><summary>' . esc_html( $it[0] ) . '</summary>'
			. awb_para( $it[1], array( 'color' => 'muted' ) ) . '</details><!-- /wp:details -->';
	}
	return $out;
}

/** Sample FAQ content. */
function awp_faq_items() {
	return array(
		array( __( 'Do I keep the rights to my book?', 'norvex' ), __( 'Always. Copyright stays in your name, every retailer account is opened for you, and each store pays you directly. We charge a flat fee, never a share of your royalties.', 'norvex' ) ),
		array( __( 'How long does the whole process take?', 'norvex' ), __( 'Most books go from manuscript to live on every major retailer in about 30 days once editing is complete.', 'norvex' ) ),
		array( __( 'Can I choose just one service?', 'norvex' ), __( 'Yes — take the full package or any single service on its own. Every price is listed on the services page.', 'norvex' ) ),
		array( __( 'How does pricing work?', 'norvex' ), __( 'We agree a fixed scope and price in writing before any work starts. The scope sets the number, and the number is the number.', 'norvex' ) ),
	);
}

/** A left-aligned constrained heading cluster (eyebrow + heading + lead). */
function awp_head_left( $eyebrow, $title, $lead = '' ) {
	$out = '';
	if ( $eyebrow ) {
		$out .= awb_para( $eyebrow, array( 'class' => 'aw-eyebrow' ) );
	}
	$out .= awb_heading( $title, 2, array( 'size' => 'x-large' ) );
	if ( $lead ) {
		$out .= awb_para( $lead, array( 'color' => 'muted', 'size' => 'medium' ) );
	}
	return $out;
}

/* =========================================================================
   HTML -> editable core blocks converter. Turns a custom block's rendered
   markup into native WordPress block markup carrying the same .norvex-* classes
   (so the CSS applies identically). Structural containers become wp:group with
   blockGap 0; headings/paragraphs become wp:heading / wp:paragraph; links,
   SVG icons, images and other inline media are preserved verbatim in wp:html.
   ========================================================================= */

/** Serialise a node's inner HTML (used for heading/paragraph content). */
function norvex_pat_inner_html( $node ) {
	$h = '';
	foreach ( $node->childNodes as $c ) {
		$h .= $node->ownerDocument->saveHTML( $c );
	}
	return trim( $h );
}

/** Recursively convert a DOM node's children into core-block markup. */
function norvex_pat_convert( $node ) {
	$out = '';
	foreach ( $node->childNodes as $n ) {
		if ( XML_ELEMENT_NODE !== $n->nodeType ) {
			continue;
		}
		$tag = strtolower( $n->nodeName );
		$cls = $n->getAttribute( 'class' );
		if ( in_array( $tag, array( 'section', 'div', 'ol', 'ul', 'li', 'article', 'aside', 'header', 'footer', 'nav' ), true ) ) {
			// A container with block-level children becomes an editable group;
			// one that only holds inline content stays verbatim (wp:html).
			$has_block_child = false;
			foreach ( $n->childNodes as $c ) {
				if ( XML_ELEMENT_NODE === $c->nodeType && in_array( strtolower( $c->nodeName ), array( 'div', 'ul', 'ol', 'li', 'section', 'article', 'p', 'h1', 'h2', 'h3', 'h4', 'h5', 'h6' ), true ) ) {
					$has_block_child = true;
					break;
				}
			}
			if ( ! $has_block_child ) {
				$out .= '<!-- wp:html -->' . $n->ownerDocument->saveHTML( $n ) . '<!-- /wp:html -->';
				continue;
			}
			$attrs = array();
			if ( 'section' === $tag ) {
				$attrs['tagName'] = 'section';
			}
			if ( '' !== $cls ) {
				$attrs['className'] = $cls;
			}
			$attrs['style']  = array( 'spacing' => array( 'blockGap' => '0' ) );
			$attrs['layout'] = array( 'type' => 'default' );
			$etag = ( 'section' === $tag ) ? 'section' : 'div';
			$out .= '<!-- wp:group ' . wp_json_encode( $attrs ) . ' --><' . $etag . ' class="wp-block-group' . ( '' !== $cls ? ' ' . $cls : '' ) . '">' . norvex_pat_convert( $n ) . '</' . $etag . '><!-- /wp:group -->';
		} elseif ( preg_match( '/^h[1-6]$/', $tag ) ) {
			$lvl   = (int) substr( $tag, 1 );
			$attrs = array();
			if ( 2 !== $lvl ) {
				$attrs['level'] = $lvl;
			}
			if ( '' !== $cls ) {
				$attrs['className'] = $cls;
			}
			$aj   = $attrs ? ' ' . wp_json_encode( $attrs ) : '';
			$out .= '<!-- wp:heading' . $aj . ' --><' . $tag . ' class="wp-block-heading' . ( '' !== $cls ? ' ' . $cls : '' ) . '">' . norvex_pat_inner_html( $n ) . '</' . $tag . '><!-- /wp:heading -->';
		} elseif ( 'p' === $tag || 'span' === $tag ) {
			$attrs = array();
			if ( '' !== $cls ) {
				$attrs['className'] = $cls;
			}
			$aj   = $attrs ? ' ' . wp_json_encode( $attrs ) : '';
			$out .= '<!-- wp:paragraph' . $aj . ' --><p' . ( '' !== $cls ? ' class="' . esc_attr( $cls ) . '"' : '' ) . '>' . norvex_pat_inner_html( $n ) . '</p><!-- /wp:paragraph -->';
		} else {
			$out .= '<!-- wp:html -->' . $n->ownerDocument->saveHTML( $n ) . '<!-- /wp:html -->';
		}
	}
	return $out;
}

/** Render a Norvex block and return an editable core-block version of it. */
function norvex_blocks_from_render( $block_name ) {
	if ( ! class_exists( 'DOMDocument' ) ) {
		return '';
	}
	$html = render_block( array( 'blockName' => $block_name, 'attrs' => array(), 'innerBlocks' => array(), 'innerHTML' => '', 'innerContent' => array() ) );
	$html = preg_replace( '/\s*wp-block-norvex-[a-z0-9-]+/', '', (string) $html, 1 );
	$html = trim( $html );
	if ( '' === $html ) {
		return '';
	}
	$doc = new DOMDocument();
	libxml_use_internal_errors( true );
	$doc->loadHTML( '<?xml encoding="utf-8"?><div id="nxroot">' . $html . '</div>', LIBXML_HTML_NOIMPLIED | LIBXML_HTML_NODEFDTD );
	libxml_clear_errors();
	$root = $doc->getElementById( 'nxroot' );
	if ( ! $root ) {
		return '';
	}
	return norvex_pat_convert( $root );
}

/* =========================================================================
   Register the library.
   ========================================================================= */
function norvex_register_block_patterns() {
	if ( ! function_exists( 'register_block_pattern' ) || ! function_exists( 'register_block_pattern_category' ) ) {
		return;
	}

	register_block_pattern_category( 'norvex', array( 'label' => __( 'Norvex', 'norvex' ) ) );
	$sections = array(
		'section'      => __( 'Norvex · Homepage sections', 'norvex' ),
		'heroes'       => __( 'Norvex · Heroes', 'norvex' ),
		'cards'        => __( 'Norvex · Feature cards', 'norvex' ),
		'pricing'      => __( 'Norvex · Pricing', 'norvex' ),
		'testimonials' => __( 'Norvex · Testimonials', 'norvex' ),
		'cta'          => __( 'Norvex · Call to action', 'norvex' ),
		'content'      => __( 'Norvex · Content', 'norvex' ),
		'stats'        => __( 'Norvex · Stats', 'norvex' ),
		'faq'          => __( 'Norvex · FAQ', 'norvex' ),
	);
	foreach ( $sections as $slug => $label ) {
		register_block_pattern_category( 'norvex-' . $slug, array( 'label' => $label ) );
	}

	$u = array( 'home' => '#', 'about' => '#', 'services' => '#', 'process' => '#', 'pricing' => '#', 'portfolio' => '#', 'contact' => '#', 'blog' => '#' );

	$svc3 = array(
		array( 'image' => 'service-quill.svg', 'title' => __( 'Ghostwriting', 'norvex' ), 'text' => __( 'A professional writer turns your idea into a finished manuscript in your voice.', 'norvex' ), 'link' => $u['services'], 'linklabel' => __( 'Learn more', 'norvex' ) ),
		array( 'image' => 'service-edit.svg', 'title' => __( 'Editing', 'norvex' ), 'text' => __( 'Developmental, line, copy and proof editing at transparent rates.', 'norvex' ), 'link' => $u['services'], 'linklabel' => __( 'Learn more', 'norvex' ) ),
		array( 'image' => 'service-design.svg', 'title' => __( 'Design', 'norvex' ), 'text' => __( 'Genre-correct covers and print-ready interiors for ebook and paperback.', 'norvex' ), 'link' => $u['services'], 'linklabel' => __( 'Learn more', 'norvex' ) ),
	);
	$svc4 = $svc3;
	$svc4[] = array( 'image' => 'service-book.svg', 'title' => __( 'Publishing', 'norvex' ), 'text' => __( 'Distribution across every major retailer — each account opened in your name.', 'norvex' ), 'link' => $u['services'], 'linklabel' => __( 'Learn more', 'norvex' ) );

	$stats3 = array( array( '100%', __( 'Royalties you keep', 'norvex' ) ), array( '30', __( 'Days to go live', 'norvex' ) ), array( '830+', __( 'Authors published', 'norvex' ) ) );
	$stats4 = array_merge( $stats3, array( array( '40+', __( 'Countries reached', 'norvex' ) ) ) );

	$quotes = array(
		array( __( 'They treated my manuscript like it mattered — and the launch reflected the work I put in.', 'norvex' ), __( 'Mara Ellison, novelist', 'norvex' ) ),
		array( __( 'One team, one point of contact, and a finished book I’m proud of. I never had to chase anyone.', 'norvex' ), __( 'James Okoro, business author', 'norvex' ) ),
		array( __( 'Transparent pricing, no surprises, and I kept every right. Exactly what they promised.', 'norvex' ), __( 'Nadia Okafor, memoirist', 'norvex' ) ),
	);

	$p = array(); // slug => array( title, section, content )

	/* ============================ HEROES ============================ */
	$p['hero-centered'] = array( __( 'Hero — Centered dark', 'norvex' ), 'heroes',
		awb_hero( array(
			'bg' => 'ink', 'minHeight' => 82,
			'eyebrow' => __( 'Ghostwriting · Editing · Publishing · Marketing', 'norvex' ),
			'title' => __( 'Publish your book, and keep 100% of your rights', 'norvex' ),
			'lead' => __( 'Full-service book publishing on a flat fee — every retailer account set up in your name.', 'norvex' ),
			'buttons' => array( array( __( 'Book a free consultation', 'norvex' ), $u['contact'], 'fill' ), array( __( 'Explore our services', 'norvex' ), $u['services'], 'outline' ) ),
			'extra' => awb_hero_stats( $stats3 ),
		) ) );

	$p['hero-split'] = array( __( 'Hero — Split image', 'norvex' ), 'heroes',
		awb_group(
			awb_media_text( array(
				'side' => 'left', 'image' => 'hero.svg',
				'eyebrow' => __( 'Full-service publishing', 'norvex' ),
				'heading' => __( 'Your book, made whole', 'norvex' ),
				'body' => array( __( 'Editing, design and worldwide distribution under one roof — every account in your name, every royalty yours to keep.', 'norvex' ) ),
				'btn' => array( __( 'Book a free call', 'norvex' ), $u['contact'] ),
			) ),
			array( 'align' => 'full' )
		) );

	$p['hero-minimal'] = array( __( 'Hero — Minimal light', 'norvex' ), 'heroes',
		awb_hero( array(
			'bg' => 'sand', 'minHeight' => 62,
			'eyebrow' => __( 'Norvex Publishing', 'norvex' ),
			'title' => __( 'The publisher built around the book', 'norvex' ),
			'lead' => __( 'Fewer titles, more attention. A considered process from first read to launch day.', 'norvex' ),
			'buttons' => array( array( __( 'Start your book', 'norvex' ), $u['contact'], 'fill' ) ),
		) ) );

	$p['hero-left'] = array( __( 'Hero — Left band', 'norvex' ), 'heroes',
		awb_group(
			awp_head_left( __( 'Ghostwriting · Editing · Publishing', 'norvex' ), __( 'Write it once. We’ll make it a book.', 'norvex' ), __( 'A finished title on every retailer is six jobs wearing one cover. We run all six — or any one alone.', 'norvex' ) )
			. awb_buttons( array( array( __( 'Book a free call', 'norvex' ), $u['contact'], 'fill' ), array( __( 'See pricing', 'norvex' ), $u['pricing'], 'outline' ) ) ),
			array( 'align' => 'full', 'bg' => 'sand' )
		) );

	$p['hero-stats'] = array( __( 'Hero — Stat forward', 'norvex' ), 'heroes',
		awb_hero( array(
			'bg' => 'ink', 'minHeight' => 70,
			'eyebrow' => __( 'By the numbers', 'norvex' ),
			'title' => __( 'A track record you can count', 'norvex' ),
			'buttons' => array( array( __( 'Work with us', 'norvex' ), $u['contact'], 'fill' ) ),
			'extra' => awb_hero_stats( $stats4 ),
		) ) );

	/* ============================ CARDS ============================ */
	$p['cards-3'] = array( __( 'Feature cards — Three up', 'norvex' ), 'cards',
		awb_group( awb_section_head( __( 'What we do', 'norvex' ), __( 'Everything your book needs, in one place', 'norvex' ), __( 'From the first draft to the final launch, one team handles the hard parts.', 'norvex' ) ) . awb_spacer( '20px' ) . awb_card_row( $svc3 ), array( 'align' => 'full' ) ) );

	$p['cards-4'] = array( __( 'Feature cards — Four up', 'norvex' ), 'cards',
		awb_group( awb_section_head( __( 'Our services', 'norvex' ), __( 'Four ways we help authors', 'norvex' ) ) . awb_spacer( '20px' ) . awb_card_row( $svc4 ), array( 'align' => 'full', 'bg' => 'sand' ) ) );

	$p['cards-alt'] = array( __( 'Feature cards — Alternating media', 'norvex' ), 'cards',
		awb_group(
			awb_media_text( array( 'side' => 'left', 'image' => 'service-edit.svg', 'eyebrow' => __( 'Editing', 'norvex' ), 'heading' => __( 'Editing that respects the book', 'norvex' ), 'body' => array( __( 'Three passes by three specialists — developmental, line and proof.', 'norvex' ) ), 'btn' => array( __( 'Learn more', 'norvex' ), $u['services'] ) ) )
			. awb_spacer( '30px' )
			. awb_media_text( array( 'side' => 'right', 'image' => 'service-design.svg', 'eyebrow' => __( 'Design', 'norvex' ), 'heading' => __( 'Covers built for your shelf', 'norvex' ), 'body' => array( __( 'Genre-correct covers and interiors, produced to every retailer’s spec.', 'norvex' ) ), 'btn' => array( __( 'Learn more', 'norvex' ), $u['services'] ) ) ),
			array( 'align' => 'full' )
		) );

	$flist_items = array(
		array( __( 'Discovery & audit', 'norvex' ), __( 'We map what you have and send a written proposal within 48 hours.', 'norvex' ) ),
		array( __( 'Editorial & design', 'norvex' ), __( 'Specialists edit, then set the cover and interior to your genre.', 'norvex' ) ),
		array( __( 'Distribution', 'norvex' ), __( 'Every file the retailers ask for, accounts opened in your name.', 'norvex' ) ),
		array( __( 'Launch & beyond', 'norvex' ), __( 'A launch sequence and 90 days of managed ads, reported in plain numbers.', 'norvex' ) ),
	);
	$flist_rows = '';
	foreach ( $flist_items as $i => $it ) {
		$flist_rows .= awb_columns(
			awb_column( '<!-- wp:paragraph {"className":"aw-flist__n"} --><p class="aw-flist__n">' . sprintf( '%02d', $i + 1 ) . '</p><!-- /wp:paragraph -->', array( 'class' => 'aw-flist__num-col' ) )
			. awb_column( awb_heading( $it[0], 3, array( 'size' => 'large' ) ) . awb_para( $it[1], array( 'color' => 'muted' ) ) )
		);
	}
	$p['cards-list'] = array( __( 'Feature cards — Numbered list', 'norvex' ), 'cards',
		awb_group(
			awb_section_head( __( 'How it works', 'norvex' ), __( 'A clear, four-step path', 'norvex' ) )
			. awb_spacer( '10px' )
			. '<!-- wp:group {"className":"aw-flist","layout":{"type":"constrained"}} --><div class="wp-block-group aw-flist">' . $flist_rows . '</div><!-- /wp:group -->',
			array( 'align' => 'full' )
		) );

	$iconrow = '';
	foreach ( array_slice( $svc3, 0, 3 ) as $c ) {
		$iconrow .= awb_column( awb_image( $c['image'], '', array( 'width' => '56px' ) ) . awb_heading( $c['title'], 3, array( 'align' => 'center', 'size' => 'large' ) ) . awb_para( $c['text'], array( 'align' => 'center', 'color' => 'muted' ) ) );
	}
	$p['cards-icons'] = array( __( 'Feature cards — Icon row', 'norvex' ), 'cards',
		awb_group( awb_section_head( __( 'Why authors choose us', 'norvex' ), __( 'Three promises, every project', 'norvex' ) ) . awb_spacer( '20px' ) . awb_columns( $iconrow, array( 'class' => 'aw-iconrow' ) ), array( 'align' => 'full', 'bg' => 'sand' ) ) );

	/* ============================ PRICING ============================ */
	$p['pricing-3'] = array( __( 'Pricing — Three plans', 'norvex' ), 'pricing',
		awb_group( awb_section_head( __( 'Pricing', 'norvex' ), __( 'Packages that fit your book', 'norvex' ), __( 'Every plan is tailored after a free consultation.', 'norvex' ) ) . awb_spacer( '20px' ) . awb_price_row( $u ), array( 'align' => 'full' ) ) );

	$p['pricing-2'] = array( __( 'Pricing — Two plans', 'norvex' ), 'pricing',
		awb_group(
			awb_section_head( __( 'Pricing', 'norvex' ), __( 'Two simple ways to work with us', 'norvex' ) ) . awb_spacer( '20px' )
			. awb_columns(
				awp_plan_card( $u, __( 'Essentials', 'norvex' ), '$1,900', __( 'A polished, publish-ready book.', 'norvex' ), array( __( 'Copy & proof editing', 'norvex' ), __( 'Cover + interior design', 'norvex' ), __( 'Ebook & paperback files', 'norvex' ), __( 'You keep all rights', 'norvex' ) ) )
				. awp_plan_card( $u, __( 'Full Service', 'norvex' ), '$4,900', __( 'From manuscript to a marketed launch.', 'norvex' ), array( __( 'Three editorial passes', 'norvex' ), __( 'Distribution in your name', 'norvex' ), __( '90-day launch & ads', 'norvex' ), __( 'Dedicated manager', 'norvex' ) ), true ),
				array( 'class' => 'aw-cards aw-pricing' )
			),
			array( 'align' => 'full' )
		) );

	$p['pricing-single'] = array( __( 'Pricing — Single highlighted', 'norvex' ), 'pricing',
		awb_group(
			awb_section_head( __( 'One flat fee', 'norvex' ), __( 'Everything, under one roof', 'norvex' ) ) . awb_spacer( '20px' )
			. '<!-- wp:group {"className":"aw-solo","layout":{"type":"constrained"}} --><div class="wp-block-group aw-solo">'
			. '<!-- wp:columns {"className":"aw-pricing"} --><div class="wp-block-columns aw-pricing">'
			. awp_plan_card( $u, __( 'Full Service', 'norvex' ), '$4,900', __( 'Our most popular package.', 'norvex' ), array( __( 'Three editorial passes', 'norvex' ), __( 'Cover + interior design', 'norvex' ), __( 'Distribution in your name', 'norvex' ), __( '90-day launch & ads', 'norvex' ), __( 'You keep 100% of rights', 'norvex' ) ), true )
			. '</div><!-- /wp:columns --></div><!-- /wp:group -->',
			array( 'align' => 'full', 'bg' => 'sand' )
		) );

	$p['pricing-table'] = array( __( 'Pricing — Comparison table', 'norvex' ), 'pricing',
		awb_group( awb_section_head( __( 'Compare', 'norvex' ), __( 'What’s included in each package', 'norvex' ) ) . awb_spacer( '16px' ) . awb_compare_table(), array( 'align' => 'full' ) ) );

	$tier = array(
		array( __( 'Ghostwriting', 'norvex' ), __( 'Your concept becomes a finished manuscript in your voice.', 'norvex' ), 'From $5,495' ),
		array( __( 'Editing', 'norvex' ), __( 'Developmental through proof, at transparent rates.', 'norvex' ), 'From $299' ),
		array( __( 'Design', 'norvex' ), __( 'Genre-correct covers and print-ready interiors.', 'norvex' ), 'From $199' ),
		array( __( 'Distribution', 'norvex' ), __( 'Every major retailer, set up in your name.', 'norvex' ), 'From $249' ),
		array( __( 'Marketing', 'norvex' ), __( 'Positioning, ads and ongoing visibility.', 'norvex' ), 'From $1,495' ),
	);
	$tier_rows = '';
	foreach ( $tier as $t ) {
		$tier_rows .= awb_columns(
			awb_column( awb_heading( $t[0], 3, array( 'size' => 'large' ) ) . awb_para( $t[1], array( 'color' => 'muted' ) ) )
			. awb_column( awb_para( $t[2], array( 'class' => 'aw-pricerow__price' ) ), array( 'class' => 'aw-pricerow__price-col' ) )
			. awb_column( awb_buttons( array( array( __( 'Get a quote', 'norvex' ), $u['contact'], 'outline' ) ) ), array( 'class' => 'aw-pricerow__btn-col' ) )
		);
	}
	$p['pricing-tiered'] = array( __( 'Pricing — Itemised list', 'norvex' ), 'pricing',
		awb_group(
			awb_section_head( __( 'Services & rates', 'norvex' ), __( 'Posted openly — no quote required', 'norvex' ) ) . awb_spacer( '10px' )
			. '<!-- wp:group {"className":"aw-pricerow","layout":{"type":"constrained"}} --><div class="wp-block-group aw-pricerow">' . $tier_rows . '</div><!-- /wp:group -->',
			array( 'align' => 'full', 'bg' => 'sand' )
		) );

	/* ========================= TESTIMONIALS ========================= */
	$p['testi-3'] = array( __( 'Testimonials — Three cards', 'norvex' ), 'testimonials',
		awb_group( awb_section_head( __( 'Loved by authors', 'norvex' ), __( 'Writers who trusted us with their books', 'norvex' ) ) . awb_spacer( '20px' ) . awb_quote_row(), array( 'align' => 'full', 'bg' => 'sand' ) ) );

	$p['testi-big'] = array( __( 'Testimonials — Single big quote', 'norvex' ), 'testimonials',
		awb_group(
			'<!-- wp:quote {"className":"aw-bigquote"} --><blockquote class="wp-block-quote aw-bigquote">' . awb_para( __( 'They treated my quiet little novel as though it were the most important book on the list. That is rarer than it should be.', 'norvex' ) ) . '<cite>' . esc_html__( 'A debut author, on working with us', 'norvex' ) . '</cite></blockquote><!-- /wp:quote -->',
			array( 'align' => 'full' )
		) );

	$p['testi-2'] = array( __( 'Testimonials — Two quotes', 'norvex' ), 'testimonials',
		awb_group( awb_section_head( __( 'In their words', 'norvex' ), __( 'What authors tell us', 'norvex' ) ) . awb_spacer( '20px' ) . awb_columns( awp_quote_card( $quotes[0][0], $quotes[0][1] ) . awp_quote_card( $quotes[1][0], $quotes[1][1] ), array( 'class' => 'aw-quotes' ) ), array( 'align' => 'full' ) ) );

	$p['testi-stats'] = array( __( 'Testimonials — Quote + stats', 'norvex' ), 'testimonials',
		awb_group(
			awb_columns(
				awb_column( awp_quote_card( $quotes[2][0], $quotes[2][1] ) )
				. awb_column( awp_statcols( array( array( '#3', __( 'Category bestseller', 'norvex' ) ), array( '11k', __( 'Copies in 90 days', 'norvex' ) ) ), false ) )
			),
			array( 'align' => 'full', 'bg' => 'sand' )
		) );

	$logos = '';
	foreach ( array( 'The Paper Review', 'Shelf & Spine', 'Reader’s Quarterly', 'Byline', 'The Margin' ) as $name ) {
		$logos .= awb_column( awb_para( $name, array( 'align' => 'center', 'class' => 'aw-logo' ) ) );
	}
	$p['testi-logos'] = array( __( 'Testimonials — Quote + logos', 'norvex' ), 'testimonials',
		awb_group(
			'<!-- wp:quote {"className":"aw-bigquote"} --><blockquote class="wp-block-quote aw-bigquote">' . awb_para( __( 'The team that authors and the press both trust.', 'norvex' ) ) . '<cite>' . esc_html__( 'As featured in', 'norvex' ) . '</cite></blockquote><!-- /wp:quote -->'
			. awb_spacer( '20px' )
			. awb_columns( $logos, array( 'class' => 'aw-iconrow' ) ),
			array( 'align' => 'full' )
		) );

	/* ============================ CTA ============================ */
	$p['cta-band'] = array( __( 'CTA — Rust band', 'norvex' ), 'cta', awb_cta( $u ) );

	$p['cta-split'] = array( __( 'CTA — Split (ink)', 'norvex' ), 'cta',
		'<!-- wp:cover ' . wp_json_encode( array( 'align' => 'full', 'overlayColor' => 'ink', 'isUserOverlayColor' => true, 'className' => 'aw-hero', 'layout' => array( 'type' => 'constrained' ) ), JSON_UNESCAPED_SLASHES ) . ' -->'
		. '<div class="wp-block-cover alignfull is-dark aw-hero"><span aria-hidden="true" class="wp-block-cover__background has-ink-background-color has-background-dim-100 has-background-dim"></span><div class="wp-block-cover__inner-container">'
		. '<!-- wp:columns {"className":"aw-split-head","verticalAlignment":"center"} --><div class="wp-block-columns are-vertically-aligned-center aw-split-head">'
		. awb_column( awb_heading( __( 'Ready to publish your book?', 'norvex' ), 2, array( 'size' => 'large' ) ) )
		. awb_column( awb_buttons( array( array( __( 'Book a free consultation', 'norvex' ), $u['contact'], 'fill' ) ) ) )
		. '</div><!-- /wp:columns --></div></div><!-- /wp:cover -->' );

	$p['cta-box'] = array( __( 'CTA — Boxed card', 'norvex' ), 'cta',
		awb_group(
			'<!-- wp:group {"className":"aw-ctabox","layout":{"type":"constrained"}} --><div class="wp-block-group aw-ctabox">'
			. awb_heading( __( 'Let’s make your book', 'norvex' ), 2, array( 'align' => 'center', 'size' => 'x-large' ) )
			. awb_para( __( 'Book a free, no-obligation consultation. We’ll map out exactly what your book needs.', 'norvex' ), array( 'align' => 'center' ) )
			. awb_spacer( '8px' )
			. awb_buttons( array( array( __( 'Book a free call', 'norvex' ), $u['contact'], 'fill' ) ), 'center' )
			. '</div><!-- /wp:group -->',
			array( 'align' => 'full', 'bg' => 'sand' )
		) );

	$p['cta-min'] = array( __( 'CTA — Minimal line', 'norvex' ), 'cta',
		awb_group(
			awb_heading( __( 'Start with a free consultation', 'norvex' ), 2, array( 'align' => 'center', 'size' => 'x-large' ) )
			. awb_buttons( array( array( __( 'Book a call', 'norvex' ), $u['contact'], 'fill' ) ), 'center' ),
			array( 'align' => 'full' )
		) );

	$p['cta-2col'] = array( __( 'CTA — Two column', 'norvex' ), 'cta',
		awb_group(
			'<!-- wp:columns {"className":"aw-split-head","verticalAlignment":"center"} --><div class="wp-block-columns are-vertically-aligned-center aw-split-head">'
			. awb_column( awb_heading( __( 'Keep 100% of your rights', 'norvex' ), 2, array( 'size' => 'large' ) ) . awb_para( __( 'Publish professionally on a flat fee — the accounts and royalties stay yours.', 'norvex' ), array( 'color' => 'muted' ) ) )
			. awb_column( awb_buttons( array( array( __( 'Get started', 'norvex' ), $u['contact'], 'fill' ), array( __( 'See pricing', 'norvex' ), $u['pricing'], 'outline' ) ) ) )
			. '</div><!-- /wp:columns -->',
			array( 'align' => 'full', 'bg' => 'sand' )
		) );

	/* ============================ CONTENT ============================ */
	$p['content-left'] = array( __( 'Content — Image left', 'norvex' ), 'content',
		awb_group( awb_media_text( array( 'side' => 'left', 'image' => 'about.svg', 'eyebrow' => __( 'Our story', 'norvex' ), 'heading' => __( 'One team, from first draft to first sale', 'norvex' ), 'body' => array( __( 'One team carries your book the whole way — writing, editing, design, distribution and marketing.', 'norvex' ), __( 'You stay the author and owner at every step.', 'norvex' ) ), 'btn' => array( __( 'Meet the team', 'norvex' ), $u['about'] ) ) ), array( 'align' => 'full' ) ) );

	$p['content-right'] = array( __( 'Content — Image right', 'norvex' ), 'content',
		awb_group( awb_media_text( array( 'side' => 'right', 'image' => 'about.svg', 'eyebrow' => __( 'Why us', 'norvex' ), 'heading' => __( 'A publishing partner, not a middleman', 'norvex' ), 'body' => array( __( 'We combine every service under one roof — so nothing gets lost between freelancers.', 'norvex' ) ), 'btn' => array( __( 'How it works', 'norvex' ), $u['process'] ) ) ), array( 'align' => 'full', 'bg' => 'sand' ) ) );

	$p['content-checklist'] = array( __( 'Content — Text + checklist', 'norvex' ), 'content',
		awb_group(
			awp_head_left( __( 'The Norvex promise', 'norvex' ), __( 'Everything you’d expect — and the rights you wouldn’t', 'norvex' ) )
			. '<!-- wp:list {"className":"aw-checks"} --><ul class="wp-block-list aw-checks">'
			. '<!-- wp:list-item --><li>' . esc_html__( 'You keep 100% of your rights and royalties', 'norvex' ) . '</li><!-- /wp:list-item -->'
			. '<!-- wp:list-item --><li>' . esc_html__( 'Every retailer account opened in your name', 'norvex' ) . '</li><!-- /wp:list-item -->'
			. '<!-- wp:list-item --><li>' . esc_html__( 'A flat fee — never a royalty share', 'norvex' ) . '</li><!-- /wp:list-item -->'
			. '<!-- wp:list-item --><li>' . esc_html__( 'Live on every major retailer in 30 days', 'norvex' ) . '</li><!-- /wp:list-item -->'
			. '</ul><!-- /wp:list -->'
			. awb_buttons( array( array( __( 'Start your book', 'norvex' ), $u['contact'], 'fill' ) ) ),
			array( 'align' => 'full' )
		) );

	$p['content-2col'] = array( __( 'Content — Two-column text', 'norvex' ), 'content',
		awb_group(
			awb_columns(
				awb_column( awb_para( __( 'Our story', 'norvex' ), array( 'class' => 'aw-eyebrow' ) ) . awb_heading( __( 'We treat every book as if it were our own', 'norvex' ), 2, array( 'size' => 'x-large' ) ) )
				. awb_column( awb_para( __( 'We exist to simplify publishing. From the first idea to the final launch, we combine ghostwriting, editing, design, publishing and marketing under one roof.', 'norvex' ), array( 'color' => 'muted' ) ) . awb_para( __( 'Hundreds of authors have trusted us — with consistent, professional results and honest, transparent pricing.', 'norvex' ), array( 'color' => 'muted' ) ) )
			),
			array( 'align' => 'full', 'bg' => 'sand' )
		) );

	$p['content-statement'] = array( __( 'Content — Centered statement', 'norvex' ), 'content',
		awb_group(
			awb_para( __( 'What we believe', 'norvex' ), array( 'align' => 'center', 'class' => 'aw-eyebrow' ) )
			. awb_heading( __( 'A book is the most personal thing most people ever make. Our whole job is to treat it that way.', 'norvex' ), 2, array( 'align' => 'center', 'size' => 'x-large' ) ),
			array( 'align' => 'full' )
		) );

	/* ============================ STATS ============================ */
	$p['stats-ink'] = array( __( 'Stats — Four on ink', 'norvex' ), 'stats',
		awb_group( awp_statcols( $stats4, true ), array( 'align' => 'full', 'bg' => 'ink', 'padY' => '4rem' ) ) );

	$p['stats-cream'] = array( __( 'Stats — Three on cream', 'norvex' ), 'stats',
		awb_group( awp_statcols( $stats3, false ), array( 'align' => 'full', 'padY' => '4rem' ) ) );

	$p['stats-headed'] = array( __( 'Stats — Heading + stats', 'norvex' ), 'stats',
		awb_group(
			awb_columns(
				awb_column( awp_head_left( __( 'The results', 'norvex' ), __( 'Numbers our authors keep', 'norvex' ) ) )
				. awb_column( awp_statcols( $stats3, false ) )
			),
			array( 'align' => 'full', 'bg' => 'sand' )
		) );

	$p['stats-big'] = array( __( 'Stats — Big single', 'norvex' ), 'stats',
		awb_group(
			'<!-- wp:group {"className":"aw-bigstat","layout":{"type":"constrained"}} --><div class="wp-block-group aw-bigstat">'
			. awb_para( __( 'Royalties you keep', 'norvex' ), array( 'align' => 'center', 'class' => 'aw-eyebrow' ) )
			. '<!-- wp:heading {"textAlign":"center","className":"aw-bignum"} --><h2 class="wp-block-heading has-text-align-center aw-bignum">100%</h2><!-- /wp:heading -->'
			. awb_para( __( 'A flat fee for the work — never a share of what your book earns. The copyright and every royalty stay yours.', 'norvex' ), array( 'align' => 'center', 'color' => 'muted' ) )
			. '</div><!-- /wp:group -->',
			array( 'align' => 'full' )
		) );

	$p['stats-cards'] = array( __( 'Stats — Cards', 'norvex' ), 'stats',
		awb_group( awb_section_head( __( 'By the numbers', 'norvex' ), __( 'A publisher built around the book', 'norvex' ) ) . awb_spacer( '20px' ) . awp_statcols( $stats4, false, true ), array( 'align' => 'full' ) ) );

	/* ============================ FAQ ============================ */
	$faqs = awp_faq_items();
	$p['faq-acc'] = array( __( 'FAQ — Accordion', 'norvex' ), 'faq',
		awb_group( awb_section_head( __( 'Good to know', 'norvex' ), __( 'Frequently asked questions', 'norvex' ) ) . awb_spacer( '16px' ) . awp_details( $faqs ), array( 'align' => 'full' ) ) );

	$p['faq-2col'] = array( __( 'FAQ — Two column', 'norvex' ), 'faq',
		awb_group(
			awb_section_head( __( 'Good to know', 'norvex' ), __( 'Questions, answered', 'norvex' ) ) . awb_spacer( '16px' )
			. awb_columns(
				awb_column( awp_details( array( $faqs[0], $faqs[1] ) ) )
				. awb_column( awp_details( array( $faqs[2], $faqs[3] ) ) )
			),
			array( 'align' => 'full', 'bg' => 'sand' )
		) );

	$qa = '';
	foreach ( $faqs as $it ) {
		$qa .= awb_heading( $it[0], 3, array( 'size' => 'large' ) ) . awb_para( $it[1], array( 'color' => 'muted' ) ) . awb_spacer( '14px' );
	}
	$p['faq-list'] = array( __( 'FAQ — Q&A list', 'norvex' ), 'faq',
		awb_group( awb_section_head( __( 'Good to know', 'norvex' ), __( 'Everything worth asking', 'norvex' ) ) . awb_spacer( '16px' ) . '<!-- wp:group {"className":"aw-solo-wide","layout":{"type":"constrained"}} --><div class="wp-block-group aw-flist">' . $qa . '</div><!-- /wp:group -->', array( 'align' => 'full' ) ) );

	$p['faq-cta'] = array( __( 'FAQ — With CTA', 'norvex' ), 'faq',
		awb_group(
			awb_columns(
				awb_column( awp_details( array( $faqs[0], $faqs[1], $faqs[2] ) ) )
				. awb_column(
					'<!-- wp:group {"className":"aw-ctabox","layout":{"type":"constrained"}} --><div class="wp-block-group aw-ctabox">'
					. awb_heading( __( 'Still have a question?', 'norvex' ), 3, array( 'align' => 'center', 'size' => 'large' ) )
					. awb_para( __( 'Talk to a publishing expert — no cost, no obligation.', 'norvex' ), array( 'align' => 'center', 'color' => 'muted' ) )
					. awb_buttons( array( array( __( 'Book a call', 'norvex' ), $u['contact'], 'fill' ) ), 'center' )
					. '</div><!-- /wp:group -->'
				)
			),
			array( 'align' => 'full' )
		) );

	$p['faq-narrow'] = array( __( 'FAQ — Narrow centered', 'norvex' ), 'faq',
		awb_group( awb_section_head( __( 'Questions', 'norvex' ), __( 'The short answers', 'norvex' ) ) . awb_spacer( '16px' ) . '<!-- wp:group {"layout":{"type":"constrained","contentSize":"720px"}} --><div class="wp-block-group">' . awp_details( $faqs ) . '</div><!-- /wp:group -->', array( 'align' => 'full', 'bg' => 'sand' ) ) );

	/* ==================== HOMEPAGE SECTIONS (exact copies) ====================
	   Each homepage section is offered as a pattern that reproduces the matching
	   custom Norvex block's exact front-end markup — a 100% copy of the block's
	   design, layout and colours. The markup is the block's own render, wrapped
	   in a core/html block. Patterns must be registered on every request (the
	   editor reads them over the REST API, where is_admin()/REST_REQUEST are not
	   yet set at init), so the render output is cached in a transient keyed to
	   the theme version — the sections are rendered once, not on every request. */
	$exact_sections = array(
		'hero'           => __( 'Section — Hero', 'norvex' ),
		'services'       => __( 'Section — Services grid', 'norvex' ),
		'cards'          => __( 'Section — What we offer', 'norvex' ),
		'feature-split'  => __( 'Section — Partnership cards', 'norvex' ),
		'timeline-h'     => __( 'Section — Marketing, six jobs', 'norvex' ),
		'zigzag'         => __( 'Section — Documented steps', 'norvex' ),
		'showcase'       => __( 'Section — Independent publishing', 'norvex' ),
		'highlights'     => __( 'Section — Why us', 'norvex' ),
		'chapters-index' => __( 'Section — Author handbook', 'norvex' ),
		'marginalia'     => __( 'Section — You wrote a book', 'norvex' ),
		'process'        => __( 'Section — How it works (ink)', 'norvex' ),
		'services-list'  => __( 'Section — Services list', 'norvex' ),
		'data-columns'   => __( 'Section — Data columns', 'norvex' ),
		'steps-media'    => __( 'Section — Steps with media', 'norvex' ),
		'stats'          => __( 'Section — Stats band', 'norvex' ),
		'why-us'         => __( 'Section — Reasons split', 'norvex' ),
		'testimonials'   => __( 'Section — Testimonials', 'norvex' ),
		'pricing'        => __( 'Section — Pricing', 'norvex' ),
		'faq'            => __( 'Section — FAQ', 'norvex' ),
		'cta'            => __( 'Section — Call to action', 'norvex' ),
		'consult'        => __( 'Section — Consultation', 'norvex' ),
	);
	$exact_cache = get_transient( 'norvex_section_patterns' );
	if ( ! is_array( $exact_cache ) || empty( $exact_cache['ver'] ) || NORVEX_VERSION !== $exact_cache['ver'] ) {
		$exact_built = array();
		foreach ( $exact_sections as $exact_block => $exact_title ) {
			$exact_name = 'norvex/' . $exact_block;
			if ( ! WP_Block_Type_Registry::get_instance()->is_registered( $exact_name ) ) {
				continue;
			}
			$exact_markup = norvex_blocks_from_render( $exact_name );
			if ( '' === trim( $exact_markup ) ) {
				continue;
			}
			// Store the theme URL as a token so the cache is portable across sites.
			$exact_built[ $exact_block ] = str_replace( NORVEX_URI, '%%NORVEX_URI%%', $exact_markup );
		}
		$exact_cache = array( 'ver' => NORVEX_VERSION, 'html' => $exact_built );
		set_transient( 'norvex_section_patterns', $exact_cache, WEEK_IN_SECONDS );
	}
	foreach ( $exact_sections as $exact_block => $exact_title ) {
		if ( empty( $exact_cache['html'][ $exact_block ] ) ) {
			continue;
		}
		$exact_markup = str_replace( '%%NORVEX_URI%%', NORVEX_URI, $exact_cache['html'][ $exact_block ] );
		$p[ 'sec-' . $exact_block ] = array( $exact_title, 'section', $exact_markup );
	}

	/* Register everything. */
	foreach ( $p as $slug => $d ) {
		register_block_pattern(
			'norvex/' . $slug,
			array(
				'title'      => $d[0],
				'categories' => array( 'norvex', 'norvex-' . $d[1] ),
				'content'    => $d[2],
			)
		);
	}
}
add_action( 'init', 'norvex_register_block_patterns' );
