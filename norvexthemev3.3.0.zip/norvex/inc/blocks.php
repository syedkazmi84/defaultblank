<?php
/**
 * Editable homepage blocks.
 *
 * Turns the formerly-hardcoded front-page sections into movable, editable
 * blocks. Static sections (hero, process, stats, why-us, FAQ, CTA…) are
 * editable in the block editor; the four data-driven sections (services,
 * featured books, testimonials, journal) are SERVER-RENDERED blocks that keep
 * pulling live from the dashboard CPTs, so adding a Service or Testimonial
 * still appears on the homepage automatically.
 *
 * A single config array (norvex_blocks_config) is the source of truth for
 * every block's editable fields — it drives PHP attribute registration, the
 * editor UI (localized to JS) and the render defaults, so the three never drift.
 *
 * @package Norvex
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Read a block attribute with a fallback.
 */
function norvex_ba( $a, $key, $default = '' ) {
	return ( isset( $a[ $key ] ) && '' !== $a[ $key ] ) ? $a[ $key ] : $default;
}

/**
 * Resolve a button URL: the editor-supplied custom URL if set, otherwise the
 * permalink of a fallback page slug. Lets every block button be pointed
 * anywhere from the sidebar while keeping a sensible default.
 *
 * @param string $custom        Custom URL from the block attribute.
 * @param string $fallback_slug Page slug to link to when no custom URL is set.
 * @return string
 */
function norvex_btn_url( $custom, $fallback_slug ) {
	$custom = trim( (string) $custom );
	if ( '' !== $custom ) {
		return $custom;
	}
	$page = get_page_by_path( $fallback_slug );
	return $page ? get_permalink( $page ) : home_url( '/' );
}

/**
 * The block catalog: name => [title, dynamic, fields].
 *
 * Each field: key => [ label, type (text|textarea|number), default ]. Defaults
 * pull from the existing Customizer options where they exist, so upgrading sites
 * keep their current copy until they edit a block.
 *
 * @return array
 */
function norvex_blocks_config() {
	$logos_default = norvex_option( 'norvex_logos', 'The Paper Review, Inkwell, Readerly, Prose & Co., Bindery' );

	$blocks = array(
		'hero' => array(
			'title'    => __( 'Norvex: Hero', 'norvex' ),
			'dynamic'  => false,
			'category' => 'norvex',
			'fields'   => array(
				'eyebrow' => array( __( 'Eyebrow', 'norvex' ), 'text', norvex_option( 'norvex_hero_eyebrow', 'Ghostwriting · Editing · Publishing · Marketing' ) ),
				'title'   => array( __( 'Title (last word is accented)', 'norvex' ), 'text', norvex_option( 'norvex_hero_title', 'Publish your book and keep 100% of your rights' ) ),
				'lead'    => array( __( 'Lead text', 'norvex' ), 'textarea', norvex_option( 'norvex_hero_lead', 'Full-service book publishing on a flat fee — with every Amazon, Apple, Kobo and IngramSpark account set up in your name. Live on every major retailer in 30 days, and 100% of the royalties are yours.' ) ),
				'btn1'    => array( __( 'Primary button', 'norvex' ), 'text', norvex_option( 'norvex_hero_btn1', 'Book a free consultation' ) ),
				'btn1url' => array( __( 'Primary button URL (blank = Contact page)', 'norvex' ), 'url', '' ),
				'btn2'    => array( __( 'Secondary button', 'norvex' ), 'text', norvex_option( 'norvex_hero_btn2', 'Explore our services' ) ),
				'btn2url' => array( __( 'Secondary button URL (blank = Services page)', 'norvex' ), 'url', '' ),
				'image'   => array( __( 'Hero image', 'norvex' ), 'image', '' ),
				's1n'     => array( __( 'Stat 1 number', 'norvex' ), 'text', '100%' ),
				's1l'     => array( __( 'Stat 1 label', 'norvex' ), 'text', 'Royalties you keep' ),
				's2n'     => array( __( 'Stat 2 number', 'norvex' ), 'text', '30' ),
				's2l'     => array( __( 'Stat 2 label', 'norvex' ), 'text', 'Days to go live' ),
				's3n'     => array( __( 'Stat 3 number', 'norvex' ), 'text', '5+' ),
				's3l'     => array( __( 'Stat 3 label', 'norvex' ), 'text', 'Years of experience' ),
				'badge'   => array( __( 'Rating badge text', 'norvex' ), 'text', '4.9 / 5 rating' ),
				'badgesub' => array( __( 'Rating badge subtext', 'norvex' ), 'text', 'from 830+ authors' ),
				'stars'   => array( __( 'Stars (1–5)', 'norvex' ), 'number', 5 ),
			),
		),
		'logos' => array(
			'title'    => __( 'Norvex: Trusted by', 'norvex' ),
			'dynamic'  => false,
			'category' => 'norvex-block',
			'fields'  => array(
				'label' => array( __( 'Label', 'norvex' ), 'text', __( 'As featured in', 'norvex' ) ),
				'items' => array( __( 'Client names', 'norvex' ), 'lines', $logos_default, array( 'join' => ', ', 'add' => __( 'Add name', 'norvex' ), 'placeholder' => __( 'e.g. The Paper Review', 'norvex' ) ) ),
			),
		),
		// Services grid is a Grid-cards block with a services seed: it reuses the
		// Grid-cards editor and renderer so each card has an icon/number, an
		// editable footer price + link, and optional borders.
		'services' => array(
			'title'   => __( 'Norvex: Services grid', 'norvex' ),
			'dynamic' => false,
			'fields'  => array(
				'carousel' => norvex_carousel_field(),
				'eyebrow' => array( __( 'Eyebrow (optional)', 'norvex' ), 'text', norvex_option( 'norvex_services_eyebrow', 'What we do' ) ),
				'heading' => array( __( 'Heading (optional)', 'norvex' ), 'text', norvex_option( 'norvex_services_title', 'Everything your book needs, in one place' ) ),
				'lead'    => array( __( 'Lead text (optional)', 'norvex' ), 'textarea', norvex_option( 'norvex_services_lead', 'From writing to marketing, our team handles the hard parts of publishing so you can focus on your story. Choose a package or build your own.' ) ),
				'cols'    => array( __( 'Cards per row', 'norvex' ), 'select', '3', array( '2' => __( '2 per row', 'norvex' ), '3' => __( '3 per row', 'norvex' ), '4' => __( '4 per row', 'norvex' ) ) ),
				'cards'   => array( __( 'Cards', 'norvex' ), 'cards', norvex_default_service_cards_json(), array( 'iconlist' => norvex_card_icon_list() ) ),
			),
		),
		'process' => array(
			'title'   => __( 'Norvex: Process steps', 'norvex' ),
			'dynamic' => false,
			'fields'  => array(
				'eyebrow' => array( __( 'Eyebrow', 'norvex' ), 'text', __( 'How it works', 'norvex' ) ),
				'title'   => array( __( 'Title', 'norvex' ), 'text', norvex_option( 'norvex_process_title', 'How we bring your book to life' ) ),
				'lead'    => array( __( 'Lead text', 'norvex' ), 'textarea', __( 'A clear, four-step path from first conversation to finished book — with a dedicated team beside you the whole way.', 'norvex' ) ),
				'btn'     => array( __( 'Button', 'norvex' ), 'text', __( 'Start with a free call', 'norvex' ) ),
				'btnurl'  => array( __( 'Button URL (blank = Contact page)', 'norvex' ), 'url', '' ),
				'steps'   => array( __( 'Steps', 'norvex' ), 'hidden', norvex_default_process_steps_json() ),
			),
		),
		'consult' => array(
			'title'   => __( 'Norvex: Book a call', 'norvex' ),
			'dynamic' => false,
			'fields'  => array(
				'eyebrow' => array( __( 'Eyebrow', 'norvex' ), 'text', __( 'No cost, no obligation', 'norvex' ) ),
				'title'   => array( __( 'Title', 'norvex' ), 'text', __( 'Book your free consultation', 'norvex' ) ),
				'text'    => array( __( 'Text', 'norvex' ), 'textarea', __( 'Talk to a publishing expert about your book. We\'ll listen to your goals, answer your questions and map out exactly what your book needs — with an honest, no-pressure quote.', 'norvex' ) ),
				'btn'     => array( __( 'Button label', 'norvex' ), 'text', __( 'Book a free call', 'norvex' ) ),
				'btnurl'  => array( __( 'Button URL (blank = Contact page)', 'norvex' ), 'url', '' ),
			),
		),
		'featured-books' => array(
			'title'   => __( 'Norvex: Featured books', 'norvex' ),
			'dynamic' => true,
			'fields'  => array(
				'carousel' => norvex_carousel_field(),
				'eyebrow' => array( __( 'Eyebrow', 'norvex' ), 'text', __( 'Our work', 'norvex' ) ),
				'title'   => array( __( 'Title', 'norvex' ), 'text', norvex_option( 'norvex_books_title', 'Books we’ve helped bring to life' ) ),
				'custom'  => array( __( 'Books', 'norvex' ), 'hidden', norvex_default_books_json() ),
			),
		),
		'portfolio-grid' => array(
			'title'   => __( 'Norvex: Portfolio grid', 'norvex' ),
			'dynamic' => true,
			'fields'  => array(
				'carousel' => norvex_carousel_field(),
				'count'    => array( __( 'How many books to show', 'norvex' ), 'number', 12 ),
			),
		),
		'stats' => array(
			'title'   => __( 'Norvex: Stats band', 'norvex' ),
			'dynamic' => false,
			'fields'  => array(
				'n1' => array( __( 'Stat 1 number', 'norvex' ), 'text', norvex_option( 'norvex_stat1_n', '100%' ) ),
				'l1' => array( __( 'Stat 1 label', 'norvex' ), 'text', norvex_option( 'norvex_stat1_l', 'Royalties you keep' ) ),
				'n2' => array( __( 'Stat 2 number', 'norvex' ), 'text', norvex_option( 'norvex_stat2_n', '30' ) ),
				'l2' => array( __( 'Stat 2 label', 'norvex' ), 'text', norvex_option( 'norvex_stat2_l', 'Days to go live' ) ),
				'n3' => array( __( 'Stat 3 number', 'norvex' ), 'text', norvex_option( 'norvex_stat3_n', '5+' ) ),
				'l3' => array( __( 'Stat 3 label', 'norvex' ), 'text', norvex_option( 'norvex_stat3_l', 'Years of experience' ) ),
				'n4' => array( __( 'Stat 4 number', 'norvex' ), 'text', norvex_option( 'norvex_stat4_n', '0%' ) ),
				'l4' => array( __( 'Stat 4 label', 'norvex' ), 'text', norvex_option( 'norvex_stat4_l', 'Royalty share we take' ) ),
			),
		),
		'why-us' => array(
			'title'   => __( 'Norvex: Why us', 'norvex' ),
			'dynamic' => false,
			'fields'  => array(
				'eyebrow' => array( __( 'Eyebrow', 'norvex' ), 'text', __( 'Why authors choose us', 'norvex' ) ),
				'title'   => array( __( 'Title', 'norvex' ), 'text', __( 'Your creative partner from first draft to final launch', 'norvex' ) ),
				'lead'    => array( __( 'Lead text', 'norvex' ), 'textarea', __( 'We treat every book like it’s our own. One dedicated team writes, edits, designs, publishes and markets your book — while you stay the author and owner throughout.', 'norvex' ) ),
				'btn'     => array( __( 'Button', 'norvex' ), 'text', __( 'More about us', 'norvex' ) ),
				'btnurl'  => array( __( 'Button URL (blank = About page)', 'norvex' ), 'url', '' ),
				'f1t'     => array( __( 'Point 1 title', 'norvex' ), 'text', __( 'You keep 100% ownership', 'norvex' ) ),
				'f1d'     => array( __( 'Point 1 text', 'norvex' ), 'textarea', __( 'You stay the sole author and keep every right and royalty — always.', 'norvex' ) ),
				'f2t'     => array( __( 'Point 2 title', 'norvex' ), 'text', __( 'One dedicated team', 'norvex' ) ),
				'f2d'     => array( __( 'Point 2 text', 'norvex' ), 'textarea', __( 'A single project manager and crew from first draft through launch.', 'norvex' ) ),
				'f3t'     => array( __( 'Point 3 title', 'norvex' ), 'text', __( 'Transparent pricing', 'norvex' ) ),
				'f3d'     => array( __( 'Point 3 text', 'norvex' ), 'textarea', __( 'Clear, itemised quotes with no hidden fees or surprise add-ons.', 'norvex' ) ),
				'f4t'     => array( __( 'Point 4 title', 'norvex' ), 'text', __( 'On-time, every milestone', 'norvex' ) ),
				'f4d'     => array( __( 'Point 4 text', 'norvex' ), 'textarea', __( 'An agreed schedule up front and reliable delivery at every step.', 'norvex' ) ),
			),
		),
		'testimonials' => array(
			'title'   => __( 'Norvex: Testimonials', 'norvex' ),
			'dynamic' => true,
			'fields'  => array(
				'carousel' => norvex_carousel_field(),
				'eyebrow' => array( __( 'Eyebrow', 'norvex' ), 'text', __( 'Loved by authors', 'norvex' ) ),
				'title'   => array( __( 'Title', 'norvex' ), 'text', norvex_option( 'norvex_testi_title', 'What our authors say' ) ),
				'custom'  => array( __( 'Testimonials', 'norvex' ), 'hidden', norvex_default_testimonials_json() ),
			),
		),
		'journal' => array(
			'title'   => __( 'Norvex: Journal', 'norvex' ),
			'dynamic' => true,
			'fields'  => array(
				'carousel' => norvex_carousel_field(),
				'eyebrow' => array( __( 'Eyebrow', 'norvex' ), 'text', __( 'From the journal', 'norvex' ) ),
				'title'   => array( __( 'Title', 'norvex' ), 'text', norvex_option( 'norvex_journal_title', 'Tips for writers & authors' ) ),
				'count'   => array( __( 'How many posts', 'norvex' ), 'number', 3 ),
			),
		),
		'faq' => array(
			'title'   => __( 'Norvex: FAQ', 'norvex' ),
			'dynamic' => false,
			'fields'  => array(
				'eyebrow' => array( __( 'Eyebrow', 'norvex' ), 'text', __( 'Good to know', 'norvex' ) ),
				'title'   => array( __( 'Title', 'norvex' ), 'text', __( 'Frequently asked questions', 'norvex' ) ),
				'items'   => array( __( 'FAQs', 'norvex' ), 'pairs', norvex_default_home_faq_text(), array( 'a' => __( 'Question', 'norvex' ), 'b' => __( 'Answer', 'norvex' ), 'sep' => '|', 'add' => __( 'Add FAQ', 'norvex' ) ) ),
				'btn'     => array( __( 'Button', 'norvex' ), 'text', __( 'Still have questions? Talk to us', 'norvex' ) ),
				'btnurl'  => array( __( 'Button URL (blank = Contact page)', 'norvex' ), 'url', '' ),
			),
		),
		'cta' => array(
			'title'   => __( 'Norvex: Final CTA', 'norvex' ),
			'dynamic' => false,
			'fields'  => array(
				'eyebrow' => array( __( 'Eyebrow', 'norvex' ), 'text', __( 'Ready when you are', 'norvex' ) ),
				'title'   => array( __( 'Title', 'norvex' ), 'text', __( 'Ready to publish your book?', 'norvex' ) ),
				'text'    => array( __( 'Text', 'norvex' ), 'textarea', __( 'Book a free, no-obligation consultation. We’ll talk through your goals and map out exactly what your book needs — start to finish.', 'norvex' ) ),
				'btn1'    => array( __( 'Primary button', 'norvex' ), 'text', __( 'Book a free consult', 'norvex' ) ),
				'btn1url' => array( __( 'Primary button URL (blank = Contact page)', 'norvex' ), 'url', '' ),
				'btn2'    => array( __( 'Secondary button', 'norvex' ), 'text', __( 'See pricing', 'norvex' ) ),
				'btn2url' => array( __( 'Secondary button URL (blank = Pricing page)', 'norvex' ), 'url', '' ),
			),
		),

		/* ---------------------------------------------------------------------
		   Inner-page section blocks. These build the About, Services, Pricing,
		   Portfolio and Contact pages the same way the homepage is built — every
		   field lives in the block sidebar. They live in their own inserter
		   category so they are easy to find.
		   --------------------------------------------------------------------- */
		'page-hero' => array(
			'title'    => __( 'Norvex: Page hero', 'norvex' ),
			'dynamic'  => false,
			'category' => 'norvex',
			'fields'   => array(
				'title' => array( __( 'Title', 'norvex' ), 'text', __( 'Page title', 'norvex' ) ),
				'lead'  => array( __( 'Intro text', 'norvex' ), 'textarea', '' ),
			),
		),
		'about-story' => array(
			'title'    => __( 'Norvex: About story', 'norvex' ),
			'dynamic'  => false,
			'category' => 'norvex',
			'fields'   => array(
				'eyebrow' => array( __( 'Eyebrow', 'norvex' ), 'text', __( 'Our story', 'norvex' ) ),
				'title'   => array( __( 'Title', 'norvex' ), 'text', __( 'We’re not just a publishing company — we’re your creative partners', 'norvex' ) ),
				'para1'   => array( __( 'Paragraph 1', 'norvex' ), 'textarea', __( 'We exist to simplify publishing. From the first idea to the final launch, we combine ghostwriting, editing, design, publishing and marketing under one roof — so you can share your message with readers around the world.', 'norvex' ) ),
				'para2'   => array( __( 'Paragraph 2', 'norvex' ), 'textarea', __( 'Hundreds of authors have trusted us for writing, editing, publishing and marketing — with consistent, professional results and honest, transparent pricing. We treat every story like our own, and you always remain the sole author and rights-holder.', 'norvex' ) ),
				'list'    => array( __( 'Checklist', 'norvex' ), 'lines', "Personalised, one-on-one guidance on every project\nYou keep 100% ownership — always\nA transparent process with no hidden fees", array( 'add' => __( 'Add item', 'norvex' ), 'placeholder' => __( 'e.g. You keep 100% ownership', 'norvex' ) ) ),
				'image'   => array( __( 'Image', 'norvex' ), 'image', '' ),
			),
		),
		'team' => array(
			'title'    => __( 'Norvex: Team grid', 'norvex' ),
			'dynamic'  => true,
			'category' => 'norvex',
			'fields'   => array(
				'eyebrow' => array( __( 'Eyebrow', 'norvex' ), 'text', __( 'The people', 'norvex' ) ),
				'title'   => array( __( 'Title', 'norvex' ), 'text', __( 'Meet the team', 'norvex' ) ),
				'custom'  => array( __( 'Team members', 'norvex' ), 'hidden', norvex_default_team_json() ),
			),
		),
		'pricing' => array(
			'title'    => __( 'Norvex: Pricing plans', 'norvex' ),
			'dynamic'  => true,
			'category' => 'norvex',
			'fields'   => array(
				'eyebrow' => array( __( 'Eyebrow (optional heading)', 'norvex' ), 'text', __( 'Pricing', 'norvex' ) ),
				'heading' => array( __( 'Heading (optional)', 'norvex' ), 'text', __( 'Simple, transparent pricing', 'norvex' ) ),
				'lead'    => array( __( 'Lead text (optional)', 'norvex' ), 'textarea', __( 'Flexible packages with honest, no-hidden-fee pricing. Every book is different, so we tailor a quote to exactly what you need.', 'norvex' ) ),
				'note'    => array( __( 'Note below the plans', 'norvex' ), 'textarea', __( 'Every package starts with a free consultation. Prefer to pick services individually? We build custom plans too — just ask.', 'norvex' ) ),
				'btn'     => array( __( 'Plan button label', 'norvex' ), 'text', __( 'Get a custom quote', 'norvex' ) ),
				'btnurl'  => array( __( 'Plan button URL (blank = Contact page)', 'norvex' ), 'url', '' ),
				'custom'  => array( __( 'Plans', 'norvex' ), 'hidden', norvex_default_plans_json() ),
			),
		),
		'contact' => array(
			'title'    => __( 'Norvex: Contact', 'norvex' ),
			'dynamic'  => true,
			'category' => 'norvex',
			'fields'   => array(
				'eyebrow'   => array( __( 'Eyebrow', 'norvex' ), 'text', __( 'Get in touch', 'norvex' ) ),
				'title'     => array( __( 'Title', 'norvex' ), 'text', __( 'We’d love to hear your story', 'norvex' ) ),
				'lead'      => array( __( 'Lead text', 'norvex' ), 'textarea', __( 'Prefer email or phone? Reach us directly, or drop by the studio.', 'norvex' ) ),
				'formtitle' => array( __( 'Form heading', 'norvex' ), 'text', __( 'Book a free consultation', 'norvex' ) ),
				'formintro' => array( __( 'Form intro', 'norvex' ), 'textarea', __( 'Share a few details and we’ll be in touch to set up your call.', 'norvex' ) ),
			),
		),
		'cards' => array(
			'title'    => __( 'Norvex: Grid cards', 'norvex' ),
			'dynamic'  => false,
			'category' => 'norvex-block',
			'fields'   => array(
				'carousel' => norvex_carousel_field(),
				'eyebrow' => array( __( 'Eyebrow (optional)', 'norvex' ), 'text', '' ),
				'heading' => array( __( 'Heading (optional)', 'norvex' ), 'text', __( 'What we offer', 'norvex' ) ),
				'lead'    => array( __( 'Lead text (optional)', 'norvex' ), 'textarea', '' ),
				'cols'    => array( __( 'Cards per row', 'norvex' ), 'select', '3', array( '2' => __( '2 per row', 'norvex' ), '3' => __( '3 per row', 'norvex' ), '4' => __( '4 per row', 'norvex' ) ) ),
				'cards'   => array( __( 'Cards', 'norvex' ), 'cards', norvex_default_cards_json(), array( 'iconlist' => norvex_card_icon_list() ) ),
			),
		),
		'buttons' => array(
			'title'    => __( 'Norvex: Buttons', 'norvex' ),
			'dynamic'  => false,
			'category' => 'norvex-block',
			'fields'   => array(
				'align' => array( __( 'Alignment', 'norvex' ), 'select', 'left', array( 'left' => __( 'Left', 'norvex' ), 'center' => __( 'Center', 'norvex' ), 'right' => __( 'Right', 'norvex' ) ) ),
				'items' => array(
					__( 'Buttons', 'norvex' ),
					'rows',
					"Book a free call | | primary\nSee pricing | | ghost",
					array(
						'sep'  => '|',
						'add'  => __( 'Add button', 'norvex' ),
						'cols' => array(
							array( 'label' => __( 'Button label', 'norvex' ), 'type' => 'text' ),
							array( 'label' => __( 'Link URL', 'norvex' ), 'type' => 'text' ),
							array( 'label' => __( 'Style', 'norvex' ), 'type' => 'select', 'options' => array( 'primary' => __( 'Primary (filled)', 'norvex' ), 'ghost' => __( 'Outline', 'norvex' ), 'light' => __( 'Light', 'norvex' ) ) ),
							array( 'label' => __( 'Open in new tab', 'norvex' ), 'type' => 'flag', 'flag' => '_blank' ),
						),
					),
				),
			),
		),
		'table' => array(
			'title'    => __( 'Norvex: Table', 'norvex' ),
			'dynamic'  => false,
			'category' => 'norvex-block',
			'fields'   => array(
				'heading' => array( __( 'Heading (optional)', 'norvex' ), 'text', '' ),
				'header'  => array( __( 'First row is a header', 'norvex' ), 'select', '1', array( '1' => __( 'Yes', 'norvex' ), '0' => __( 'No', 'norvex' ) ) ),
				'data'    => array( __( 'Table', 'norvex' ), 'table', norvex_default_table_json() ),
			),
		),
		/* ---------------------------------------------------------------------
		   Building Blocks — small single-element blocks used to compose custom
		   sections (rendered by inc/building-blocks.php).
		   --------------------------------------------------------------------- */
		'section-header' => array(
			'title'    => __( 'Norvex: Section header', 'norvex' ),
			'dynamic'  => true,
			'category' => 'norvex-block',
			'fields'   => array(
				'eyebrow' => array( __( 'Eyebrow', 'norvex' ), 'text', __( 'What we do', 'norvex' ) ),
				'title'   => array( __( 'Heading', 'norvex' ), 'text', __( 'A section heading', 'norvex' ) ),
				'lead'    => array( __( 'Lead text (optional)', 'norvex' ), 'textarea', '' ),
				'align'   => array( __( 'Alignment', 'norvex' ), 'select', 'center', array( 'left' => __( 'Left', 'norvex' ), 'center' => __( 'Center', 'norvex' ) ) ),
			),
		),

		'callout' => array(
			'title'    => __( 'Norvex: Verdict / Quote', 'norvex' ),
			'dynamic'  => true,
			'category' => 'norvex-block',
			'fields'   => array(
				'text'   => array( __( 'Statement', 'norvex' ), 'textarea', __( 'Norvex keeps 100% of your royalties and the rights in your name — for one flat fee.', 'norvex' ) ),
				'cite'   => array( __( 'Attribution (optional, e.g. “The Norvex promise”)', 'norvex' ), 'text', '' ),
				'accent' => array( __( 'Accent colour', 'norvex' ), 'select', 'green', array( 'green' => __( 'Green', 'norvex' ), 'rust' => __( 'Rust', 'norvex' ), 'ink' => __( 'Ink', 'norvex' ), 'muted' => __( 'Muted', 'norvex' ) ) ),
			),
		),

		'checklist' => array(
			'title'    => __( 'Norvex: Checklist', 'norvex' ),
			'dynamic'  => true,
			'category' => 'norvex-block',
			'fields'   => array(
				'items' => array( __( 'Items — one per line. Start a line with ! to show it crossed-out.', 'norvex' ), 'bigtext', "You keep 100% of your rights\nEvery account in your name\nFlat fee — no royalty share\nLive on every retailer in 30 days" ),
				'cols'  => array( __( 'Columns', 'norvex' ), 'select', '1', array( '1' => __( '1 column', 'norvex' ), '2' => __( '2 columns', 'norvex' ) ) ),
			),
		),

		'notice' => array(
			'title'    => __( 'Norvex: Notice', 'norvex' ),
			'dynamic'  => true,
			'category' => 'norvex-block',
			'fields'   => array(
				'icon'    => array( __( 'Icon', 'norvex' ), 'select', 'bulb', array( 'bulb' => __( 'Idea', 'norvex' ), 'check' => __( 'Check', 'norvex' ), 'star' => __( 'Star', 'norvex' ), 'shield' => __( 'Shield', 'norvex' ), 'bell' => __( 'Bell', 'norvex' ), 'gift' => __( 'Gift', 'norvex' ) ) ),
				'heading' => array( __( 'Heading', 'norvex' ), 'text', __( 'Keep 100% of your rights', 'norvex' ) ),
				'text'    => array( __( 'Message', 'norvex' ), 'textarea', __( 'Every retailer account is opened in your name and every royalty is paid straight to you — for one transparent flat fee.', 'norvex' ) ),
				'btn'     => array( __( 'Button label (optional)', 'norvex' ), 'text', '' ),
				'btnurl'  => array( __( 'Button URL', 'norvex' ), 'url', '' ),
			),
		),

		/* -------------------------------------------------------------------------
		   Split feature sections — an icon-card grid or numbered list paired with
		   an accented heading. Edited in the sidebar with a live preview.
		   ------------------------------------------------------------------------- */
		'feature-split' => array(
			'title'    => __( 'Norvex: Feature split', 'norvex' ),
			'dynamic'  => false,
			'category' => 'norvex',
			'fields'   => array(
				'eyebrow' => array( __( 'Eyebrow', 'norvex' ), 'text', __( 'Why us', 'norvex' ) ),
				'heading' => array( __( 'Heading', 'norvex' ), 'text', __( 'Because we don’t just publish books — we build', 'norvex' ) ),
				'accent'  => array( __( 'Accent word(s) — shown in script italic', 'norvex' ), 'text', __( 'partnerships.', 'norvex' ) ),
				'lead'    => array( __( 'Lead text', 'norvex' ), 'textarea', __( 'Authors choose us for the quality of our work, the clarity of our process, and the care we bring to every project. Here’s what sets us apart.', 'norvex' ) ),
				'btn'     => array( __( 'Button label (blank = hide)', 'norvex' ), 'text', __( 'Start your project', 'norvex' ) ),
				'btnurl'  => array( __( 'Button URL (blank = Contact page)', 'norvex' ), 'url', '' ),
				'side'    => array( __( 'Text column side', 'norvex' ), 'select', 'right', array( 'right' => __( 'Right', 'norvex' ), 'left' => __( 'Left', 'norvex' ) ) ),
				'cards'   => array( __( 'Feature cards', 'norvex' ), 'cards', norvex_default_feature_split_json(), array( 'iconlist' => norvex_card_icon_list() ) ),
			),
		),

		'highlights' => array(
			'title'    => __( 'Norvex: Highlights + note', 'norvex' ),
			'dynamic'  => false,
			'category' => 'norvex',
			'fields'   => array(
				'heading'  => array( __( 'Heading', 'norvex' ), 'text', __( 'We turn ideas into books that', 'norvex' ) ),
				'accent'   => array( __( 'Accent word(s) — script italic', 'norvex' ), 'text', __( 'inspire.', 'norvex' ) ),
				'subhead'  => array( __( 'Sub-heading (accent colour)', 'norvex' ), 'text', __( 'And help you share your story with the world.', 'norvex' ) ),
				'body'     => array( __( 'Body text — leave a blank line to start a new paragraph', 'norvex' ), 'textarea', __( "Whether you need a ghostwriter to draft your book, a publishing partner to bring it to life, or a marketing team to help it shine — we’re here from concept to completion.\n\nOur process is transparent, collaborative, and designed to keep you firmly in control of your work.", 'norvex' ) ),
				'signame'  => array( __( 'Signature name (optional)', 'norvex' ), 'text', __( 'The editorial team', 'norvex' ) ),
				'sigrole'  => array( __( 'Signature role (optional)', 'norvex' ), 'text', __( 'Founders & publishers', 'norvex' ) ),
				'sigphoto' => array( __( 'Signature photo (optional)', 'norvex' ), 'image', '' ),
				'featured' => array( __( 'Highlight which item', 'norvex' ), 'select', '2', array( '0' => __( 'None', 'norvex' ), '1' => '1', '2' => '2', '3' => '3', '4' => '4', '5' => '5' ) ),
				'items'    => array( __( 'Highlights', 'norvex' ), 'pairs', norvex_default_highlights_text(), array( 'a' => __( 'Title', 'norvex' ), 'b' => __( 'Description', 'norvex' ), 'sep' => '::', 'add' => __( 'Add highlight', 'norvex' ) ) ),
			),
		),

		'showcase' => array(
			'title'    => __( 'Norvex: Showcase list', 'norvex' ),
			'dynamic'  => false,
			'category' => 'norvex',
			'fields'   => array(
				'eyebrow' => array( __( 'Eyebrow', 'norvex' ), 'text', __( 'Full-service publishing', 'norvex' ) ),
				'heading' => array( __( 'Heading', 'norvex' ), 'text', __( 'Independent publishing, with none of the', 'norvex' ) ),
				'accent'  => array( __( 'Accent word(s) — script italic', 'norvex' ), 'text', __( 'compromises.', 'norvex' ) ),
				'body'    => array( __( 'Body text (first letter becomes a drop cap)', 'norvex' ), 'textarea', __( 'As a selective partner for serious authors, we shepherd your manuscript from the first read to the finished book — and stay beside you through launch and everything after.', 'norvex' ) ),
				'btn'     => array( __( 'Button label (blank = hide)', 'norvex' ), 'text', __( 'See the process', 'norvex' ) ),
				'btnurl'  => array( __( 'Button URL (blank = Services page)', 'norvex' ), 'url', '' ),
				'items'   => array( __( 'Numbered features', 'norvex' ), 'pairs', norvex_default_showcase_text(), array( 'a' => __( 'Title', 'norvex' ), 'b' => __( 'Description', 'norvex' ), 'sep' => '::', 'add' => __( 'Add feature', 'norvex' ) ) ),
			),
		),

		/* -------------------------------------------------------------------------
		   Rates / hero / checklist sections — the same warm card-and-section
		   language as the rest of the theme, each with one distinctive element.
		   ------------------------------------------------------------------------- */
		'broadsheet' => array(
			'title'    => __( 'Norvex: Rates & story', 'norvex' ),
			'dynamic'  => false,
			'category' => 'norvex',
			'fields'   => array(
				'eyebrow'    => array( __( 'Eyebrow', 'norvex' ), 'text', __( 'Transparent pricing', 'norvex' ) ),
				'heading'    => array( __( 'Heading', 'norvex' ), 'text', __( 'You wrote it. We’ll make it', 'norvex' ) ),
				'accent'     => array( __( 'Accent word(s) — script italic', 'norvex' ), 'text', __( 'a book.', 'norvex' ) ),
				'lead'       => array( __( 'Lead text', 'norvex' ), 'textarea', __( 'Every price sits in plain figures — never behind a discovery call that reprices to your budget. The scope sets the number, and the number is the number.', 'norvex' ) ),
				'body'       => array( __( 'Story — leave a blank line between paragraphs', 'norvex' ), 'textarea', __( "A finished title on every retailer is really six jobs wearing one cover — the writing, the edit, the design, the interior, the distribution, and the launch. We run all six as a single contract, or any one alone.\n\nEvery distribution account is opened in your name. The ISBN is yours, the copyright is yours, and each retailer pays you directly — no exclusivity clause and no permanent royalty share.", 'norvex' ) ),
				'ratestitle' => array( __( 'Rates card title', 'norvex' ), 'text', __( 'Services & rates', 'norvex' ) ),
				'ratessub'   => array( __( 'Rates card strapline', 'norvex' ), 'text', __( 'Posted openly — no quote required', 'norvex' ) ),
				'rates'      => array( __( 'Rates', 'norvex' ), 'rows', "Ghostwriting | $5,495\nEditing | $299\nCover & interior | $199\nDistribution | $249\nMarketing | $1,495\nCoaching | $549", array( 'sep' => '|', 'add' => __( 'Add rate', 'norvex' ), 'cols' => array( array( 'label' => __( 'Service', 'norvex' ), 'type' => 'text' ), array( 'label' => __( 'Price', 'norvex' ), 'type' => 'text' ) ) ) ),
				'quote'      => array( __( 'Pull quote (blank = hide)', 'norvex' ), 'textarea', __( 'The author keeps everything the work produces.', 'norvex' ) ),
				'quoteby'    => array( __( 'Pull quote attribution', 'norvex' ), 'text', __( 'The Norvex standing policy', 'norvex' ) ),
			),
		),

		'marginalia' => array(
			'title'    => __( 'Norvex: Launch checklist', 'norvex' ),
			'dynamic'  => false,
			'category' => 'norvex',
			'fields'   => array(
				'eyebrow'    => array( __( 'Eyebrow', 'norvex' ), 'text', __( 'From idea to launch day', 'norvex' ) ),
				'headbefore' => array( __( 'Heading — start', 'norvex' ), 'text', __( 'You wrote', 'norvex' ) ),
				'strike'     => array( __( 'Heading — struck-through word (blank = hide)', 'norvex' ), 'text', __( 'a document.', 'norvex' ) ),
				'fix'        => array( __( 'Heading — correction (rust italic)', 'norvex' ), 'text', __( 'a book.', 'norvex' ) ),
				'lead'       => array( __( 'Lead text', 'norvex' ), 'textarea', __( 'A finished title is six jobs wearing one cover. We run all of them as a single contract — so you stop being the project manager and go back to being the author.', 'norvex' ) ),
				'checkh'     => array( __( 'Checklist heading (blank = hide)', 'norvex' ), 'text', __( 'Editor’s checklist', 'norvex' ) ),
				'items'      => array( __( 'Checklist', 'norvex' ), 'rows', "Manuscript ghostwritten in your voice | $5,495 | done\nDevelopmental & copy edit passed | $299 | done\nCover & interior set to genre | $199 |\nDistribution live, accounts in your name | $249 |\nLaunch campaign scheduled | $1,495 |", array( 'sep' => '|', 'add' => __( 'Add item', 'norvex' ), 'cols' => array( array( 'label' => __( 'Item', 'norvex' ), 'type' => 'text' ), array( 'label' => __( 'Price', 'norvex' ), 'type' => 'text' ), array( 'label' => __( 'Done', 'norvex' ), 'type' => 'flag', 'flag' => 'done' ) ) ) ),
				'btn'        => array( __( 'Button label (blank = hide)', 'norvex' ), 'text', __( 'Start your book', 'norvex' ) ),
				'btnurl'     => array( __( 'Button URL (blank = Contact page)', 'norvex' ), 'url', '' ),
			),
		),

		/* -------------------------------------------------------------------------
		   Content-rich sections — chapters index, data columns and a
		   priced services list. Same warm card language as the rest of the theme.
		   ------------------------------------------------------------------------- */
		'chapters-index' => array(
			'title'    => __( 'Norvex: Chapters index', 'norvex' ),
			'dynamic'  => false,
			'category' => 'norvex',
			'fields'   => array(
				'eyebrow' => array( __( 'Eyebrow', 'norvex' ), 'text', __( 'The handbook', 'norvex' ) ),
				'heading' => array( __( 'Heading', 'norvex' ), 'text', __( 'Everything an author should know, in order', 'norvex' ) ),
				'meta'    => array( __( 'Meta note (top right, blank = hide)', 'norvex' ), 'text', __( 'Six chapters · updated 2026', 'norvex' ) ),
				'items'   => array( __( 'Entries', 'norvex' ), 'rows', "Before you begin | Deciding what kind of book you are writing, who it is for, and what publishing route will serve it best — the questions worth answering before the first chapter.\nThe editorial process | What developmental, line, and copy editing each do, how they differ, and how to get the most from working closely with an editor on your manuscript.\nDesign & typesetting | How a cover is developed, why interior typography matters more than most authors expect, and what to look for when you review your first proofs.\nProduction & print | Choosing formats and paper, understanding print runs and print-on-demand, and preparing the files that turn an approved proof into a finished book.\nDistribution | How books reach retailers, libraries, and wholesalers around the world, and what metadata quietly determines whether readers ever find yours.\nLaunch & beyond | Building anticipation before publication and sustaining momentum after it — reviews, events, and the long, patient work of finding a book's readers.", array( 'sep' => '|', 'add' => __( 'Add entry', 'norvex' ), 'cols' => array( array( 'label' => __( 'Title', 'norvex' ), 'type' => 'text' ), array( 'label' => __( 'Description', 'norvex' ), 'type' => 'text' ) ) ) ),
			),
		),

		'data-columns' => array(
			'title'    => __( 'Norvex: Data columns', 'norvex' ),
			'dynamic'  => false,
			'category' => 'norvex',
			'fields'   => array(
				'eyebrow' => array( __( 'Eyebrow', 'norvex' ), 'text', __( 'The industry data', 'norvex' ) ),
				'heading' => array( __( 'Heading', 'norvex' ), 'text', __( 'The case isn’t our opinion — it’s in the data.', 'norvex' ) ),
				'lead'    => array( __( 'Lead text', 'norvex' ), 'textarea', __( 'The argument for fee-for-service publishing sits in figures published by industry bodies with no commercial interest in selling author services. Three sources matter most.', 'norvex' ) ),
				'cols'    => array( __( 'Columns', 'norvex' ), 'rows', "Authors Guild | Fair Contracts | On hybrid contracts | The oldest professional writers’ organization in the US runs a Fair Contract Initiative focused on the terms most often blurred in rights-share arrangements: transparency, royalty fairness, limited-term agreements. | Read the initiative | \nBowker · 2025 | 3.5M | On indie publishing volume | Of 4.2 million US titles registered in 2025 — up 32.5% over 2024 — some 3.5 million were self-published, a 38.7% jump. Indie publishing is no longer niche; it’s the dominant path for new US books. | See the report | \nEFA rate chart | Public Rates | On editing rates | The Editorial Freelancers Association publishes a public rates chart used across the industry. Our editing prices align with EFA-documented rates — not the inflated figures hybrid publishers fold into bundled contracts. | View the chart | ", array( 'sep' => '|', 'add' => __( 'Add column', 'norvex' ), 'cols' => array( array( 'label' => __( 'Source', 'norvex' ), 'type' => 'text' ), array( 'label' => __( 'Figure', 'norvex' ), 'type' => 'text' ), array( 'label' => __( 'Sub-heading', 'norvex' ), 'type' => 'text' ), array( 'label' => __( 'Description', 'norvex' ), 'type' => 'text' ), array( 'label' => __( 'Link label', 'norvex' ), 'type' => 'text' ), array( 'label' => __( 'Link URL', 'norvex' ), 'type' => 'text' ) ) ) ),
			),
		),

		'services-list' => array(
			'title'    => __( 'Norvex: Services list', 'norvex' ),
			'dynamic'  => false,
			'category' => 'norvex',
			'fields'   => array(
				'eyebrow' => array( __( 'Eyebrow', 'norvex' ), 'text', __( 'What we offer', 'norvex' ) ),
				'heading' => array( __( 'Heading', 'norvex' ), 'text', __( 'Six author services, from idea to launch day.', 'norvex' ) ),
				'accent'  => array( __( 'Heading accent (script italic, blank = none)', 'norvex' ), 'text', '' ),
				'lead'    => array( __( 'Lead text', 'norvex' ), 'textarea', __( 'A finished book on Amazon is the result of six different jobs, not one. Take all six as a single contract, or any one on its own — the price is printed next to each.', 'norvex' ) ),
				'learn'   => array( __( 'Row link label', 'norvex' ), 'text', __( 'Learn more', 'norvex' ) ),
				'items'   => array( __( 'Services', 'norvex' ), 'rows', "Ghostwriting | Best standard | A professional writer turns your concept, transcripts, or rough draft into a finished manuscript in your voice — memoir, non-fiction, fiction, children’s. You hold the byline, the copyright, and the royalties. | From $5,495 | \nBook Editing | Free sample edit | Developmental, line, copy, and proof editing on a per-service or bundled basis. Pricing transparent on the page, EFA rate-aligned, with a free sample edit before you commit. | From $299 | \nBook Design | | Cover design and interior formatting for ebook and print. Genre-correct visual language, KDP and IngramSpark file specs, and fixed-layout options for children’s and illustrated books. | From $199 | \nBook Publishing | Accounts in your name | Distribution setup across Amazon KDP, IngramSpark, Apple Books, Kobo, and Google Play. ISBN registration, metadata optimization, pricing strategy, and copyright guidance. | From $249 | \nBook Marketing | | Pre-launch positioning, ARC distribution, Amazon Ads strategy, and ongoing visibility campaigns. Optional premium add-ons for podcast booking, PR, and book-fair exhibition. | From $1,495 | \nBook Coaching | | One-on-one work for authors writing the book themselves. Manuscript review, structural feedback, accountability, and craft coaching — designed so the book stays yours. | From $549 | ", array( 'sep' => '|', 'add' => __( 'Add service', 'norvex' ), 'cols' => array( array( 'label' => __( 'Title', 'norvex' ), 'type' => 'text' ), array( 'label' => __( 'Badge (optional)', 'norvex' ), 'type' => 'text' ), array( 'label' => __( 'Description', 'norvex' ), 'type' => 'text' ), array( 'label' => __( 'Price', 'norvex' ), 'type' => 'text' ), array( 'label' => __( 'Link URL (optional)', 'norvex' ), 'type' => 'text' ) ) ) ),
			),
		),

		'steps-media' => array(
			'title'    => __( 'Norvex: Steps with media', 'norvex' ),
			'dynamic'  => false,
			'category' => 'norvex',
			'fields'   => array(
				'eyebrow' => array( __( 'Eyebrow (optional)', 'norvex' ), 'text', __( 'How it works', 'norvex' ) ),
				'heading' => array( __( 'Heading', 'norvex' ), 'text', __( 'From first idea to finished book', 'norvex' ) ),
				'lead'    => array( __( 'Lead text', 'norvex' ), 'textarea', __( 'A clear, guided path with a dedicated team beside you at every step — no jargon, no surprises.', 'norvex' ) ),
				'align'   => array( __( 'Heading alignment', 'norvex' ), 'select', 'center', array( 'center' => __( 'Center', 'norvex' ), 'left' => __( 'Left', 'norvex' ) ) ),
				'steps'   => array( __( 'Steps', 'norvex' ), 'hidden', norvex_default_steps_json() ),
			),
		),

		'timeline-h' => array(
			'title'    => __( 'Norvex: Timeline (horizontal)', 'norvex' ),
			'dynamic'  => false,
			'category' => 'norvex',
			'fields'   => array(
				'eyebrow' => array( __( 'Eyebrow', 'norvex' ), 'text', __( 'What you get', 'norvex' ) ),
				'heading' => array( __( 'Heading', 'norvex' ), 'text', __( 'What real marketing actually buys you', 'norvex' ) ),
				'accent'  => array( __( 'Heading accent (script italic, blank = none)', 'norvex' ), 'text', __( '— six jobs, not one', 'norvex' ) ),
				'lead'    => array( __( 'Lead text', 'norvex' ), 'textarea', __( 'The line item on the invoice says “marketing.” The real deliverable is six different jobs done across 30 to 90 days — foundation, platform, ads, launch, outreach and ongoing visibility.', 'norvex' ) ),
				'scale'   => array( __( 'Scale markers below the line (pipe-separated, blank = hide)', 'norvex' ), 'text', 'Day 1 | Day 30 | Day 60 | Day 90+' ),
				'items'   => array( __( 'Milestones', 'norvex' ), 'rows', "Foundation | Sellable listing | Optimized title, subtitle, description and keywords, structured around your genre's real search behaviour.\nPlatform | Author platform | A website with email capture, a lead magnet and a working autoresponder — the place readers land after clicking an ad.\nAds | Advertising setup | Ad campaigns built around your genre's real cost-per-click economics, not generic templates from a tutorial.\nLaunch | Launch coordination | Pre-order strategy, a launch-day sequence and review-pool activation inside the algorithmic boost window.\nOutreach | Reader outreach | Newsletter-swap coordination, ARC distribution and author-profile work — the audience the retailers can't take away.\nVisibility | Ongoing visibility | Post-launch ad management, a promotional calendar and ranking monitoring — the work that keeps a backlist alive.", array( 'sep' => '|', 'add' => __( 'Add milestone', 'norvex' ), 'cols' => array( array( 'label' => __( 'Phase label', 'norvex' ), 'type' => 'text' ), array( 'label' => __( 'Title', 'norvex' ), 'type' => 'text' ), array( 'label' => __( 'Description', 'norvex' ), 'type' => 'text' ) ) ) ),
			),
		),

		'zigzag' => array(
			'title'    => __( 'Norvex: Zig-zag steps', 'norvex' ),
			'dynamic'  => false,
			'category' => 'norvex',
			'fields'   => array(
				'eyebrow' => array( __( 'Eyebrow', 'norvex' ), 'text', __( 'How it works', 'norvex' ) ),
				'heading' => array( __( 'Heading', 'norvex' ), 'text', __( 'How it actually works, across', 'norvex' ) ),
				'accent'  => array( __( 'Heading accent (script italic, blank = none)', 'norvex' ), 'text', __( 'six documented steps', 'norvex' ) ),
				'lead'    => array( __( 'Lead text', 'norvex' ), 'textarea', __( 'Named deliverables and an approval gate between every operating decision — nothing happens to your book without you seeing it first.', 'norvex' ) ),
				'items'   => array( __( 'Steps', 'norvex' ), 'rows', "Week 1–2 | Discovery & launch audit | A short consultation maps what you have — manuscript, sales history, audience — then we recommend the right services and send a written proposal within 48 hours.\nWeek 2–3 | Foundation build-out | Listing optimized, author site live, email capture and lead magnet in place, keywords and categories set, and the autoresponder written before the campaign starts.\nWeek 3–4 | Ad account & strategy lock | Your ad account and creative structured around your genre's economics, plus newsletter and promo plans. You approve the written strategy before a cent is spent.\nWeek 4–8 | Active campaign management | The daily work behind the price: bid adjustments, budget shifts, category refinement and weekly reports in plain numbers, not dashboards.\nLaunch + 30 | Launch window & visibility push | The launch sequence when it matters — pre-order, blast, social activation, newsletter swaps and daily monitoring through the boost window.\nFinal week | End-of-campaign review | A detailed report of spend, rankings and conversions with a plain-English plan for the next 60–90 days — keep it running yourself or hand it back to us.", array( 'sep' => '|', 'add' => __( 'Add step', 'norvex' ), 'cols' => array( array( 'label' => __( 'Label', 'norvex' ), 'type' => 'text' ), array( 'label' => __( 'Title', 'norvex' ), 'type' => 'text' ), array( 'label' => __( 'Description', 'norvex' ), 'type' => 'text' ) ) ) ),
			),
		),
	);

	// Give every block that has the eyebrow / heading / lead header a set of
	// optional per-line colour pickers. These are appended here (rather than
	// hand-added to each block) so the ~24 header sections stay in sync. When a
	// colour is picked it is applied to that line only, by norvex_apply_header_colors().
	foreach ( $blocks as $name => $block ) {
		if ( empty( $block['fields'] ) || ! is_array( $block['fields'] ) ) {
			continue;
		}
		$fields = $block['fields'];
		if ( isset( $fields['eyebrow'] ) ) {
			$fields['ceyebrow'] = array( __( 'Eyebrow colour', 'norvex' ), 'color', '' );
		}
		if ( isset( $fields['heading'] ) || isset( $fields['title'] ) ) {
			$fields['cheading'] = array( __( 'Heading colour', 'norvex' ), 'color', '' );
		}
		if ( isset( $fields['lead'] ) ) {
			$fields['clead'] = array( __( 'Lead colour', 'norvex' ), 'color', '' );
		}
		$blocks[ $name ]['fields'] = $fields;
	}

	return $blocks;
}

/**
 * Default steps for a freshly inserted Steps-with-media block (JSON string of
 * { title, text, image }).
 *
 * @return string
 */
function norvex_default_steps_json() {
	return wp_json_encode(
		array(
			array( 'title' => __( 'Book your consultation', 'norvex' ), 'text' => __( 'Tell us about your book and your goals. We listen first, then map out exactly what it needs — no pressure and no obligation.', 'norvex' ), 'image' => '' ),
			array( 'title' => __( 'Get a clear plan & quote', 'norvex' ), 'text' => __( 'We recommend the right services and send transparent, itemised pricing. The scope sets the number, and the number is the number.', 'norvex' ), 'image' => '' ),
			array( 'title' => __( 'Your team gets to work', 'norvex' ), 'text' => __( 'A dedicated project manager guides editing, design and production, keeping you updated at every milestone.', 'norvex' ), 'image' => '' ),
			array( 'title' => __( 'Launch — and beyond', 'norvex' ), 'text' => __( 'We publish in your name on every major retailer and support your launch, so your book reaches its readers.', 'norvex' ), 'image' => '' ),
		)
	);
}

/**
 * Default tabs for a freshly inserted Tabs block (JSON string).
 *
 * @return string
 */
function norvex_default_tabs_json() {
	return wp_json_encode(
		array(
			array( 'title' => __( 'Overview', 'norvex' ), 'content' => __( "We help authors write, edit, design, publish and market their books — while they keep full ownership every step of the way.\n\nTell us where you are and we'll map out exactly what your book needs.", 'norvex' ) ),
			array( 'title' => __( 'How it works', 'norvex' ), 'content' => __( "1. Book a free consultation.\n2. We recommend the right services and send a clear quote.\n3. Your dedicated team delivers, milestone by milestone, through to launch.", 'norvex' ) ),
			array( 'title' => __( 'What you get', 'norvex' ), 'content' => __( "A dedicated project manager, transparent pricing with no hidden fees, and on-time delivery — with you as the sole author and rights-holder throughout.", 'norvex' ) ),
		)
	);
}

/**
 * Whether a grid block is set to display as a carousel.
 *
 * @param array $a Block attributes.
 * @return bool
 */
function norvex_grid_is_carousel( $a ) {
	return isset( $a['carousel'] ) && '1' === (string) $a['carousel'];
}

/**
 * A reusable "Display as carousel" field for grid blocks.
 *
 * @return array
 */
function norvex_carousel_field() {
	return array( __( 'Display', 'norvex' ), 'select', 'grid', array( 'grid' => __( 'Grid', 'norvex' ), '1' => __( 'Carousel / slider', 'norvex' ) ) );
}

/**
 * Default table data for a freshly inserted Table block (JSON string).
 *
 * @return string
 */
function norvex_default_table_json() {
	return wp_json_encode(
		array(
			array( __( 'Plan', 'norvex' ), __( 'Price', 'norvex' ), __( 'Best for', 'norvex' ) ),
			array( __( 'Essentials', 'norvex' ), 'from $999', __( 'A finished draft', 'norvex' ) ),
			array( __( 'Complete', 'norvex' ), 'from $2,999', __( 'End-to-end publishing', 'norvex' ) ),
			array( __( 'Bestseller', 'norvex' ), 'from $8,995', __( 'A full launch', 'norvex' ) ),
		)
	);
}

/**
 * Every icon available to the Grid cards block, grouped into categories, each
 * with its rendered SVG so the editor can show a visual icon library.
 *
 * @return array List of array( label, icons => array( value, label, svg ) ).
 */
function norvex_card_icon_list() {
	$groups = array(
		'General'           => array( 'check', 'star', 'sparkle', 'award', 'shield', 'chart', 'target', 'search', 'globe', 'clock', 'calendar', 'pin', 'map', 'users', 'link', 'arrow', 'heart', 'gift', 'bulb', 'tag', 'flag', 'home', 'bell', 'lock', 'rocket', 'thumbup', 'download', 'upload', 'play', 'cart', 'coffee', 'smile' ),
		'Publishing & media' => array( 'edit', 'book', 'quill', 'design', 'print', 'monitor', 'mic', 'image', 'folder', 'camera' ),
		'Contact & social'  => array( 'mail', 'phone', 'twitter', 'instagram', 'facebook', 'linkedin', 'megaphone' ),
	);

	$out = array();
	foreach ( $groups as $label => $keys ) {
		$icons = array();
		foreach ( $keys as $k ) {
			$icons[] = array(
				'value' => $k,
				'label' => ucfirst( $k ),
				'svg'   => norvex_icon( $k, false ),
			);
		}
		$out[] = array(
			'label' => $label,
			'icons' => $icons,
		);
	}
	return $out;
}

/**
 * Sanitise a user-pasted SVG for safe output as a card icon.
 *
 * Allows only inline vector shape tags and a safe attribute set — scripts,
 * event handlers, external references and foreign objects are stripped.
 *
 * @param string $svg Raw SVG markup.
 * @return string Clean SVG, or '' if it isn't a usable SVG.
 */
function norvex_sanitize_svg( $svg ) {
	$svg = trim( (string) $svg );
	if ( '' === $svg || false === stripos( $svg, '<svg' ) ) {
		return '';
	}

	$shape = array(
		'fill' => true, 'stroke' => true, 'stroke-width' => true, 'stroke-linecap' => true,
		'stroke-linejoin' => true, 'fill-rule' => true, 'clip-rule' => true, 'opacity' => true,
		'transform' => true,
	);
	$allowed = array(
		'svg'      => array_merge( $shape, array( 'xmlns' => true, 'viewbox' => true, 'width' => true, 'height' => true, 'class' => true, 'role' => true, 'aria-hidden' => true, 'focusable' => true ) ),
		'g'        => $shape,
		'title'    => array(),
		'path'     => array_merge( $shape, array( 'd' => true ) ),
		'circle'   => array_merge( $shape, array( 'cx' => true, 'cy' => true, 'r' => true ) ),
		'ellipse'  => array_merge( $shape, array( 'cx' => true, 'cy' => true, 'rx' => true, 'ry' => true ) ),
		'rect'     => array_merge( $shape, array( 'x' => true, 'y' => true, 'width' => true, 'height' => true, 'rx' => true, 'ry' => true ) ),
		'line'     => array_merge( $shape, array( 'x1' => true, 'y1' => true, 'x2' => true, 'y2' => true ) ),
		'polyline' => array_merge( $shape, array( 'points' => true ) ),
		'polygon'  => array_merge( $shape, array( 'points' => true ) ),
	);

	return wp_kses( $svg, $allowed );
}

/**
 * Default cards for a freshly inserted Grid cards block (JSON string).
 *
 * @return string
 */
function norvex_default_cards_json() {
	return wp_json_encode(
		array(
			array( 'icon' => 'edit', 'image' => '', 'title' => __( 'Editing & proofreading', 'norvex' ), 'text' => __( 'Developmental, line and copy editing to make your manuscript shine.', 'norvex' ), 'url' => '', 'linklabel' => '' ),
			array( 'icon' => 'design', 'image' => '', 'title' => __( 'Cover & interior design', 'norvex' ), 'text' => __( 'Original, market-ready design for both print and ebook editions.', 'norvex' ), 'url' => '', 'linklabel' => '' ),
			array( 'icon' => 'megaphone', 'image' => '', 'title' => __( 'Marketing & launch', 'norvex' ), 'text' => __( 'Launch campaigns, author websites and media outreach that reach readers.', 'norvex' ), 'url' => '', 'linklabel' => __( 'Learn more', 'norvex' ) ),
		)
	);
}

/**
 * Default feature cards for a freshly inserted Feature-split block (JSON).
 *
 * @return string
 */
function norvex_default_feature_split_json() {
	return wp_json_encode(
		array(
			array( 'icon' => 'heart',  'title' => __( 'Personalized service', 'norvex' ), 'text' => __( 'Every book is custom-crafted with one-on-one guidance — no templates, no shortcuts.', 'norvex' ) ),
			array( 'icon' => 'edit',   'title' => __( 'Transparent process', 'norvex' ), 'text' => __( 'Clear steps, flexible options, and no hidden fees or confusing fine print.', 'norvex' ) ),
			array( 'icon' => 'award',  'title' => __( 'Experienced professionals', 'norvex' ), 'text' => __( 'Editors and consultants with real, verifiable publishing-industry expertise.', 'norvex' ) ),
			array( 'icon' => 'shield', 'title' => __( 'You keep 100% ownership', 'norvex' ), 'text' => __( 'You remain the sole author and rights-holder — we stay behind the scenes.', 'norvex' ) ),
		)
	);
}

/**
 * Seed "Title :: Description" text for the Highlights block.
 *
 * @return string
 */
function norvex_default_highlights_text() {
	return implode(
		"\n",
		array(
			__( 'Experienced team :: Hundreds of authors trust us for editorial, design, and marketing — with consistent results.', 'norvex' ),
			__( 'On time, every time :: A structured workflow and a dedicated project manager keep your book moving smoothly.', 'norvex' ),
			__( 'Quality that lasts :: From manuscript to print, every project gets the same care as a bestseller.', 'norvex' ),
		)
	);
}

/**
 * Seed "Title :: Description" text for the Showcase list block.
 *
 * @return string
 */
function norvex_default_showcase_text() {
	return implode(
		"\n",
		array(
			__( 'Expert editorial :: Credentialed editors who treat your manuscript with the care it deserves.', 'norvex' ),
			__( 'Considered design :: Original cover concepts and interior layouts crafted for your book.', 'norvex' ),
			__( 'Global distribution :: Your book reaches major retailers, libraries, and wholesalers worldwide.', 'norvex' ),
			__( 'Dedicated publicity :: A tailored campaign that connects your work with the right readers.', 'norvex' ),
		)
	);
}

/**
 * Parse a "Title :: Description" per-line string into title/text rows. Mirrors
 * the block editor's pairs control, which joins each row with " :: ".
 *
 * @param string $text Raw pairs text.
 * @param string $sep  Separator (default "::").
 * @return array List of array( 'title' => string, 'text' => string ).
 */
function norvex_parse_pair_lines( $text, $sep = '::' ) {
	$out = array();
	foreach ( preg_split( '/\r\n|\r|\n/', (string) $text ) as $line ) {
		if ( '' === trim( $line ) ) {
			continue;
		}
		$pos = strpos( $line, $sep );
		if ( false === $pos ) {
			$out[] = array( 'title' => trim( $line ), 'text' => '' );
		} else {
			$out[] = array(
				'title' => trim( substr( $line, 0, $pos ) ),
				'text'  => trim( substr( $line, $pos + strlen( $sep ) ) ),
			);
		}
	}
	return $out;
}

/**
 * Parse a "col | col | col" per-line rows string into arrays of trimmed cells.
 * Mirrors the block editor's rows control (blank lines skipped, cells trimmed).
 *
 * @param string $text Raw rows text.
 * @param string $sep  Column separator (default "|").
 * @return array List of numeric arrays of cell strings.
 */
function norvex_split_rows( $text, $sep = '|' ) {
	$out = array();
	foreach ( preg_split( '/\r\n|\r|\n/', (string) $text ) as $line ) {
		if ( '' === trim( $line ) ) {
			continue;
		}
		$out[] = array_map( 'trim', explode( $sep, $line ) );
	}
	return $out;
}

/**
 * Build a heading with a script-italic accent word appended. The accent is the
 * standard two-tone treatment used across the split section blocks.
 *
 * @param string $heading Plain heading text.
 * @param string $accent  Accent word(s) rendered in serif italic.
 * @param string $tag     Heading tag (default h2).
 * @return string Escaped HTML.
 */
function norvex_accent_heading( $heading, $accent, $tag = 'h2' ) {
	$tag = preg_match( '/^h[1-6]$/', $tag ) ? $tag : 'h2';
	$out = '<' . $tag . ' class="norvex-accent-heading">';
	$out .= esc_html( $heading );
	if ( '' !== trim( (string) $accent ) ) {
		$out .= ' <em class="norvex-accent-word">' . esc_html( $accent ) . '</em>';
	}
	$out .= '</' . $tag . '>';
	return $out;
}

/**
 * Default home FAQ list as "Question | Answer" lines (also used by the block).
 */
function norvex_default_home_faq_text() {
	$faqs = array(
		array( 'Do I keep the rights to my book?', 'Always. You remain the sole author and keep 100% of your rights and royalties. Unlike traditional or vanity presses, we never take a share of your work or your earnings.' ),
		array( 'Whose name are the accounts in?', 'Yours. Every retailer account — Amazon KDP, IngramSpark, Apple Books, Kobo and Google Play — is opened in your name, so you keep full control and every royalty is paid directly to you.' ),
		array( 'How is this different from a hybrid publisher?', 'Hybrid and vanity presses charge you and then take ongoing royalties or own your ISBN. We charge a transparent flat fee, take zero royalties, and set everything up in your name.' ),
		array( 'How much does it cost?', 'Every price is published up front — no hidden fees and no "custom quote" games. Start from a service price, build your own package, or run the cost calculator for an instant estimate.' ),
		array( 'How long until my book is live?', 'Once your files are ready, most books are live on every major retailer within 30 days. After your consultation we give you a clear timeline with milestones.' ),
	);
	$lines = array();
	foreach ( $faqs as $f ) {
		$lines[] = $f[0] . ' | ' . $f[1];
	}
	return implode( "\n", $lines );
}

/**
 * Merge stored attributes over the block's registered defaults.
 */
function norvex_block_defaults( $name ) {
	$config = norvex_blocks_config();
	$out    = array();
	if ( isset( $config[ $name ] ) ) {
		foreach ( $config[ $name ]['fields'] as $key => $field ) {
			$out[ $key ] = $field[2];
		}
	}
	return $out;
}

/**
 * Register all blocks + the shared editor asset.
 */
function norvex_register_blocks() {
	$config = norvex_blocks_config();

	foreach ( $config as $name => $block ) {
		$attributes = array();
		foreach ( $block['fields'] as $key => $field ) {
			$attributes[ $key ] = array(
				'type'    => 'number' === $field[1] ? 'number' : 'string',
				'default' => $field[2],
			);
		}

		// The section markup is produced by the PHP render_callback, so wrap it
		// once to apply the design-tool styles (colour, background, gradient,
		// spacing, border) that WordPress computes from the block supports.
		// Without this the Color / Dimensions / Border panels would show in the
		// editor but their choices would never reach the front end.
		$callback = 'norvex_render_block_' . str_replace( '-', '_', $name );
		$render   = function ( $atts, $content = '', $block_obj = null ) use ( $callback ) {
			$html = call_user_func( $callback, $atts );
			$html = norvex_apply_header_colors( $html, $atts );
			return norvex_apply_block_style_supports( $html );
		};

		register_block_type(
			'norvex/' . $name,
			array(
				'attributes'      => $attributes,
				'supports'        => norvex_block_style_supports(),
				'render_callback' => $render,
				'editor_script'   => 'norvex-blocks',
			)
		);
	}
}
add_action( 'init', 'norvex_register_blocks' );

/**
 * Shared block "supports" for every Norvex section. Declaring these turns on
 * the native WordPress design tools — the Color panel (text, background,
 * gradient and link colours), the Dimensions panel (padding & margin) and the
 * Border panel — so each block can be restyled from the editor sidebar with no
 * per-block custom UI.
 *
 * @return array
 */
function norvex_block_style_supports() {
	return array(
		'html'                    => false,
		'reusable'                => false,
		'multiple'                => true,
		'anchor'                  => true,
		'align'                   => array( 'wide', 'full' ),
		'color'                   => array(
			'background' => true,
			'text'       => true,
			'gradients'  => true,
			'link'       => true,
		),
		'spacing'                 => array(
			'padding' => true,
			'margin'  => true,
		),
		'__experimentalBorder'    => array(
			'color'  => true,
			'radius' => true,
			'style'  => true,
			'width'  => true,
		),
	);
}

/**
 * Merge the style-support classes and inline styles WordPress derives from a
 * block's colour/spacing/border attributes onto the first HTML element of a
 * server-rendered section.
 *
 * The render callbacks emit their own outer element (a <section>, <div>, <ul>
 * or <blockquote>), so we inject the computed wrapper attributes into that tag
 * rather than adding an extra nesting div that could disturb the layout.
 *
 * @param string $html Rendered block HTML.
 * @return string
 */
function norvex_apply_block_style_supports( $html ) {
	$html = (string) $html;
	if ( '' === trim( $html ) || ! function_exists( 'get_block_wrapper_attributes' ) ) {
		return $html;
	}

	$wrapper = get_block_wrapper_attributes();
	if ( '' === $wrapper ) {
		return $html;
	}

	$class = '';
	$style = '';
	if ( preg_match( '/class="([^"]*)"/', $wrapper, $m ) ) {
		$class = html_entity_decode( $m[1], ENT_QUOTES );
	}
	if ( preg_match( '/style="([^"]*)"/', $wrapper, $m ) ) {
		$style = html_entity_decode( $m[1], ENT_QUOTES );
	}
	if ( '' === $class && '' === $style ) {
		return $html;
	}

	if ( class_exists( 'WP_HTML_Tag_Processor' ) ) {
		$p = new WP_HTML_Tag_Processor( $html );
		if ( $p->next_tag() ) {
			foreach ( array_filter( explode( ' ', $class ) ) as $c ) {
				$p->add_class( $c );
			}
			if ( '' !== $style ) {
				$existing = (string) $p->get_attribute( 'style' );
				$existing = '' !== trim( $existing ) ? rtrim( trim( $existing ), ';' ) . ';' : '';
				$p->set_attribute( 'style', $existing . $style );
			}
			return $p->get_updated_html();
		}
		return $html;
	}

	// Fallback for very old cores without the tag processor: inject into the
	// first opening tag by hand.
	return preg_replace_callback(
		'/<([a-zA-Z0-9]+)((?:\s[^>]*)?)>/',
		function ( $mm ) use ( $class, $style ) {
			$attrs = $mm[2];
			if ( '' !== $class ) {
				if ( preg_match( '/class="([^"]*)"/', $attrs ) ) {
					$attrs = preg_replace( '/class="([^"]*)"/', 'class="$1 ' . esc_attr( $class ) . '"', $attrs, 1 );
				} else {
					$attrs .= ' class="' . esc_attr( $class ) . '"';
				}
			}
			if ( '' !== $style ) {
				if ( preg_match( '/style="([^"]*)"/', $attrs ) ) {
					$attrs = preg_replace( '/style="([^"]*)"/', 'style="$1;' . esc_attr( $style ) . '"', $attrs, 1 );
				} else {
					$attrs .= ' style="' . esc_attr( $style ) . '"';
				}
			}
			return '<' . $mm[1] . $attrs . '>';
		},
		$html,
		1
	);
}

/**
 * Validate a colour value coming from a block field. Accepts hex (#rgb /
 * #rrggbb / #rrggbbaa) and rgb/rgba()/hsl()/hsla() notations; anything else
 * (including empty) yields '' so no colour is applied.
 *
 * @param string $value Raw colour string.
 * @return string
 */
function norvex_sanitize_color( $value ) {
	$value = trim( (string) $value );
	if ( '' === $value ) {
		return '';
	}
	if ( preg_match( '/^#(?:[0-9a-fA-F]{3}|[0-9a-fA-F]{6}|[0-9a-fA-F]{8})$/', $value ) ) {
		return $value;
	}
	if ( preg_match( '/^(?:rgb|rgba|hsl|hsla)\(\s*[0-9.,%\s\/]+\)$/', $value ) ) {
		return $value;
	}
	return '';
}

/**
 * Apply the optional per-line "Header line colours" (eyebrow / heading / lead)
 * onto a rendered section. Each colour is set as an inline style on the first
 * matching element only — the section's eyebrow, its first heading and its
 * lead paragraph — so it overrides the section-level Text colour for that line
 * without touching the block's other markup. Blocks/fields left blank are
 * unchanged.
 *
 * @param string $html Rendered block HTML.
 * @param array  $a    Block attributes.
 * @return string
 */
function norvex_apply_header_colors( $html, $a ) {
	$html = (string) $html;
	if ( '' === trim( $html ) || ! class_exists( 'WP_HTML_Tag_Processor' ) ) {
		return $html;
	}

	$eyebrow = isset( $a['ceyebrow'] ) ? norvex_sanitize_color( $a['ceyebrow'] ) : '';
	$heading = isset( $a['cheading'] ) ? norvex_sanitize_color( $a['cheading'] ) : '';
	$lead    = isset( $a['clead'] ) ? norvex_sanitize_color( $a['clead'] ) : '';

	if ( '' === $eyebrow && '' === $heading && '' === $lead ) {
		return $html;
	}

	$set_color = function ( $p, $color ) {
		$existing = (string) $p->get_attribute( 'style' );
		$existing = '' !== trim( $existing ) ? rtrim( trim( $existing ), ';' ) . ';' : '';
		// $color is validated by norvex_sanitize_color(); append last so it wins
		// over any colour already present on the element.
		$p->set_attribute( 'style', $existing . 'color:' . $color . ';' );
	};

	$p            = new WP_HTML_Tag_Processor( $html );
	$done_eyebrow = ( '' === $eyebrow );
	$done_heading = ( '' === $heading );
	$done_lead    = ( '' === $lead );

	while ( $p->next_tag() && ( ! $done_eyebrow || ! $done_heading || ! $done_lead ) ) {
		$tag   = (string) $p->get_tag();
		$class = (string) $p->get_attribute( 'class' );

		if ( ! $done_eyebrow && false !== strpos( $class, 'norvex-eyebrow' ) ) {
			$set_color( $p, $eyebrow );
			$done_eyebrow = true;
			continue;
		}
		if ( ! $done_heading && preg_match( '/^H[1-6]$/', $tag ) ) {
			$set_color( $p, $heading );
			$done_heading = true;
			continue;
		}
		if ( ! $done_lead && false !== strpos( $class, 'lead' ) ) {
			$set_color( $p, $lead );
			$done_lead = true;
			continue;
		}
	}

	return $p->get_updated_html();
}

/**
 * A dedicated block category so the sections are easy to find.
 */
function norvex_block_category( $categories ) {
	array_unshift(
		$categories,
		array(
			'slug'  => 'norvex-block',
			'title' => __( 'Norvex · Building Blocks', 'norvex' ),
			'icon'  => 'screenoptions',
		),
		array(
			'slug'  => 'norvex',
			'title' => __( 'Norvex · Sections', 'norvex' ),
			'icon'  => 'book',
		)
	);
	return $categories;
}
add_filter( 'block_categories_all', 'norvex_block_category' );

/**
 * Enqueue the editor script and expose the block config to it.
 */
function norvex_blocks_editor_assets() {
	wp_register_script(
		'norvex-blocks',
		NORVEX_URI . '/blocks/editor.js',
		array( 'wp-blocks', 'wp-element', 'wp-block-editor', 'wp-components', 'wp-i18n', 'wp-server-side-render' ),
		NORVEX_VERSION,
		true
	);
	wp_enqueue_script( 'norvex-blocks' );
	if ( function_exists( 'wp_set_script_translations' ) ) {
		wp_set_script_translations( 'norvex-blocks', 'norvex' );
	}

	// Build a lean config for the editor UI: name, title, category, fields.
	$editor_config = array();
	foreach ( norvex_blocks_config() as $name => $block ) {
		$fields = array();
		foreach ( $block['fields'] as $key => $field ) {
			$entry = array(
				'key'     => $key,
				'label'   => $field[0],
				'type'    => $field[1],
				'default' => $field[2],
			);
			// Optional 4th element: select options (assoc array, or a callable
			// name that returns one). Optional 5th: show-if [ otherKey, value ].
			if ( isset( $field[3] ) ) {
				$opts = $field[3];
				if ( is_string( $opts ) && is_callable( $opts ) ) {
					$opts = call_user_func( $opts );
				}
				$entry['options'] = $opts;
			}
			if ( isset( $field[4] ) ) {
				$entry['showif'] = $field[4];
			}
			$fields[] = $entry;
		}
		$editor_config[] = array(
			'name'     => 'norvex/' . $name,
			'title'    => $block['title'],
			'dynamic'  => (bool) $block['dynamic'],
			'category' => isset( $block['category'] ) ? $block['category'] : 'norvex',
			'fields'   => $fields,
		);
	}

	wp_add_inline_script(
		'norvex-blocks',
		'window.NorvexBlocks = ' . wp_json_encode( $editor_config ) . ';',
		'before'
	);
}
add_action( 'enqueue_block_editor_assets', 'norvex_blocks_editor_assets' );

/* =========================================================================
   Render callbacks — each returns the section's front-end HTML. The markup is
   the same as the former front-page.php so the design is unchanged.
   ========================================================================= */

function norvex_render_block_hero( $a ) {
	$a = wp_parse_args( $a, norvex_block_defaults( 'hero' ) );
	ob_start();
	?>
	<section class="norvex-hero">
		<div class="norvex-wrap norvex-hero__grid">
			<div class="norvex-hero__intro">
				<span class="norvex-eyebrow"><?php echo esc_html( $a['eyebrow'] ); ?></span>
				<h1><?php norvex_hero_title( $a['title'] ); ?></h1>
				<p class="norvex-hero__lead"><?php echo esc_html( $a['lead'] ); ?></p>
				<div class="norvex-hero__actions">
					<a class="norvex-btn norvex-btn--primary" href="<?php echo esc_url( norvex_btn_url( norvex_ba( $a, 'btn1url' ), 'contact' ) ); ?>"><?php echo esc_html( $a['btn1'] ); ?> <?php norvex_icon( 'arrow' ); ?></a>
					<a class="norvex-btn norvex-btn--ghost" href="<?php echo esc_url( norvex_btn_url( norvex_ba( $a, 'btn2url' ), 'services' ) ); ?>"><?php echo esc_html( $a['btn2'] ); ?></a>
				</div>
				<div class="norvex-hero__stats">
					<div class="norvex-hero__stat"><?php norvex_stat_number( $a['s1n'] ); ?><span><?php echo esc_html( $a['s1l'] ); ?></span></div>
					<div class="norvex-hero__stat"><?php norvex_stat_number( $a['s2n'] ); ?><span><?php echo esc_html( $a['s2l'] ); ?></span></div>
					<div class="norvex-hero__stat"><?php norvex_stat_number( $a['s3n'] ); ?><span><?php echo esc_html( $a['s3l'] ); ?></span></div>
				</div>
			</div>
			<div class="norvex-hero__art">
				<img src="<?php echo $a['image'] ? esc_url( $a['image'] ) : norvex_img( 'hero.svg' ); ?>" alt="<?php esc_attr_e( 'Stacked books and manuscript illustration', 'norvex' ); ?>" width="560" height="520" />
				<div class="norvex-hero__badge">
					<span class="norvex-stars"><?php echo esc_html( str_repeat( '★', max( 1, min( 5, (int) norvex_ba( $a, 'stars', 5 ) ) ) ) ); ?></span>
					<span><strong><?php echo esc_html( $a['badge'] ); ?></strong><?php echo esc_html( $a['badgesub'] ); ?></span>
				</div>
			</div>
		</div>
	</section>
	<?php
	return ob_get_clean();
}

function norvex_render_block_logos( $a ) {
	$a = wp_parse_args( $a, norvex_block_defaults( 'logos' ) );
	ob_start();
	?>
	<div class="norvex-logos">
		<div class="norvex-wrap">
			<p><?php echo esc_html( $a['label'] ); ?></p>
			<ul>
				<?php
				$logos = array_filter( array_map( 'trim', explode( ',', $a['items'] ) ) );
				foreach ( $logos as $logo ) {
					echo '<li>' . esc_html( $logo ) . '</li>';
				}
				?>
			</ul>
		</div>
	</div>
	<?php
	return ob_get_clean();
}

/**
 * Render one service card (classic icon style, or numbered with a price footer).
 *
 * @param string $title    Service title.
 * @param string $excerpt  Short description.
 * @param string $icon     Icon key / SVG (classic style only).
 * @param string $url      Card link.
 * @param int    $i        1-based index (numbered style).
 * @param string $price    "From …" price (numbered style; may be empty).
 * @param bool   $numbered Whether to use the numbered style.
 */
function norvex_service_card_html( $title, $excerpt, $icon, $url, $i, $price, $numbered ) {
	if ( $numbered ) {
		$price = trim( preg_replace( '/^from\s+/i', '', (string) $price ) );
		?>
		<article class="norvex-card norvex-lift norvex-card--numbered">
			<span class="norvex-card__num"><?php echo esc_html( sprintf( '%02d', $i ) ); ?> ·</span>
			<h3><?php echo esc_html( $title ); ?></h3>
			<p><?php echo esc_html( $excerpt ); ?></p>
			<div class="norvex-card__foot">
				<span class="norvex-card__note"><?php echo '' !== $price ? esc_html( sprintf( __( 'From %s', 'norvex' ), $price ) ) : ''; ?></span>
				<a class="norvex-card__link" href="<?php echo esc_url( $url ); ?>"><?php esc_html_e( 'Learn more', 'norvex' ); ?></a>
			</div>
		</article>
		<?php
		return;
	}
	?>
	<article class="norvex-card norvex-lift">
		<?php norvex_card_icon_html( $icon ); ?>
		<h3><?php echo esc_html( $title ); ?></h3>
		<p><?php echo esc_html( $excerpt ); ?></p>
		<a class="norvex-card__link" href="<?php echo esc_url( $url ); ?>"><?php esc_html_e( 'Learn more', 'norvex' ); ?></a>
	</article>
	<?php
}

function norvex_render_block_services( $a ) {
	// The Services grid is a Grid-cards block with a services seed — render it
	// through the same renderer so the two stay identical.
	$a = wp_parse_args( $a, norvex_block_defaults( 'services' ) );
	return norvex_render_block_cards( $a );
}

function norvex_render_block_process( $a ) {
	$a = wp_parse_args( $a, norvex_block_defaults( 'process' ) );
	ob_start();
	?>
	<section class="norvex-section norvex-section--ink norvex-process">
		<div class="norvex-wrap norvex-process__grid">
			<div class="norvex-process__intro">
				<span class="norvex-eyebrow" style="color:var(--norvex-gold);"><?php echo esc_html( $a['eyebrow'] ); ?></span>
				<h2><?php echo esc_html( $a['title'] ); ?></h2>
				<?php if ( '' !== trim( (string) $a['lead'] ) ) : ?>
					<p class="norvex-process__lead"><?php echo esc_html( $a['lead'] ); ?></p>
				<?php endif; ?>
				<?php if ( '' !== trim( (string) $a['btn'] ) ) : ?>
					<a class="norvex-btn norvex-btn--primary" href="<?php echo esc_url( norvex_btn_url( norvex_ba( $a, 'btnurl' ), 'contact' ) ); ?>"><?php echo esc_html( $a['btn'] ); ?> <?php norvex_icon( 'arrow' ); ?></a>
				<?php endif; ?>
			</div>
			<ol class="norvex-process__steps">
				<?php
				$steps = json_decode( (string) norvex_ba( $a, 'steps', '' ), true );
				$list  = array();
				if ( is_array( $steps ) ) {
					foreach ( $steps as $st ) {
						if ( is_array( $st ) && '' !== trim( (string) ( isset( $st['title'] ) ? $st['title'] : '' ) . (string) ( isset( $st['text'] ) ? $st['text'] : '' ) ) ) {
							$list[] = $st;
						}
					}
				}
				if ( empty( $list ) ) {
					$list = json_decode( norvex_default_process_steps_json(), true );
				}
				$n = 0;
				foreach ( $list as $st ) :
					$n++;
					?>
					<li class="norvex-pstep">
						<span class="norvex-pstep__num"><?php echo esc_html( sprintf( '%02d', $n ) ); ?></span>
						<div class="norvex-pstep__body">
							<h4><?php echo esc_html( isset( $st['title'] ) ? $st['title'] : '' ); ?></h4>
							<p><?php echo esc_html( isset( $st['text'] ) ? $st['text'] : '' ); ?></p>
						</div>
					</li>
					<?php
				endforeach;
				?>
			</ol>
		</div>
	</section>
	<?php
	return ob_get_clean();
}

function norvex_render_block_consult( $a ) {
	$a = wp_parse_args( $a, norvex_block_defaults( 'consult' ) );
	ob_start();
	?>
	<section class="norvex-section norvex-section--tight">
		<div class="norvex-wrap">
			<div class="norvex-consult">
				<div class="norvex-consult__text">
					<span class="norvex-eyebrow" style="color:var(--norvex-gold);"><?php echo esc_html( $a['eyebrow'] ); ?></span>
					<h2><?php echo esc_html( $a['title'] ); ?></h2>
					<p><?php echo esc_html( $a['text'] ); ?></p>
					<p class="norvex-consult__hours"><?php norvex_icon( 'clock' ); ?> <?php echo esc_html( norvex_option( 'norvex_hours', 'Mon–Fri · 9:00 AM – 6:00 PM' ) ); ?></p>
				</div>
				<div class="norvex-consult__actions">
					<a class="norvex-btn norvex-btn--primary" href="<?php echo esc_url( norvex_btn_url( norvex_ba( $a, 'btnurl' ), 'contact' ) ); ?>"><?php norvex_icon( 'calendar' ); ?> <?php echo esc_html( norvex_ba( $a, 'btn', __( 'Book a free call', 'norvex' ) ) ); ?></a>
					<a class="norvex-btn norvex-btn--light" href="tel:<?php echo esc_attr( norvex_option( 'norvex_phone', '' ) ); ?>"><?php norvex_icon( 'phone' ); ?> <?php echo esc_html( norvex_option( 'norvex_phone', '+1 (732) 454-6871' ) ); ?></a>
				</div>
			</div>
		</div>
	</section>
	<?php
	return ob_get_clean();
}

function norvex_render_block_featured_books( $a ) {
	$a = wp_parse_args( $a, norvex_block_defaults( 'featured-books' ) );
	ob_start();
	?>
	<section class="norvex-section">
		<div class="norvex-wrap">
			<div class="norvex-section-head norvex-center">
				<span class="norvex-eyebrow"><?php echo esc_html( $a['eyebrow'] ); ?></span>
				<h2><?php echo esc_html( $a['title'] ); ?></h2>
			</div>
			<div class="norvex-books<?php echo norvex_grid_is_carousel( $a ) ? ' norvex-carousel__track' : ''; ?>"<?php echo norvex_grid_is_carousel( $a ) ? ' data-norvex-carousel="1"' : ''; ?>>
				<?php
				// Book cards are typed on the block.
				$items = json_decode( (string) norvex_ba( $a, 'custom', '' ), true );
				$list  = array();
				if ( is_array( $items ) ) {
					foreach ( $items as $b ) {
						if ( is_array( $b ) && '' !== trim( (string) ( isset( $b['title'] ) ? $b['title'] : '' ) . (string) ( isset( $b['cover'] ) ? $b['cover'] : '' ) ) ) {
							$list[] = $b;
						}
					}
				}
				if ( empty( $list ) ) {
					for ( $fi = 1; $fi <= 4; $fi++ ) {
						$list[] = array( 'cover' => norvex_img( 'cover-' . $fi . '.svg' ), 'title' => __( 'Recent project', 'norvex' ), 'author' => __( 'Client author', 'norvex' ), 'url' => '', 'tag' => '' );
					}
				}
				foreach ( $list as $b ) :
					$cover  = isset( $b['cover'] ) && '' !== $b['cover'] ? $b['cover'] : norvex_img( 'cover-1.svg' );
					$b_url  = isset( $b['url'] ) ? $b['url'] : '';
					$b_tag  = isset( $b['tag'] ) ? $b['tag'] : '';
					$b_auth = isset( $b['author'] ) ? $b['author'] : '';
					?>
					<article class="norvex-book norvex-lift">
						<?php if ( '' !== $b_url ) : ?><a href="<?php echo esc_url( $b_url ); ?>" class="norvex-book__cover"><?php else : ?><div class="norvex-book__cover"><?php endif; ?>
							<?php if ( '' !== trim( (string) $b_tag ) ) : ?><span class="norvex-book__tag"><?php echo esc_html( $b_tag ); ?></span><?php endif; ?>
							<img src="<?php echo esc_url( $cover ); ?>" alt="<?php echo esc_attr( isset( $b['title'] ) ? $b['title'] : '' ); ?>" loading="lazy" />
						<?php echo '' !== $b_url ? '</a>' : '</div>'; ?>
						<h3><?php echo esc_html( isset( $b['title'] ) ? $b['title'] : '' ); ?></h3>
						<?php if ( '' !== trim( (string) $b_auth ) ) : ?><p class="norvex-book__author"><?php echo esc_html( $b_auth ); ?></p><?php endif; ?>
					</article>
					<?php
				endforeach;
				?>
			</div>
			<div class="norvex-center" style="margin-top:44px;">
				<a class="norvex-btn norvex-btn--ghost" href="<?php echo esc_url( get_permalink( get_page_by_path( 'portfolio' ) ) ); ?>"><?php esc_html_e( 'See our full portfolio', 'norvex' ); ?> <?php norvex_icon( 'arrow' ); ?></a>
			</div>
		</div>
	</section>
	<?php
	return ob_get_clean();
}

/**
 * Portfolio grid — pulls live projects from the Portfolio (`book`) post type and
 * renders each as a card that links through to its project page. The number of
 * projects shown is set on the block ("How many books to show"). Falls back to
 * sample covers when no projects have been added yet.
 */
function norvex_render_block_portfolio_grid( $a ) {
	$a     = wp_parse_args( $a, norvex_block_defaults( 'portfolio-grid' ) );
	$count = max( 1, (int) $a['count'] );
	ob_start();
	?>
	<section class="norvex-section">
		<div class="norvex-wrap">
			<div class="norvex-books<?php echo norvex_grid_is_carousel( $a ) ? ' norvex-carousel__track' : ''; ?>"<?php echo norvex_grid_is_carousel( $a ) ? ' data-norvex-carousel="1"' : ''; ?>>
				<?php
				$books = new WP_Query(
					array(
						'post_type'      => 'book',
						'posts_per_page' => $count,
						'orderby'        => 'menu_order',
						'order'          => 'ASC',
					)
				);
				if ( $books->have_posts() ) :
					while ( $books->have_posts() ) :
						$books->the_post();
						get_template_part( 'template-parts/book', 'card' );
					endwhile;
					wp_reset_postdata();
				else :
					for ( $norvex_i = 1; $norvex_i <= 6; $norvex_i++ ) {
						echo '<article class="norvex-book norvex-lift"><div class="norvex-book__cover"><img src="' . norvex_img( 'cover-' . $norvex_i . '.svg' ) . '" alt="" loading="lazy" /></div><h3>' . esc_html__( 'Sample Title', 'norvex' ) . '</h3><p class="norvex-book__author">' . esc_html__( 'Author Name', 'norvex' ) . '</p></article>';
					}
				endif;
				?>
			</div>
		</div>
	</section>
	<?php
	return ob_get_clean();
}

function norvex_render_block_stats( $a ) {
	$a = wp_parse_args( $a, norvex_block_defaults( 'stats' ) );
	ob_start();
	?>
	<section class="norvex-section norvex-section--tight norvex-section--ink">
		<div class="norvex-wrap">
			<div class="norvex-stats-band">
				<?php for ( $i = 1; $i <= 4; $i++ ) : ?>
					<div class="norvex-stat-lg">
						<?php norvex_stat_number( $a[ 'n' . $i ] ); ?>
						<span><?php echo esc_html( $a[ 'l' . $i ] ); ?></span>
					</div>
				<?php endfor; ?>
			</div>
		</div>
	</section>
	<?php
	return ob_get_clean();
}

function norvex_render_block_why_us( $a ) {
	$a = wp_parse_args( $a, norvex_block_defaults( 'why-us' ) );
	ob_start();
	?>
	<section class="norvex-section">
		<div class="norvex-wrap">
			<div class="norvex-whyus__head">
				<div>
					<span class="norvex-eyebrow"><?php echo esc_html( $a['eyebrow'] ); ?></span>
					<h2><?php echo esc_html( $a['title'] ); ?></h2>
				</div>
				<div class="norvex-whyus__intro">
					<p class="norvex-lead"><?php echo esc_html( $a['lead'] ); ?></p>
					<a class="norvex-btn norvex-btn--primary" href="<?php echo esc_url( norvex_btn_url( norvex_ba( $a, 'btnurl' ), 'about' ) ); ?>"><?php echo esc_html( $a['btn'] ); ?></a>
				</div>
			</div>
			<div class="norvex-whyus__grid">
				<?php for ( $n = 1; $n <= 4; $n++ ) : ?>
					<div class="norvex-whyus__item">
						<h4><?php echo esc_html( $a[ 'f' . $n . 't' ] ); ?></h4>
						<p><?php echo esc_html( $a[ 'f' . $n . 'd' ] ); ?></p>
					</div>
				<?php endfor; ?>
			</div>
		</div>
	</section>
	<?php
	return ob_get_clean();
}

/**
 * Feature split — an icon-card grid beside an accented heading + CTA.
 */
function norvex_render_block_feature_split( $a ) {
	$a     = wp_parse_args( $a, norvex_block_defaults( 'feature-split' ) );
	$cards = json_decode( (string) norvex_ba( $a, 'cards', '' ), true );
	if ( ! is_array( $cards ) || empty( $cards ) ) {
		$cards = json_decode( norvex_default_feature_split_json(), true );
	}
	$side = ( 'left' === $a['side'] ) ? 'left' : 'right';
	ob_start();
	?>
	<section class="norvex-section">
		<div class="norvex-wrap norvex-featuresplit norvex-featuresplit--<?php echo esc_attr( $side ); ?>">
			<div class="norvex-featuresplit__grid">
				<?php
				foreach ( $cards as $c ) :
					if ( ! is_array( $c ) ) {
						continue;
					}
					$icon  = isset( $c['icon'] ) ? (string) $c['icon'] : '';
					$title = isset( $c['title'] ) ? (string) $c['title'] : '';
					$text  = isset( $c['text'] ) ? (string) $c['text'] : '';
					if ( '' === trim( $title . $text ) ) {
						continue;
					}
					?>
					<div class="norvex-fcard norvex-lift">
						<span class="norvex-fcard__icon"><?php norvex_render_icon( $icon, 'star' ); ?></span>
						<h3><?php echo esc_html( $title ); ?></h3>
						<p><?php echo esc_html( $text ); ?></p>
					</div>
				<?php endforeach; ?>
			</div>
			<div class="norvex-featuresplit__text">
				<?php if ( '' !== trim( (string) $a['eyebrow'] ) ) : ?><span class="norvex-eyebrow"><?php echo esc_html( $a['eyebrow'] ); ?></span><?php endif; ?>
				<?php echo norvex_accent_heading( $a['heading'], $a['accent'] ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- escaped in helper. ?>
				<?php if ( '' !== trim( (string) $a['lead'] ) ) : ?><p class="norvex-lead"><?php echo esc_html( $a['lead'] ); ?></p><?php endif; ?>
				<?php if ( '' !== trim( (string) $a['btn'] ) ) : ?>
					<a class="norvex-btn norvex-btn--primary" href="<?php echo esc_url( norvex_btn_url( norvex_ba( $a, 'btnurl' ), 'contact' ) ); ?>"><?php echo esc_html( $a['btn'] ); ?> <?php norvex_icon( 'arrow' ); ?></a>
				<?php endif; ?>
			</div>
		</div>
	</section>
	<?php
	return ob_get_clean();
}

/**
 * Highlights + note — a numbered highlight list (one may be emphasised) beside
 * an accented heading, body copy and an optional signature.
 */
function norvex_render_block_highlights( $a ) {
	$a     = wp_parse_args( $a, norvex_block_defaults( 'highlights' ) );
	$items = norvex_parse_pair_lines( norvex_ba( $a, 'items', '' ) );
	if ( empty( $items ) ) {
		$items = norvex_parse_pair_lines( norvex_default_highlights_text() );
	}
	$featured = (int) norvex_ba( $a, 'featured', 0 );
	ob_start();
	?>
	<section class="norvex-section">
		<div class="norvex-wrap norvex-splitlist">
			<div class="norvex-splitlist__list">
				<?php
				$n = 0;
				foreach ( $items as $it ) :
					$n++;
					$is_feat = ( $n === $featured );
					?>
					<div class="norvex-hl<?php echo $is_feat ? ' norvex-hl--on' : ''; ?>">
						<span class="norvex-hl__num">
							<?php if ( $is_feat ) : ?>
								<span class="norvex-hl__check"><?php norvex_icon( 'check' ); ?></span>
							<?php else : ?>
								<?php echo esc_html( sprintf( '%02d', $n ) ); ?>
							<?php endif; ?>
						</span>
						<div class="norvex-hl__body">
							<h4><?php echo esc_html( $it['title'] ); ?></h4>
							<?php if ( '' !== trim( (string) $it['text'] ) ) : ?><p><?php echo esc_html( $it['text'] ); ?></p><?php endif; ?>
						</div>
					</div>
				<?php endforeach; ?>
			</div>
			<div class="norvex-splitlist__aside">
				<?php echo norvex_accent_heading( $a['heading'], $a['accent'] ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- escaped in helper. ?>
				<?php if ( '' !== trim( (string) $a['subhead'] ) ) : ?><p class="norvex-splitlist__sub"><?php echo esc_html( $a['subhead'] ); ?></p><?php endif; ?>
				<?php
				foreach ( preg_split( '/\n\s*\n/', (string) $a['body'] ) as $para ) :
					$para = trim( $para );
					if ( '' === $para ) {
						continue;
					}
					?>
					<p><?php echo esc_html( $para ); ?></p>
				<?php endforeach; ?>
				<?php if ( '' !== trim( (string) $a['signame'] . (string) $a['sigrole'] ) ) : ?>
					<div class="norvex-sign">
						<?php if ( '' !== trim( (string) $a['sigphoto'] ) ) : ?>
							<img class="norvex-sign__photo" src="<?php echo esc_url( $a['sigphoto'] ); ?>" alt="" width="52" height="52" />
						<?php else : ?>
							<span class="norvex-sign__photo norvex-sign__photo--ph"><?php norvex_icon( 'users' ); ?></span>
						<?php endif; ?>
						<span class="norvex-sign__meta"><strong><?php echo esc_html( $a['signame'] ); ?></strong><span><?php echo esc_html( $a['sigrole'] ); ?></span></span>
					</div>
				<?php endif; ?>
			</div>
		</div>
	</section>
	<?php
	return ob_get_clean();
}

/**
 * Showcase list — an accented heading with a drop-cap lead + CTA beside a
 * numbered feature list.
 */
function norvex_render_block_showcase( $a ) {
	$a     = wp_parse_args( $a, norvex_block_defaults( 'showcase' ) );
	$items = norvex_parse_pair_lines( norvex_ba( $a, 'items', '' ) );
	if ( empty( $items ) ) {
		$items = norvex_parse_pair_lines( norvex_default_showcase_text() );
	}
	$body = trim( (string) $a['body'] );
	ob_start();
	?>
	<section class="norvex-section">
		<div class="norvex-wrap norvex-showcase">
			<div class="norvex-showcase__intro">
				<?php if ( '' !== trim( (string) $a['eyebrow'] ) ) : ?><span class="norvex-eyebrow"><?php echo esc_html( $a['eyebrow'] ); ?></span><?php endif; ?>
				<?php echo norvex_accent_heading( $a['heading'], $a['accent'] ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- escaped in helper. ?>
				<span class="norvex-showcase__rule" aria-hidden="true"></span>
				<?php if ( '' !== $body ) : ?><p class="norvex-showcase__lead norvex-dropcap"><?php echo esc_html( $body ); ?></p><?php endif; ?>
				<?php if ( '' !== trim( (string) $a['btn'] ) ) : ?>
					<a class="norvex-btn norvex-btn--primary" href="<?php echo esc_url( norvex_btn_url( norvex_ba( $a, 'btnurl' ), 'services' ) ); ?>"><?php echo esc_html( $a['btn'] ); ?> <?php norvex_icon( 'arrow' ); ?></a>
				<?php endif; ?>
			</div>
			<ol class="norvex-showcase__list">
				<?php
				$n = 0;
				foreach ( $items as $it ) :
					$n++;
					?>
					<li class="norvex-showitem">
						<span class="norvex-showitem__num"><?php echo esc_html( sprintf( '%02d', $n ) ); ?></span>
						<div class="norvex-showitem__body">
							<h4><?php echo esc_html( $it['title'] ); ?></h4>
							<?php if ( '' !== trim( (string) $it['text'] ) ) : ?><p><?php echo esc_html( $it['text'] ); ?></p><?php endif; ?>
						</div>
					</li>
				<?php endforeach; ?>
			</ol>
		</div>
	</section>
	<?php
	return ob_get_clean();
}

/**
 * Rates & story — a centred section head over a two-column split: story prose
 * with a pull-quote callout beside an open "services & rates" card.
 */
function norvex_render_block_broadsheet( $a ) {
	$a     = wp_parse_args( $a, norvex_block_defaults( 'broadsheet' ) );
	$rates = norvex_split_rows( norvex_ba( $a, 'rates', '' ) );
	ob_start();
	?>
	<section class="norvex-section">
		<div class="norvex-wrap">
			<?php if ( '' !== trim( (string) $a['eyebrow'] . (string) $a['heading'] . (string) $a['lead'] ) ) : ?>
				<div class="norvex-section-head norvex-center">
					<?php if ( '' !== trim( (string) $a['eyebrow'] ) ) : ?><span class="norvex-eyebrow"><?php echo esc_html( $a['eyebrow'] ); ?></span><?php endif; ?>
					<?php echo norvex_accent_heading( $a['heading'], $a['accent'] ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- escaped in helper. ?>
					<?php if ( '' !== trim( (string) $a['lead'] ) ) : ?><p class="norvex-lead"><?php echo esc_html( $a['lead'] ); ?></p><?php endif; ?>
				</div>
			<?php endif; ?>
			<div class="norvex-ratesplit">
				<div class="norvex-ratesplit__prose">
					<?php
					foreach ( preg_split( '/\n\s*\n/', (string) $a['body'] ) as $para ) :
						$para = trim( $para );
						if ( '' === $para ) {
							continue;
						}
						?>
						<p><?php echo esc_html( $para ); ?></p>
					<?php endforeach; ?>
					<?php if ( '' !== trim( (string) $a['quote'] ) ) : ?>
						<blockquote class="norvex-ratesplit__quote">
							<p><?php echo esc_html( $a['quote'] ); ?></p>
							<?php if ( '' !== trim( (string) $a['quoteby'] ) ) : ?><cite><?php echo esc_html( $a['quoteby'] ); ?></cite><?php endif; ?>
						</blockquote>
					<?php endif; ?>
				</div>
				<aside class="norvex-ratecard norvex-lift">
					<h3><?php echo esc_html( $a['ratestitle'] ); ?></h3>
					<?php if ( '' !== trim( (string) $a['ratessub'] ) ) : ?><p class="norvex-ratecard__sub"><?php echo esc_html( $a['ratessub'] ); ?></p><?php endif; ?>
					<ul>
						<?php foreach ( $rates as $r ) : if ( '' === trim( (string) ( isset( $r[0] ) ? $r[0] : '' ) ) ) { continue; } ?>
							<li><span class="norvex-ratecard__name"><?php echo esc_html( $r[0] ); ?></span><span class="norvex-ratecard__dots" aria-hidden="true"></span><span class="norvex-ratecard__price"><?php echo esc_html( isset( $r[1] ) ? $r[1] : '' ); ?></span></li>
						<?php endforeach; ?>
					</ul>
				</aside>
			</div>
		</div>
	</section>
	<?php
	return ob_get_clean();
}

/**
 * Launch checklist — a centred heading with an optional struck-through word,
 * over a clean card listing the priced steps from idea to launch.
 */
function norvex_render_block_marginalia( $a ) {
	$a     = wp_parse_args( $a, norvex_block_defaults( 'marginalia' ) );
	$items = norvex_split_rows( norvex_ba( $a, 'items', '' ) );
	ob_start();
	?>
	<section class="norvex-section norvex-section--sand">
		<div class="norvex-wrap">
			<div class="norvex-section-head norvex-center">
				<?php if ( '' !== trim( (string) $a['eyebrow'] ) ) : ?><span class="norvex-eyebrow"><?php echo esc_html( $a['eyebrow'] ); ?></span><?php endif; ?>
				<h2 class="norvex-accent-heading"><?php echo esc_html( $a['headbefore'] ); ?> <?php if ( '' !== trim( (string) $a['strike'] ) ) : ?><span class="norvex-strike"><?php echo esc_html( $a['strike'] ); ?></span> <?php endif; ?><em class="norvex-accent-word"><?php echo esc_html( $a['fix'] ); ?></em></h2>
				<?php if ( '' !== trim( (string) $a['lead'] ) ) : ?><p class="norvex-lead"><?php echo esc_html( $a['lead'] ); ?></p><?php endif; ?>
			</div>
			<div class="norvex-checkcard norvex-lift">
				<?php if ( '' !== trim( (string) $a['checkh'] ) ) : ?><div class="norvex-checkcard__h"><?php echo esc_html( $a['checkh'] ); ?></div><?php endif; ?>
				<ul>
					<?php
					foreach ( $items as $it ) :
						$label = isset( $it[0] ) ? $it[0] : '';
						if ( '' === trim( $label ) ) {
							continue;
						}
						$price = isset( $it[1] ) ? $it[1] : '';
						$done  = ( isset( $it[2] ) && 'done' === $it[2] );
						?>
						<li class="<?php echo $done ? 'is-done' : ''; ?>">
							<span class="norvex-checkcard__box<?php echo $done ? ' is-done' : ''; ?>"><?php echo $done ? '&#10003;' : ''; ?></span>
							<span class="norvex-checkcard__label"><?php echo esc_html( $label ); ?></span>
							<?php if ( '' !== trim( (string) $price ) ) : ?><span class="norvex-checkcard__pr"><?php echo esc_html( $price ); ?></span><?php endif; ?>
						</li>
					<?php endforeach; ?>
				</ul>
				<?php if ( '' !== trim( (string) $a['btn'] ) ) : ?>
					<div class="norvex-checkcard__cta"><a class="norvex-btn norvex-btn--primary" href="<?php echo esc_url( norvex_btn_url( norvex_ba( $a, 'btnurl' ), 'contact' ) ); ?>"><?php echo esc_html( $a['btn'] ); ?> <?php norvex_icon( 'arrow' ); ?></a></div>
				<?php endif; ?>
			</div>
		</div>
	</section>
	<?php
	return ob_get_clean();
}

/**
 * Chapters index — a heading with an optional meta note over a bordered grid of
 * numbered content entries.
 */
function norvex_render_block_chapters_index( $a ) {
	$a     = wp_parse_args( $a, norvex_block_defaults( 'chapters-index' ) );
	$items = norvex_split_rows( norvex_ba( $a, 'items', '' ) );
	ob_start();
	?>
	<section class="norvex-section">
		<div class="norvex-wrap">
			<div class="norvex-chapters__head">
				<div>
					<?php if ( '' !== trim( (string) $a['eyebrow'] ) ) : ?><span class="norvex-eyebrow"><?php echo esc_html( $a['eyebrow'] ); ?></span><?php endif; ?>
					<h2><?php echo esc_html( $a['heading'] ); ?></h2>
				</div>
				<?php if ( '' !== trim( (string) $a['meta'] ) ) : ?><span class="norvex-chapters__meta"><?php echo esc_html( $a['meta'] ); ?></span><?php endif; ?>
			</div>
			<div class="norvex-chapters__grid">
				<?php
				$n = 0;
				foreach ( $items as $it ) :
					$title = isset( $it[0] ) ? $it[0] : '';
					if ( '' === trim( $title ) ) {
						continue;
					}
					$n++;
					?>
					<div class="norvex-chapters__item">
						<div class="norvex-chapters__top"><span class="norvex-chapters__num"><?php echo esc_html( sprintf( '%02d', $n ) ); ?></span><h3><?php echo esc_html( $title ); ?></h3></div>
						<?php if ( '' !== trim( (string) ( isset( $it[1] ) ? $it[1] : '' ) ) ) : ?><p><?php echo esc_html( $it[1] ); ?></p><?php endif; ?>
					</div>
				<?php endforeach; ?>
			</div>
		</div>
	</section>
	<?php
	return ob_get_clean();
}

/**
 * Data columns — a section head over N source columns, each with a big figure,
 * a sub-heading, description and an optional link, split by vertical rules.
 */
function norvex_render_block_data_columns( $a ) {
	$a    = wp_parse_args( $a, norvex_block_defaults( 'data-columns' ) );
	$cols = norvex_split_rows( norvex_ba( $a, 'cols', '' ) );
	ob_start();
	?>
	<section class="norvex-section">
		<div class="norvex-wrap">
			<div class="norvex-section-head norvex-section-head--left">
				<?php if ( '' !== trim( (string) $a['eyebrow'] ) ) : ?><span class="norvex-eyebrow"><?php echo esc_html( $a['eyebrow'] ); ?></span><?php endif; ?>
				<?php if ( '' !== trim( (string) $a['heading'] ) ) : ?><h2><?php echo esc_html( $a['heading'] ); ?></h2><?php endif; ?>
				<?php if ( '' !== trim( (string) $a['lead'] ) ) : ?><p class="norvex-lead"><?php echo esc_html( $a['lead'] ); ?></p><?php endif; ?>
			</div>
			<div class="norvex-datacols">
				<?php
				foreach ( $cols as $c ) :
					$fig = isset( $c[1] ) ? $c[1] : '';
					if ( '' === trim( (string) ( isset( $c[0] ) ? $c[0] : '' ) . $fig ) ) {
						continue;
					}
					$linklabel = isset( $c[4] ) ? $c[4] : '';
					$linkurl   = isset( $c[5] ) ? $c[5] : '';
					?>
					<div class="norvex-datacol">
						<?php if ( '' !== trim( (string) ( isset( $c[0] ) ? $c[0] : '' ) ) ) : ?><span class="norvex-datacol__src"><?php echo esc_html( $c[0] ); ?></span><?php endif; ?>
						<div class="norvex-datacol__fig"><?php echo esc_html( $fig ); ?></div>
						<?php if ( '' !== trim( (string) ( isset( $c[2] ) ? $c[2] : '' ) ) ) : ?><h4><?php echo esc_html( $c[2] ); ?></h4><?php endif; ?>
						<?php if ( '' !== trim( (string) ( isset( $c[3] ) ? $c[3] : '' ) ) ) : ?><p><?php echo esc_html( $c[3] ); ?></p><?php endif; ?>
						<?php if ( '' !== trim( (string) $linklabel ) ) : ?><a class="norvex-readmore" href="<?php echo esc_url( '' !== trim( (string) $linkurl ) ? $linkurl : '#' ); ?>"><?php echo esc_html( $linklabel ); ?> <?php norvex_icon( 'arrow' ); ?></a><?php endif; ?>
					</div>
				<?php endforeach; ?>
			</div>
		</div>
	</section>
	<?php
	return ob_get_clean();
}

/**
 * Services list — a section head over a numbered list of services, each with an
 * optional badge, a description, a price and a "learn more" link.
 */
function norvex_render_block_services_list( $a ) {
	$a     = wp_parse_args( $a, norvex_block_defaults( 'services-list' ) );
	$items = norvex_split_rows( norvex_ba( $a, 'items', '' ) );
	$learn = norvex_ba( $a, 'learn', '' );
	ob_start();
	?>
	<section class="norvex-section">
		<div class="norvex-wrap">
			<div class="norvex-section-head norvex-section-head--left">
				<?php if ( '' !== trim( (string) $a['eyebrow'] ) ) : ?><span class="norvex-eyebrow"><?php echo esc_html( $a['eyebrow'] ); ?></span><?php endif; ?>
				<?php echo norvex_accent_heading( $a['heading'], $a['accent'] ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- escaped in helper. ?>
				<?php if ( '' !== trim( (string) $a['lead'] ) ) : ?><p class="norvex-lead"><?php echo esc_html( $a['lead'] ); ?></p><?php endif; ?>
			</div>
			<ul class="norvex-servlist">
				<?php
				$n = 0;
				foreach ( $items as $it ) :
					$title = isset( $it[0] ) ? $it[0] : '';
					if ( '' === trim( $title ) ) {
						continue;
					}
					$n++;
					$badge = isset( $it[1] ) ? $it[1] : '';
					$desc  = isset( $it[2] ) ? $it[2] : '';
					$price = isset( $it[3] ) ? $it[3] : '';
					$url   = isset( $it[4] ) ? $it[4] : '';
					?>
					<li class="norvex-servlist__row">
						<span class="norvex-servlist__num"><?php echo esc_html( sprintf( '%02d', $n ) ); ?></span>
						<div class="norvex-servlist__main">
							<h3><?php echo esc_html( $title ); ?><?php if ( '' !== trim( (string) $badge ) ) : ?> <span class="norvex-servlist__badge"><?php echo esc_html( $badge ); ?></span><?php endif; ?></h3>
							<?php if ( '' !== trim( (string) $desc ) ) : ?><p><?php echo esc_html( $desc ); ?></p><?php endif; ?>
						</div>
						<div class="norvex-servlist__side">
							<?php if ( '' !== trim( (string) $price ) ) : ?><span class="norvex-servlist__price"><?php echo esc_html( $price ); ?></span><?php endif; ?>
							<?php if ( '' !== trim( (string) $learn ) ) : ?><a class="norvex-servlist__learn" href="<?php echo esc_url( norvex_btn_url( $url, 'services' ) ); ?>"><?php echo esc_html( $learn ); ?> <?php norvex_icon( 'arrow' ); ?></a><?php endif; ?>
						</div>
					</li>
				<?php endforeach; ?>
			</ul>
		</div>
	</section>
	<?php
	return ob_get_clean();
}

/**
 * Steps with media — a centred/left section head over a numbered list of steps,
 * each with a title, description and an optional image.
 */
function norvex_render_block_steps_media( $a ) {
	$a     = wp_parse_args( $a, norvex_block_defaults( 'steps-media' ) );
	$steps = json_decode( (string) norvex_ba( $a, 'steps', '' ), true );
	if ( ! is_array( $steps ) || empty( $steps ) ) {
		$steps = json_decode( norvex_default_steps_json(), true );
	}
	$center = ( 'left' === $a['align'] ) ? '' : ' norvex-center';
	ob_start();
	?>
	<section class="norvex-section">
		<div class="norvex-wrap">
			<?php if ( '' !== trim( (string) $a['eyebrow'] . (string) $a['heading'] . (string) $a['lead'] ) ) : ?>
				<div class="norvex-section-head<?php echo esc_attr( $center ); ?>">
					<?php if ( '' !== trim( (string) $a['eyebrow'] ) ) : ?><span class="norvex-eyebrow"><?php echo esc_html( $a['eyebrow'] ); ?></span><?php endif; ?>
					<?php if ( '' !== trim( (string) $a['heading'] ) ) : ?><h2><?php echo esc_html( $a['heading'] ); ?></h2><?php endif; ?>
					<?php if ( '' !== trim( (string) $a['lead'] ) ) : ?><p class="norvex-lead"><?php echo esc_html( $a['lead'] ); ?></p><?php endif; ?>
				</div>
			<?php endif; ?>
			<div class="norvex-steps">
				<?php
				$n = 0;
				foreach ( $steps as $s ) :
					if ( ! is_array( $s ) ) {
						continue;
					}
					$title = isset( $s['title'] ) ? (string) $s['title'] : '';
					$text  = isset( $s['text'] ) ? (string) $s['text'] : '';
					$img   = isset( $s['image'] ) ? (string) $s['image'] : '';
					if ( '' === trim( $title . $text . $img ) ) {
						continue;
					}
					$n++;
					?>
					<div class="norvex-step<?php echo '' !== trim( $img ) ? '' : ' norvex-step--noimg'; ?>">
						<span class="norvex-step__num"><?php echo esc_html( $n ); ?></span>
						<div class="norvex-step__body">
							<h3><?php echo esc_html( $title ); ?></h3>
							<?php if ( '' !== trim( $text ) ) : ?><p><?php echo esc_html( $text ); ?></p><?php endif; ?>
						</div>
						<?php if ( '' !== trim( $img ) ) : ?>
							<div class="norvex-step__media"><img src="<?php echo esc_url( $img ); ?>" alt="" loading="lazy" /></div>
						<?php endif; ?>
					</div>
				<?php endforeach; ?>
			</div>
		</div>
	</section>
	<?php
	return ob_get_clean();
}

/**
 * Horizontal timeline — a centred head over a row of numbered milestones joined
 * by a connecting line, with an optional scale (Day 1 … Day 90+) beneath.
 */
function norvex_render_block_timeline_h( $a ) {
	$a     = wp_parse_args( $a, norvex_block_defaults( 'timeline-h' ) );
	$items = norvex_split_rows( norvex_ba( $a, 'items', '' ) );
	$scale = array_values( array_filter( array_map( 'trim', explode( '|', (string) norvex_ba( $a, 'scale', '' ) ) ) ) );
	ob_start();
	?>
	<section class="norvex-section">
		<div class="norvex-wrap">
			<div class="norvex-section-head norvex-center">
				<?php if ( '' !== trim( (string) $a['eyebrow'] ) ) : ?><span class="norvex-eyebrow"><?php echo esc_html( $a['eyebrow'] ); ?></span><?php endif; ?>
				<?php echo norvex_accent_heading( $a['heading'], $a['accent'] ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- escaped in helper. ?>
				<?php if ( '' !== trim( (string) $a['lead'] ) ) : ?><p class="norvex-lead"><?php echo esc_html( $a['lead'] ); ?></p><?php endif; ?>
			</div>
			<div class="norvex-hztl">
				<div class="norvex-hztl__track">
					<?php
					$n = 0;
					foreach ( $items as $it ) :
						$phase = isset( $it[0] ) ? $it[0] : '';
						$title = isset( $it[1] ) ? $it[1] : '';
						if ( '' === trim( $phase . $title . ( isset( $it[2] ) ? $it[2] : '' ) ) ) {
							continue;
						}
						$n++;
						?>
						<div class="norvex-hztl__item">
							<span class="norvex-hztl__dot"><?php echo esc_html( sprintf( '%02d', $n ) ); ?></span>
							<div class="norvex-hztl__body">
								<?php if ( '' !== trim( (string) $phase ) ) : ?><span class="norvex-hztl__phase"><?php echo esc_html( $phase ); ?></span><?php endif; ?>
								<h4><?php echo esc_html( $title ); ?></h4>
								<?php if ( '' !== trim( (string) ( isset( $it[2] ) ? $it[2] : '' ) ) ) : ?><p><?php echo esc_html( $it[2] ); ?></p><?php endif; ?>
							</div>
						</div>
					<?php endforeach; ?>
				</div>
				<?php if ( ! empty( $scale ) ) : ?>
					<div class="norvex-hztl__scale">
						<?php foreach ( $scale as $mk ) : ?><span><?php echo esc_html( $mk ); ?></span><?php endforeach; ?>
					</div>
				<?php endif; ?>
			</div>
		</div>
	</section>
	<?php
	return ob_get_clean();
}

/**
 * Zig-zag steps — a centred head over numbered steps that alternate left and
 * right down the page, each with a small label, a title and a description.
 */
function norvex_render_block_zigzag( $a ) {
	$a     = wp_parse_args( $a, norvex_block_defaults( 'zigzag' ) );
	$items = norvex_split_rows( norvex_ba( $a, 'items', '' ) );
	ob_start();
	?>
	<section class="norvex-section">
		<div class="norvex-wrap">
			<div class="norvex-section-head norvex-center">
				<?php if ( '' !== trim( (string) $a['eyebrow'] ) ) : ?><span class="norvex-eyebrow"><?php echo esc_html( $a['eyebrow'] ); ?></span><?php endif; ?>
				<?php echo norvex_accent_heading( $a['heading'], $a['accent'] ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- escaped in helper. ?>
				<?php if ( '' !== trim( (string) $a['lead'] ) ) : ?><p class="norvex-lead"><?php echo esc_html( $a['lead'] ); ?></p><?php endif; ?>
			</div>
			<div class="norvex-zz">
				<?php
				$n = 0;
				foreach ( $items as $it ) :
					$title = isset( $it[1] ) ? $it[1] : '';
					if ( '' === trim( ( isset( $it[0] ) ? $it[0] : '' ) . $title ) ) {
						continue;
					}
					$n++;
					?>
					<div class="norvex-zz__step">
						<span class="norvex-zz__no"><?php echo esc_html( sprintf( '%02d', $n ) ); ?></span>
						<div class="norvex-zz__body">
							<?php if ( '' !== trim( (string) ( isset( $it[0] ) ? $it[0] : '' ) ) ) : ?><span class="norvex-zz__label"><?php echo esc_html( $it[0] ); ?></span><?php endif; ?>
							<h4><?php echo esc_html( $title ); ?></h4>
							<?php if ( '' !== trim( (string) ( isset( $it[2] ) ? $it[2] : '' ) ) ) : ?><p><?php echo esc_html( $it[2] ); ?></p><?php endif; ?>
						</div>
					</div>
				<?php endforeach; ?>
			</div>
		</div>
	</section>
	<?php
	return ob_get_clean();
}

function norvex_render_block_testimonials( $a ) {
	$a = wp_parse_args( $a, norvex_block_defaults( 'testimonials' ) );
	ob_start();
	?>
	<section class="norvex-section norvex-section--sand">
		<div class="norvex-wrap">
			<div class="norvex-section-head norvex-center">
				<span class="norvex-eyebrow"><?php echo esc_html( $a['eyebrow'] ); ?></span>
				<h2><?php echo esc_html( $a['title'] ); ?></h2>
			</div>
			<div class="norvex-quotes<?php echo norvex_grid_is_carousel( $a ) ? ' norvex-carousel__track' : ''; ?>"<?php echo norvex_grid_is_carousel( $a ) ? ' data-norvex-carousel="1"' : ''; ?>>
				<?php
				// Quotes are typed on the block itself: [ name, quote, role, rating, photo-url ].
				$quotes = array();
				$items  = json_decode( (string) norvex_ba( $a, 'custom', '' ), true );
				if ( is_array( $items ) ) {
					foreach ( $items as $t ) {
						if ( ! is_array( $t ) || '' === trim( (string) ( isset( $t['quote'] ) ? $t['quote'] : '' ) ) ) {
							continue;
						}
						$photo    = ( isset( $t['photo'] ) && '' !== $t['photo'] ) ? $t['photo'] : norvex_img( 'avatar-1.svg' );
						$quotes[] = array(
							isset( $t['name'] ) ? $t['name'] : '',
							isset( $t['quote'] ) ? $t['quote'] : '',
							isset( $t['role'] ) ? $t['role'] : '',
							(int) ( isset( $t['rating'] ) ? $t['rating'] : 5 ),
							$photo,
						);
					}
				}
				// A brand-new / emptied block still shows sample quotes.
				if ( empty( $quotes ) ) {
					foreach ( norvex_default_testimonials() as $t ) {
						$quotes[] = array( $t[0], $t[1], $t[2], (int) $t[3], norvex_img( $t[4] ) );
					}
				}

				foreach ( $quotes as $t ) :
					$rating = max( 1, min( 5, (int) $t[3] ) );
					?>
					<figure class="norvex-quote norvex-lift">
						<div class="norvex-quote__stars"><?php echo esc_html( str_repeat( '★', $rating ) ); ?></div>
						<blockquote style="border:0;background:none;padding:0;margin:0;font-size:1.12rem;"><p style="margin:0;">&ldquo;<?php echo esc_html( $t[1] ); ?>&rdquo;</p></blockquote>
						<figcaption class="norvex-quote__by">
							<img src="<?php echo esc_url( $t[4] ); ?>" alt="<?php echo esc_attr( $t[0] ); ?>" />
							<span><strong><?php echo esc_html( $t[0] ); ?></strong><span><?php echo esc_html( $t[2] ); ?></span></span>
						</figcaption>
					</figure>
					<?php
				endforeach;
				?>
			</div>
		</div>
	</section>
	<?php
	return ob_get_clean();
}

function norvex_render_block_journal( $a ) {
	$a     = wp_parse_args( $a, norvex_block_defaults( 'journal' ) );
	$count = max( 1, (int) $a['count'] );
	ob_start();
	?>
	<section class="norvex-section">
		<div class="norvex-wrap">
			<div class="norvex-section-head norvex-center">
				<span class="norvex-eyebrow"><?php echo esc_html( $a['eyebrow'] ); ?></span>
				<h2><?php echo esc_html( $a['title'] ); ?></h2>
			</div>
			<div class="norvex-cards<?php echo norvex_grid_is_carousel( $a ) ? ' norvex-carousel__track' : ''; ?>"<?php echo norvex_grid_is_carousel( $a ) ? ' data-norvex-carousel="1"' : ''; ?>>
				<?php
				$recent = new WP_Query( array( 'post_type' => 'post', 'posts_per_page' => $count, 'ignore_sticky_posts' => true ) );
				if ( $recent->have_posts() ) :
					while ( $recent->have_posts() ) :
						$recent->the_post();
						?>
						<article class="norvex-article norvex-lift" style="box-shadow:var(--norvex-shadow-sm);">
							<a href="<?php the_permalink(); ?>" class="norvex-article__thumb"><?php norvex_thumbnail(); ?></a>
							<div class="norvex-article__body">
								<div class="norvex-article__meta"><?php norvex_post_meta(); ?></div>
								<h2 style="font-size:1.25rem;"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>
								<p class="norvex-article__excerpt"><?php echo esc_html( wp_trim_words( get_the_excerpt(), 18 ) ); ?></p>
								<a class="norvex-readmore" href="<?php the_permalink(); ?>"><?php esc_html_e( 'Read article', 'norvex' ); ?> <?php norvex_icon( 'arrow' ); ?></a>
							</div>
						</article>
						<?php
					endwhile;
					wp_reset_postdata();
				else :
					esc_html_e( 'Journal posts will appear here once published.', 'norvex' );
				endif;
				?>
			</div>
		</div>
	</section>
	<?php
	return ob_get_clean();
}

function norvex_render_block_faq( $a ) {
	$a = wp_parse_args( $a, norvex_block_defaults( 'faq' ) );
	ob_start();
	?>
	<section class="norvex-section norvex-section--sand">
		<div class="norvex-wrap">
			<div class="norvex-section-head norvex-center">
				<span class="norvex-eyebrow"><?php echo esc_html( $a['eyebrow'] ); ?></span>
				<h2><?php echo esc_html( $a['title'] ); ?></h2>
			</div>
			<?php
			$faqs = array();
			foreach ( array_filter( array_map( 'trim', explode( "\n", $a['items'] ) ) ) as $line ) {
				$parts = array_map( 'trim', explode( '|', $line, 2 ) );
				if ( '' !== $parts[0] ) {
					$faqs[] = array( $parts[0], isset( $parts[1] ) ? $parts[1] : '' );
				}
			}
			norvex_faq_accordion( $faqs );
			?>
			<?php if ( '' !== trim( (string) $a['btn'] ) ) : ?>
				<p class="norvex-center" style="margin-top:26px;">
					<a class="norvex-btn norvex-btn--ghost" href="<?php echo esc_url( norvex_btn_url( norvex_ba( $a, 'btnurl' ), 'contact' ) ); ?>"><?php echo esc_html( $a['btn'] ); ?></a>
				</p>
			<?php endif; ?>
		</div>
	</section>
	<?php
	return ob_get_clean();
}

/**
 * Build the inline border style for one card from its editor fields.
 *
 * @param string $side  none|all|top|right|bottom|left.
 * @param string $color Hex colour (#rgb or #rrggbb); falls back to the accent.
 * @param string $width Width in px.
 * @return string Inline CSS (empty when no border requested).
 */
function norvex_card_border_style( $side, $color, $width ) {
	$side = strtolower( trim( $side ) );
	if ( ! in_array( $side, array( 'all', 'top', 'right', 'bottom', 'left' ), true ) ) {
		return '';
	}
	$w = (int) $width;
	if ( $w < 1 ) {
		$w = 3;
	}
	$col = ( $color && preg_match( '/^#([0-9a-f]{3}|[0-9a-f]{6})$/i', trim( $color ) ) ) ? trim( $color ) : 'var(--norvex-gold)';
	$prop = ( 'all' === $side ) ? 'border' : 'border-' . $side;
	return $prop . ': ' . $w . 'px solid ' . $col . ';';
}

/**
 * Grid cards block — a flexible row of cards, each with an optional image or
 * icon, title, text and link. Column count is configurable.
 *
 * @param array $a Block attributes.
 * @return string
 */
function norvex_render_block_cards( $a ) {
	$a     = wp_parse_args( $a, norvex_block_defaults( 'cards' ) );
	$cards = json_decode( (string) $a['cards'], true );
	if ( ! is_array( $cards ) ) {
		$cards = array();
	}
	$cols  = in_array( (string) $a['cols'], array( '2', '3', '4' ), true ) ? (string) $a['cols'] : '3';
	$grid  = 'norvex-cards';
	if ( '2' === $cols ) {
		$grid .= ' norvex-cards--2';
	} elseif ( '4' === $cols ) {
		$grid .= ' norvex-cards--4';
	}

	ob_start();
	?>
	<section class="norvex-section">
		<div class="norvex-wrap">
			<?php if ( '' !== trim( (string) $a['eyebrow'] . (string) $a['heading'] . (string) $a['lead'] ) ) : ?>
				<div class="norvex-section-head norvex-center">
					<?php if ( '' !== trim( (string) $a['eyebrow'] ) ) : ?><span class="norvex-eyebrow"><?php echo esc_html( $a['eyebrow'] ); ?></span><?php endif; ?>
					<?php if ( '' !== trim( (string) $a['heading'] ) ) : ?><h2><?php echo esc_html( $a['heading'] ); ?></h2><?php endif; ?>
					<?php if ( '' !== trim( (string) $a['lead'] ) ) : ?><p class="norvex-lead"><?php echo esc_html( $a['lead'] ); ?></p><?php endif; ?>
				</div>
			<?php endif; ?>
			<div class="<?php echo esc_attr( $grid ); ?><?php echo norvex_grid_is_carousel( $a ) ? ' norvex-carousel__track' : ''; ?>"<?php echo norvex_grid_is_carousel( $a ) ? ' data-norvex-carousel="1"' : ''; ?>>
				<?php
				foreach ( $cards as $c ) :
					$image = isset( $c['image'] ) ? (string) $c['image'] : '';
					$icon  = isset( $c['icon'] ) ? (string) $c['icon'] : '';
					$title = isset( $c['title'] ) ? (string) $c['title'] : '';
					$text  = isset( $c['text'] ) ? (string) $c['text'] : '';
					$url   = isset( $c['url'] ) ? (string) $c['url'] : '';
					$label = isset( $c['linklabel'] ) ? (string) $c['linklabel'] : '';
					$price = isset( $c['price'] ) ? (string) $c['price'] : '';
					$note  = isset( $c['note'] ) ? (string) $c['note'] : '';
					$norvex_has_link = ( '' !== $url && '' !== $label );
					$norvex_has_foot = ( '' !== trim( $price ) );
					// "Media" card: an image with no paragraph text and no labelled link.
					// It renders as a clean picture tile — with an optional caption
					// (taken from the Title field) shown as a small strip beneath it.
					// The "Image only (caption tile)" toggle forces this mode even if
					// other fields hold left-over values.
					$norvex_caption     = isset( $c['caption'] ) && '1' === (string) $c['caption'];
					$norvex_is_media    = ( '' !== $image && ( $norvex_caption || ( '' === trim( $text ) && ! $norvex_has_link && ! $norvex_has_foot ) ) );
					$norvex_has_caption = ( $norvex_is_media && '' !== trim( $title ) );
					$norvex_card_class  = 'norvex-card norvex-lift';
					if ( $norvex_is_media ) {
						$norvex_card_class .= $norvex_has_caption ? ' norvex-card--figure' : ' norvex-card--media-only';
					} elseif ( $norvex_has_foot ) {
						$norvex_card_class .= ' norvex-card--has-foot';
					}
					// Per-card border override (side / colour / width).
					$norvex_border = norvex_card_border_style(
						isset( $c['bside'] ) ? (string) $c['bside'] : '',
						isset( $c['bcolor'] ) ? (string) $c['bcolor'] : '',
						isset( $c['bwidth'] ) ? (string) $c['bwidth'] : ''
					);
					// A number / letter in the icon field renders as a large bare badge
					// (no icon box), while a real icon key or SVG keeps its boxed style.
					$norvex_icon_num = norvex_icon_is_text( $icon );
					?>
					<article class="<?php echo esc_attr( $norvex_card_class ); ?>"<?php echo '' !== $norvex_border ? ' style="' . esc_attr( $norvex_border ) . '"' : ''; ?>>
						<?php if ( '' !== $image ) : ?>
							<div class="norvex-card__media">
								<?php if ( $norvex_is_media && '' !== $url ) : ?>
									<a href="<?php echo esc_url( $url ); ?>"><img src="<?php echo esc_url( $image ); ?>" alt="<?php echo esc_attr( $title ); ?>" loading="lazy" /></a>
								<?php else : ?>
									<img src="<?php echo esc_url( $image ); ?>" alt="<?php echo esc_attr( $title ); ?>" loading="lazy" />
								<?php endif; ?>
							</div>
						<?php elseif ( $norvex_icon_num ) : ?>
							<span class="norvex-card__num"><?php echo esc_html( trim( $icon ) ); ?></span>
						<?php elseif ( '<' === substr( ltrim( $icon ), 0, 1 ) ) : ?>
							<?php $custom_svg = norvex_sanitize_svg( $icon ); ?>
							<?php if ( '' !== $custom_svg ) : ?>
								<div class="norvex-card__icon"><?php echo $custom_svg; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- sanitised by norvex_sanitize_svg(). ?></div>
							<?php endif; ?>
						<?php elseif ( '' !== $icon ) : ?>
							<div class="norvex-card__icon"><?php norvex_render_icon( $icon ); ?></div>
						<?php endif; ?>
						<?php if ( $norvex_is_media ) : ?>
							<?php if ( $norvex_has_caption ) : ?>
								<div class="norvex-card__caption"><?php echo esc_html( $title ); ?></div>
							<?php endif; ?>
						<?php else : ?>
							<?php if ( '' !== $title ) : ?><h3><?php echo esc_html( $title ); ?></h3><?php endif; ?>
							<?php if ( '' !== $text ) : ?><p><?php echo esc_html( $text ); ?></p><?php endif; ?>
							<?php if ( $norvex_has_foot ) : ?>
								<div class="norvex-card__foot">
									<span class="norvex-card__note"><?php echo esc_html( $price ); ?></span>
									<?php if ( $norvex_has_link ) : ?>
										<a class="norvex-card__link" href="<?php echo esc_url( $url ); ?>"><?php echo esc_html( $label ); ?></a>
									<?php endif; ?>
								</div>
							<?php elseif ( $norvex_has_link ) : ?>
								<a class="norvex-card__link" href="<?php echo esc_url( $url ); ?>"><?php echo esc_html( $label ); ?></a>
							<?php endif; ?>
							<?php if ( '' !== trim( $note ) ) : ?>
								<p class="norvex-card__fnote"><?php echo esc_html( $note ); ?></p>
							<?php endif; ?>
						<?php endif; ?>
					</article>
				<?php endforeach; ?>
			</div>
		</div>
	</section>
	<?php
	return ob_get_clean();
}

/**
 * Buttons block — one or more styled buttons with alignment.
 *
 * @param array $a Block attributes.
 * @return string
 */
function norvex_render_block_buttons( $a ) {
	$a     = wp_parse_args( $a, norvex_block_defaults( 'buttons' ) );
	$align = in_array( (string) $a['align'], array( 'left', 'center', 'right' ), true ) ? (string) $a['align'] : 'left';

	$buttons = array();
	foreach ( array_filter( array_map( 'trim', explode( "\n", (string) $a['items'] ) ) ) as $line ) {
		$parts = array_map( 'trim', explode( '|', $line ) );
		$label = isset( $parts[0] ) ? $parts[0] : '';
		if ( '' === $label ) {
			continue;
		}
		$style     = ( isset( $parts[2] ) && in_array( $parts[2], array( 'primary', 'ghost', 'light' ), true ) ) ? $parts[2] : 'primary';
		$buttons[] = array(
			'label' => $label,
			'url'   => isset( $parts[1] ) ? $parts[1] : '',
			'style' => $style,
			'blank' => isset( $parts[3] ) && '' !== $parts[3],
		);
	}
	if ( empty( $buttons ) ) {
		return '';
	}

	ob_start();
	?>
	<div class="norvex-section norvex-section--tight">
		<div class="norvex-wrap">
			<div class="norvex-buttons norvex-buttons--<?php echo esc_attr( $align ); ?>">
				<?php foreach ( $buttons as $b ) : ?>
					<a class="norvex-btn norvex-btn--<?php echo esc_attr( $b['style'] ); ?>" href="<?php echo esc_url( norvex_btn_url( $b['url'], 'contact' ) ); ?>"<?php echo $b['blank'] ? ' target="_blank" rel="noopener"' : ''; ?>><?php echo esc_html( $b['label'] ); ?></a>
				<?php endforeach; ?>
			</div>
		</div>
	</div>
	<?php
	return ob_get_clean();
}

/**
 * Table block — a simple editable table with an optional header row.
 *
 * @param array $a Block attributes.
 * @return string
 */
function norvex_render_block_table( $a ) {
	$a    = wp_parse_args( $a, norvex_block_defaults( 'table' ) );
	$rows = json_decode( (string) $a['data'], true );
	if ( ! is_array( $rows ) || empty( $rows ) ) {
		return '';
	}
	$has_header = '1' === (string) $a['header'];

	ob_start();
	?>
	<div class="norvex-section norvex-section--tight">
		<div class="norvex-wrap">
			<?php if ( '' !== trim( (string) $a['heading'] ) ) : ?>
				<h2 class="norvex-table__title"><?php echo esc_html( $a['heading'] ); ?></h2>
			<?php endif; ?>
			<div class="norvex-table-wrap">
				<table class="norvex-table">
					<?php if ( $has_header && isset( $rows[0] ) && is_array( $rows[0] ) ) : ?>
						<thead><tr>
							<?php foreach ( $rows[0] as $cell ) : ?>
								<th><?php echo esc_html( (string) $cell ); ?></th>
							<?php endforeach; ?>
						</tr></thead>
					<?php endif; ?>
					<tbody>
						<?php
						$start = $has_header ? 1 : 0;
						$count = count( $rows );
						for ( $i = $start; $i < $count; $i++ ) :
							if ( ! is_array( $rows[ $i ] ) ) {
								continue;
							}
							?>
							<tr>
								<?php foreach ( $rows[ $i ] as $cell ) : ?>
									<td><?php echo esc_html( (string) $cell ); ?></td>
								<?php endforeach; ?>
							</tr>
						<?php endfor; ?>
					</tbody>
				</table>
			</div>
		</div>
	</div>
	<?php
	return ob_get_clean();
}

function norvex_render_block_tabs( $a ) {
	static $n = 0;
	$a    = wp_parse_args( $a, norvex_block_defaults( 'tabs' ) );
	$tabs = json_decode( (string) $a['tabs'], true );
	if ( ! is_array( $tabs ) ) {
		$tabs = array();
	}
	// Keep only tabs that have a title; a body is optional.
	$tabs = array_values(
		array_filter(
			$tabs,
			function ( $t ) {
				return is_array( $t ) && '' !== trim( (string) ( isset( $t['title'] ) ? $t['title'] : '' ) );
			}
		)
	);
	if ( empty( $tabs ) ) {
		return '';
	}
	$n++;
	$uid = 'norvex-tabs-' . $n;

	ob_start();
	?>
	<div class="norvex-section norvex-section--tight">
		<div class="norvex-wrap">
			<?php if ( '' !== trim( (string) $a['heading'] ) ) : ?>
				<h2 class="norvex-tabs__heading"><?php echo esc_html( $a['heading'] ); ?></h2>
			<?php endif; ?>
			<div class="norvex-tabs" data-norvex-tabs>
				<div class="norvex-tabs__nav" role="tablist">
					<?php foreach ( $tabs as $i => $tab ) : ?>
						<button
							type="button"
							class="norvex-tabs__tab<?php echo 0 === $i ? ' is-active' : ''; ?>"
							id="<?php echo esc_attr( $uid . '-tab-' . $i ); ?>"
							role="tab"
							aria-selected="<?php echo 0 === $i ? 'true' : 'false'; ?>"
							aria-controls="<?php echo esc_attr( $uid . '-panel-' . $i ); ?>"
							tabindex="<?php echo 0 === $i ? '0' : '-1'; ?>"
						><?php echo esc_html( (string) $tab['title'] ); ?></button>
					<?php endforeach; ?>
				</div>
				<div class="norvex-tabs__panels">
					<?php foreach ( $tabs as $i => $tab ) : ?>
						<div
							class="norvex-tabs__panel<?php echo 0 === $i ? ' is-active' : ''; ?>"
							id="<?php echo esc_attr( $uid . '-panel-' . $i ); ?>"
							role="tabpanel"
							aria-labelledby="<?php echo esc_attr( $uid . '-tab-' . $i ); ?>"
							<?php echo 0 === $i ? '' : 'hidden'; ?>
						><?php echo wp_kses_post( wpautop( esc_html( (string) ( isset( $tab['content'] ) ? $tab['content'] : '' ) ) ) ); ?></div>
					<?php endforeach; ?>
				</div>
			</div>
		</div>
	</div>
	<?php
	return ob_get_clean();
}

function norvex_render_block_cta( $a ) {
	$a = wp_parse_args( $a, norvex_block_defaults( 'cta' ) );
	ob_start();
	?>
	<section class="norvex-section norvex-section--tight">
		<div class="norvex-wrap">
			<div class="norvex-cta">
				<span class="norvex-eyebrow" style="color:var(--norvex-gold);"><?php echo esc_html( $a['eyebrow'] ); ?></span>
				<h2><?php echo esc_html( $a['title'] ); ?></h2>
				<p><?php echo esc_html( $a['text'] ); ?></p>
				<div class="norvex-cta__actions">
					<a class="norvex-btn norvex-btn--primary" href="<?php echo esc_url( norvex_btn_url( norvex_ba( $a, 'btn1url' ), 'contact' ) ); ?>"><?php echo esc_html( $a['btn1'] ); ?></a>
					<a class="norvex-btn norvex-btn--ghost" href="<?php echo esc_url( norvex_btn_url( norvex_ba( $a, 'btn2url' ), 'pricing' ) ); ?>"><?php echo esc_html( $a['btn2'] ); ?></a>
				</div>
			</div>
		</div>
	</section>
	<?php
	return ob_get_clean();
}

/* =========================================================================
   Inner-page section render callbacks.
   ========================================================================= */

function norvex_render_block_page_hero( $a ) {
	$a = wp_parse_args( $a, norvex_block_defaults( 'page-hero' ) );
	ob_start();
	?>
	<section class="norvex-page-hero">
		<div class="norvex-wrap">
			<?php norvex_breadcrumb(); ?>
			<h1><?php norvex_hero_title( $a['title'] ); ?></h1>
			<?php if ( '' !== trim( (string) $a['lead'] ) ) : ?>
				<p><?php echo esc_html( $a['lead'] ); ?></p>
			<?php endif; ?>
		</div>
	</section>
	<?php
	return ob_get_clean();
}

function norvex_render_block_about_story( $a ) {
	$a = wp_parse_args( $a, norvex_block_defaults( 'about-story' ) );
	// Fall back to the page's Featured Image, then the bundled art.
	$img = $a['image'];
	if ( '' === $img ) {
		$pid = get_queried_object_id();
		$img = ( $pid && has_post_thumbnail( $pid ) ) ? get_the_post_thumbnail_url( $pid, 'large' ) : norvex_img( 'about.svg' );
	}
	ob_start();
	?>
	<section class="norvex-section">
		<div class="norvex-wrap norvex-split">
			<div class="norvex-media"><img src="<?php echo esc_url( $img ); ?>" alt="<?php esc_attr_e( 'Our team at work', 'norvex' ); ?>" /></div>
			<div>
				<span class="norvex-eyebrow"><?php echo esc_html( $a['eyebrow'] ); ?></span>
				<h2><?php echo esc_html( $a['title'] ); ?></h2>
				<?php if ( '' !== trim( (string) $a['para1'] ) ) : ?><p><?php echo esc_html( $a['para1'] ); ?></p><?php endif; ?>
				<?php if ( '' !== trim( (string) $a['para2'] ) ) : ?><p><?php echo esc_html( $a['para2'] ); ?></p><?php endif; ?>
				<ul class="norvex-checklist">
					<?php
					foreach ( array_filter( array_map( 'trim', explode( "\n", $a['list'] ) ) ) as $item ) {
						echo '<li>' . esc_html( $item ) . '</li>';
					}
					?>
				</ul>
			</div>
		</div>
	</section>
	<?php
	return ob_get_clean();
}

function norvex_render_block_values( $a ) {
	$a = wp_parse_args( $a, norvex_block_defaults( 'values' ) );
	ob_start();
	?>
	<section class="norvex-section">
		<div class="norvex-wrap">
			<div class="norvex-section-head norvex-center">
				<span class="norvex-eyebrow"><?php echo esc_html( $a['eyebrow'] ); ?></span>
				<h2><?php echo esc_html( $a['title'] ); ?></h2>
			</div>
			<div class="norvex-cards">
				<?php for ( $n = 1; $n <= 3; $n++ ) : ?>
					<article class="norvex-card norvex-lift">
						<div class="norvex-card__icon"><?php norvex_icon( $a[ 'i' . $n ] ? $a[ 'i' . $n ] : 'shield' ); ?></div>
						<h3><?php echo esc_html( $a[ 'h' . $n ] ); ?></h3>
						<p><?php echo esc_html( $a[ 'b' . $n ] ); ?></p>
					</article>
				<?php endfor; ?>
			</div>
		</div>
	</section>
	<?php
	return ob_get_clean();
}

function norvex_render_block_team( $a ) {
	$a = wp_parse_args( $a, norvex_block_defaults( 'team' ) );
	ob_start();
	?>
	<section class="norvex-section norvex-section--sand">
		<div class="norvex-wrap">
			<div class="norvex-section-head norvex-center">
				<span class="norvex-eyebrow"><?php echo esc_html( $a['eyebrow'] ); ?></span>
				<h2><?php echo esc_html( $a['title'] ); ?></h2>
			</div>
			<div class="norvex-team">
				<?php
				// Team members are typed on the block.
				$items = json_decode( (string) norvex_ba( $a, 'custom', '' ), true );
				$list  = array();
				if ( is_array( $items ) ) {
					foreach ( $items as $m ) {
						if ( is_array( $m ) && '' !== trim( (string) ( isset( $m['name'] ) ? $m['name'] : '' ) ) ) {
							$list[] = array(
								isset( $m['name'] ) ? $m['name'] : '',
								isset( $m['role'] ) ? $m['role'] : '',
								( isset( $m['photo'] ) && '' !== $m['photo'] ) ? $m['photo'] : norvex_img( 'avatar-1.svg' ),
							);
						}
					}
				}
				if ( empty( $list ) ) {
					foreach ( norvex_default_team() as $m ) {
						$list[] = array( $m[0], $m[1], norvex_img( $m[2] ) );
					}
				}
				foreach ( $list as $m ) :
					?>
					<div class="norvex-member norvex-lift">
						<div class="norvex-member__photo"><img src="<?php echo esc_url( $m[2] ); ?>" alt="<?php echo esc_attr( $m[0] ); ?>" /></div>
						<h4><?php echo esc_html( $m[0] ); ?></h4>
						<span><?php echo esc_html( $m[1] ); ?></span>
					</div>
					<?php
				endforeach;
				?>
			</div>
		</div>
	</section>
	<?php
	return ob_get_clean();
}


function norvex_render_block_pricing( $a ) {
	$a = wp_parse_args( $a, norvex_block_defaults( 'pricing' ) );
	ob_start();
	?>
	<section class="norvex-section">
		<div class="norvex-wrap">
			<?php if ( '' !== trim( (string) $a['eyebrow'] . (string) $a['heading'] . (string) $a['lead'] ) ) : ?>
				<div class="norvex-section-head norvex-center">
					<?php if ( '' !== trim( (string) $a['eyebrow'] ) ) : ?><span class="norvex-eyebrow"><?php echo esc_html( $a['eyebrow'] ); ?></span><?php endif; ?>
					<?php if ( '' !== trim( (string) $a['heading'] ) ) : ?><h2><?php echo esc_html( $a['heading'] ); ?></h2><?php endif; ?>
					<?php if ( '' !== trim( (string) $a['lead'] ) ) : ?><p class="norvex-lead"><?php echo esc_html( $a['lead'] ); ?></p><?php endif; ?>
				</div>
			<?php endif; ?>
			<div class="norvex-pricing">
				<?php
				$btn_label = norvex_ba( $a, 'btn', __( 'Get a custom quote', 'norvex' ) );
				$btn_url   = esc_url( norvex_btn_url( norvex_ba( $a, 'btnurl' ), 'contact' ) );

				// Plans are typed on the block itself.
				$plans = array();
				$items = json_decode( (string) norvex_ba( $a, 'custom', '' ), true );
				if ( is_array( $items ) ) {
					foreach ( $items as $pk ) {
						if ( ! is_array( $pk ) || '' === trim( (string) ( isset( $pk['name'] ) ? $pk['name'] : '' ) ) ) {
							continue;
						}
						$plans[] = array(
							'name'     => isset( $pk['name'] ) ? $pk['name'] : '',
							'price'    => isset( $pk['price'] ) ? $pk['price'] : '',
							'was'      => isset( $pk['was'] ) ? $pk['was'] : '',
							'per'      => isset( $pk['per'] ) ? $pk['per'] : '',
							'desc'     => isset( $pk['desc'] ) ? $pk['desc'] : '',
							'featured' => ! empty( $pk['featured'] ),
							'btn'      => isset( $pk['btn'] ) ? $pk['btn'] : '',
							'btnurl'   => isset( $pk['btnurl'] ) ? $pk['btnurl'] : '',
							'feats'    => norvex_parse_features( isset( $pk['features'] ) ? $pk['features'] : '' ),
						);
					}
				}
				// A brand-new / emptied block still shows sample plans.
				if ( empty( $plans ) ) {
					foreach ( norvex_default_plans() as $d ) {
						$plans[] = array(
							'name'     => $d['name'],
							'price'    => $d['price'],
							'was'      => isset( $d['was'] ) ? $d['was'] : '',
							'per'      => $d['period'],
							'desc'     => $d['desc'],
							'featured' => $d['featured'],
							'btn'      => '',
							'btnurl'   => '',
							'feats'    => norvex_parse_features( $d['features'] ),
						);
					}
				}

				foreach ( $plans as $p ) :
					$save     = norvex_price_saving_pct( $p['was'], $p['price'] );
					$plan_lbl = '' !== trim( (string) $p['btn'] ) ? $p['btn'] : $btn_label;
					$plan_url = '' !== trim( (string) $p['btnurl'] )
						? esc_url( norvex_btn_url( $p['btnurl'], 'contact' ) )
						: $btn_url;
					?>
					<div class="norvex-plan norvex-lift <?php echo $p['featured'] ? 'norvex-plan--featured' : ''; ?>">
						<?php if ( $p['featured'] ) : ?>
							<span class="norvex-plan__flag"><?php esc_html_e( 'Most popular', 'norvex' ); ?></span>
						<?php endif; ?>
						<h3><?php echo esc_html( $p['name'] ); ?></h3>
						<div class="norvex-plan__price">
							<span class="norvex-plan__amount"><?php echo esc_html( $p['price'] ); ?></span>
							<?php if ( '' !== trim( (string) $p['per'] ) ) : ?><span class="norvex-plan__per"><?php echo esc_html( $p['per'] ); ?></span><?php endif; ?>
						</div>
						<?php if ( $save > 0 ) : ?>
							<div class="norvex-plan__compare">
								<span class="norvex-plan__was"><?php echo esc_html( $p['was'] ); ?></span>
								<span class="norvex-plan__save">
									<?php
									/* translators: %d: percentage saved. */
									echo esc_html( sprintf( __( 'Save %d%%', 'norvex' ), $save ) );
									?>
								</span>
							</div>
						<?php endif; ?>
						<p class="norvex-plan__desc"><?php echo esc_html( $p['desc'] ); ?></p>
						<ul>
							<?php foreach ( $p['feats'] as $f ) : ?>
								<li class="<?php echo $f[1] ? '' : 'norvex-off'; ?>"><?php echo esc_html( $f[0] ); ?></li>
							<?php endforeach; ?>
						</ul>
						<a class="norvex-btn <?php echo $p['featured'] ? 'norvex-btn--primary' : 'norvex-btn--ghost'; ?>" href="<?php echo $plan_url; ?>"><?php echo esc_html( $plan_lbl ); ?></a>
					</div>
				<?php endforeach; ?>
			</div>
			<?php if ( '' !== trim( (string) $a['note'] ) ) : ?>
				<p class="norvex-center" style="margin-top:34px;color:var(--norvex-muted);"><?php echo esc_html( $a['note'] ); ?></p>
			<?php endif; ?>
		</div>
	</section>
	<?php
	return ob_get_clean();
}

function norvex_render_block_contact( $a ) {
	$a = wp_parse_args( $a, norvex_block_defaults( 'contact' ) );
	ob_start();
	?>
	<section class="norvex-section">
		<div class="norvex-wrap">
			<div class="norvex-contact-grid">

				<div>
					<span class="norvex-eyebrow"><?php echo esc_html( $a['eyebrow'] ); ?></span>
					<h2><?php echo esc_html( $a['title'] ); ?></h2>
					<p class="norvex-lead"><?php echo esc_html( $a['lead'] ); ?></p>

					<div class="norvex-contact-info" style="margin-top:26px;">
						<div class="norvex-contact-item">
							<div class="norvex-card__icon"><?php norvex_icon( 'mail' ); ?></div>
							<div><strong><?php esc_html_e( 'Email', 'norvex' ); ?></strong><span><a href="mailto:<?php echo esc_attr( norvex_option( 'norvex_email', 'hello@norvexpublishingservices.com' ) ); ?>"><?php echo esc_html( norvex_option( 'norvex_email', 'hello@norvexpublishingservices.com' ) ); ?></a></span></div>
						</div>
						<div class="norvex-contact-item">
							<div class="norvex-card__icon"><?php norvex_icon( 'phone' ); ?></div>
							<div><strong><?php esc_html_e( 'Phone', 'norvex' ); ?></strong><span><a href="tel:<?php echo esc_attr( norvex_option( 'norvex_phone', '' ) ); ?>"><?php echo esc_html( norvex_option( 'norvex_phone', '+1 (732) 454-6871' ) ); ?></a></span></div>
						</div>
						<div class="norvex-contact-item">
							<div class="norvex-card__icon"><?php norvex_icon( 'pin' ); ?></div>
							<div><strong><?php esc_html_e( 'Studio', 'norvex' ); ?></strong><span><?php echo esc_html( norvex_option( 'norvex_address', '1102 Glenwood Road, F4, Brooklyn, NY 11230' ) ); ?></span></div>
						</div>
						<div class="norvex-contact-item">
							<div class="norvex-card__icon"><?php norvex_icon( 'clock' ); ?></div>
							<div><strong><?php esc_html_e( 'Hours', 'norvex' ); ?></strong><span><?php echo esc_html( norvex_option( 'norvex_hours', 'Mon–Fri · 9:00 AM – 6:00 PM' ) ); ?></span></div>
						</div>
					</div>

					<div class="norvex-map" style="margin-top:26px;">
						<iframe title="<?php esc_attr_e( 'Studio location map', 'norvex' ); ?>" src="https://www.openstreetmap.org/export/embed.html?bbox=-73.99%2C40.735%2C-73.978%2C40.742&amp;layer=mapnik" loading="lazy"></iframe>
					</div>
				</div>

				<div class="norvex-card" id="norvex-contact-form" style="padding:38px;">
					<h3><?php echo esc_html( $a['formtitle'] ); ?></h3>
					<p style="color:var(--norvex-muted);"><?php echo esc_html( $a['formintro'] ); ?></p>
					<?php
					$content = get_post_field( 'post_content', get_the_ID() );
					if ( has_shortcode( $content, 'contact-form-7' ) || has_shortcode( $content, 'wpforms' ) || has_shortcode( $content, 'gravityform' ) ) {
						echo do_shortcode( $content );
					} else {
						$norvex_form  = norvex_contact_form_state();
						$norvex_val   = $norvex_form['values'];
						$norvex_error = static function ( $field ) use ( $norvex_form ) {
							if ( ! empty( $norvex_form['errors'][ $field ] ) ) {
								printf( '<span class="norvex-field__error">%s</span>', esc_html( $norvex_form['errors'][ $field ] ) );
							}
						};

						if ( $norvex_form['sent'] ) :
							?>
							<p class="norvex-form__note norvex-form__note--ok" role="status">
								<?php esc_html_e( 'Thank you! Your message is on its way — we’ll be in touch within one business day.', 'norvex' ); ?>
							</p>
							<?php
						else :
							if ( ! empty( $norvex_form['errors']['general'] ) ) :
								?>
								<p class="norvex-form__note norvex-form__note--error" role="alert"><?php echo esc_html( $norvex_form['errors']['general'] ); ?></p>
								<?php
							endif;
							?>
							<form class="norvex-form" action="<?php echo esc_url( get_permalink() ); ?>#norvex-contact-form" method="post" style="margin-top:18px;" novalidate>
								<div class="norvex-row">
									<div class="norvex-field">
										<label for="norvex-name"><?php esc_html_e( 'Your name', 'norvex' ); ?></label>
										<input id="norvex-name" type="text" name="norvex_name" value="<?php echo esc_attr( $norvex_val['name'] ); ?>" required />
										<?php $norvex_error( 'name' ); ?>
									</div>
									<div class="norvex-field">
										<label for="norvex-email"><?php esc_html_e( 'Email', 'norvex' ); ?></label>
										<input id="norvex-email" type="email" name="email" value="<?php echo esc_attr( $norvex_val['email'] ); ?>" required />
										<?php $norvex_error( 'email' ); ?>
									</div>
								</div>
								<div class="norvex-field">
									<label for="norvex-service"><?php esc_html_e( 'What do you need?', 'norvex' ); ?></label>
									<?php
									$norvex_services = array(
										__( 'Editing & proofreading', 'norvex' ),
										__( 'Cover & interior design', 'norvex' ),
										__( 'Publishing & distribution', 'norvex' ),
										__( 'Marketing & launch', 'norvex' ),
										__( 'The full package', 'norvex' ),
										__( 'Not sure yet', 'norvex' ),
									);
									?>
									<select id="norvex-service" name="service">
										<?php foreach ( $norvex_services as $norvex_service_opt ) : ?>
											<option<?php selected( $norvex_val['service'], $norvex_service_opt ); ?>><?php echo esc_html( $norvex_service_opt ); ?></option>
										<?php endforeach; ?>
									</select>
								</div>
								<div class="norvex-field">
									<label for="norvex-msg"><?php esc_html_e( 'Tell us about your book', 'norvex' ); ?></label>
									<textarea id="norvex-msg" name="message" placeholder="<?php esc_attr_e( 'Genre, word count, where you are in the process…', 'norvex' ); ?>" required><?php echo esc_textarea( $norvex_val['message'] ); ?></textarea>
									<?php $norvex_error( 'message' ); ?>
								</div>
								<div class="norvex-hp" aria-hidden="true">
									<label for="norvex-website"><?php esc_html_e( 'Leave this field empty', 'norvex' ); ?></label>
									<input id="norvex-website" type="text" name="norvex_website" tabindex="-1" autocomplete="off" />
								</div>
								<?php wp_nonce_field( 'norvex_contact', 'norvex_contact_nonce' ); ?>
								<?php norvex_gclid_field(); ?>
								<button type="submit" class="norvex-btn norvex-btn--primary"><?php esc_html_e( 'Send message', 'norvex' ); ?> <?php norvex_icon( 'arrow' ); ?></button>
							</form>
							<p style="font-size:.82rem;color:var(--norvex-muted);margin-top:14px;"><?php esc_html_e( 'Submissions are emailed to your Norvex contact address. Prefer a plugin? Paste a Contact Form 7 or WPForms shortcode into this page and it takes over automatically.', 'norvex' ); ?></p>
							<?php
						endif;
					}
					?>
				</div>

			</div>
		</div>
	</section>
	<?php
	return ob_get_clean();
}

/**
 * Parse the estimate calculator's service lines.
 *
 * Each line: "Name | type | price | *" where type is word|flat and a trailing
 * "*" pre-selects the row. Returns a list of normalized service arrays.
 *
 * @param string $raw Raw textarea value.
 * @return array
 */
function norvex_parse_estimate_items( $raw ) {
	$items = array();
	foreach ( array_filter( array_map( 'trim', preg_split( '/\r\n|\r|\n/', (string) $raw ) ) ) as $line ) {
		$parts = array_map( 'trim', explode( '|', $line ) );
		$name  = isset( $parts[0] ) ? $parts[0] : '';
		if ( '' === $name ) {
			continue;
		}
		$type  = ( isset( $parts[1] ) && 'word' === strtolower( $parts[1] ) ) ? 'word' : 'flat';
		$price = isset( $parts[2] ) ? (float) preg_replace( '/[^0-9.]/', '', $parts[2] ) : 0;
		$pre   = isset( $parts[3] ) && '*' === $parts[3];
		$items[] = array(
			'name'  => $name,
			'type'  => $type,
			'price' => $price,
			'pre'   => $pre,
		);
	}
	return $items;
}

function norvex_render_block_estimate( $a ) {
	$a     = wp_parse_args( $a, norvex_block_defaults( 'estimate' ) );
	$items = norvex_parse_estimate_items( $a['items'] );
	$cur   = $a['currency'] ? $a['currency'] : '$';
	$words = max( 0, (int) $a['words'] );
	ob_start();
	?>
	<section class="norvex-section norvex-section--sand">
		<div class="norvex-wrap">
			<div class="norvex-section-head norvex-center">
				<span class="norvex-eyebrow"><?php echo esc_html( $a['eyebrow'] ); ?></span>
				<h2><?php echo esc_html( $a['title'] ); ?></h2>
				<?php if ( '' !== trim( (string) $a['lead'] ) ) : ?>
					<p class="norvex-lead"><?php echo esc_html( $a['lead'] ); ?></p>
				<?php endif; ?>
			</div>

			<div class="norvex-estimate" data-currency="<?php echo esc_attr( $cur ); ?>">
				<div class="norvex-estimate__panel">
					<div class="norvex-estimate__field">
						<label for="norvex-estimate-words"><?php echo esc_html( $a['wordlabel'] ); ?></label>
						<input id="norvex-estimate-words" class="norvex-estimate__words" type="number" min="0" step="1000" inputmode="numeric" value="<?php echo esc_attr( $words ); ?>" />
					</div>

					<fieldset class="norvex-estimate__services">
						<legend class="screen-reader-text"><?php esc_html_e( 'Choose your services', 'norvex' ); ?></legend>
						<?php foreach ( $items as $i => $item ) : ?>
							<label class="norvex-estimate__service">
								<input
									type="checkbox"
									class="norvex-estimate__toggle"
									data-type="<?php echo esc_attr( $item['type'] ); ?>"
									data-price="<?php echo esc_attr( $item['price'] ); ?>"
									<?php checked( $item['pre'] ); ?>
								/>
								<span class="norvex-estimate__service-name"><?php echo esc_html( $item['name'] ); ?></span>
								<span class="norvex-estimate__service-price" aria-hidden="true">
									<?php
									if ( 'word' === $item['type'] ) {
										/* translators: %s: formatted per-word price. */
										printf( esc_html__( '%s / word', 'norvex' ), esc_html( $cur . rtrim( rtrim( number_format( $item['price'], 3 ), '0' ), '.' ) ) );
									} else {
										/* translators: %s: formatted flat price. */
										printf( esc_html__( 'from %s', 'norvex' ), esc_html( $cur . number_format( $item['price'] ) ) );
									}
									?>
								</span>
							</label>
						<?php endforeach; ?>
					</fieldset>
				</div>

				<aside class="norvex-estimate__result" aria-live="polite">
					<span class="norvex-estimate__result-label"><?php esc_html_e( 'Estimated total', 'norvex' ); ?></span>
					<span class="norvex-estimate__total" data-empty="<?php esc_attr_e( 'Select a service', 'norvex' ); ?>"><?php echo esc_html( $cur ); ?>0</span>
					<span class="norvex-estimate__range"></span>
					<?php if ( '' !== trim( (string) $a['note'] ) ) : ?>
						<p class="norvex-estimate__note"><?php echo esc_html( $a['note'] ); ?></p>
					<?php endif; ?>
					<a class="norvex-btn norvex-btn--primary norvex-estimate__cta" href="<?php echo esc_url( get_permalink( get_page_by_path( 'contact' ) ) ); ?>"><?php echo esc_html( $a['btn'] ); ?> <?php norvex_icon( 'arrow' ); ?></a>
				</aside>
			</div>
		</div>
	</section>
	<?php
	return ob_get_clean();
}

/**
 * The default homepage as block markup — seeded into the Home page by the demo
 * importer and used as the front-page fallback. Each block relies on its
 * registered attribute defaults, so no attributes need to be written inline.
 *
 * @return string
 */
function norvex_default_homepage_blocks() {
	$blocks = array(
		norvex_block_markup( 'hero' ),
		norvex_block_markup( 'logos' ),
		norvex_block_markup( 'services' ),
		norvex_block_markup( 'process' ),
		norvex_block_markup( 'consult' ),
		norvex_block_markup(
			'pricing',
			array(
				'eyebrow' => __( 'Pricing', 'norvex' ),
				'heading' => __( 'Packages that fit your book', 'norvex' ),
				'lead'    => __( 'Start with a package or build your own. Every plan is tailored after your free consultation — these are typical starting points.', 'norvex' ),
				'note'    => __( 'Prefer to pay per service? Build your own package →', 'norvex' ),
			)
		),
		norvex_block_markup( 'featured-books' ),
		norvex_block_markup( 'stats' ),
		norvex_block_markup( 'why-us' ),
		norvex_block_markup( 'testimonials' ),
		norvex_block_markup( 'journal' ),
		norvex_block_markup( 'faq' ),
		norvex_block_markup( 'cta' ),
	);
	return norvex_blocks_to_content( $blocks );
}

/**
 * Build a single Norvex block comment, optionally with attributes.
 *
 * @param string $name  Block name without the "norvex/" prefix.
 * @param array  $attrs Attribute overrides.
 * @return string
 */
function norvex_block_markup( $name, $attrs = array() ) {
	if ( empty( $attrs ) ) {
		return '<!-- wp:norvex/' . $name . ' /-->';
	}
	// Encode literal UTF-8 (not \uXXXX escapes): a lone backslash in the block
	// comment is stripped when the post is saved, which would corrupt em-dashes
	// and arrows into "u2014"/"u2192".
	return '<!-- wp:norvex/' . $name . ' ' . wp_json_encode( $attrs, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES ) . ' /-->';
}

/**
 * Assemble a list of block markup strings into page content.
 */
function norvex_blocks_to_content( $blocks ) {
	return trim( implode( "\n\n", $blocks ) );
}
