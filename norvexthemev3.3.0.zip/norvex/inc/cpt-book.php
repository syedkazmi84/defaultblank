<?php
/**
 * "Portfolio" custom post type + Category taxonomy.
 *
 * Showcases books the company has helped create (writing, editing, design,
 * publishing, marketing). This is a non-commercial portfolio — there are no
 * prices or buy buttons; it demonstrates the work, it does not sell books.
 *
 * The post type key stays `book` for template continuity (single-book.php,
 * archive-book.php, template-parts/book-card.php).
 *
 * @package Norvex
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Register the Portfolio post type.
 */
function norvex_register_book_cpt() {
	$labels = array(
		'name'               => __( 'Portfolio', 'norvex' ),
		'singular_name'      => __( 'Project', 'norvex' ),
		'add_new'            => __( 'Add New Project', 'norvex' ),
		'add_new_item'       => __( 'Add New Project', 'norvex' ),
		'edit_item'          => __( 'Edit Project', 'norvex' ),
		'new_item'           => __( 'New Project', 'norvex' ),
		'view_item'          => __( 'View Project', 'norvex' ),
		'search_items'       => __( 'Search Portfolio', 'norvex' ),
		'not_found'          => __( 'No projects found', 'norvex' ),
		'not_found_in_trash' => __( 'No projects found in Trash', 'norvex' ),
		'all_items'          => __( 'All Projects', 'norvex' ),
		'menu_name'          => __( 'Portfolio', 'norvex' ),
	);

	register_post_type(
		'book',
		array(
			'labels'        => $labels,
			'public'        => true,
			'has_archive'   => true,
			'show_in_menu'  => 'norvex-hub',
			'menu_icon'     => 'dashicons-portfolio',
			'menu_position' => 5,
			'rewrite'       => array( 'slug' => 'books' ),
			'supports'      => array( 'title', 'editor', 'thumbnail', 'excerpt', 'page-attributes' ),
			'show_in_rest'  => true,
		)
	);
}
add_action( 'init', 'norvex_register_book_cpt' );

/**
 * Register the Category taxonomy (genre) for portfolio projects.
 */
function norvex_register_genre_tax() {
	register_taxonomy(
		'genre',
		'book',
		array(
			'labels'            => array(
				'name'          => __( 'Categories', 'norvex' ),
				'singular_name' => __( 'Category', 'norvex' ),
				'menu_name'     => __( 'Categories', 'norvex' ),
			),
			'hierarchical'      => true,
			'public'            => true,
			'show_admin_column' => true,
			'show_in_rest'      => true,
			'rewrite'           => array( 'slug' => 'work-category' ),
		)
	);
}
add_action( 'init', 'norvex_register_genre_tax' );

/**
 * Project detail meta box (author/client + the service we provided).
 */
function norvex_book_metabox() {
	add_meta_box(
		'norvex_book_details',
		__( 'Project Details', 'norvex' ),
		'norvex_book_metabox_html',
		'book',
		'side',
		'high'
	);
}
add_action( 'add_meta_boxes', 'norvex_book_metabox' );

function norvex_book_metabox_html( $post ) {
	wp_nonce_field( 'norvex_save_book', 'norvex_book_nonce' );
	$fields = array(
		'_norvex_author'  => __( 'Author / client name', 'norvex' ),
		'_norvex_service' => __( 'Service provided (e.g. Ghostwriting, Cover design)', 'norvex' ),
	);
	foreach ( $fields as $key => $label ) {
		$val = get_post_meta( $post->ID, $key, true );
		printf(
			'<p><label style="display:block;font-weight:600;margin-bottom:4px;">%s</label><input type="text" name="%s" value="%s" style="width:100%%;" /></p>',
			esc_html( $label ),
			esc_attr( $key ),
			esc_attr( $val )
		);
	}
	echo '<p style="color:#666;font-size:12px;">' . esc_html__( 'Set a Featured Image to use a real cover, or leave blank to use a bundled sample cover.', 'norvex' ) . '</p>';
}

function norvex_save_book_meta( $post_id ) {
	if ( ! isset( $_POST['norvex_book_nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['norvex_book_nonce'] ) ), 'norvex_save_book' ) ) {
		return;
	}
	if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
		return;
	}
	if ( ! current_user_can( 'edit_post', $post_id ) ) {
		return;
	}
	foreach ( array( '_norvex_author', '_norvex_service' ) as $key ) {
		if ( isset( $_POST[ $key ] ) ) {
			update_post_meta( $post_id, $key, sanitize_text_field( wp_unslash( $_POST[ $key ] ) ) );
		}
	}
}
add_action( 'save_post_book', 'norvex_save_book_meta' );

/**
 * Helper to fetch a project meta value.
 */
function norvex_book_meta( $key, $post_id = null ) {
	$post_id = $post_id ? $post_id : get_the_ID();
	return get_post_meta( $post_id, $key, true );
}
