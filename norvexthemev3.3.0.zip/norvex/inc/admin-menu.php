<?php
/**
 * Consolidated admin menu.
 *
 * Puts all of the theme's editors (Portfolio, Services, Testimonials, Team,
 * Pricing Plans) under a single top-level "Norvex" tab, instead of each
 * one being its own separate item in the sidebar. The custom post types attach
 * here via their `show_in_menu => 'norvex-hub'` setting.
 *
 * @package Norvex
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Register the top-level hub and rename its first submenu to "Overview".
 */
function norvex_admin_hub_menu() {
	add_menu_page(
		__( 'Norvex', 'norvex' ),
		__( 'Norvex', 'norvex' ),
		'edit_posts',
		'norvex-hub',
		'norvex_admin_hub_page',
		'dashicons-book-alt',
		3
	);

	add_submenu_page(
		'norvex-hub',
		__( 'Overview', 'norvex' ),
		__( 'Overview', 'norvex' ),
		'edit_posts',
		'norvex-hub',
		'norvex_admin_hub_page'
	);
}
add_action( 'admin_menu', 'norvex_admin_hub_menu' );

/**
 * The hub landing page — quick links to every editable part of the site.
 */
function norvex_admin_hub_page() {
	$content = array(
		array( 'dashicons-admin-page', __( 'Pages', 'norvex' ), __( 'Home, About, Services, Pricing, Portfolio, Contact — all built from blocks.', 'norvex' ), admin_url( 'edit.php?post_type=page' ) ),
		array( 'dashicons-email-alt2', __( 'Leads', 'norvex' ), __( 'Contact-form enquiries — never lost.', 'norvex' ), admin_url( 'edit.php?post_type=norvex_lead' ) ),
		array( 'dashicons-admin-post', __( 'Blog Posts', 'norvex' ), __( 'Articles in the Journal.', 'norvex' ), admin_url( 'edit.php' ) ),
	);

	$customize = array(
		array( __( 'Design — colors & fonts', 'norvex' ), __( 'Accent color, ink color, heading & body fonts.', 'norvex' ), 'norvex_design' ),
		array( __( 'Contact & social', 'norvex' ), __( 'Email, phone, address, hours, socials.', 'norvex' ), 'norvex_contact' ),
		array( __( 'Footer text & copyright', 'norvex' ), __( 'Services links, newsletter blurb, copyright line.', 'norvex' ), 'norvex_footer' ),
		array( __( 'Cookie consent', 'norvex' ), __( 'GDPR consent bar — message, buttons, policy link.', 'norvex' ), 'norvex_cookie' ),
		array( __( 'Logo & site title', 'norvex' ), __( 'Upload your logo and set the site name.', 'norvex' ), 'title_tagline' ),
	);

	$imported = norvex_demo_is_imported();
	?>
	<div class="wrap">
		<h1 style="display:flex;align-items:center;gap:10px;">
			<span class="dashicons dashicons-book-alt" style="font-size:30px;width:30px;height:30px;"></span>
			<?php esc_html_e( 'Norvex — Manage Your Site', 'norvex' ); ?>
		</h1>
		<p style="font-size:14px;max-width:760px;color:#50575e;">
			<?php esc_html_e( 'Everything you can edit is here. The Norvex blocks are available in the editor for any new page you build. Site-wide contact details, colors, fonts and your logo live in the Customizer.', 'norvex' ); ?>
		</p>

		<?php if ( isset( $_GET['norvex_imported'] ) ) : // phpcs:ignore WordPress.Security.NonceVerification.Recommended ?>
			<div class="notice notice-success is-dismissible" style="max-width:1000px;">
				<p><?php esc_html_e( 'Demo content imported. Your pages, menu, portfolio and sample content are ready — visit your site to see it.', 'norvex' ); ?></p>
			</div>
		<?php endif; ?>

		<?php if ( isset( $_GET['norvex_reset'] ) ) : // phpcs:ignore WordPress.Security.NonceVerification.Recommended ?>
			<div class="notice notice-success is-dismissible" style="max-width:1000px;">
				<p><?php esc_html_e( 'Demo content reset and re-imported. Your pages, menu, portfolio, pricing and sample content are fresh — visit your site to see it.', 'norvex' ); ?></p>
			</div>
		<?php endif; ?>

		<?php if ( current_user_can( 'manage_options' ) ) : ?>
			<div style="max-width:1000px;margin-top:18px;background:#fff;border:1px solid #dcdcde;border-left:4px solid #c08a3e;border-radius:8px;padding:20px 22px;box-shadow:0 1px 2px rgba(0,0,0,.04);">
				<?php if ( ! $imported ) : ?>
					<h2 style="margin:0 0 6px;"><?php esc_html_e( 'Start with the demo content', 'norvex' ); ?></h2>
					<p style="margin:0 0 14px;color:#50575e;max-width:720px;">
						<?php esc_html_e( 'Activating the theme does not add anything to your site. Click below to import the full starter site — every page (Home, About, Services, Pricing, Portfolio, Contact) built from editable blocks, the navigation menus and sample journal posts. You can edit or delete any of it afterwards.', 'norvex' ); ?>
					</p>
					<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
						<input type="hidden" name="action" value="norvex_import_demo" />
						<?php wp_nonce_field( 'norvex_import_demo' ); ?>
						<button type="submit" class="button button-primary button-hero">
							<span class="dashicons dashicons-download" style="margin:4px 6px 0 0;"></span>
							<?php esc_html_e( 'Import demo content', 'norvex' ); ?>
						</button>
					</form>
				<?php else : ?>
					<h2 style="margin:0 0 6px;display:flex;align-items:center;gap:8px;">
						<span class="dashicons dashicons-yes-alt" style="color:#00a32a;"></span>
						<?php esc_html_e( 'Demo content imported', 'norvex' ); ?>
					</h2>
					<p style="margin:0 0 16px;color:#50575e;max-width:720px;">
						<?php esc_html_e( 'Your starter content is in place. Edit it from the sections below, or build brand-new pages with the bundled blocks in the editor.', 'norvex' ); ?>
					</p>
					<hr style="border:none;border-top:1px solid #eee;margin:16px 0;" />
					<h3 style="margin:0 0 6px;"><?php esc_html_e( 'Reset the demo content', 'norvex' ); ?></h3>
					<p style="margin:0 0 14px;color:#50575e;max-width:720px;">
						<?php esc_html_e( 'Reloads the latest starter site. This deletes the demo pages (Home, About, Services, How It Works, Pricing, Portfolio, Contact, Journal, Privacy, Terms), the sample journal posts and the navigation menus — then imports them again fresh. Newsletter subscribers and any other pages or posts you created are left untouched. This cannot be undone.', 'norvex' ); ?>
					</p>
					<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" onsubmit="return confirm(<?php echo esc_js( wp_json_encode( __( 'Reset demo content? The demo pages, menus and sample journal posts will be deleted and re-imported. This cannot be undone.', 'norvex' ) ) ); ?>);">
						<input type="hidden" name="action" value="norvex_reset_demo" />
						<?php wp_nonce_field( 'norvex_reset_demo' ); ?>
						<button type="submit" class="button button-secondary">
							<span class="dashicons dashicons-update" style="margin:4px 6px 0 0;"></span>
							<?php esc_html_e( 'Reset &amp; re-import demo content', 'norvex' ); ?>
						</button>
					</form>
				<?php endif; ?>
			</div>

			<?php $norvex_variant = get_option( 'norvex_demo_variant', 'theme' ); ?>
			<div style="max-width:1000px;margin-top:14px;background:#fff;border:1px solid #dcdcde;border-left:4px solid #7c2b3b;border-radius:8px;padding:20px 22px;box-shadow:0 1px 2px rgba(0,0,0,.04);">
				<h3 style="margin:0 0 6px;"><?php esc_html_e( 'Alternative: block-only starter site', 'norvex' ); ?>
					<?php if ( $imported && 'blocks' === $norvex_variant ) : ?>
						<span class="dashicons dashicons-yes-alt" style="color:#00a32a;vertical-align:middle;"></span>
					<?php endif; ?>
				</h3>
				<p style="margin:0 0 14px;color:#50575e;max-width:720px;">
					<?php esc_html_e( 'Prefer pages built entirely from core WordPress (Gutenberg) blocks — cover, columns, media &amp; text, gallery, buttons, table — with no custom theme blocks? Import this variant instead. It builds the same pages (Home, About, Services, How It Works, Pricing, Portfolio, Contact, plus Privacy &amp; Terms) using the theme’s palette and fonts, so everything is standard, editable Gutenberg content. This replaces the current demo pages and navigation.', 'norvex' ); ?>
				</p>
				<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" onsubmit="return confirm(<?php echo esc_js( wp_json_encode( __( 'Import the block-only demo? This deletes the current demo pages and menus and rebuilds them from core WordPress blocks. This cannot be undone.', 'norvex' ) ) ); ?>);">
					<input type="hidden" name="action" value="norvex_import_block_demo" />
					<?php wp_nonce_field( 'norvex_import_block_demo' ); ?>
					<button type="submit" class="button button-secondary">
						<span class="dashicons dashicons-block-default" style="margin:4px 6px 0 0;"></span>
						<?php esc_html_e( 'Import block-only demo', 'norvex' ); ?>
					</button>
				</form>
			</div>
		<?php endif; ?>

		<?php norvex_admin_dashboard_panels(); ?>

		<h2 style="margin-top:24px;"><?php esc_html_e( 'Content', 'norvex' ); ?></h2>
		<div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(240px,1fr));gap:16px;max-width:1000px;">
			<?php foreach ( $content as $c ) : ?>
				<a href="<?php echo esc_url( $c[3] ); ?>" style="display:block;text-decoration:none;background:#fff;border:1px solid #dcdcde;border-radius:8px;padding:18px 20px;color:#1d2327;box-shadow:0 1px 2px rgba(0,0,0,.04);">
					<span class="dashicons <?php echo esc_attr( $c[0] ); ?>" style="color:#c08a3e;font-size:24px;width:24px;height:24px;"></span>
					<strong style="display:block;margin:8px 0 4px;font-size:15px;"><?php echo esc_html( $c[1] ); ?></strong>
					<span style="color:#646970;font-size:13px;"><?php echo esc_html( $c[2] ); ?></span>
				</a>
			<?php endforeach; ?>
		</div>

		<h2 style="margin-top:30px;"><?php esc_html_e( 'Site-wide settings (Customizer)', 'norvex' ); ?></h2>
		<div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(240px,1fr));gap:16px;max-width:1000px;">
			<?php foreach ( $customize as $cz ) : ?>
				<a href="<?php echo esc_url( admin_url( 'customize.php?autofocus[section]=' . $cz[2] ) ); ?>" style="display:block;text-decoration:none;background:#fff;border:1px solid #dcdcde;border-radius:8px;padding:18px 20px;color:#1d2327;box-shadow:0 1px 2px rgba(0,0,0,.04);">
					<span class="dashicons dashicons-admin-customizer" style="color:#c08a3e;font-size:24px;width:24px;height:24px;"></span>
					<strong style="display:block;margin:8px 0 4px;font-size:15px;"><?php echo esc_html( $cz[0] ); ?></strong>
					<span style="color:#646970;font-size:13px;"><?php echo esc_html( $cz[1] ); ?></span>
				</a>
			<?php endforeach; ?>
		</div>

		<h2 style="margin-top:30px;"><?php esc_html_e( 'Pages & menu', 'norvex' ); ?></h2>
		<div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(240px,1fr));gap:16px;max-width:1000px;">
			<a href="<?php echo esc_url( admin_url( 'edit.php?post_type=page' ) ); ?>" style="display:block;text-decoration:none;background:#fff;border:1px solid #dcdcde;border-radius:8px;padding:18px 20px;color:#1d2327;box-shadow:0 1px 2px rgba(0,0,0,.04);">
				<span class="dashicons dashicons-admin-page" style="color:#c08a3e;font-size:24px;width:24px;height:24px;"></span>
				<strong style="display:block;margin:8px 0 4px;font-size:15px;"><?php esc_html_e( 'Pages', 'norvex' ); ?></strong>
				<span style="color:#646970;font-size:13px;"><?php esc_html_e( 'Home is built from blocks. About, Services, Pricing, Portfolio & Contact each have their own content fields when you edit the page.', 'norvex' ); ?></span>
			</a>
			<a href="<?php echo esc_url( admin_url( 'nav-menus.php' ) ); ?>" style="display:block;text-decoration:none;background:#fff;border:1px solid #dcdcde;border-radius:8px;padding:18px 20px;color:#1d2327;box-shadow:0 1px 2px rgba(0,0,0,.04);">
				<span class="dashicons dashicons-menu" style="color:#c08a3e;font-size:24px;width:24px;height:24px;"></span>
				<strong style="display:block;margin:8px 0 4px;font-size:15px;"><?php esc_html_e( 'Menus', 'norvex' ); ?></strong>
				<span style="color:#646970;font-size:13px;"><?php esc_html_e( 'Add pages to your navigation.', 'norvex' ); ?></span>
			</a>
			<a href="<?php echo esc_url( admin_url( 'admin.php?page=norvex-smtp' ) ); ?>" style="display:block;text-decoration:none;background:#fff;border:1px solid #dcdcde;border-radius:8px;padding:18px 20px;color:#1d2327;box-shadow:0 1px 2px rgba(0,0,0,.04);">
				<span class="dashicons dashicons-email-alt" style="color:#c08a3e;font-size:24px;width:24px;height:24px;"></span>
				<strong style="display:block;margin:8px 0 4px;font-size:15px;"><?php esc_html_e( 'Email (SMTP)', 'norvex' ); ?></strong>
				<span style="color:#646970;font-size:13px;"><?php esc_html_e( 'Deliver contact & newsletter mail reliably, and send a test.', 'norvex' ); ?></span>
			</a>
			<a href="<?php echo esc_url( admin_url( 'admin.php?page=norvex-tracking' ) ); ?>" style="display:block;text-decoration:none;background:#fff;border:1px solid #dcdcde;border-radius:8px;padding:18px 20px;color:#1d2327;box-shadow:0 1px 2px rgba(0,0,0,.04);">
				<span class="dashicons dashicons-chart-line" style="color:#c08a3e;font-size:24px;width:24px;height:24px;"></span>
				<strong style="display:block;margin:8px 0 4px;font-size:15px;"><?php esc_html_e( 'Marketing &amp; Tracking', 'norvex' ); ?></strong>
				<span style="color:#646970;font-size:13px;"><?php esc_html_e( 'Google Analytics, Tag Manager & Meta Pixel — plus lead conversions.', 'norvex' ); ?></span>
			</a>
		</div>

		<p style="margin-top:28px;color:#646970;font-size:13px;max-width:760px;">
			<?php esc_html_e( 'Tip: the Home page is edited in the block editor. About, Services, Pricing, Portfolio & Contact are edited by opening the page and filling in the content fields shown below the editor (headings, intro text, stats, process steps, FAQs…). The Norvex blocks are also available on any new page you create.', 'norvex' ); ?>
		</p>
	</div>
	<?php
}

/**
 * The setup checklist + at-a-glance stats + recent leads panel.
 *
 * Gives the hub a real "dashboard" first screen: a guided checklist of the key
 * setup steps (with a link to fix each), headline content counts, and the most
 * recent enquiries.
 */
function norvex_admin_dashboard_panels() {
	// --- Setup checklist items: [ done?, label, fix-link, done-hint ] ---
	$menu_set    = has_nav_menu( 'primary' );
	$email       = function_exists( 'norvex_option' ) ? norvex_option( 'norvex_email', '' ) : get_option( 'admin_email' );
	$smtp_on     = function_exists( 'norvex_smtp_is_active' ) && norvex_smtp_is_active();
	$tracking_on = function_exists( 'norvex_tracking_active' ) && norvex_tracking_active();
	$sitemap_on  = function_exists( 'norvex_sitemap_settings' ) ? ! empty( norvex_sitemap_settings()['sitemap_enabled'] ) : true;

	$checklist = array(
		array(
			(bool) norvex_demo_is_imported(),
			__( 'Import the demo content', 'norvex' ),
			admin_url( 'admin.php?page=norvex-hub' ),
		),
		array(
			has_custom_logo(),
			__( 'Add your logo', 'norvex' ),
			admin_url( 'customize.php?autofocus[section]=title_tagline' ),
		),
		array(
			(bool) $menu_set,
			__( 'Build your navigation menu', 'norvex' ),
			admin_url( 'nav-menus.php' ),
		),
		array(
			(bool) is_email( $email ),
			__( 'Set your contact email', 'norvex' ),
			admin_url( 'customize.php?autofocus[section]=norvex_contact' ),
		),
		array(
			(bool) $smtp_on,
			__( 'Set up reliable email delivery (SMTP)', 'norvex' ),
			admin_url( 'admin.php?page=norvex-smtp' ),
		),
		array(
			(bool) $tracking_on,
			__( 'Connect analytics (GA4 / Tag Manager / Pixel)', 'norvex' ),
			admin_url( 'admin.php?page=norvex-tracking' ),
		),
		array(
			(bool) $sitemap_on,
			__( 'Enable the XML sitemap', 'norvex' ),
			admin_url( 'admin.php?page=norvex-tracking' ),
		),
	);

	$done  = count( array_filter( wp_list_pluck( $checklist, 0 ) ) );
	$total = count( $checklist );

	// --- Stats ---
	$count = function ( $type, $status ) {
		$counts = wp_count_posts( $type );
		return $counts && isset( $counts->$status ) ? (int) $counts->$status : 0;
	};
	$leads_total = $count( 'norvex_lead', 'private' ) + $count( 'norvex_lead', 'publish' );
	$leads_month = function_exists( 'norvex_leads_this_month' ) ? norvex_leads_this_month() : 0;
	$subscribers = $count( 'norvex_subscriber', 'private' ) + $count( 'norvex_subscriber', 'publish' );

	$stats = array(
		array( $leads_total, __( 'Leads', 'norvex' ), admin_url( 'edit.php?post_type=norvex_lead' ) ),
		array( $leads_month, __( 'Leads this month', 'norvex' ), admin_url( 'edit.php?post_type=norvex_lead' ) ),
		array( $subscribers, __( 'Subscribers', 'norvex' ), admin_url( 'edit.php?post_type=norvex_subscriber' ) ),
		array( $count( 'book', 'publish' ), __( 'Portfolio books', 'norvex' ), admin_url( 'edit.php?post_type=book' ) ),
		array( $count( 'norvex_service', 'publish' ), __( 'Services', 'norvex' ), admin_url( 'edit.php?post_type=norvex_service' ) ),
	);

	// --- Recent leads ---
	$recent = get_posts(
		array(
			'post_type'   => 'norvex_lead',
			'post_status' => array( 'private', 'publish' ),
			'numberposts' => 5,
		)
	);
	?>
	<div style="display:grid;grid-template-columns:minmax(0,1.1fr) minmax(0,0.9fr);gap:18px;max-width:1000px;margin-top:22px;align-items:start;">

		<!-- Setup checklist -->
		<div style="background:#fff;border:1px solid #dcdcde;border-radius:8px;padding:20px 22px;box-shadow:0 1px 2px rgba(0,0,0,.04);">
			<h2 style="margin:0 0 4px;display:flex;align-items:center;gap:8px;">
				<span class="dashicons dashicons-yes"></span>
				<?php esc_html_e( 'Setup checklist', 'norvex' ); ?>
				<span style="margin-left:auto;font-size:13px;font-weight:400;color:#646970;">
					<?php
					/* translators: 1: completed steps, 2: total steps. */
					echo esc_html( sprintf( __( '%1$d of %2$d done', 'norvex' ), $done, $total ) );
					?>
				</span>
			</h2>
			<div style="height:6px;background:#f0f0f1;border-radius:99px;overflow:hidden;margin:10px 0 16px;">
				<div style="height:100%;width:<?php echo esc_attr( $total ? round( $done / $total * 100 ) : 0 ); ?>%;background:#00a32a;"></div>
			</div>
			<ul style="margin:0;padding:0;list-style:none;">
				<?php foreach ( $checklist as $item ) : ?>
					<li style="display:flex;align-items:center;gap:10px;padding:7px 0;border-top:1px solid #f3f3f4;">
						<span class="dashicons <?php echo $item[0] ? 'dashicons-yes-alt' : 'dashicons-marker'; ?>" style="color:<?php echo $item[0] ? '#00a32a' : '#c0c0c0'; ?>;"></span>
						<span style="flex:1;<?php echo $item[0] ? 'color:#646970;text-decoration:line-through;' : ''; ?>"><?php echo esc_html( $item[1] ); ?></span>
						<?php if ( ! $item[0] ) : ?>
							<a href="<?php echo esc_url( $item[2] ); ?>" class="button button-small"><?php esc_html_e( 'Set up', 'norvex' ); ?></a>
						<?php endif; ?>
					</li>
				<?php endforeach; ?>
			</ul>
		</div>

		<!-- Stats + recent leads -->
		<div style="display:grid;gap:18px;">
			<div style="background:#fff;border:1px solid #dcdcde;border-radius:8px;padding:20px 22px;box-shadow:0 1px 2px rgba(0,0,0,.04);">
				<h2 style="margin:0 0 12px;"><?php esc_html_e( 'At a glance', 'norvex' ); ?></h2>
				<div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(120px,1fr));gap:10px;">
					<?php foreach ( $stats as $stat ) : ?>
						<a href="<?php echo esc_url( $stat[2] ); ?>" style="display:block;text-decoration:none;background:#ffffff;border:1px solid #eee;border-radius:6px;padding:12px 14px;color:#1d2327;">
							<strong style="display:block;font-size:22px;line-height:1.1;color:#c08a3e;"><?php echo esc_html( number_format_i18n( $stat[0] ) ); ?></strong>
							<span style="font-size:12px;color:#646970;"><?php echo esc_html( $stat[1] ); ?></span>
						</a>
					<?php endforeach; ?>
				</div>
			</div>

			<div style="background:#fff;border:1px solid #dcdcde;border-radius:8px;padding:20px 22px;box-shadow:0 1px 2px rgba(0,0,0,.04);">
				<h2 style="margin:0 0 10px;display:flex;align-items:center;gap:8px;">
					<?php esc_html_e( 'Recent leads', 'norvex' ); ?>
					<a href="<?php echo esc_url( admin_url( 'edit.php?post_type=norvex_lead' ) ); ?>" style="margin-left:auto;font-size:12px;font-weight:400;"><?php esc_html_e( 'View all', 'norvex' ); ?></a>
				</h2>
				<?php if ( $recent ) : ?>
					<ul style="margin:0;padding:0;list-style:none;">
						<?php foreach ( $recent as $lead ) : ?>
							<li style="padding:7px 0;border-top:1px solid #f3f3f4;font-size:13px;">
								<a href="<?php echo esc_url( get_edit_post_link( $lead->ID ) ); ?>" style="font-weight:600;text-decoration:none;"><?php echo esc_html( get_the_title( $lead ) ); ?></a>
								<span style="color:#646970;">— <?php echo esc_html( get_post_meta( $lead->ID, '_norvex_lead_email', true ) ); ?></span>
								<span style="display:block;color:#909090;font-size:12px;"><?php echo esc_html( get_the_date( '', $lead ) . ' ' . get_the_time( '', $lead ) ); ?></span>
							</li>
						<?php endforeach; ?>
					</ul>
				<?php else : ?>
					<p style="color:#646970;font-size:13px;margin:6px 0 0;"><?php esc_html_e( 'No enquiries yet. Contact-form submissions will appear here — and are emailed to you too.', 'norvex' ); ?></p>
				<?php endif; ?>
			</div>
		</div>
	</div>
	<?php
}
