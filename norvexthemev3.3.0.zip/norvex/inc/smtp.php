<?php
/**
 * SMTP email delivery + test/preview tool.
 *
 * Routes WordPress's wp_mail() (used by the theme's contact form and newsletter
 * signup) through an SMTP server so messages actually reach the inbox instead of
 * silently failing on hosts with no local mail transport. Settings live under
 * Norvex → Email (SMTP), where an admin can also send a test message and
 * preview exactly what the theme's notification emails look like.
 *
 * A dedicated deliverability plugin (e.g. WP Mail SMTP) can still take over — if
 * another plugin has already reconfigured PHPMailer for SMTP, leave this off.
 *
 * @package Norvex
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * SMTP settings, merged over defaults so every key is always present.
 *
 * @return array{enabled:bool,host:string,port:int,encryption:string,auth:bool,username:string,password:string,from_email:string,from_name:string}
 */
function norvex_smtp_settings() {
	$defaults = array(
		'enabled'    => false,
		'host'       => '',
		'port'       => 587,
		'encryption' => 'tls', // '', 'ssl', 'tls'.
		'auth'       => true,
		'username'   => '',
		'password'   => '',
		'from_email' => '',
		'from_name'  => '',
	);
	$stored = get_option( 'norvex_smtp', array() );
	if ( ! is_array( $stored ) ) {
		$stored = array();
	}
	return wp_parse_args( $stored, $defaults );
}

/**
 * Is SMTP delivery switched on and pointed at a host?
 *
 * @return bool
 */
function norvex_smtp_is_active() {
	$s = norvex_smtp_settings();
	return ! empty( $s['enabled'] ) && '' !== trim( (string) $s['host'] );
}

/**
 * Configure PHPMailer to use the SMTP server before WordPress sends.
 *
 * @param PHPMailer\PHPMailer\PHPMailer $phpmailer PHPMailer instance (by ref).
 */
function norvex_smtp_configure( $phpmailer ) {
	if ( ! norvex_smtp_is_active() ) {
		return;
	}
	$s = norvex_smtp_settings();

	$phpmailer->isSMTP();
	$phpmailer->Host    = $s['host'];
	$phpmailer->Port    = (int) $s['port'];
	$phpmailer->SMTPAuth = ! empty( $s['auth'] );

	if ( ! empty( $s['auth'] ) ) {
		$phpmailer->Username = $s['username'];
		$phpmailer->Password = $s['password'];
	}

	if ( 'ssl' === $s['encryption'] || 'tls' === $s['encryption'] ) {
		$phpmailer->SMTPSecure = $s['encryption'];
	} else {
		$phpmailer->SMTPSecure  = '';
		$phpmailer->SMTPAutoTLS = false;
	}

	if ( is_email( $s['from_email'] ) ) {
		$phpmailer->setFrom( $s['from_email'], $s['from_name'] ? $s['from_name'] : '', false );
	}
}
add_action( 'phpmailer_init', 'norvex_smtp_configure' );

/**
 * Apply the configured From address/name to every outgoing email.
 */
function norvex_smtp_from_email( $email ) {
	$s = norvex_smtp_settings();
	return ( ! empty( $s['enabled'] ) && is_email( $s['from_email'] ) ) ? $s['from_email'] : $email;
}
add_filter( 'wp_mail_from', 'norvex_smtp_from_email' );

function norvex_smtp_from_name( $name ) {
	$s = norvex_smtp_settings();
	return ( ! empty( $s['enabled'] ) && '' !== trim( (string) $s['from_name'] ) ) ? $s['from_name'] : $name;
}
add_filter( 'wp_mail_from_name', 'norvex_smtp_from_name' );

/**
 * Record the reason a wp_mail() call failed, so the test tool can show it.
 *
 * @param WP_Error $error The mailer error.
 */
function norvex_smtp_capture_error( $error ) {
	$GLOBALS['norvex_smtp_last_error'] = $error->get_error_message();
}
add_action( 'wp_mail_failed', 'norvex_smtp_capture_error' );

/* -------------------------------------------------------------------------
 * Admin: settings page under the Norvex hub.
 * ---------------------------------------------------------------------- */

/**
 * Register the "Email (SMTP)" submenu under the Norvex hub.
 */
function norvex_smtp_menu() {
	add_submenu_page(
		'norvex-hub',
		__( 'Email (SMTP)', 'norvex' ),
		__( 'Email (SMTP)', 'norvex' ),
		'manage_options',
		'norvex-smtp',
		'norvex_smtp_page'
	);
}
add_action( 'admin_menu', 'norvex_smtp_menu', 11 );

/**
 * Build the sample notification emails so an admin can preview what visitors'
 * actions actually send. Mirrors inc/contact-form.php and inc/newsletter.php.
 *
 * @return array<string,array{subject:string,body:string}>
 */
function norvex_smtp_preview_samples() {
	$site = wp_specialchars_decode( get_bloginfo( 'name' ), ENT_QUOTES );

	$contact_lines = array(
		sprintf( __( 'Name: %s', 'norvex' ), __( 'Jane Author', 'norvex' ) ),
		sprintf( __( 'Email: %s', 'norvex' ), 'jane@example.com' ),
		sprintf( __( 'Service: %s', 'norvex' ), __( 'Editing & proofreading', 'norvex' ) ),
		'',
		__( 'Message:', 'norvex' ),
		__( 'I have a 60,000-word memoir and would love help getting it ready to publish.', 'norvex' ),
	);

	return array(
		'contact'    => array(
			/* translators: %s: site name. */
			'subject' => sprintf( __( '[%s] New consultation request', 'norvex' ), $site ),
			'body'    => implode( "\n", $contact_lines ),
		),
		'newsletter' => array(
			/* translators: %s: site name. */
			'subject' => sprintf( __( '[%s] New newsletter subscriber', 'norvex' ), $site ),
			/* translators: %s: subscriber email. */
			'body'    => sprintf( __( 'New subscriber: %s', 'norvex' ), 'reader@example.com' ),
		),
	);
}

/**
 * Render the SMTP settings + test/preview screen.
 */
function norvex_smtp_page() {
	if ( ! current_user_can( 'manage_options' ) ) {
		return;
	}
	$s      = norvex_smtp_settings();
	$active = norvex_smtp_is_active();

	// One-time notices after a save or a test (stored per-user to survive the
	// Post/Redirect/Get round-trip from admin-post.php).
	$test = get_transient( 'norvex_smtp_test_' . get_current_user_id() );
	if ( false !== $test ) {
		delete_transient( 'norvex_smtp_test_' . get_current_user_id() );
	}

	$encs = array(
		''    => __( 'None', 'norvex' ),
		'tls' => __( 'TLS (usually port 587)', 'norvex' ),
		'ssl' => __( 'SSL (usually port 465)', 'norvex' ),
	);
	?>
	<div class="wrap">
		<h1 style="display:flex;align-items:center;gap:10px;">
			<span class="dashicons dashicons-email-alt" style="font-size:28px;width:28px;height:28px;"></span>
			<?php esc_html_e( 'Email delivery (SMTP)', 'norvex' ); ?>
		</h1>
		<p style="font-size:14px;max-width:760px;color:#50575e;">
			<?php esc_html_e( 'Send the theme’s contact-form and newsletter emails through your own SMTP server so they reliably reach the inbox. Fill in the details from your email host or transactional-email provider, save, then send yourself a test.', 'norvex' ); ?>
		</p>

		<?php if ( isset( $_GET['norvex_smtp_saved'] ) ) : // phpcs:ignore WordPress.Security.NonceVerification.Recommended ?>
			<div class="notice notice-success is-dismissible"><p><?php esc_html_e( 'Email settings saved.', 'norvex' ); ?></p></div>
		<?php endif; ?>

		<?php if ( is_array( $test ) ) : ?>
			<?php if ( ! empty( $test['sent'] ) ) : ?>
				<div class="notice notice-success is-dismissible">
					<p><strong><?php esc_html_e( 'Test email sent.', 'norvex' ); ?></strong>
					<?php
					/* translators: %s: recipient email address. */
					echo esc_html( sprintf( __( 'WordPress handed the message to %s. Check that inbox (and its spam folder).', 'norvex' ), $test['to'] ) );
					?></p>
				</div>
			<?php else : ?>
				<div class="notice notice-error is-dismissible">
					<p><strong><?php esc_html_e( 'Test email failed.', 'norvex' ); ?></strong>
					<?php if ( ! empty( $test['error'] ) ) : ?>
						<br><code style="white-space:pre-wrap;"><?php echo esc_html( $test['error'] ); ?></code>
					<?php endif; ?></p>
				</div>
			<?php endif; ?>
		<?php endif; ?>

		<div style="display:grid;grid-template-columns:minmax(0,1fr) minmax(0,360px);gap:24px;align-items:start;max-width:1100px;margin-top:12px;">

			<div style="background:#fff;border:1px solid #dcdcde;border-radius:8px;padding:22px 24px;box-shadow:0 1px 2px rgba(0,0,0,.04);">
				<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
					<input type="hidden" name="action" value="norvex_save_smtp" />
					<?php wp_nonce_field( 'norvex_save_smtp' ); ?>
					<table class="form-table" role="presentation">
						<tr>
							<th scope="row"><?php esc_html_e( 'Enable SMTP', 'norvex' ); ?></th>
							<td>
								<label>
									<input type="checkbox" name="norvex_smtp[enabled]" value="1" <?php checked( ! empty( $s['enabled'] ) ); ?> />
									<?php esc_html_e( 'Route all site email through the SMTP server below', 'norvex' ); ?>
								</label>
							</td>
						</tr>
						<tr>
							<th scope="row"><label for="norvex-smtp-host"><?php esc_html_e( 'SMTP host', 'norvex' ); ?></label></th>
							<td><input name="norvex_smtp[host]" id="norvex-smtp-host" type="text" class="regular-text" value="<?php echo esc_attr( $s['host'] ); ?>" placeholder="smtp.example.com" /></td>
						</tr>
						<tr>
							<th scope="row"><label for="norvex-smtp-port"><?php esc_html_e( 'Port', 'norvex' ); ?></label></th>
							<td><input name="norvex_smtp[port]" id="norvex-smtp-port" type="number" min="1" max="65535" class="small-text" value="<?php echo esc_attr( (string) $s['port'] ); ?>" /></td>
						</tr>
						<tr>
							<th scope="row"><label for="norvex-smtp-enc"><?php esc_html_e( 'Encryption', 'norvex' ); ?></label></th>
							<td>
								<select name="norvex_smtp[encryption]" id="norvex-smtp-enc">
									<?php foreach ( $encs as $val => $lbl ) : ?>
										<option value="<?php echo esc_attr( $val ); ?>" <?php selected( $s['encryption'], $val ); ?>><?php echo esc_html( $lbl ); ?></option>
									<?php endforeach; ?>
								</select>
							</td>
						</tr>
						<tr>
							<th scope="row"><?php esc_html_e( 'Authentication', 'norvex' ); ?></th>
							<td>
								<label>
									<input type="checkbox" name="norvex_smtp[auth]" value="1" <?php checked( ! empty( $s['auth'] ) ); ?> />
									<?php esc_html_e( 'Server requires a username and password', 'norvex' ); ?>
								</label>
							</td>
						</tr>
						<tr>
							<th scope="row"><label for="norvex-smtp-user"><?php esc_html_e( 'Username', 'norvex' ); ?></label></th>
							<td><input name="norvex_smtp[username]" id="norvex-smtp-user" type="text" class="regular-text" value="<?php echo esc_attr( $s['username'] ); ?>" autocomplete="off" /></td>
						</tr>
						<tr>
							<th scope="row"><label for="norvex-smtp-pass"><?php esc_html_e( 'Password', 'norvex' ); ?></label></th>
							<td>
								<input name="norvex_smtp[password]" id="norvex-smtp-pass" type="password" class="regular-text" value="" autocomplete="new-password" placeholder="<?php echo $s['password'] ? esc_attr__( '••••••••  (leave blank to keep current)', 'norvex' ) : ''; ?>" />
								<p class="description"><?php esc_html_e( 'Stored in your database. Leave blank to keep the saved password; use an app-specific password where your provider offers one.', 'norvex' ); ?></p>
							</td>
						</tr>
						<tr><th colspan="2"><hr style="border:none;border-top:1px solid #eee;margin:4px 0;" /></th></tr>
						<tr>
							<th scope="row"><label for="norvex-smtp-from"><?php esc_html_e( 'From address', 'norvex' ); ?></label></th>
							<td><input name="norvex_smtp[from_email]" id="norvex-smtp-from" type="email" class="regular-text" value="<?php echo esc_attr( $s['from_email'] ); ?>" placeholder="<?php echo esc_attr( get_option( 'admin_email' ) ); ?>" /></td>
						</tr>
						<tr>
							<th scope="row"><label for="norvex-smtp-fromname"><?php esc_html_e( 'From name', 'norvex' ); ?></label></th>
							<td><input name="norvex_smtp[from_name]" id="norvex-smtp-fromname" type="text" class="regular-text" value="<?php echo esc_attr( $s['from_name'] ); ?>" placeholder="<?php echo esc_attr( wp_specialchars_decode( get_bloginfo( 'name' ), ENT_QUOTES ) ); ?>" /></td>
						</tr>
					</table>
					<?php submit_button( __( 'Save email settings', 'norvex' ) ); ?>
				</form>
			</div>

			<div style="display:grid;gap:20px;">
				<div style="background:#fff;border:1px solid #dcdcde;border-left:4px solid #c08a3e;border-radius:8px;padding:20px 22px;box-shadow:0 1px 2px rgba(0,0,0,.04);">
					<h2 style="margin-top:0;"><?php esc_html_e( 'Send a test email', 'norvex' ); ?></h2>
					<p style="color:#50575e;">
						<?php
						echo esc_html(
							$active
								? __( 'SMTP is active. Send a test message to confirm delivery.', 'norvex' )
								: __( 'SMTP is off — this will use your server’s default PHP mail. Enable and save SMTP above first for a real test.', 'norvex' )
						);
						?>
					</p>
					<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
						<input type="hidden" name="action" value="norvex_send_test_email" />
						<?php wp_nonce_field( 'norvex_send_test_email' ); ?>
						<p>
							<label for="norvex-smtp-testto" style="display:block;font-weight:600;margin-bottom:4px;"><?php esc_html_e( 'Send to', 'norvex' ); ?></label>
							<input name="norvex_test_to" id="norvex-smtp-testto" type="email" class="regular-text" value="<?php echo esc_attr( wp_get_current_user()->user_email ); ?>" required />
						</p>
						<?php submit_button( __( 'Send test email', 'norvex' ), 'secondary', 'submit', false ); ?>
					</form>
				</div>

				<div style="background:#fff;border:1px solid #dcdcde;border-radius:8px;padding:20px 22px;box-shadow:0 1px 2px rgba(0,0,0,.04);">
					<h2 style="margin-top:0;"><?php esc_html_e( 'Preview: what visitors send', 'norvex' ); ?></h2>
					<p style="color:#50575e;font-size:13px;">
						<?php
						$from_show = is_email( $s['from_email'] ) ? $s['from_email'] : get_option( 'admin_email' );
						/* translators: 1: from address, 2: contact recipient address. */
						echo esc_html( sprintf( __( 'Sent from %1$s to your contact address (%2$s).', 'norvex' ), $from_show, norvex_option( 'norvex_email', get_option( 'admin_email' ) ) ) );
						?>
					</p>
					<?php foreach ( norvex_smtp_preview_samples() as $sample ) : ?>
						<p style="margin:14px 0 4px;font-weight:600;"><?php echo esc_html( $sample['subject'] ); ?></p>
						<pre style="background:#f6f7f7;border:1px solid #e0e0e0;border-radius:6px;padding:12px 14px;white-space:pre-wrap;font-size:12.5px;margin:0;"><?php echo esc_html( $sample['body'] ); ?></pre>
					<?php endforeach; ?>
				</div>
			</div>
		</div>
	</div>
	<?php
}

/**
 * Persist the SMTP settings (admin-post handler).
 */
function norvex_smtp_save() {
	if ( ! current_user_can( 'manage_options' ) ) {
		wp_die( esc_html__( 'You are not allowed to do that.', 'norvex' ) );
	}
	check_admin_referer( 'norvex_save_smtp' );

	$in       = isset( $_POST['norvex_smtp'] ) && is_array( $_POST['norvex_smtp'] ) ? wp_unslash( $_POST['norvex_smtp'] ) : array(); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- each field sanitized individually below.
	$existing = norvex_smtp_settings();

	$enc = isset( $in['encryption'] ) ? sanitize_key( $in['encryption'] ) : '';
	if ( ! in_array( $enc, array( '', 'ssl', 'tls' ), true ) ) {
		$enc = '';
	}

	// Password: keep the stored value when the field is submitted blank, so the
	// secret never has to be re-typed (and is never echoed back into the form).
	$posted_pw = isset( $in['password'] ) ? trim( (string) $in['password'] ) : '';
	$password  = ( '' === $posted_pw ) ? $existing['password'] : $posted_pw;

	$settings = array(
		'enabled'    => ! empty( $in['enabled'] ),
		'host'       => isset( $in['host'] ) ? sanitize_text_field( $in['host'] ) : '',
		'port'       => isset( $in['port'] ) ? min( 65535, max( 1, absint( $in['port'] ) ) ) : 587,
		'encryption' => $enc,
		'auth'       => ! empty( $in['auth'] ),
		'username'   => isset( $in['username'] ) ? sanitize_text_field( $in['username'] ) : '',
		'password'   => $password,
		'from_email' => isset( $in['from_email'] ) ? sanitize_email( $in['from_email'] ) : '',
		'from_name'  => isset( $in['from_name'] ) ? sanitize_text_field( $in['from_name'] ) : '',
	);

	// Not autoloaded: read only in the admin and when sending mail.
	update_option( 'norvex_smtp', $settings, false );

	wp_safe_redirect( add_query_arg( 'norvex_smtp_saved', '1', admin_url( 'admin.php?page=norvex-smtp' ) ) );
	exit;
}
add_action( 'admin_post_norvex_save_smtp', 'norvex_smtp_save' );

/**
 * Send a test email and record the outcome (admin-post handler).
 */
function norvex_smtp_send_test() {
	if ( ! current_user_can( 'manage_options' ) ) {
		wp_die( esc_html__( 'You are not allowed to do that.', 'norvex' ) );
	}
	check_admin_referer( 'norvex_send_test_email' );

	$to = isset( $_POST['norvex_test_to'] ) ? sanitize_email( wp_unslash( $_POST['norvex_test_to'] ) ) : '';
	if ( ! is_email( $to ) ) {
		$to = get_option( 'admin_email' );
	}

	$site    = wp_specialchars_decode( get_bloginfo( 'name' ), ENT_QUOTES );
	/* translators: %s: site name. */
	$subject = sprintf( __( '[%s] SMTP test email', 'norvex' ), $site );
	$body    = implode(
		"\n",
		array(
			__( 'This is a test email from your Norvex theme.', 'norvex' ),
			'',
			norvex_smtp_is_active()
				/* translators: %s: SMTP host. */
				? sprintf( __( 'Sent via SMTP host: %s', 'norvex' ), norvex_smtp_settings()['host'] )
				: __( 'Sent via the server’s default PHP mail (SMTP is off).', 'norvex' ),
			/* translators: %s: date/time. */
			sprintf( __( 'Time: %s', 'norvex' ), current_time( 'mysql' ) ),
		)
	);

	unset( $GLOBALS['norvex_smtp_last_error'] );
	$sent = wp_mail( $to, $subject, $body, array( 'Content-Type: text/plain; charset=UTF-8' ) );

	set_transient(
		'norvex_smtp_test_' . get_current_user_id(),
		array(
			'sent'  => (bool) $sent,
			'to'    => $to,
			'error' => isset( $GLOBALS['norvex_smtp_last_error'] ) ? (string) $GLOBALS['norvex_smtp_last_error'] : '',
		),
		60
	);

	wp_safe_redirect( admin_url( 'admin.php?page=norvex-smtp' ) );
	exit;
}
add_action( 'admin_post_norvex_send_test_email', 'norvex_smtp_send_test' );
