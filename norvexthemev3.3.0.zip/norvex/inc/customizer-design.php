<?php
/**
 * Design manager — colors & typography.
 *
 * Adds a Customizer section that overrides Norvex's core CSS variables
 * (accent, ink, heading & body fonts, base size) so the whole theme can be
 * re-skinned from the dashboard without editing theme.css.
 *
 * @package Norvex
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Font choices for the heading/body selects: key => label.
 */
function norvex_font_choices() {
	// Only fonts bundled locally with the theme are offered, so no visitor IP is
	// ever sent to a third-party font CDN (Google Fonts) at render time — keeping
	// the self-hosted, GDPR-friendly promise the theme makes in functions.php.
	return array(
		'playfair' => 'Playfair Display (default heading)',
		'inter'    => 'Inter (default body)',
		'system'   => 'System sans',
	);
}

/**
 * Map a font key to a CSS font-family stack.
 */
function norvex_font_stack( $key ) {
	$stacks = array(
		'cormorant'    => '"Cormorant Garamond", "Iowan Old Style", "Palatino Linotype", Georgia, serif',
		'playfair'     => '"Playfair Display", "Iowan Old Style", "Palatino Linotype", Georgia, serif',
		'lora'         => '"Lora", Georgia, serif',
		'merriweather' => '"Merriweather", Georgia, serif',
		'mulish'       => '"Mulish", -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif',
		'inter'        => '"Inter", -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif',
		'montserrat'   => '"Montserrat", -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif',
		'poppins'      => '"Poppins", -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif',
		'roboto'       => '"Roboto", -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif',
		'system'       => '-apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif',
	);
	return isset( $stacks[ $key ] ) ? $stacks[ $key ] : $stacks['inter'];
}

/**
 * Sanitize a font key against the allowed list.
 */
function norvex_sanitize_font( $value ) {
	return array_key_exists( $value, norvex_font_choices() ) ? $value : '';
}

/**
 * Darken a hex color by a percentage (for deriving the gold-dark shade).
 *
 * @param string $hex     e.g. #c08a3e
 * @param float  $percent 0–1, portion to remove from each channel.
 * @return string Hex color.
 */
function norvex_darken_hex( $hex, $percent = 0.18 ) {
	$hex = ltrim( (string) $hex, '#' );
	if ( 3 === strlen( $hex ) ) {
		$hex = $hex[0] . $hex[0] . $hex[1] . $hex[1] . $hex[2] . $hex[2];
	}
	if ( 6 !== strlen( $hex ) ) {
		return '#' . $hex;
	}
	$r = max( 0, min( 255, (int) round( hexdec( substr( $hex, 0, 2 ) ) * ( 1 - $percent ) ) ) );
	$g = max( 0, min( 255, (int) round( hexdec( substr( $hex, 2, 2 ) ) * ( 1 - $percent ) ) ) );
	$b = max( 0, min( 255, (int) round( hexdec( substr( $hex, 4, 2 ) ) * ( 1 - $percent ) ) ) );
	return sprintf( '#%02x%02x%02x', $r, $g, $b );
}

/**
 * Register the Design section and its controls.
 */
function norvex_customize_design( $wp_customize ) {
	$wp_customize->add_section(
		'norvex_design',
		array(
			'title'       => __( 'Norvex · Design (Colors & Fonts)', 'norvex' ),
			'priority'    => 20,
			'description' => __( 'Re-skin the whole theme: accent color, ink color and fonts. Leave defaults for the standard Norvex look.', 'norvex' ),
		)
	);

	$controls = array(
		'norvex_accent_color' => array( 'label' => __( 'Accent color (gold)', 'norvex' ), 'default' => '#c08a3e', 'type' => 'color' ),
		'norvex_ink_color'    => array( 'label' => __( 'Ink color (headings, dark UI)', 'norvex' ), 'default' => '#1c2438', 'type' => 'color' ),
		'norvex_heading_font' => array( 'label' => __( 'Heading font', 'norvex' ), 'default' => 'playfair', 'type' => 'font' ),
		'norvex_body_font'    => array( 'label' => __( 'Body font', 'norvex' ), 'default' => 'inter', 'type' => 'font' ),
		'norvex_base_font_size' => array( 'label' => __( 'Base font size (px · 13–20)', 'norvex' ), 'default' => 16, 'type' => 'number' ),
	);

	foreach ( $controls as $id => $cfg ) {
		$sanitize = 'sanitize_text_field';
		if ( 'color' === $cfg['type'] ) {
			$sanitize = 'sanitize_hex_color';
		} elseif ( 'font' === $cfg['type'] ) {
			$sanitize = 'norvex_sanitize_font';
		} elseif ( 'number' === $cfg['type'] ) {
			$sanitize = 'absint';
		}

		$wp_customize->add_setting(
			$id,
			array(
				'default'           => $cfg['default'],
				'sanitize_callback' => $sanitize,
				'transport'         => 'refresh',
			)
		);

		if ( 'color' === $cfg['type'] ) {
			$wp_customize->add_control(
				new WP_Customize_Color_Control(
					$wp_customize,
					$id,
					array( 'label' => $cfg['label'], 'section' => 'norvex_design' )
				)
			);
		} elseif ( 'font' === $cfg['type'] ) {
			$wp_customize->add_control(
				$id,
				array(
					'label'   => $cfg['label'],
					'section' => 'norvex_design',
					'type'    => 'select',
					'choices' => norvex_font_choices(),
				)
			);
		} else {
			$wp_customize->add_control(
				$id,
				array(
					'label'       => $cfg['label'],
					'section'     => 'norvex_design',
					'type'        => 'number',
					'input_attrs' => array( 'min' => 13, 'max' => 20, 'step' => 1 ),
				)
			);
		}
	}
}
add_action( 'customize_register', 'norvex_customize_design' );

/**
 * Build the inline CSS that overrides Norvex's :root variables.
 *
 * @return string
 */
function norvex_design_css() {
	$accent  = sanitize_hex_color( get_theme_mod( 'norvex_accent_color', '#c08a3e' ) );
	$ink     = sanitize_hex_color( get_theme_mod( 'norvex_ink_color', '#1c2438' ) );
	$h_font  = get_theme_mod( 'norvex_heading_font', 'playfair' );
	$b_font  = get_theme_mod( 'norvex_body_font', 'inter' );
	// Base size: clamp into the supported 13–20px range instead of discarding
	// out-of-range values, so a typed-in number like 50 still responds (as 20)
	// rather than silently doing nothing. A blank/0 value falls back to 16.
	$raw     = absint( get_theme_mod( 'norvex_base_font_size', 16 ) );
	$size    = $raw ? min( 20, max( 13, $raw ) ) : 16;

	$vars = array();
	if ( $accent ) {
		$vars[] = '--norvex-gold:' . $accent;
		$vars[] = '--norvex-gold-dark:' . norvex_darken_hex( $accent, 0.18 );
	}
	if ( $ink ) {
		$vars[] = '--norvex-ink:' . $ink;
	}
	if ( $h_font ) {
		$vars[] = '--norvex-serif:' . norvex_font_stack( $h_font );
	}
	if ( $b_font ) {
		$vars[] = '--norvex-sans:' . norvex_font_stack( $b_font );
	}

	$css = '';
	if ( $vars ) {
		$css .= ':root{' . implode( ';', $vars ) . ';}';
	}
	if ( 16 !== $size ) {
		// Scale the whole type system: the theme sizes text in `rem`, which is
		// relative to the <html> root — not <body> — so the base size has to be
		// set on the root for headings, buttons and cards to scale with it.
		$css .= 'html{font-size:' . $size . 'px;}';
	}
	return $css;
}

/**
 * Attach the design CSS after the main stylesheet.
 */
function norvex_output_design_css() {
	$css = norvex_design_css();
	if ( $css ) {
		wp_add_inline_style( 'norvex-theme', $css );
	}
}
add_action( 'wp_enqueue_scripts', 'norvex_output_design_css', 20 );
