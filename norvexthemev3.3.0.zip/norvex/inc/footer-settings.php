<?php
/**
 * Editable footer content.
 *
 * Puts the footer's text into the Customizer so it can be edited from the
 * dashboard (Appearance → Customize → Norvex · Footer) instead of the
 * template: the "Services" column, the newsletter column heading/blurb and the
 * bottom-bar copyright line. The "Company" column stays menu-driven
 * (Appearance → Menus → Footer Menu), and the logo, about text, social links,
 * phone and address stay in Norvex · Contact & Social.
 *
 * @package Norvex
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Register the Footer Customizer section and its controls.
 */
function norvex_footer_customize( $wp_customize ) {
	$wp_customize->add_section(
		'norvex_footer',
		array(
			'title'       => __( 'Norvex · Footer', 'norvex' ),
			'description' => __( 'Edit the footer text. The “Company” links come from Appearance → Menus (Footer Menu); the logo, about text, social icons, phone and address are in Norvex · Contact & Social.', 'norvex' ),
			'priority'    => 40,
		)
	);

	$fields = array(
		'norvex_footer_services_title' => array(
			'label'   => __( 'Services column — heading', 'norvex' ),
			'type'    => 'text',
			'default' => __( 'Services', 'norvex' ),
		),
		'norvex_footer_services_links' => array(
			'label'       => __( 'Services column — links', 'norvex' ),
			'type'        => 'textarea',
			'default'     => '',
			'description' => __( 'One link per line as “Label | URL”. Leave blank to link to your Services page.', 'norvex' ),
		),
		'norvex_footer_news_title'     => array(
			'label'   => __( 'Newsletter column — heading', 'norvex' ),
			'type'    => 'text',
			'default' => __( 'Stay in the loop', 'norvex' ),
		),
		'norvex_footer_news_text'      => array(
			'label'   => __( 'Newsletter column — text', 'norvex' ),
			'type'    => 'textarea',
			'default' => __( 'Craft, publishing and marketing tips — twice a month, no spam.', 'norvex' ),
		),
		'norvex_footer_copyright'      => array(
			'label'       => __( 'Copyright line', 'norvex' ),
			'type'        => 'text',
			'default'     => __( '© {year} {site}. All rights reserved.', 'norvex' ),
			'description' => __( 'Use {year} for the current year and {site} for the site name.', 'norvex' ),
		),
	);

	foreach ( $fields as $id => $f ) {
		$wp_customize->add_setting(
			$id,
			array(
				'default'           => $f['default'],
				'sanitize_callback' => ( 'textarea' === $f['type'] ) ? 'sanitize_textarea_field' : 'sanitize_text_field',
			)
		);
		$wp_customize->add_control(
			$id,
			array(
				'label'       => $f['label'],
				'description' => isset( $f['description'] ) ? $f['description'] : '',
				'section'     => 'norvex_footer',
				'type'        => $f['type'],
			)
		);
	}
}
add_action( 'customize_register', 'norvex_footer_customize' );

/**
 * The footer copyright line, with {year}/{site} tokens resolved.
 *
 * @return string
 */
function norvex_footer_copyright() {
	$text = get_theme_mod( 'norvex_footer_copyright', __( '© {year} {site}. All rights reserved.', 'norvex' ) );
	$site = wp_specialchars_decode( get_bloginfo( 'name' ), ENT_QUOTES );
	return str_replace( array( '{year}', '{site}' ), array( gmdate( 'Y' ), $site ), $text );
}

/**
 * The footer "Services" column links as an array of array( label, url ).
 *
 * Falls back to four links to the Services page when the setting is blank.
 *
 * @return array<int,array{0:string,1:string}>
 */
function norvex_footer_services_links() {
	$raw = trim( (string) get_theme_mod( 'norvex_footer_services_links', '' ) );

	if ( '' === $raw ) {
		$services_url = get_permalink( get_page_by_path( 'services' ) );
		if ( ! $services_url ) {
			$services_url = home_url( '/' );
		}
		return array(
			array( __( 'Editing', 'norvex' ), $services_url ),
			array( __( 'Cover Design', 'norvex' ), $services_url ),
			array( __( 'Publishing', 'norvex' ), $services_url ),
			array( __( 'Marketing', 'norvex' ), $services_url ),
		);
	}

	$out = array();
	foreach ( preg_split( '/\r\n|\r|\n/', $raw ) as $line ) {
		$line = trim( $line );
		if ( '' === $line ) {
			continue;
		}
		$parts = array_map( 'trim', explode( '|', $line, 2 ) );
		$label = $parts[0];
		$url   = isset( $parts[1] ) && '' !== $parts[1] ? $parts[1] : '#';
		if ( '' !== $label ) {
			$out[] = array( $label, $url );
		}
	}
	return $out;
}
