<?php
/**
 * Editable content types.
 *
 * Turns the sections that used to be hard-coded in templates — Services,
 * Testimonials, Team, Pricing Plans and FAQs — into dashboard-managed custom
 * post types with simple meta boxes, so the whole site is editable with no code.
 *
 * @package Norvex
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Render an FAQ accordion from a plain array of [ question, answer ] pairs.
 *
 * FAQs are defined directly in the FAQ block on each page, so every page can
 * have its own set — there is no FAQ post type or dashboard editor to manage.
 *
 * @param array $items      Array of array( question, answer ).
 * @param bool  $first_open Whether to open the first item by default.
 */
function norvex_faq_accordion( $items, $first_open = true ) {
	if ( empty( $items ) || ! is_array( $items ) ) {
		return;
	}

	// Register these Q&As for the page's FAQPage JSON-LD (see inc/seo.php).
	if ( function_exists( 'norvex_seo_register_faqs' ) ) {
		norvex_seo_register_faqs( $items );
	}

	echo '<div class="norvex-faq">';
	$i = 0;
	foreach ( $items as $f ) {
		if ( empty( $f[0] ) ) {
			continue;
		}
		$open = ( 0 === $i && $first_open ) ? ' open' : '';
		printf(
			'<details%1$s><summary>%2$s</summary><p>%3$s</p></details>',
			esc_attr( $open ), // phpcs:ignore WordPress.Security.EscapeOutput
			esc_html( $f[0] ),
			esc_html( isset( $f[1] ) ? $f[1] : '' )
		);
		$i++;
	}
	echo '</div>';
}

/* ---------------------------------------------------------------------------
 * Built-in default content — used both as the template fallback (when no
 * editable items exist yet) and as the source for the demo seeder.
 * ------------------------------------------------------------------------- */

function norvex_default_services() {
	/*
	 * Each service is a self-contained, ready-to-publish page. Keys:
	 *   icon      Icon name (see norvex_icon()).
	 *   title     Service name.
	 *   slug      URL slug for the /service/{slug}/ page.
	 *   excerpt   One-line summary (service cards).
	 *   intro     Hero sub-headline on the service page.
	 *   body      Array of paragraphs for the "overview" section.
	 *   features  Deliverables checklist ("What's included").
	 *   image     Bundled illustration (assets/images/…).
	 *   packages  Array of pricing tiers: name, price, period, featured, desc, features[]
	 *             (prefix a feature with ! to show it greyed-out / not included).
	 *   faqs      Array of array( question, answer ).
	 */
	return array(

		array(
			'icon'    => 'quill',
			'title'   => 'Ghostwriting',
			'slug'    => 'ghostwriting',
			'excerpt' => 'A professional writer turns your concept, transcripts or rough draft into a finished manuscript — written in your voice.',
			'intro'   => 'Have the story but not the time? Our ghostwriters do the writing for you, in your voice — and you stay the sole, named author with 100% of the rights and royalties.',
			'body'    => array(
				'You know your story, your expertise and your message better than anyone — but turning that into a polished, publishable manuscript takes hundreds of hours and a particular craft. That is exactly what our ghostwriters are for.',
				'We start by listening. Through a series of relaxed interviews we capture how you think, speak and tell a story, then build a chapter-by-chapter outline you approve before a single page is written. From there we draft, you review, and we revise until every chapter genuinely sounds like you.',
				'The whole engagement is 100% confidential. Your name goes on the cover, you keep every right and royalty, and no one ever needs to know we were involved.',
			),
			'features' => array(
				'One-on-one discovery interviews',
				'Approved chapter-by-chapter outline',
				'Full manuscript drafted in your voice',
				'Two rounds of revisions included',
				'100% confidential — credited entirely to you',
				'You keep all rights and royalties',
			),
			'image'    => 'service-quill.svg',
			'packages' => array(
				array(
					'name' => 'Short Book', 'price' => '$5,495', 'period' => 'up to 20,000 words', 'featured' => false,
					'desc' => 'Ideal for a lead-magnet book, a business-card book or a focused non-fiction guide.',
					'features' => array( 'Up to 20,000 words', '2 discovery interviews', 'Chapter outline', '1 round of revisions', '!Developmental edit', '!Marketing launch' ),
				),
				array(
					'name' => 'Full Manuscript', 'price' => '$12,995', 'period' => 'up to 50,000 words', 'featured' => true,
					'desc' => 'Our most popular option — a complete, market-ready book from concept to final draft.',
					'features' => array( 'Up to 50,000 words', '5 discovery interviews', 'Detailed chapter outline', '2 rounds of revisions', 'Developmental edit included', 'Dedicated project manager' ),
				),
				array(
					'name' => 'Signature Author', 'price' => 'Custom', 'period' => '50,000+ words', 'featured' => false,
					'desc' => 'For memoirs, epics and thought-leadership books that need a longer, deeper collaboration.',
					'features' => array( 'Unlimited length', 'Ongoing interview access', 'Research & fact-checking', 'Unlimited revisions', 'Developmental + line edit', 'Priority scheduling' ),
				),
			),
			'faqs' => array(
				array( 'Will the book really sound like me?', 'Yes — that is the whole craft. We interview you, study how you speak and write, and revise until you read a chapter and think, "that\'s exactly how I would have said it."' ),
				array( 'Do I get credited as the author?', 'Always. You are the sole, named author. Ghostwriting is completely confidential and you keep 100% of the rights and royalties.' ),
				array( 'How involved do I need to be?', 'Mostly at the start (interviews and outline) and at review points. We do the heavy lifting of writing; you approve the direction and the drafts.' ),
				array( 'What if I don\'t like a draft?', 'Every package includes revision rounds. We refine chapters until you are happy — collaboration and feedback are built into the process.' ),
				array( 'How long does ghostwriting take?', 'A typical full manuscript takes 4–6 months depending on length and interview availability. You get a clear schedule with milestones after your consultation.' ),
			),
			'process' => array(
				array( 'Discovery', 'We interview you and gather notes, recordings or drafts to learn your voice and story.' ),
				array( 'Outline', 'We build a chapter-by-chapter outline and agree the structure before writing begins.' ),
				array( 'Writing', 'Your writer drafts chapters on a schedule; you review and give feedback as we go.' ),
				array( 'Polish', 'We refine through revision rounds until the manuscript is exactly right — and yours.' ),
			),
		),

		array(
			'icon'    => 'edit',
			'title'   => 'Book Editing',
			'slug'    => 'book-editing',
			'excerpt' => 'Developmental, line, copy and proof editing on a per-service or bundled basis, so your book reads clean and professional.',
			'intro'   => 'Great books are shaped in the edit. Our editors work in clear, ordered stages so your manuscript reads sharp, consistent and error-free from the first page to the last.',
			'body'    => array(
				'A brilliant idea can be let down by clumsy structure, uneven pacing or a scatter of typos — and readers notice. Professional editing is what separates a manuscript that feels self-published from one that feels like it came from a major imprint.',
				'We edit in the right order so your money goes where the manuscript needs it. Developmental editing fixes the big picture — structure, argument, pacing and clarity. Line and copy editing sharpen every sentence, tighten word choice and enforce consistency. A final proofread catches the last stray errors before print.',
				'Every project comes with a style sheet and an editorial letter, so you understand not just what changed but why — and your voice stays firmly your own.',
			),
			'features' => array(
				'Developmental / structural editing',
				'Line editing for flow and clarity',
				'Copy editing for grammar & consistency',
				'Final proofread before publishing',
				'Custom style sheet & editorial letter',
				'Tracked changes you stay in control of',
			),
			'image'    => 'service-edit.svg',
			'packages' => array(
				array(
					'name' => 'Proofreading', 'price' => 'from $299', 'period' => 'per manuscript', 'featured' => false,
					'desc' => 'A final polish for a manuscript that has already been edited and just needs a clean pass.',
					'features' => array( 'Spelling & punctuation', 'Grammar & typos', 'Formatting consistency', '!Line editing', '!Structural feedback', '!Style sheet' ),
				),
				array(
					'name' => 'Copy & Line Edit', 'price' => 'from $699', 'period' => 'per manuscript', 'featured' => true,
					'desc' => 'Our most popular edit — sentence-level polish plus grammar, consistency and a style sheet.',
					'features' => array( 'Everything in Proofreading', 'Line editing for flow', 'Word-choice & tone', 'Custom style sheet', 'Editorial summary', '!Developmental edit' ),
				),
				array(
					'name' => 'Developmental Edit', 'price' => 'from $1,299', 'period' => 'per manuscript', 'featured' => false,
					'desc' => 'The complete edit: big-picture structure work through to a final line-level polish.',
					'features' => array( 'Developmental / structural edit', 'Detailed editorial letter', 'Line & copy editing', 'Style sheet', 'Two passes', 'Final proofread included' ),
				),
			),
			'faqs' => array(
				array( 'Which type of editing do I need?', 'If your story or argument still needs shaping, start with a developmental edit. If the structure is solid and you want sharper prose, choose the copy & line edit. If it is already edited, a proofread is the final polish.' ),
				array( 'Will you change my voice?', 'Never. Good editing amplifies your voice and fixes what gets in its way. Every change is tracked and yours to accept or reject.' ),
				array( 'How is pricing calculated?', 'Editing is quoted from your manuscript\'s length and the level of edit you need. Send us your word count and we\'ll give you an exact price — no surprises.' ),
				array( 'Can I see a sample edit first?', 'Yes. We\'ll edit a few sample pages so you can feel the collaboration before committing to the full project.' ),
				array( 'How long does editing take?', 'A typical 60,000-word copy edit takes 2–3 weeks; a full developmental edit takes longer. You get a firm delivery date up front.' ),
			),
			'process' => array(
				array( 'Assessment', 'We review a sample and your word count to recommend the right level of edit and give an exact quote.' ),
				array( 'Editing', 'Your editor works through the manuscript with tracked changes and margin notes.' ),
				array( 'Editorial letter', 'You receive a style sheet and a clear letter explaining the changes and suggestions.' ),
				array( 'Final pass', 'We proofread the revised manuscript so it is clean and ready to publish.' ),
			),
		),

		array(
			'icon'    => 'design',
			'title'   => 'Book Design',
			'slug'    => 'book-design',
			'excerpt' => 'Original cover design and interior formatting for ebook and print that make your book look its best.',
			'intro'   => 'Readers really do judge a book by its cover — in about a tenth of a second. Our designers craft original covers and polished interiors built to make your book look like it belongs on a bestseller shelf.',
			'body'    => array(
				'A cover has one job in the instant a reader sees it on a thumbnail: signal the genre and make a promise. Get it right and you earn the click; get it wrong and the best writing in the world never gets read. The interior then has to keep that reader comfortable for hundreds of pages.',
				'Our designers start by studying the bestsellers in your category, then create distinct, original cover concepts. You choose a direction, we refine it to perfection, and deliver print-ready and ebook-ready files. Nothing is stock-template — every cover is designed for your book alone.',
				'Inside, we typeset your manuscript with professional layout, chapter styling and typography that reads beautifully in paperback, hardcover and ebook — so your book feels considered from the shelf to the last page.',
			),
			'features' => array(
				'Original cover concepts to choose from',
				'Unlimited refinement on your chosen concept',
				'Print & ebook cover files',
				'Professional interior formatting',
				'Chapter styling & typography',
				'Print-ready files for KDP & IngramSpark',
			),
			'image'    => 'service-design.svg',
			'packages' => array(
				array(
					'name' => 'Cover Design', 'price' => 'from $199', 'period' => 'one-time', 'featured' => false,
					'desc' => 'A standout, original cover for your ebook and paperback — designed to sell the click.',
					'features' => array( 'Original cover concepts', 'Front cover design', 'Ebook cover file', 'Full paperback wrap', '!Interior formatting', '!Hardcover jacket' ),
				),
				array(
					'name' => 'Cover + Interior', 'price' => 'from $499', 'period' => 'one-time', 'featured' => true,
					'desc' => 'Our most popular package — a cover and a beautifully formatted interior, print and ebook ready.',
					'features' => array( 'Original cover concepts', 'Print & ebook covers', 'Full interior formatting', 'Chapter & heading styling', 'Print-ready files', 'One revision round' ),
				),
				array(
					'name' => 'Premium Design', 'price' => 'from $999', 'period' => 'one-time', 'featured' => false,
					'desc' => 'The full treatment for illustrated, hardcover or highly designed books.',
					'features' => array( 'Everything in Cover + Interior', 'Hardcover jacket & case', 'Custom illustrations / motifs', 'Image & photo placement', 'Unlimited revisions', 'Marketing graphics pack' ),
				),
			),
			'faqs' => array(
				array( 'Are the designs original?', 'Yes — every cover is designed from scratch for your book. We never resell a template, so your cover is unique to you.' ),
				array( 'How many concepts do I get?', 'You receive several distinct cover concepts to choose from, then we refine your favourite until it\'s exactly right.' ),
				array( 'Will the files work with Amazon and IngramSpark?', 'Always. We deliver print-ready files built to each platform\'s exact specifications, so upload is smooth and trouble-free.' ),
				array( 'Do you design the inside of the book too?', 'Yes. Our Cover + Interior and Premium packages include full formatting — chapter styling, typography and layout for print and ebook.' ),
				array( 'Can you match a series or existing brand?', 'Absolutely. We can design to match an existing series, your author brand or a specific reference you love.' ),
			),
			'process' => array(
				array( 'Brief', 'We learn your genre, comparable titles and the mood you want the cover to strike.' ),
				array( 'Concepts', 'You receive several original directions and pick the one that fits your book.' ),
				array( 'Refine', 'We perfect your chosen concept and format the interior to match.' ),
				array( 'Deliver', 'You get print-ready and ebook-ready files, built to retailer specs.' ),
			),
		),

		array(
			'icon'    => 'book',
			'title'   => 'Book Publishing',
			'slug'    => 'book-publishing',
			'excerpt' => 'Distribution setup across Amazon KDP, IngramSpark, Apple Books, Kobo and Google Play — every account in your name.',
			'intro'   => 'We handle the technical maze of getting your book listed, priced and available everywhere readers shop — in print and digital — while every account is opened in your name and you keep 100% of your royalties.',
			'body'    => array(
				'Getting a finished manuscript onto Amazon, Apple Books, Barnes & Noble and thousands of retailers sounds simple until you are staring at ISBNs, trim sizes, metadata fields and royalty settings. One wrong choice can cost you sales for the life of the book.',
				'We do it all for you. We format and convert your book for both print and ebook, register ISBNs, write and optimise your metadata and categories, and set up your accounts on the platforms that matter — then upload, proof and publish.',
				'Crucially, every account is opened in your name and under your control. You own the book, you own the rights, and every royalty is paid directly to you. We are here to assist, never to take a cut of your work.',
			),
			'features' => array(
				'Print & ebook file formatting',
				'ISBN registration & assignment',
				'Metadata & category optimisation',
				'Amazon KDP, IngramSpark, Apple, Kobo & Google Play',
				'Every account set up in your name',
				'You keep the rights and royalties',
			),
			'image'    => 'service-book.svg',
			'packages' => array(
				array(
					'name' => 'Ebook Distribution', 'price' => 'from $249', 'period' => 'one-time', 'featured' => false,
					'desc' => 'Get your book selling as a professional ebook across all the major digital stores.',
					'features' => array( 'Ebook formatting (EPUB)', 'Metadata & keywords', 'Amazon Kindle setup', 'Apple, Kobo & Google Play', '!Print edition', '!ISBN' ),
				),
				array(
					'name' => 'Print & Ebook', 'price' => 'from $499', 'period' => 'one-time', 'featured' => true,
					'desc' => 'Our most popular setup — your book in paperback and ebook, everywhere readers shop.',
					'features' => array( 'Print & ebook formatting', 'ISBN included', 'Amazon KDP + IngramSpark', 'Global retail distribution', 'Proof copy review', 'Pricing & category strategy' ),
				),
				array(
					'name' => 'Wide Distribution', 'price' => 'from $899', 'period' => 'one-time', 'featured' => false,
					'desc' => 'Maximum reach — print, ebook and library/bookstore distribution with expanded channels.',
					'features' => array( 'Everything in Print & Ebook', 'Hardcover edition setup', 'Library & bookstore channels', 'Multiple ISBNs', 'Expanded metadata SEO', 'Priority publishing support' ),
				),
			),
			'faqs' => array(
				array( 'Do I keep the rights to my book?', 'Absolutely. Every retail account is opened in your name and under your control. You own the book outright and keep every royalty — we never take a share.' ),
				array( 'Where will my book be available?', 'Everywhere that matters: Amazon, Apple Books, Barnes & Noble, Kobo, Google Play and, with wide distribution, thousands of bookstores and libraries.' ),
				array( 'Do I need my own ISBN?', 'Not necessarily. Our Print & Ebook and Wide packages include ISBNs registered to you. If you already have your own, we\'ll use those.' ),
				array( 'How much do I earn per sale?', 'You keep 100% of the royalties the retailers pay — typically up to 70% of the list price on ebooks. We set your pricing to maximise that.' ),
				array( 'How long until my book is live?', 'Once files are approved, most books are live on every major retailer within 30 days. Print proofs add a few days for shipping and review.' ),
			),
			'process' => array(
				array( 'Set up accounts', 'We open Amazon, IngramSpark, Apple, Kobo and Google Play accounts in your name.' ),
				array( 'Format & convert', 'We prepare print and ebook files and register your ISBNs and metadata.' ),
				array( 'Proof', 'You review a proof of every edition before anything goes live.' ),
				array( 'Publish', 'We list your book everywhere and hand you the keys — royalties come straight to you.' ),
			),
		),

		array(
			'icon'    => 'megaphone',
			'title'   => 'Book Marketing',
			'slug'    => 'book-marketing',
			'excerpt' => 'Pre-launch positioning, ARC distribution coordination and Amazon Ads strategy that reach the right readers.',
			'intro'   => 'A finished book is the start line, not the finish. Our marketing team builds an author brand and a launch that connects your book with the readers who will love it.',
			'body'    => array(
				'The hardest part of publishing is not writing the book — it is getting it discovered. Thousands of good books are released every day and vanish because no one built momentum around them. Marketing is what turns a quiet release into a launch.',
				'We build you a clear launch strategy and timeline, sharpen your author brand and messaging, coordinate ARC (advance-reader copy) distribution, and run targeted advertising on Amazon and Meta to put your book in front of the exact readers searching for it. Around launch we coordinate reviews, email campaigns and media outreach so the momentum compounds.',
				'Everything is measured. You get regular reporting on reach, clicks and sales so you can see what your marketing budget is actually buying — no vanity metrics, just results.',
			),
			'features' => array(
				'Pre-launch strategy & timeline',
				'Author brand & messaging',
				'ARC distribution coordination',
				'Amazon Ads & Meta advertising',
				'Email & newsletter campaigns',
				'Transparent performance reporting',
			),
			'image'    => 'service-megaphone.svg',
			'packages' => array(
				array(
					'name' => 'Launch Kit', 'price' => 'from $1,495', 'period' => 'one-time', 'featured' => false,
					'desc' => 'Everything you need to launch well — strategy, assets, ARC coordination and a review push.',
					'features' => array( 'Launch strategy & timeline', 'Optimised book description', 'Social graphics pack', 'ARC & review outreach', '!Paid ad management', '!Ongoing campaigns' ),
				),
				array(
					'name' => 'Growth Campaign', 'price' => '$1,995', 'period' => 'per month', 'featured' => true,
					'desc' => 'Our most popular plan — managed advertising and marketing that keeps sales climbing.',
					'features' => array( 'Everything in Launch Kit', 'Amazon & Meta ad management', 'Ad spend optimisation', 'Email campaign setup', 'Monthly performance report', 'Dedicated marketer' ),
				),
				array(
					'name' => 'Bestseller Push', 'price' => 'Custom', 'period' => 'tailored', 'featured' => false,
					'desc' => 'An all-in campaign aimed at category bestseller status and lasting visibility.',
					'features' => array( 'Everything in Growth Campaign', 'Multi-channel advertising', 'PR & media outreach', 'Influencer partnerships', 'Launch-week blitz', 'Weekly strategy calls' ),
				),
			),
			'faqs' => array(
				array( 'Is ad spend included in the price?', 'The fee covers strategy and management. Advertising budget is separate and paid to the platforms directly, so 100% of it works for your book — we recommend a starting budget on your call.' ),
				array( 'When should marketing start?', 'Ideally 4–6 weeks before launch so we can build pre-orders and reviews. That said, we run campaigns for already-published books just as effectively.' ),
				array( 'Can you guarantee bestseller status?', 'No honest marketer can guarantee rankings, but our campaigns are built around the levers that drive them. We focus on real, sustainable sales rather than one-day spikes.' ),
				array( 'How do I know it\'s working?', 'You get regular reporting on reach, clicks, ad spend and sales — clear numbers, no vanity metrics — so you always see the return.' ),
				array( 'Do you help with reviews?', 'Yes. We coordinate ARC distribution and ethical review outreach to advance-reader teams and relevant communities — never fake or paid-for reviews, which violate retailer policies.' ),
			),
			'process' => array(
				array( 'Strategy', 'We map your audience, positioning and a launch timeline built around your goals.' ),
				array( 'Build', 'We prepare assets, optimise your listing and coordinate ARC and review outreach.' ),
				array( 'Advertise', 'We run and optimise Amazon and Meta campaigns to reach the right readers.' ),
				array( 'Report', 'You get clear reporting on reach, spend and sales — and we refine from there.' ),
			),
		),

		array(
			'icon'    => 'mic',
			'title'   => 'Book Coaching',
			'slug'    => 'book-coaching',
			'excerpt' => 'One-on-one work for authors writing the book themselves — accountability, structure and expert feedback.',
			'intro'   => 'Writing it yourself, but want a pro in your corner? Our coaches give you the structure, feedback and accountability to actually finish your book — and finish it well.',
			'body'    => array(
				'Most books that never get written don\'t fail for lack of talent — they fail for lack of a plan and someone to keep you moving. A good book coach is part strategist, part editor and part accountability partner, turning a vague ambition into a finished manuscript on a real schedule.',
				'We start by shaping your idea into a clear structure and a realistic writing plan. Then we meet regularly to review your pages, solve the problems that stall you, and keep you accountable to your word-count goals — so you make steady progress instead of stalling out.',
				'You keep full ownership of every word. The book is entirely yours; we simply give you the expert guidance and momentum to write the best version of it.',
			),
			'features' => array(
				'One-on-one coaching sessions',
				'Book structure & outline planning',
				'Chapter-by-chapter feedback',
				'Accountability & goal-setting',
				'Craft guidance on voice & pacing',
				'A clear path to a finished draft',
			),
			'image'    => 'service-mic.svg',
			'packages' => array(
				array(
					'name' => 'Starter Session', 'price' => 'from $549', 'period' => 'per session', 'featured' => false,
					'desc' => 'A focused one-on-one session to unblock, plan your book or get expert feedback.',
					'features' => array( '90-minute strategy session', 'Book idea & structure review', 'Personalised action plan', 'Session recording & notes', '!Ongoing accountability', '!Manuscript feedback' ),
				),
				array(
					'name' => 'Coaching Program', 'price' => 'from $1,499', 'period' => 'per month', 'featured' => true,
					'desc' => 'Our most popular plan — regular coaching that carries you from outline to finished draft.',
					'features' => array( 'Bi-weekly coaching calls', 'Full outline & writing plan', 'Chapter-by-chapter feedback', 'Accountability check-ins', 'Email support between calls', 'Craft & revision guidance' ),
				),
				array(
					'name' => 'Elite Author', 'price' => 'Custom', 'period' => 'tailored', 'featured' => false,
					'desc' => 'Intensive, high-touch coaching for authors on a deadline or a demanding project.',
					'features' => array( 'Weekly coaching calls', 'Priority manuscript review', 'Developmental guidance', 'Unlimited email support', 'Publishing & launch planning', 'Direct access to your coach' ),
				),
			),
			'faqs' => array(
				array( 'How is coaching different from ghostwriting?', 'With coaching, you write the book — we guide, structure and keep you accountable. With ghostwriting, our writer does the writing for you. Coaching is for authors who want to write it themselves.' ),
				array( 'Do I keep all the rights?', 'Completely. The book is 100% yours — every word, every right and every royalty. Coaching simply helps you write the best version of it.' ),
				array( 'How often will we meet?', 'It depends on your plan — from a single strategy session to weekly calls. Most authors do best with a regular bi-weekly rhythm that keeps momentum without pressure.' ),
				array( 'What if I\'m a first-time writer?', 'Perfect — that\'s exactly who coaching helps most. We meet you where you are and build the skills, structure and confidence as we go.' ),
				array( 'How long until I finish my book?', 'That depends on your pace and length, but a clear plan and regular accountability typically get first-time authors to a finished draft in a few months rather than years.' ),
			),
			'process' => array(
				array( 'Plan', 'We shape your idea into a clear structure and a realistic writing schedule.' ),
				array( 'Write', 'You draft on a steady rhythm while we keep you accountable to your goals.' ),
				array( 'Feedback', 'We review your pages and coach you through the problems that stall you.' ),
				array( 'Finish', 'You reach a complete, polished draft — ready for editing and publishing.' ),
			),
		),

	);
}

/**
 * Serialise a service's packages array into the editable text format used in
 * the meta box (and parsed back by norvex_parse_packages()).
 */
function norvex_packages_to_text( $packages ) {
	$blocks = array();
	foreach ( (array) $packages as $p ) {
		$head = '== ' . $p['name'] . ' | ' . $p['price'] . ' | ' . $p['period'];
		if ( ! empty( $p['featured'] ) ) {
			$head .= ' | popular';
		}
		$lines = array( $head );
		if ( ! empty( $p['desc'] ) ) {
			$lines[] = $p['desc'];
		}
		foreach ( (array) $p['features'] as $f ) {
			$lines[] = '- ' . $f;
		}
		$blocks[] = implode( "\n", $lines );
	}
	return implode( "\n\n", $blocks );
}

/**
 * Parse the packages text format back into a normalised array.
 *
 * Format:
 *   == Name | $Price | period | popular
 *   Short description line
 *   - Feature one
 *   - !Excluded feature
 */
function norvex_parse_packages( $raw ) {
	$out     = array();
	$current = null;
	foreach ( preg_split( '/\r\n|\r|\n/', (string) $raw ) as $line ) {
		$line = rtrim( $line );
		if ( '' === trim( $line ) ) {
			continue;
		}
		if ( '==' === substr( ltrim( $line ), 0, 2 ) ) {
			if ( $current ) {
				$out[] = $current;
			}
			$parts   = array_map( 'trim', explode( '|', ltrim( ltrim( $line ), '= ' ) ) );
			$current = array(
				'name'     => isset( $parts[0] ) ? $parts[0] : '',
				'price'    => isset( $parts[1] ) ? $parts[1] : '',
				'period'   => isset( $parts[2] ) ? $parts[2] : '',
				'featured' => isset( $parts[3] ) && '' !== $parts[3],
				'was'      => isset( $parts[4] ) ? $parts[4] : '',
				'desc'     => '',
				'features' => array(),
			);
			continue;
		}
		if ( ! $current ) {
			continue;
		}
		if ( '-' === substr( ltrim( $line ), 0, 1 ) ) {
			$current['features'][] = trim( ltrim( ltrim( $line ), '- ' ) );
		} elseif ( '' === $current['desc'] ) {
			$current['desc'] = trim( $line );
		}
	}
	if ( $current ) {
		$out[] = $current;
	}
	return $out;
}

/**
 * Serialise FAQs into the editable text format ("Question :: Answer" per line).
 */
function norvex_faqs_to_text( $faqs ) {
	$lines = array();
	foreach ( (array) $faqs as $f ) {
		if ( empty( $f[0] ) ) {
			continue;
		}
		$lines[] = $f[0] . ' :: ' . ( isset( $f[1] ) ? $f[1] : '' );
	}
	return implode( "\n", $lines );
}

/**
 * Parse the FAQ text format ("Question :: Answer") into array( array( q, a ) ).
 */
function norvex_parse_faqs( $raw ) {
	$out = array();
	foreach ( preg_split( '/\r\n|\r|\n/', (string) $raw ) as $line ) {
		$line = trim( $line );
		if ( '' === $line ) {
			continue;
		}
		$parts = explode( '::', $line, 2 );
		$q     = trim( $parts[0] );
		$a     = isset( $parts[1] ) ? trim( $parts[1] ) : '';
		if ( '' !== $q ) {
			$out[] = array( $q, $a );
		}
	}
	return $out;
}

/**
 * Serialise process steps (array of array( title, desc )) to the editable
 * "Title :: Description" per-line text format.
 */
function norvex_process_to_text( $steps ) {
	$lines = array();
	foreach ( (array) $steps as $s ) {
		if ( empty( $s[0] ) ) {
			continue;
		}
		$lines[] = $s[0] . ' :: ' . ( isset( $s[1] ) ? $s[1] : '' );
	}
	return implode( "\n", $lines );
}

/**
 * Parse the process-steps text format ("Title :: Description", one per line)
 * into array( array( title, desc ) ). Used by the single service page.
 */
function norvex_parse_process( $raw ) {
	$out = array();
	foreach ( preg_split( '/\r\n|\r|\n/', (string) $raw ) as $line ) {
		$line = trim( $line );
		if ( '' === $line ) {
			continue;
		}
		$parts = explode( '::', $line, 2 );
		$title = trim( $parts[0] );
		$desc  = isset( $parts[1] ) ? trim( $parts[1] ) : '';
		if ( '' !== $title ) {
			$out[] = array( $title, $desc );
		}
	}
	return $out;
}

/**
 * A short overview heading for a service, keyed by slug. Used as the heading
 * above the overview text on the single service page (falls back to '' for
 * unknown slugs, in which case the template simply omits the heading).
 *
 * @param string $slug Service post slug.
 * @return string
 */
function norvex_service_overview_title( $slug ) {
	$map = array(
		'ghostwriting'    => __( 'Your voice, on every page', 'norvex' ),
		'book-editing'    => __( 'Every sentence, at its best', 'norvex' ),
		'book-design'     => __( 'A cover that earns the click', 'norvex' ),
		'book-publishing' => __( 'Everywhere your readers shop', 'norvex' ),
		'book-marketing'  => __( 'Readers who can’t wait for your book', 'norvex' ),
		'book-coaching'   => __( 'Finish the book you set out to write', 'norvex' ),
	);
	return isset( $map[ $slug ] ) ? $map[ $slug ] : '';
}

function norvex_default_testimonials() {
	return array(
		array( 'Rebecca Hale', 'They took my half-finished draft and turned it into a book I’m proud to hand to anyone. The whole process was clear and completely stress-free.', 'First-time author', 5, 'avatar-1.svg' ),
		array( 'James Okoro', 'From ghostwriting to launch, one team handled everything and kept me updated at every step — and I still own 100% of my book.', 'Business author', 5, 'avatar-3.svg' ),
		array( 'Sofia Marín', 'The cover and the marketing launch went beyond what I imagined. My release week was the best I could have hoped for.', 'Memoir author', 5, 'avatar-2.svg' ),
	);
}

function norvex_default_team() {
	return array(
		array( 'Amara Bright', 'Founder & Publisher', 'avatar-1.svg' ),
		array( 'Daniel Cho', 'Editorial Director', 'avatar-4.svg' ),
		array( 'Priya Raman', 'Creative Director', 'avatar-2.svg' ),
		array( 'Marcus Ellison', 'Head of Marketing', 'avatar-3.svg' ),
	);
}

function norvex_default_plans() {
	return array(
		array(
			'name' => 'Essentials', 'price' => 'from $999', 'period' => '', 'featured' => false,
			'desc' => 'For authors with a finished draft who need it polished, designed and published.',
			'features' => "Copy & line editing + proofread\nOriginal cover design\nPrint & ebook formatting\nDistribution set up in your name\nYou keep 100% of royalties\n!Book marketing campaign",
		),
		array(
			'name' => 'Complete Publishing', 'price' => 'from $2,999', 'period' => '', 'featured' => true,
			'desc' => 'Everything you need to take a manuscript to a professional, market-ready book.',
			'features' => "Everything in Essentials\nDevelopmental editing\nCover + interior design\nWide retail & library distribution\nDedicated project manager\n!Book marketing campaign",
		),
		array(
			'name' => 'Bestseller', 'price' => 'from $8,995', 'period' => '', 'featured' => false,
			'desc' => 'A full launch — book, brand and marketing to reach the widest audience.',
			'features' => "Everything in Complete\nLaunch marketing campaign\nARC & review coordination\nAmazon Ads management\nPriority scheduling\nAuthor-brand strategy session",
		),
	);
}

/**
 * Seed JSON for a Testimonials block switched to "Custom" mode, so it starts
 * with editable sample quotes instead of an empty block.
 *
 * @return string JSON array of { quote, name, role, rating, photo }.
 */
function norvex_default_testimonials_json() {
	$out = array();
	foreach ( norvex_default_testimonials() as $t ) {
		$out[] = array(
			'quote'  => $t[1],
			'name'   => $t[0],
			'role'   => $t[2],
			'rating' => (int) $t[3],
			'photo'  => '',
		);
	}
	return wp_json_encode( $out );
}

/**
 * Seed JSON for a Pricing block switched to "Custom" mode.
 *
 * @return string JSON array of { name, price, was, per, desc, featured, btn, btnurl, features }.
 */
function norvex_default_plans_json() {
	$out = array();
	foreach ( norvex_default_plans() as $d ) {
		$out[] = array(
			'name'     => $d['name'],
			'price'    => $d['price'],
			'was'      => isset( $d['was'] ) ? $d['was'] : '',
			'per'      => $d['period'],
			'desc'     => $d['desc'],
			'featured' => ! empty( $d['featured'] ),
			'btn'      => '',
			'btnurl'   => '',
			'features' => $d['features'],
		);
	}
	return wp_json_encode( $out );
}

/**
 * Seed JSON for a Services grid block (typed on the block).
 *
 * @return string JSON array of { icon, title, text, url, price }.
 */
function norvex_default_services_json() {
	$out = array();
	foreach ( norvex_default_services() as $s ) {
		$price = ( ! empty( $s['packages'][0]['price'] ) ) ? $s['packages'][0]['price'] : '';
		$out[] = array(
			'icon'  => isset( $s['icon'] ) ? $s['icon'] : '',
			'title' => isset( $s['title'] ) ? $s['title'] : '',
			'text'  => isset( $s['excerpt'] ) ? $s['excerpt'] : '',
			'url'   => '',
			'price' => $price,
		);
	}
	return wp_json_encode( $out );
}

/**
 * Seed JSON for a Process steps block (steps typed on the block).
 *
 * @return string JSON array of { title, text }.
 */
function norvex_default_process_steps_json() {
	return wp_json_encode(
		array(
			array( 'title' => __( 'Book a free call', 'norvex' ), 'text' => __( 'Book a no-obligation consultation at a time that suits you. No prep needed — just bring your idea, however finished or unfinished it is.', 'norvex' ) ),
			array( 'title' => __( 'Share your vision', 'norvex' ), 'text' => __( 'Tell us about your book, your goals and where you are right now. We listen closely so the plan fits your story, not a template.', 'norvex' ) ),
			array( 'title' => __( 'Get a tailored plan', 'norvex' ), 'text' => __( 'We recommend the right services and send you a clear, no-pressure quote — so you know exactly what’s involved before you commit.', 'norvex' ) ),
			array( 'title' => __( 'We bring it to life', 'norvex' ), 'text' => __( 'Your dedicated team writes, edits, designs, publishes and markets your book — keeping every milestone on track through to launch.', 'norvex' ) ),
		)
	);
}

/**
 * Seed JSON for a Services grid block in the Grid-cards format, so the Services
 * block can reuse the Grid-cards editor and renderer (icon/number, footer price
 * + editable link, borders).
 *
 * @return string JSON array of card objects.
 */
function norvex_default_service_cards_json() {
	$out = array();
	foreach ( norvex_default_services() as $s ) {
		$price = ( ! empty( $s['packages'][0]['price'] ) ) ? $s['packages'][0]['price'] : '';
		$out[] = array(
			'icon'      => isset( $s['icon'] ) ? $s['icon'] : '',
			'image'     => '',
			'title'     => isset( $s['title'] ) ? $s['title'] : '',
			'text'      => isset( $s['excerpt'] ) ? $s['excerpt'] : '',
			'url'       => '',
			'linklabel' => __( 'Learn more', 'norvex' ),
			'price'     => $price,
			'note'      => '',
			'bside'     => '',
			'bcolor'    => '',
			'bwidth'    => '',
		);
	}
	return wp_json_encode( $out );
}

/**
 * Seed JSON for a Team grid block (typed on the block).
 *
 * @return string JSON array of { name, role, photo }.
 */
function norvex_default_team_json() {
	$out = array();
	foreach ( norvex_default_team() as $m ) {
		$out[] = array(
			'name'  => $m[0],
			'role'  => $m[1],
			'photo' => norvex_img( $m[2] ),
		);
	}
	return wp_json_encode( $out );
}

/**
 * Seed JSON for a Featured books block (typed on the block).
 *
 * @return string JSON array of { cover, title, author, url, tag }.
 */
function norvex_default_books_json() {
	$out = array();
	for ( $i = 1; $i <= 4; $i++ ) {
		$out[] = array(
			'cover'  => norvex_img( 'cover-' . $i . '.svg' ),
			'title'  => __( 'Recent project', 'norvex' ),
			'author' => __( 'Client author', 'norvex' ),
			'url'    => '',
			'tag'    => '',
		);
	}
	return wp_json_encode( $out );
}

/**
 * Parse a plan's feature textarea into array( array( label, included ) ).
 */
function norvex_parse_features( $raw ) {
	$out = array();
	foreach ( preg_split( '/\r\n|\r|\n/', (string) $raw ) as $line ) {
		$line = trim( $line );
		if ( '' === $line ) {
			continue;
		}
		$off = ( '!' === substr( $line, 0, 1 ) );
		$out[] = array( ltrim( $line, '!' ), ! $off );
	}
	return $out;
}

/**
 * Pull the first numeric amount out of a free-form price string.
 *
 * Handles thousands separators and decimals, e.g. "from $2,999/mo" => 2999.0.
 *
 * @param string $price Price label as typed by the user.
 * @return float|null Amount, or null when no number is present.
 */
function norvex_price_amount( $price ) {
	if ( ! preg_match( '/[\d][\d.,]*/', (string) $price, $m ) ) {
		return null;
	}
	$num = str_replace( ',', '', $m[0] );
	// A trailing dot (e.g. "$999.") isn't a decimal point — strip it.
	$num = rtrim( $num, '.' );
	return is_numeric( $num ) ? (float) $num : null;
}

/**
 * Whole-number percentage saved when a plan drops from an old price to a new
 * one. Returns 0 when either price is missing/unparseable or there's no saving.
 *
 * @param string $was Old ("was") price.
 * @param string $now Current price.
 * @return int Percentage saved (0–99), or 0 when not applicable.
 */
function norvex_price_saving_pct( $was, $now ) {
	$old = norvex_price_amount( $was );
	$new = norvex_price_amount( $now );
	if ( null === $old || null === $new || $old <= 0 || $new >= $old ) {
		return 0;
	}
	return (int) round( ( ( $old - $new ) / $old ) * 100 );
}
