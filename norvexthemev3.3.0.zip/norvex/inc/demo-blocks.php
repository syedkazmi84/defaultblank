<?php
/**
 * Block-only demo content.
 *
 * A complete, professional starter website built entirely from CORE WordPress
 * (Gutenberg) blocks — cover, group, columns, media-text, buttons, image,
 * gallery, list, quote, table — and no Norvex custom blocks. It uses the
 * theme.json palette, font families and layout so the core blocks render fully
 * on-brand. Imported from a dedicated button on the Norvex → Overview
 * screen; pages use the "Full-width (Gutenberg blocks)" template.
 *
 * @package Norvex
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/* =========================================================================
   Low-level markup helpers — each emits canonical core-block markup. Text
   arguments are escaped inside; "*_html" arguments are already-built markup.
   ========================================================================= */

/**
 * JSON attribute string for a block comment (leading space, or empty).
 */
function awb_attrs( $a ) {
	return $a ? ' ' . wp_json_encode( $a, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE ) : '';
}

/**
 * Heading block. $o: align, class, size (font-size slug), color (palette slug).
 */
function awb_heading( $text, $level = 2, $o = array() ) {
	$attrs = array();
	$cls   = array( 'wp-block-heading' );
	if ( 2 !== $level ) {
		$attrs['level'] = $level;
	}
	if ( ! empty( $o['align'] ) ) {
		$attrs['textAlign'] = $o['align'];
		$cls[]              = 'has-text-align-' . $o['align'];
	}
	if ( ! empty( $o['class'] ) ) {
		$attrs['className'] = $o['class'];
		$cls[]              = $o['class'];
	}
	if ( ! empty( $o['size'] ) ) {
		$attrs['fontSize'] = $o['size'];
		$cls[]             = 'has-' . $o['size'] . '-font-size';
	}
	if ( ! empty( $o['color'] ) ) {
		$attrs['textColor'] = $o['color'];
		$cls[]              = 'has-' . $o['color'] . '-color has-text-color';
	}
	$tag = 'h' . $level;
	return '<!-- wp:heading' . awb_attrs( $attrs ) . ' --><' . $tag . ' class="' . implode( ' ', $cls ) . '">' . esc_html( $text ) . '</' . $tag . '><!-- /wp:heading -->';
}

/**
 * Paragraph block. $o: align, class, size, color.
 */
function awb_para( $text, $o = array() ) {
	$attrs = array();
	$cls   = array();
	if ( ! empty( $o['align'] ) ) {
		$attrs['align'] = $o['align'];
		$cls[]          = 'has-text-align-' . $o['align'];
	}
	if ( ! empty( $o['class'] ) ) {
		$attrs['className'] = $o['class'];
		$cls[]              = $o['class'];
	}
	if ( ! empty( $o['size'] ) ) {
		$attrs['fontSize'] = $o['size'];
		$cls[]             = 'has-' . $o['size'] . '-font-size';
	}
	if ( ! empty( $o['color'] ) ) {
		$attrs['textColor'] = $o['color'];
		$cls[]              = 'has-' . $o['color'] . '-color has-text-color';
	}
	$cattr = $cls ? ' class="' . implode( ' ', $cls ) . '"' : '';
	return '<!-- wp:paragraph' . awb_attrs( $attrs ) . ' --><p' . $cattr . '>' . esc_html( $text ) . '</p><!-- /wp:paragraph -->';
}

/**
 * Buttons block. $btns: array of array( label, url, 'fill'|'outline' ). $justify: '', 'center', 'left'.
 */
function awb_buttons( $btns, $justify = '' ) {
	$inner = '';
	foreach ( $btns as $b ) {
		$style   = isset( $b[2] ) ? $b[2] : 'fill';
		$outline = ( 'outline' === $style );
		$bcls    = 'wp-block-button' . ( $outline ? ' is-style-outline' : '' );
		$battrs  = $outline ? array( 'className' => 'is-style-outline' ) : array();
		$inner  .= '<!-- wp:button' . awb_attrs( $battrs ) . ' --><div class="' . $bcls . '"><a class="wp-block-button__link wp-element-button" href="' . esc_url( $b[1] ) . '">' . esc_html( $b[0] ) . '</a></div><!-- /wp:button -->';
	}
	$attrs = array();
	$cls   = array( 'wp-block-buttons' );
	if ( $justify ) {
		$attrs['layout'] = array( 'type' => 'flex', 'justifyContent' => $justify );
		$cls[]           = 'is-content-justification-' . $justify;
		$cls[]           = 'is-layout-flex';
	}
	return '<!-- wp:buttons' . awb_attrs( $attrs ) . ' --><div class="' . implode( ' ', $cls ) . '">' . $inner . '</div><!-- /wp:buttons -->';
}

/**
 * Image block. $o: width (e.g. '56px'), round (border radius), class, alt.
 */
function awb_image( $file, $alt = '', $o = array() ) {
	$url   = norvex_img( $file );
	$attrs = array( 'sizeSlug' => 'large' );
	$cls   = array( 'wp-block-image', 'size-large' );
	$style = '';
	if ( ! empty( $o['width'] ) ) {
		$attrs['width'] = $o['width'];
		$cls[]          = 'is-resized';
		$style         .= 'width:' . $o['width'] . ';';
	}
	if ( ! empty( $o['round'] ) ) {
		$attrs['style'] = array( 'border' => array( 'radius' => $o['round'] ) );
		$style         .= 'border-radius:' . $o['round'] . ';';
	}
	if ( ! empty( $o['class'] ) ) {
		$attrs['className'] = $o['class'];
		$cls[]              = $o['class'];
	}
	$imgstyle = $style ? ' style="' . esc_attr( rtrim( $style, ';' ) ) . '"' : '';
	return '<!-- wp:image' . awb_attrs( $attrs ) . ' --><figure class="' . implode( ' ', $cls ) . '"><img src="' . esc_url( $url ) . '" alt="' . esc_attr( $alt ) . '"' . $imgstyle . '/></figure><!-- /wp:image -->';
}

/**
 * Unordered list block from an array of strings.
 */
function awb_list( $items ) {
	$li = '';
	foreach ( $items as $it ) {
		$li .= '<!-- wp:list-item --><li>' . esc_html( $it ) . '</li><!-- /wp:list-item -->';
	}
	return '<!-- wp:list --><ul class="wp-block-list">' . $li . '</ul><!-- /wp:list -->';
}

/**
 * Spacer block.
 */
function awb_spacer( $h = '40px' ) {
	return '<!-- wp:spacer {"height":"' . $h . '"} --><div style="height:' . $h . '" aria-hidden="true" class="wp-block-spacer"></div><!-- /wp:spacer -->';
}

/**
 * Group block (constrained). $o: align ('full'|'wide'), bg (palette slug),
 * class, padY (vertical padding), inner content string.
 */
function awb_group( $inner_html, $o = array() ) {
	$attrs = array();
	$cls   = array( 'wp-block-group' );
	if ( ! empty( $o['align'] ) ) {
		$attrs['align'] = $o['align'];
		$cls[]          = 'align' . $o['align'];
	}
	if ( ! empty( $o['bg'] ) ) {
		$attrs['backgroundColor'] = $o['bg'];
		$cls[]                    = 'has-' . $o['bg'] . '-background-color has-background';
	}
	if ( ! empty( $o['class'] ) ) {
		$attrs['className'] = $o['class'];
		$cls[]              = $o['class'];
	}
	$pad_y            = isset( $o['padY'] ) ? $o['padY'] : '5.5rem';
	$attrs['style']   = array( 'spacing' => array( 'padding' => array( 'top' => $pad_y, 'bottom' => $pad_y, 'left' => '1.5rem', 'right' => '1.5rem' ) ) );
	$attrs['layout']  = array( 'type' => 'constrained' );
	$style            = ' style="padding-top:' . $pad_y . ';padding-right:1.5rem;padding-bottom:' . $pad_y . ';padding-left:1.5rem"';
	return '<!-- wp:group' . awb_attrs( $attrs ) . ' --><div class="' . implode( ' ', $cls ) . '"' . $style . '>' . $inner_html . '</div><!-- /wp:group -->';
}

/**
 * Columns wrapper. $o: class, align.
 */
function awb_columns( $columns_html, $o = array() ) {
	$attrs = array();
	$cls   = array( 'wp-block-columns' );
	if ( ! empty( $o['align'] ) ) {
		$attrs['align'] = $o['align'];
		$cls[]          = 'align' . $o['align'];
	}
	if ( ! empty( $o['class'] ) ) {
		$attrs['className'] = $o['class'];
		$cls[]              = $o['class'];
	}
	return '<!-- wp:columns' . awb_attrs( $attrs ) . ' --><div class="' . implode( ' ', $cls ) . '">' . $columns_html . '</div><!-- /wp:columns -->';
}

/**
 * Single column. $o: bg (palette slug), class, pad (padding shorthand value).
 */
function awb_column( $inner_html, $o = array() ) {
	$attrs = array();
	$cls   = array( 'wp-block-column' );
	if ( ! empty( $o['bg'] ) ) {
		$attrs['backgroundColor'] = $o['bg'];
		$cls[]                    = 'has-' . $o['bg'] . '-background-color has-background';
	}
	if ( ! empty( $o['class'] ) ) {
		$attrs['className'] = $o['class'];
		$cls[]              = $o['class'];
	}
	$style = '';
	if ( ! empty( $o['pad'] ) ) {
		$attrs['style'] = array( 'spacing' => array( 'padding' => array( 'top' => $o['pad'], 'right' => $o['pad'], 'bottom' => $o['pad'], 'left' => $o['pad'] ) ) );
		$style          = ' style="padding-top:' . $o['pad'] . ';padding-right:' . $o['pad'] . ';padding-bottom:' . $o['pad'] . ';padding-left:' . $o['pad'] . '"';
	}
	return '<!-- wp:column' . awb_attrs( $attrs ) . ' --><div class="' . implode( ' ', $cls ) . '"' . $style . '>' . $inner_html . '</div><!-- /wp:column -->';
}

/**
 * Media + text block. $o: side ('left'|'right'), image, alt, eyebrow, heading,
 * body (array of paragraphs), btn ( array(label,url) ).
 */
function awb_media_text( $o ) {
	$o        = wp_parse_args( $o, array( 'side' => 'left', 'image' => 'about.svg', 'alt' => '', 'eyebrow' => '', 'heading' => '', 'body' => array(), 'btn' => null ) );
	$is_right = ( 'right' === $o['side'] );
	$attrs    = array( 'align' => 'wide', 'mediaType' => 'image', 'className' => 'norvex-mt' );
	$cls      = 'wp-block-media-text alignwide is-stacked-on-mobile norvex-mt';
	if ( $is_right ) {
		$attrs['mediaPosition'] = 'right';
		$cls                   .= ' has-media-on-the-right';
	}
	$content = '';
	if ( '' !== $o['eyebrow'] ) {
		$content .= awb_para( $o['eyebrow'], array( 'class' => 'aw-eyebrow' ) );
	}
	if ( '' !== $o['heading'] ) {
		$content .= awb_heading( $o['heading'], 2, array( 'size' => 'large' ) );
	}
	foreach ( (array) $o['body'] as $p ) {
		$content .= awb_para( $p, array( 'color' => 'muted' ) );
	}
	if ( $o['btn'] ) {
		$content .= awb_buttons( array( array( $o['btn'][0], $o['btn'][1], 'fill' ) ) );
	}
	$media = '<figure class="wp-block-media-text__media"><img src="' . esc_url( norvex_img( $o['image'] ) ) . '" alt="' . esc_attr( $o['alt'] ) . '"/></figure>';
	$inner = '<div class="wp-block-media-text__content">' . $content . '</div>';
	$html  = $is_right ? ( $inner . $media ) : ( $media . $inner );
	return '<!-- wp:media-text' . awb_attrs( $attrs ) . ' --><div class="' . $cls . '">' . $html . '</div><!-- /wp:media-text -->';
}

/* =========================================================================
   Mid-level section helpers, composed from the primitives above.
   ========================================================================= */

/**
 * Centered eyebrow + heading + optional lead cluster.
 */
function awb_section_head( $eyebrow, $title, $lead = '', $align = 'center' ) {
	$out = '';
	if ( $eyebrow ) {
		$out .= awb_para( $eyebrow, array( 'align' => $align, 'class' => 'aw-eyebrow' ) );
	}
	$out .= awb_heading( $title, 2, array( 'align' => $align, 'size' => 'x-large' ) );
	if ( $lead ) {
		$out .= awb_para( $lead, array( 'align' => $align, 'class' => 'aw-lead', 'color' => 'muted', 'size' => 'medium' ) );
	}
	return $out;
}

/**
 * Full-bleed cover hero. $o: bg (palette slug), eyebrow, title, lead, buttons,
 * extra (extra inner markup, e.g. a stats row), minHeight.
 */
function awb_hero( $o ) {
	$o     = wp_parse_args( $o, array( 'bg' => 'ink', 'eyebrow' => '', 'title' => '', 'lead' => '', 'buttons' => array(), 'extra' => '', 'minHeight' => '' ) );
	$inner = '';
	if ( '' !== $o['eyebrow'] ) {
		$inner .= awb_para( $o['eyebrow'], array( 'align' => 'center', 'class' => 'aw-eyebrow' ) );
	}
	$inner .= awb_heading( $o['title'], 1, array( 'align' => 'center', 'size' => 'xx-large' ) );
	if ( '' !== $o['lead'] ) {
		$inner .= awb_para( $o['lead'], array( 'align' => 'center', 'size' => 'medium' ) );
	}
	if ( $o['buttons'] ) {
		$inner .= awb_buttons( $o['buttons'], 'center' );
	}
	if ( $o['extra'] ) {
		$inner .= awb_spacer( '10px' ) . $o['extra'];
	}

	$dark   = ! in_array( $o['bg'], array( 'cream', 'paper', 'sand' ), true );
	$cls    = array( 'wp-block-cover', 'alignfull', 'aw-hero' );
	if ( $dark ) {
		$cls[] = 'is-dark';
	}
	$attrs = array(
		'align'             => 'full',
		'overlayColor'      => $o['bg'],
		'isUserOverlayColor' => true,
		'className'         => 'aw-hero',
		'layout'            => array( 'type' => 'constrained' ),
	);
	$minstyle = '';
	if ( $o['minHeight'] ) {
		$attrs['minHeight'] = (int) $o['minHeight'];
		$attrs['minHeightUnit'] = 'vh';
		$minstyle           = ' style="min-height:' . (int) $o['minHeight'] . 'vh"';
	}
	$span = '<span aria-hidden="true" class="wp-block-cover__background has-' . $o['bg'] . '-background-color has-background-dim-100 has-background-dim"></span>';
	return '<!-- wp:cover' . awb_attrs( $attrs ) . ' --><div class="' . implode( ' ', $cls ) . '"' . $minstyle . '>' . $span . '<div class="wp-block-cover__inner-container">' . $inner . '</div></div><!-- /wp:cover -->';
}

/**
 * A row of stat columns for inside a dark hero. $stats: array of array( number, label ).
 */
function awb_hero_stats( $stats ) {
	$cols = '';
	foreach ( $stats as $s ) {
		$inner = awb_heading( $s[0], 2, array( 'align' => 'center', 'class' => 'aw-stat-n', 'size' => 'x-large' ) )
			. awb_para( $s[1], array( 'align' => 'center', 'class' => 'aw-stat-l', 'size' => 'small' ) );
		$cols .= awb_column( $inner );
	}
	return awb_columns( $cols, array( 'class' => 'aw-herostats' ) );
}

/**
 * Three/four-up card row. $cards: array of array( image, title, text, link ).
 */
function awb_card_row( $cards ) {
	$cols = '';
	foreach ( $cards as $c ) {
		$inner  = '';
		if ( ! empty( $c['image'] ) ) {
			$inner .= awb_image( $c['image'], '', array( 'width' => '52px' ) );
		}
		$inner .= awb_heading( $c['title'], 3, array( 'size' => 'large' ) );
		$inner .= awb_para( $c['text'], array( 'color' => 'muted' ) );
		if ( ! empty( $c['link'] ) && ! empty( $c['linklabel'] ) ) {
			$inner .= '<!-- wp:paragraph {"className":"aw-morelink"} --><p class="aw-morelink"><a href="' . esc_url( $c['link'] ) . '">' . esc_html( $c['linklabel'] ) . ' →</a></p><!-- /wp:paragraph -->';
		}
		$cols .= awb_column( $inner, array( 'bg' => 'paper', 'class' => 'aw-card', 'pad' => '32px' ) );
	}
	return awb_columns( $cols, array( 'class' => 'aw-cards' ) );
}

/**
 * A rust-accented call-to-action band (cover), core blocks only.
 */
function awb_cta( $urls, $title = '', $text = '', $btn = '' ) {
	$title = $title ? $title : __( 'Ready to publish your book?', 'norvex' );
	$text  = $text ? $text : __( 'Book a free, no-obligation consultation. We’ll map out exactly what your book needs — and you keep 100% of your rights.', 'norvex' );
	$btn   = $btn ? $btn : __( 'Book a free consultation', 'norvex' );
	$inner = awb_heading( $title, 2, array( 'align' => 'center', 'size' => 'x-large' ) )
		. awb_para( $text, array( 'align' => 'center', 'size' => 'medium' ) )
		. awb_buttons( array( array( $btn, $urls['contact'], 'fill' ), array( __( 'See pricing', 'norvex' ), $urls['pricing'], 'outline' ) ), 'center' );
	$attrs = array( 'align' => 'full', 'overlayColor' => 'burgundy', 'isUserOverlayColor' => true, 'className' => 'aw-hero aw-cta', 'layout' => array( 'type' => 'constrained' ) );
	return '<!-- wp:cover' . awb_attrs( $attrs ) . ' -->'
		. '<div class="wp-block-cover alignfull is-dark aw-hero aw-cta"><span aria-hidden="true" class="wp-block-cover__background has-burgundy-background-color has-background-dim-100 has-background-dim"></span><div class="wp-block-cover__inner-container">'
		. $inner . '</div></div><!-- /wp:cover -->';
}

/* =========================================================================
   Page builders (core blocks only). Each receives a $urls map of the other
   pages' permalinks so cross-links resolve.
   ========================================================================= */

/**
 * Home page.
 */
function awb_page_home( $urls ) {
	$hero = awb_hero(
		array(
			'bg'        => 'ink',
			'minHeight' => 82,
			'eyebrow'   => __( 'Ghostwriting · Editing · Publishing · Marketing', 'norvex' ),
			'title'     => __( 'Publish your book, and keep 100% of your rights', 'norvex' ),
			'lead'      => __( 'Full-service book publishing on a flat fee — every retailer account set up in your name. Live on every major store in 30 days, and every royalty is yours.', 'norvex' ),
			'buttons'   => array(
				array( __( 'Book a free consultation', 'norvex' ), $urls['contact'], 'fill' ),
				array( __( 'Explore our services', 'norvex' ), $urls['services'], 'outline' ),
			),
			'extra'     => awb_hero_stats(
				array(
					array( '100%', __( 'Royalties you keep', 'norvex' ) ),
					array( '30', __( 'Days to go live', 'norvex' ) ),
					array( '830+', __( 'Authors published', 'norvex' ) ),
				)
			),
		)
	);

	$services = awb_group(
		awb_section_head( __( 'What we do', 'norvex' ), __( 'Everything your book needs, in one place', 'norvex' ), __( 'From the first draft to the final launch, one team handles the hard parts of publishing so you can focus on your story.', 'norvex' ) )
		. awb_spacer( '20px' )
		. awb_card_row(
			array(
				array( 'image' => 'service-quill.svg', 'title' => __( 'Ghostwriting', 'norvex' ), 'text' => __( 'A professional writer turns your idea, transcripts or rough draft into a finished manuscript in your voice.', 'norvex' ), 'link' => $urls['services'], 'linklabel' => __( 'Learn more', 'norvex' ) ),
				array( 'image' => 'service-edit.svg', 'title' => __( 'Editing', 'norvex' ), 'text' => __( 'Developmental, line, copy and proof editing — each pass handled by a specialist, at transparent rates.', 'norvex' ), 'link' => $urls['services'], 'linklabel' => __( 'Learn more', 'norvex' ) ),
				array( 'image' => 'service-design.svg', 'title' => __( 'Design', 'norvex' ), 'text' => __( 'Genre-correct covers and print-ready interiors for ebook and paperback that make your book look its best.', 'norvex' ), 'link' => $urls['services'], 'linklabel' => __( 'Learn more', 'norvex' ) ),
			)
		),
		array( 'align' => 'full' )
	);

	$why = awb_group(
		awb_media_text(
			array(
				'side'    => 'left',
				'image'   => 'about.svg',
				'eyebrow' => __( 'Why authors choose us', 'norvex' ),
				'heading' => __( 'A publishing partner, not a middleman', 'norvex' ),
				'body'    => array(
					__( 'We combine writing, editing, design, publishing and marketing under one roof — so nothing gets lost between freelancers who never speak to each other.', 'norvex' ),
					__( 'You keep the copyright, the accounts stay in your name, and every retailer pays you directly. We take a flat fee for the work — never a share of your royalties.', 'norvex' ),
				),
				'btn'     => array( __( 'How it works', 'norvex' ), $urls['process'] ),
			)
		),
		array( 'align' => 'full', 'bg' => 'sand' )
	);

	$pricing = awb_group(
		awb_section_head( __( 'Pricing', 'norvex' ), __( 'Packages that fit your book', 'norvex' ), __( 'Start with a package or build your own — every plan is tailored after a free consultation.', 'norvex' ) )
		. awb_spacer( '20px' )
		. awb_price_row( $urls ),
		array( 'align' => 'full' )
	);

	$testi = awb_group(
		awb_section_head( __( 'Loved by authors', 'norvex' ), __( 'Writers who trusted us with their books', 'norvex' ) )
		. awb_spacer( '20px' )
		. awb_quote_row(),
		array( 'align' => 'full', 'bg' => 'sand' )
	);

	return $hero . $services . $why . $pricing . $testi . awb_cta( $urls );
}

/**
 * Pricing cards row (3 columns, middle featured). Core blocks only.
 */
function awb_price_row( $urls ) {
	$plans = array(
		array(
			'name'     => __( 'Essentials', 'norvex' ),
			'price'    => '$1,900',
			'blurb'    => __( 'For authors who mainly need a polished, publish-ready book.', 'norvex' ),
			'features' => array( __( 'Copy & proof editing', 'norvex' ), __( 'Cover + interior design', 'norvex' ), __( 'Ebook & paperback files', 'norvex' ), __( 'You keep all rights', 'norvex' ) ),
			'feature'  => false,
		),
		array(
			'name'     => __( 'Full Service', 'norvex' ),
			'price'    => '$4,900',
			'blurb'    => __( 'Our most popular package — from manuscript to a marketed launch.', 'norvex' ),
			'features' => array( __( 'Three editorial passes', 'norvex' ), __( 'Cover + interior design', 'norvex' ), __( 'Distribution in your name', 'norvex' ), __( '90-day launch & ads', 'norvex' ) ),
			'feature'  => true,
		),
		array(
			'name'     => __( 'Author Plus', 'norvex' ),
			'price'    => '$7,500',
			'blurb'    => __( 'Everything in Full Service, plus ghostwriting and premium marketing.', 'norvex' ),
			'features' => array( __( 'Ghostwriting included', 'norvex' ), __( 'Priority scheduling', 'norvex' ), __( 'PR & podcast outreach', 'norvex' ), __( 'Dedicated manager', 'norvex' ) ),
			'feature'  => false,
		),
	);
	$cols = '';
	foreach ( $plans as $p ) {
		$inner  = '';
		if ( $p['feature'] ) {
			$inner .= awb_para( __( 'Most popular', 'norvex' ), array( 'align' => 'center', 'class' => 'aw-badge' ) );
		}
		$inner .= awb_heading( $p['name'], 3, array( 'align' => 'center', 'size' => 'large' ) );
		$inner .= awb_heading( $p['price'], 2, array( 'align' => 'center', 'class' => 'aw-price' ) );
		$inner .= awb_para( $p['blurb'], array( 'align' => 'center', 'color' => 'muted', 'size' => 'small' ) );
		$inner .= awb_list( $p['features'] );
		$inner .= awb_buttons( array( array( __( 'Get started', 'norvex' ), $urls['contact'], $p['feature'] ? 'fill' : 'outline' ) ), 'center' );
		$cols  .= awb_column( $inner, array( 'bg' => 'paper', 'class' => 'aw-card aw-price-card' . ( $p['feature'] ? ' aw-card--feature' : '' ), 'pad' => '34px' ) );
	}
	return awb_columns( $cols, array( 'class' => 'aw-cards aw-pricing' ) );
}

/**
 * Testimonial quote cards (3 columns). Core wp:quote blocks.
 */
function awb_quote_row() {
	$quotes = array(
		array( __( 'They treated my manuscript like it mattered, and the launch actually reflected the work I put in.', 'norvex' ), __( 'Mara Ellison, novelist', 'norvex' ) ),
		array( __( 'One team, one point of contact, and a finished book I’m proud of. I never had to chase anyone.', 'norvex' ), __( 'James Okoro, business author', 'norvex' ) ),
		array( __( 'Transparent pricing, no surprises, and I kept every right. Exactly what they promised.', 'norvex' ), __( 'Nadia Okafor, memoirist', 'norvex' ) ),
	);
	$cols = '';
	foreach ( $quotes as $q ) {
		$inner = '<!-- wp:quote {"className":"aw-quote-card"} --><blockquote class="wp-block-quote aw-quote-card">'
			. awb_para( $q[0] )
			. '<cite>' . esc_html( $q[1] ) . '</cite></blockquote><!-- /wp:quote -->';
		$cols .= awb_column( $inner );
	}
	return awb_columns( $cols, array( 'class' => 'aw-quotes' ) );
}

/**
 * About page.
 */
function awb_page_about( $urls ) {
	$hero = awb_hero(
		array(
			'bg'      => 'ink',
			'eyebrow' => __( 'About Norvex', 'norvex' ),
			'title'   => __( 'We help authors publish — and keep everything they earn', 'norvex' ),
			'lead'    => __( 'A full-service publishing team built around one belief: the author should stay the owner of their work, always.', 'norvex' ),
		)
	);

	$story = awb_group(
		awb_media_text(
			array(
				'side'    => 'right',
				'image'   => 'about.svg',
				'eyebrow' => __( 'Our story', 'norvex' ),
				'heading' => __( 'One team, from first draft to first sale', 'norvex' ),
				'body'    => array(
					__( 'We started Norvex because publishing had become a maze of freelancers, hybrid contracts and hidden royalty shares. Authors deserved something simpler and fairer.', 'norvex' ),
					__( 'So we built one team that carries a book the whole way — writing, editing, design, distribution and marketing — while the author keeps the copyright and 100% of the royalties.', 'norvex' ),
				),
			)
		),
		array( 'align' => 'full' )
	);

	$quote = awb_group(
		'<!-- wp:pullquote {"className":"aw-pullquote"} --><figure class="wp-block-pullquote aw-pullquote"><blockquote><p>' . esc_html__( 'A book is the most personal thing most people ever make. Our whole job is to treat it that way — and hand it back entirely yours.', 'norvex' ) . '</p><cite>' . esc_html__( 'The Norvex founding promise', 'norvex' ) . '</cite></blockquote></figure><!-- /wp:pullquote -->',
		array( 'align' => 'full', 'bg' => 'sand' )
	);

	$values = awb_group(
		awb_section_head( __( 'What we stand for', 'norvex' ), __( 'Three commitments behind every project', 'norvex' ) )
		. awb_spacer( '20px' )
		. awb_card_row(
			array(
				array( 'image' => 'service-book.svg', 'title' => __( 'You keep your rights', 'norvex' ), 'text' => __( 'Copyright in your name, accounts in your name, royalties paid to you. A flat fee, never a share.', 'norvex' ) ),
				array( 'image' => 'service-edit.svg', 'title' => __( 'Specialists, not generalists', 'norvex' ), 'text' => __( 'Editing, design, production and marketing each handled by someone who does that one thing well.', 'norvex' ) ),
				array( 'image' => 'service-monitor.svg', 'title' => __( 'Transparent pricing', 'norvex' ), 'text' => __( 'Every price is on the page and agreed in writing before work starts. The scope sets the number.', 'norvex' ) ),
			)
		),
		array( 'align' => 'full' )
	);

	$team = awb_group(
		awb_section_head( __( 'The people', 'norvex' ), __( 'A small team, wholly focused on your book', 'norvex' ) )
		. awb_spacer( '20px' )
		. awb_team_row(),
		array( 'align' => 'full', 'bg' => 'sand' )
	);

	return $hero . $story . $quote . $values . $team . awb_cta( $urls );
}

/**
 * Team member cards (4 columns) using bundled avatar illustrations.
 */
function awb_team_row() {
	$team = array(
		array( 'avatar-1.svg', __( 'Sarah Whitman', 'norvex' ), __( 'Founder & Publisher', 'norvex' ) ),
		array( 'avatar-2.svg', __( 'Daniel Cho', 'norvex' ), __( 'Editorial Director', 'norvex' ) ),
		array( 'avatar-3.svg', __( 'Amara Bright', 'norvex' ), __( 'Design Lead', 'norvex' ) ),
		array( 'avatar-4.svg', __( 'Priya Raman', 'norvex' ), __( 'Marketing Lead', 'norvex' ) ),
	);
	$cols = '';
	foreach ( $team as $m ) {
		$inner = awb_image( $m[0], $m[1], array( 'width' => '96px', 'round' => '999px' ) )
			. awb_heading( $m[1], 3, array( 'size' => 'medium' ) )
			. awb_para( $m[2], array( 'color' => 'muted', 'size' => 'small' ) );
		$cols .= awb_column( $inner, array( 'class' => 'aw-teamcard' ) );
	}
	return awb_columns( $cols, array( 'class' => 'aw-team' ) );
}

/**
 * Services page.
 */
function awb_page_services( $urls ) {
	$hero = awb_hero(
		array(
			'bg'      => 'ink',
			'eyebrow' => __( 'Our services', 'norvex' ),
			'title'   => __( 'Six author services, from idea to launch day', 'norvex' ),
			'lead'    => __( 'A finished book is really six jobs, not one. Take all six as a single package — or any one on its own. Every price is printed next to it.', 'norvex' ),
			'buttons' => array( array( __( 'Book a free call', 'norvex' ), $urls['contact'], 'fill' ) ),
		)
	);

	$rows = array(
		array( 'service-quill.svg', __( 'Ghostwriting', 'norvex' ), __( 'A professional writer turns your concept, interviews or rough draft into a finished manuscript in your voice. You hold the byline and the copyright.', 'norvex' ), __( 'From $5,495', 'norvex' ), 'left' ),
		array( 'service-edit.svg', __( 'Book Editing', 'norvex' ), __( 'Developmental, line, copy and proof editing — per service or bundled, at transparent EFA-aligned rates, with a free sample edit first.', 'norvex' ), __( 'From $299', 'norvex' ), 'right' ),
		array( 'service-design.svg', __( 'Book Design', 'norvex' ), __( 'Genre-correct cover design and interior formatting for ebook and print, built to the exact specs the retailers require.', 'norvex' ), __( 'From $199', 'norvex' ), 'left' ),
		array( 'service-book.svg', __( 'Publishing', 'norvex' ), __( 'Distribution across Amazon KDP, IngramSpark, Apple Books, Kobo and Google Play — every account opened in your name.', 'norvex' ), __( 'From $249', 'norvex' ), 'right' ),
		array( 'service-megaphone.svg', __( 'Book Marketing', 'norvex' ), __( 'Pre-launch positioning, ARC distribution, Amazon Ads strategy and ongoing visibility campaigns reported in plain numbers.', 'norvex' ), __( 'From $1,495', 'norvex' ), 'left' ),
		array( 'service-mic.svg', __( 'Book Coaching', 'norvex' ), __( 'One-on-one guidance for authors writing the book themselves — manuscript review, structure and accountability.', 'norvex' ), __( 'From $549', 'norvex' ), 'right' ),
	);
	$sections = '';
	$i        = 0;
	foreach ( $rows as $r ) {
		$bg       = ( 0 === $i % 2 ) ? '' : 'sand';
		$sections .= awb_group(
			awb_media_text(
				array(
					'side'    => $r[4],
					'image'   => $r[0],
					'eyebrow' => $r[3],
					'heading' => $r[1],
					'body'    => array( $r[2] ),
					'btn'     => array( __( 'Get a quote', 'norvex' ), $urls['contact'] ),
				)
			),
			array( 'align' => 'full', 'bg' => $bg, 'padY' => '4rem' )
		);
		$i++;
	}

	$faq = awb_group(
		awb_section_head( __( 'Good to know', 'norvex' ), __( 'Frequently asked questions', 'norvex' ) )
		. awb_spacer( '16px' )
		. awb_faq(),
		array( 'align' => 'full' )
	);

	return $hero . $sections . $faq . awb_cta( $urls );
}

/**
 * FAQ built from core Details blocks (accordion).
 */
function awb_faq() {
	$items = array(
		array( __( 'Do I keep the rights to my book?', 'norvex' ), __( 'Always. Copyright stays in your name, every retailer account is opened for you, and each store pays you directly. We charge a flat fee and never take a share of your royalties.', 'norvex' ) ),
		array( __( 'How long does the whole process take?', 'norvex' ), __( 'Most books go from manuscript to live on every major retailer in about 30 days once editing is complete. Ghostwriting projects take longer and are scheduled around your availability.', 'norvex' ) ),
		array( __( 'Can I choose just one service?', 'norvex' ), __( 'Yes. Take the full package or any single service on its own — editing, design, distribution or marketing. Every price is listed on the services page.', 'norvex' ) ),
		array( __( 'How does pricing work?', 'norvex' ), __( 'We agree a fixed scope and price in writing before any work starts. The scope sets the number, and the number is the number — no surprise add-ons.', 'norvex' ) ),
	);
	$out = '';
	foreach ( $items as $it ) {
		$out .= '<!-- wp:details {"className":"aw-faq"} --><details class="wp-block-details aw-faq"><summary>' . esc_html( $it[0] ) . '</summary>'
			. awb_para( $it[1], array( 'color' => 'muted' ) )
			. '</details><!-- /wp:details -->';
	}
	return $out;
}

/**
 * How It Works page.
 */
function awb_page_process( $urls ) {
	$hero = awb_hero(
		array(
			'bg'      => 'ink',
			'eyebrow' => __( 'How it works', 'norvex' ),
			'title'   => __( 'A clear path from first call to launch day', 'norvex' ),
			'lead'    => __( 'A named deliverable and your sign-off at every step — nothing happens to your book without you seeing it first.', 'norvex' ),
		)
	);

	$steps = array(
		array( '01', __( 'Discovery & audit', 'norvex' ), __( 'A short consultation maps what you have — manuscript, sales history, audience — and we send a written proposal within 48 hours.', 'norvex' ) ),
		array( '02', __( 'Editorial & design', 'norvex' ), __( 'Your specialists edit, then set the cover and interior to your genre. You approve proofs before anything moves forward.', 'norvex' ) ),
		array( '03', __( 'Production & distribution', 'norvex' ), __( 'We export every file the retailers ask for and open distribution accounts in your name across all major stores.', 'norvex' ) ),
		array( '04', __( 'Launch & beyond', 'norvex' ), __( 'A launch sequence, 90 days of managed ads, and a written plan for the next quarter — reported in plain numbers.', 'norvex' ) ),
	);
	$cols = '';
	foreach ( $steps as $s ) {
		$inner = awb_heading( $s[0], 2, array( 'class' => 'aw-stepno', 'size' => 'x-large' ) )
			. awb_heading( $s[1], 3, array( 'size' => 'large' ) )
			. awb_para( $s[2], array( 'color' => 'muted' ) );
		$cols .= awb_column( $inner, array( 'class' => 'aw-step' ) );
	}
	$stepband = awb_group(
		awb_section_head( __( 'The process', 'norvex' ), __( 'Four steps, fully documented', 'norvex' ) )
		. awb_spacer( '20px' )
		. awb_columns( $cols, array( 'class' => 'aw-steps' ) ),
		array( 'align' => 'full' )
	);

	return $hero . $stepband . awb_cta( $urls );
}

/**
 * Pricing page.
 */
function awb_page_pricing( $urls ) {
	$hero = awb_hero(
		array(
			'bg'      => 'ink',
			'eyebrow' => __( 'Pricing', 'norvex' ),
			'title'   => __( 'Simple, transparent pricing', 'norvex' ),
			'lead'    => __( 'No hidden fees and no royalty share. Start with a package below, or build your own from individual services.', 'norvex' ),
		)
	);

	$plans = awb_group(
		awb_price_row( $urls ),
		array( 'align' => 'full' )
	);

	$compare = awb_group(
		awb_section_head( __( 'Compare', 'norvex' ), __( 'What’s included in each package', 'norvex' ) )
		. awb_spacer( '16px' )
		. awb_compare_table(),
		array( 'align' => 'full', 'bg' => 'sand' )
	);

	$faq = awb_group(
		awb_section_head( __( 'Good to know', 'norvex' ), __( 'Pricing questions', 'norvex' ) )
		. awb_spacer( '16px' )
		. awb_faq(),
		array( 'align' => 'full' )
	);

	return $hero . $plans . $compare . $faq . awb_cta( $urls );
}

/**
 * Package comparison as a core wp:table.
 */
function awb_compare_table() {
	$head = array( __( 'Feature', 'norvex' ), __( 'Essentials', 'norvex' ), __( 'Full Service', 'norvex' ), __( 'Author Plus', 'norvex' ) );
	$rows = array(
		array( __( 'Editing', 'norvex' ), __( 'Copy & proof', 'norvex' ), __( 'Three passes', 'norvex' ), __( 'Three passes', 'norvex' ) ),
		array( __( 'Cover & interior design', 'norvex' ), '✓', '✓', '✓' ),
		array( __( 'Distribution in your name', 'norvex' ), '✓', '✓', '✓' ),
		array( __( 'Ghostwriting', 'norvex' ), '—', '—', '✓' ),
		array( __( 'Launch & 90-day ads', 'norvex' ), '—', '✓', '✓' ),
		array( __( 'PR & podcast outreach', 'norvex' ), '—', '—', '✓' ),
		array( __( 'You keep 100% of rights', 'norvex' ), '✓', '✓', '✓' ),
	);
	$thead = '<thead><tr>';
	foreach ( $head as $h ) {
		$thead .= '<th>' . esc_html( $h ) . '</th>';
	}
	$thead .= '</tr></thead>';
	$tbody  = '<tbody>';
	foreach ( $rows as $r ) {
		$tbody .= '<tr>';
		foreach ( $r as $cell ) {
			$tbody .= '<td>' . esc_html( $cell ) . '</td>';
		}
		$tbody .= '</tr>';
	}
	$tbody .= '</tbody>';
	return '<!-- wp:table {"className":"aw-table"} --><figure class="wp-block-table aw-table"><table>' . $thead . $tbody . '</table></figure><!-- /wp:table -->';
}

/**
 * Portfolio page.
 */
function awb_page_portfolio( $urls ) {
	$hero = awb_hero(
		array(
			'bg'      => 'ink',
			'eyebrow' => __( 'Portfolio', 'norvex' ),
			'title'   => __( 'A shelf of books we’ve brought to life', 'norvex' ),
			'lead'    => __( 'Written, edited, designed and launched — every one released with the author keeping all rights.', 'norvex' ),
		)
	);

	$covers = array(
		array( 'cover-1.svg', __( 'The Founder’s Compass', 'norvex' ) ),
		array( 'cover-2.svg', __( 'Quiet Wealth', 'norvex' ) ),
		array( 'cover-3.svg', __( 'Saltwater Girlhood', 'norvex' ) ),
		array( 'cover-4.svg', __( 'The Clockwork Garden', 'norvex' ) ),
		array( 'cover-5.svg', __( 'Field Notes on Wonder', 'norvex' ) ),
		array( 'cover-6.svg', __( 'Signal & Noise', 'norvex' ) ),
	);
	$imgs = '';
	foreach ( $covers as $c ) {
		$imgs .= awb_image( $c[0], $c[1] );
	}
	$gallery = awb_group(
		awb_section_head( __( 'Recent work', 'norvex' ), __( 'Covers from across our list', 'norvex' ), __( 'Fiction, memoir, business and children’s books — each designed for its genre and its readers.', 'norvex' ) )
		. awb_spacer( '20px' )
		. '<!-- wp:gallery {"columns":3,"linkTo":"none","className":"aw-gallery"} --><figure class="wp-block-gallery has-nested-images columns-3 is-cropped aw-gallery">' . $imgs . '</figure><!-- /wp:gallery -->',
		array( 'align' => 'full' )
	);

	return $hero . $gallery . awb_cta( $urls );
}

/**
 * Contact page. (WordPress core has no form block, so this uses contact
 * details + email/phone buttons — still core blocks only.)
 */
function awb_page_contact( $urls ) {
	$hero = awb_hero(
		array(
			'bg'      => 'ink',
			'eyebrow' => __( 'Contact us', 'norvex' ),
			'title'   => __( 'Tell us about your book', 'norvex' ),
			'lead'    => __( 'Share a few details and we’ll set up your free consultation — no cost and no obligation.', 'norvex' ),
		)
	);

	$left = awb_heading( __( 'Get in touch', 'norvex' ), 2, array( 'size' => 'large' ) )
		. awb_para( __( 'The fastest way to start is a short call. Email or phone us and we’ll find a time that suits you.', 'norvex' ), array( 'color' => 'muted' ) )
		. awb_list(
			array(
				__( 'Email — hello@norvexpublishingservices.com', 'norvex' ),
				__( 'Phone — +1 (732) 454-6871', 'norvex' ),
				__( 'Hours — Mon–Fri · 9:00 AM – 6:00 PM', 'norvex' ),
				__( 'Studio — 1102 Glenwood Road, F4, Brooklyn, NY 11230', 'norvex' ),
			)
		)
		. awb_buttons(
			array(
				array( __( 'Email us', 'norvex' ), 'mailto:hello@norvexpublishingservices.com', 'fill' ),
				array( __( 'Call us', 'norvex' ), 'tel:+17324546871', 'outline' ),
			)
		);
	$right = awb_heading( __( 'What happens next', 'norvex' ), 3, array( 'size' => 'medium' ) )
		. awb_list(
			array(
				__( 'We reply within one business day.', 'norvex' ),
				__( 'A short, no-pressure consultation about your goals.', 'norvex' ),
				__( 'An honest, itemised quote for exactly what you need.', 'norvex' ),
			)
		);
	$cols = awb_columns(
		awb_column( $left ) . awb_column( $right, array( 'bg' => 'paper', 'class' => 'aw-card', 'pad' => '34px' ) ),
		array( 'class' => 'aw-contact' )
	);

	$band = awb_group( $cols, array( 'align' => 'full' ) );

	return $hero . $band . awb_cta( $urls );
}

/**
 * The core-block prose group for the Privacy / Terms pages. Reuses the exact
 * copy from the theme demo's legal builders (which is already pure core blocks)
 * by extracting just the .norvex-prose group, dropping the theme page-hero
 * and CTA around it.
 */
function awb_legal_body( $full ) {
	if ( preg_match( '/<!-- wp:group \{"className":"norvex-prose"\}.*?<!-- \/wp:group -->/s', $full, $m ) ) {
		return $m[0];
	}
	return '';
}
function awb_legal_privacy_body() {
	return awb_legal_body( norvex_build_privacy_page() );
}
function awb_legal_terms_body() {
	return awb_legal_body( norvex_build_terms_page() );
}

/**
 * Legal page (Privacy / Terms) — core hero + prose + CTA, reusing the shared
 * legal section builder from demo-content.php (which is already core blocks).
 */
function awb_page_legal( $urls, $which ) {
	if ( 'privacy' === $which ) {
		$title   = __( 'Privacy Policy', 'norvex' );
		$lead    = __( 'How Norvex collects, uses and protects your information.', 'norvex' );
		$content = awb_legal_privacy_body();
	} else {
		$title   = __( 'Terms of Service', 'norvex' );
		$lead    = __( 'The terms that govern our website and the services we provide.', 'norvex' );
		$content = awb_legal_terms_body();
	}
	$hero  = awb_hero( array( 'bg' => 'ink', 'eyebrow' => __( 'Legal', 'norvex' ), 'title' => $title, 'lead' => $lead ) );
	$prose = awb_group( $content, array( 'align' => 'full' ) );
	return $hero . $prose . awb_cta( $urls );
}

/* =========================================================================
   Import + admin wiring.
   ========================================================================= */

/**
 * Delete the current demo pages and menus so a fresh variant can be imported.
 */
function norvex_blocks_purge() {
	$slugs = array( 'home', 'about', 'services', 'how-it-works', 'pricing', 'portfolio', 'contact', 'journal', 'privacy-policy', 'terms' );
	if ( function_exists( 'norvex_default_services' ) ) {
		foreach ( norvex_default_services() as $s ) {
			$slugs[] = isset( $s['slug'] ) ? $s['slug'] : sanitize_title( $s['title'] );
		}
	}
	foreach ( array_unique( $slugs ) as $slug ) {
		$page = get_page_by_path( $slug );
		if ( $page ) {
			wp_delete_post( $page->ID, true );
		}
	}
	foreach ( array( 'Primary Navigation', 'Footer Menu' ) as $menu_name ) {
		$menu = wp_get_nav_menu_object( $menu_name );
		if ( $menu ) {
			wp_delete_nav_menu( $menu->term_id );
		}
	}
	delete_option( 'norvex_demo_imported' );
}

/**
 * Build all block-only pages and return the slug => ID map.
 */
function norvex_blocks_create_pages() {
	$defs = array(
		'home'      => array( __( 'Home', 'norvex' ), 'home' ),
		'about'     => array( __( 'About', 'norvex' ), 'about' ),
		'services'  => array( __( 'Services', 'norvex' ), 'services' ),
		'process'   => array( __( 'How It Works', 'norvex' ), 'how-it-works' ),
		'pricing'   => array( __( 'Pricing', 'norvex' ), 'pricing' ),
		'portfolio' => array( __( 'Portfolio', 'norvex' ), 'portfolio' ),
		'contact'   => array( __( 'Contact', 'norvex' ), 'contact' ),
		'privacy'   => array( __( 'Privacy Policy', 'norvex' ), 'privacy-policy' ),
		'terms'     => array( __( 'Terms of Service', 'norvex' ), 'terms' ),
	);

	// Pass 1 — create empty pages on the full-width block template, collect URLs.
	$ids  = array();
	$urls = array();
	foreach ( $defs as $key => $d ) {
		$ids[ $key ]  = norvex_make_page( $d[0], $d[1], '', 'tpl-blocks.php' );
		$urls[ $key ] = ( $ids[ $key ] && ! is_wp_error( $ids[ $key ] ) ) ? get_permalink( $ids[ $key ] ) : home_url( '/' . $d[1] . '/' );
	}
	// Journal (posts) page + its URL.
	$ids['blog']  = norvex_make_page( __( 'Journal', 'norvex' ), 'journal', '' );
	$urls['blog'] = ( $ids['blog'] && ! is_wp_error( $ids['blog'] ) ) ? get_permalink( $ids['blog'] ) : home_url( '/journal/' );

	// Pass 2 — fill each page's content now that every URL is known.
	$builders = array(
		'home'      => 'awb_page_home',
		'about'     => 'awb_page_about',
		'services'  => 'awb_page_services',
		'process'   => 'awb_page_process',
		'pricing'   => 'awb_page_pricing',
		'portfolio' => 'awb_page_portfolio',
		'contact'   => 'awb_page_contact',
	);
	foreach ( $builders as $key => $fn ) {
		if ( empty( $ids[ $key ] ) || is_wp_error( $ids[ $key ] ) ) {
			continue;
		}
		wp_update_post(
			array(
				'ID'           => $ids[ $key ],
				'post_content' => wp_slash( call_user_func( $fn, $urls ) ),
			)
		);
	}
	// Legal pages.
	foreach ( array( 'privacy', 'terms' ) as $which ) {
		if ( empty( $ids[ $which ] ) || is_wp_error( $ids[ $which ] ) ) {
			continue;
		}
		wp_update_post(
			array(
				'ID'           => $ids[ $which ],
				'post_content' => wp_slash( awb_page_legal( $urls, $which ) ),
			)
		);
	}
	if ( ! empty( $ids['privacy'] ) && ! is_wp_error( $ids['privacy'] ) ) {
		update_option( 'wp_page_for_privacy_policy', $ids['privacy'] );
	}

	return $ids;
}

/**
 * Import the block-only demo: purge, build core-block pages, set front page,
 * seed journal posts, build menus.
 */
function norvex_import_block_demo() {
	norvex_blocks_purge();
	norvex_apply_brand_defaults();

	$pages = norvex_blocks_create_pages();
	norvex_configure_front_page( $pages );
	norvex_create_posts();
	norvex_build_menus( $pages );

	update_option( 'norvex_demo_imported', NORVEX_VERSION );
	update_option( 'norvex_demo_variant', 'blocks' );
	update_option( 'norvex_content_version', NORVEX_CONTENT_VERSION );
	flush_rewrite_rules();
}

/**
 * Handle the "Import block-only demo" button.
 */
function norvex_handle_block_demo_import() {
	if ( ! current_user_can( 'manage_options' ) ) {
		wp_die( esc_html__( 'You are not allowed to import demo content.', 'norvex' ) );
	}
	check_admin_referer( 'norvex_import_block_demo' );

	norvex_import_block_demo();

	wp_safe_redirect(
		add_query_arg(
			array( 'page' => 'norvex-hub', 'norvex_imported' => 'blocks' ),
			admin_url( 'admin.php' )
		)
	);
	exit;
}
add_action( 'admin_post_norvex_import_block_demo', 'norvex_handle_block_demo_import' );
