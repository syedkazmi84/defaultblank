<?php
/**
 * Marketing & analytics tracking.
 *
 * Dedicated fields for Google Analytics 4, Google Tag Manager and the Meta
 * (Facebook) Pixel, so the site owner can add tracking without pasting raw
 * <script> into a code box. All output is consent-aware: when the cookie-consent
 * bar (Customizer → Norvex · Cookie consent) is enabled, the tracking libraries
 * only load after the visitor accepts — otherwise nothing that sets a marketing
 * cookie is ever printed.
 *
 * It also fires a lead conversion whenever the built-in contact form or the
 * newsletter form is submitted successfully: a `norvex_lead` dataLayer event
 * plus, when the matching library is present, a GA4 `generate_lead` / `sign_up`
 * event and a Meta Pixel `Lead` / `Subscribe` event. Google Tag Manager users
 * can build their own tags off the dataLayer event.
 *
 * @package Norvex
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Tracking settings, merged over defaults so every key is always present.
 *
 * @return array{ga4_id:string,gtm_id:string,pixel_id:string,respect_consent:bool}
 */
function norvex_tracking_settings() {
	$defaults = array(
		'ga4_id'          => '',
		'gtm_id'          => '',
		'pixel_id'        => '',
		'respect_consent' => true,
	);
	$stored = get_option( 'norvex_tracking', array() );
	if ( ! is_array( $stored ) ) {
		$stored = array();
	}
	$settings                    = wp_parse_args( $stored, $defaults );
	$settings['respect_consent'] = ! empty( $settings['respect_consent'] );
	return $settings;
}

/**
 * Is any tracking ID configured?
 *
 * @return bool
 */
function norvex_tracking_active() {
	$s = norvex_tracking_settings();
	return '' !== $s['ga4_id'] || '' !== $s['gtm_id'] || '' !== $s['pixel_id'];
}

/**
 * May the tracking libraries load on this request?
 *
 * When consent is being respected and the consent bar is switched on, the
 * visitor must have accepted. With no consent bar there is no way to collect a
 * decision, so tracking loads (the site owner is responsible for compliance).
 *
 * @return bool
 */
function norvex_tracking_consent_ok() {
	$s = norvex_tracking_settings();

	if ( ! $s['respect_consent'] ) {
		return true;
	}
	if ( ! get_theme_mod( 'norvex_cookie_enabled', false ) ) {
		return true;
	}
	return 'accept' === norvex_cookie_consent();
}

/**
 * Validate a tracking ID against its expected shape; '' if it doesn't match.
 *
 * @param string $type One of 'ga4', 'gtm', 'pixel'.
 * @param string $raw  Raw submitted value.
 * @return string Clean ID or ''.
 */
function norvex_tracking_clean_id( $type, $raw ) {
	$raw = strtoupper( trim( (string) $raw ) );
	switch ( $type ) {
		case 'ga4':
			// GA4 (G-), Google Ads (AW-) or legacy Universal Analytics (UA-).
			return preg_match( '/^(G|AW|UA)-[A-Z0-9-]+$/', $raw ) ? $raw : '';
		case 'gtm':
			return preg_match( '/^GTM-[A-Z0-9]+$/', $raw ) ? $raw : '';
		case 'pixel':
			$digits = preg_replace( '/[^0-9]/', '', $raw );
			return ( strlen( $digits ) >= 5 && strlen( $digits ) <= 20 ) ? $digits : '';
	}
	return '';
}

/* -------------------------------------------------------------------------
 * Front-end output.
 * ---------------------------------------------------------------------- */

/**
 * Print the dataLayer + the conversion helper, then the consent-gated tracking
 * libraries, in the document <head>.
 *
 * The helper is always defined (front end): it pushes a `norvex_lead` event to
 * the dataLayer — harmless before consent, and it only calls gtag()/fbq() when
 * those libraries actually exist, which is post-consent.
 */
function norvex_tracking_head() {
	if ( is_admin() || is_customize_preview() ) {
		return;
	}

	// Always-available conversion helper (no cookies of its own).
	?>
<script>
window.dataLayer = window.dataLayer || [];
window.norvexTrackConversion = function ( type, detail ) {
	detail = detail || {};
	var payload = { event: 'norvex_lead', norvex_lead_type: type };
	for ( var k in detail ) { if ( Object.prototype.hasOwnProperty.call( detail, k ) ) { payload[ k ] = detail[ k ]; } }
	try { window.dataLayer.push( payload ); } catch ( e ) {}
	if ( typeof window.gtag === 'function' ) {
		window.gtag( 'event', type === 'newsletter' ? 'sign_up' : 'generate_lead', { method: 'norvex_' + type } );
	}
	if ( typeof window.fbq === 'function' ) {
		window.fbq( 'track', type === 'newsletter' ? 'Subscribe' : 'Lead' );
	}
	try { window.dispatchEvent( new CustomEvent( 'norvex:conversion', { detail: payload } ) ); } catch ( e ) {}
};
</script>
	<?php

	if ( ! norvex_tracking_active() || ! norvex_tracking_consent_ok() ) {
		return;
	}

	$s = norvex_tracking_settings();

	// Google Tag Manager.
	if ( '' !== $s['gtm_id'] ) {
		$gtm = esc_js( $s['gtm_id'] );
		echo "\n<!-- Google Tag Manager -->\n";
		echo "<script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src='https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);})(window,document,'script','dataLayer','" . $gtm . "');</script>\n"; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- ID escaped with esc_js; remainder is a static vendor snippet.
		echo "<!-- End Google Tag Manager -->\n";
	}

	// Google Analytics 4 / Google Ads global site tag.
	if ( '' !== $s['ga4_id'] ) {
		$ga = $s['ga4_id'];
		printf(
			'<script async src="https://www.googletagmanager.com/gtag/js?id=%s"></script>' . "\n",
			esc_attr( rawurlencode( $ga ) )
		);
		echo "<script>window.dataLayer=window.dataLayer||[];function gtag(){dataLayer.push(arguments);}gtag('js',new Date());gtag('config','" . esc_js( $ga ) . "');</script>\n";
	}

	// Meta (Facebook) Pixel.
	if ( '' !== $s['pixel_id'] ) {
		$px = esc_js( $s['pixel_id'] );
		echo "\n<!-- Meta Pixel -->\n";
		echo "<script>!function(f,b,e,v,n,t,s){if(f.fbq)return;n=f.fbq=function(){n.callMethod?n.callMethod.apply(n,arguments):n.queue.push(arguments)};if(!f._fbq)f._fbq=n;n.push=n;n.loaded=!0;n.version='2.0';n.queue=[];t=b.createElement(e);t.async=!0;t.src=v;s=b.getElementsByTagName(e)[0];s.parentNode.insertBefore(t,s)}(window,document,'script','https://connect.facebook.net/en_US/fbevents.js');fbq('init','" . $px . "');fbq('track','PageView');</script>\n"; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- ID escaped with esc_js; remainder is a static vendor snippet.
		echo "<!-- End Meta Pixel -->\n";
	}
}
add_action( 'wp_head', 'norvex_tracking_head', 1 );

/**
 * Print the GTM + Meta Pixel <noscript> fallbacks right after <body>.
 */
function norvex_tracking_body_open() {
	if ( is_admin() || is_customize_preview() || ! norvex_tracking_active() || ! norvex_tracking_consent_ok() ) {
		return;
	}
	$s = norvex_tracking_settings();

	if ( '' !== $s['gtm_id'] ) {
		printf(
			'<noscript><iframe src="https://www.googletagmanager.com/ns.html?id=%s" height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>' . "\n",
			esc_attr( rawurlencode( $s['gtm_id'] ) )
		);
	}
	if ( '' !== $s['pixel_id'] ) {
		printf(
			'<noscript><img height="1" width="1" style="display:none" alt="" src="https://www.facebook.com/tr?id=%s&ev=PageView&noscript=1" /></noscript>' . "\n",
			esc_attr( rawurlencode( $s['pixel_id'] ) )
		);
	}
}
add_action( 'wp_body_open', 'norvex_tracking_body_open' );

/**
 * Fire a lead conversion after a successful contact or newsletter submission.
 *
 * Covers the no-JS / full-reload paths: the contact form re-renders in a sent
 * state, and the newsletter form redirects back with ?norvex_sub=ok. The AJAX
 * newsletter path fires client-side from theme.js instead (no reload happens).
 */
function norvex_tracking_conversion_events() {
	if ( is_admin() ) {
		return;
	}

	$type = '';

	if ( function_exists( 'norvex_contact_form_state' ) ) {
		$state = norvex_contact_form_state();
		if ( ! empty( $state['submitted'] ) && ! empty( $state['sent'] ) && empty( $state['errors'] ) ) {
			$type = 'contact';
		}
	}

	if ( '' === $type && isset( $_GET['norvex_sub'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- read-only status flag set by our own redirect.
		if ( 'ok' === sanitize_key( wp_unslash( $_GET['norvex_sub'] ) ) ) {
			$type = 'newsletter';
		}
	}

	if ( '' === $type ) {
		return;
	}
	?>
<script>document.addEventListener('DOMContentLoaded',function(){if(window.norvexTrackConversion){window.norvexTrackConversion('<?php echo esc_js( $type ); ?>');}});</script>
	<?php
}
add_action( 'wp_footer', 'norvex_tracking_conversion_events', 30 );

/* -------------------------------------------------------------------------
 * Admin: settings page under the Norvex hub.
 * ---------------------------------------------------------------------- */

/**
 * Register the "Marketing & Tracking" submenu under the Norvex hub.
 */
function norvex_tracking_menu() {
	add_submenu_page(
		'norvex-hub',
		__( 'Marketing & Tracking', 'norvex' ),
		__( 'Marketing & Tracking', 'norvex' ),
		'manage_options',
		'norvex-tracking',
		'norvex_tracking_page'
	);
}
add_action( 'admin_menu', 'norvex_tracking_menu', 11 );

/**
 * Render the tracking settings screen.
 */
function norvex_tracking_page() {
	if ( ! current_user_can( 'manage_options' ) ) {
		return;
	}
	$s              = norvex_tracking_settings();
	$consent_bar_on = (bool) get_theme_mod( 'norvex_cookie_enabled', false );
	?>
	<div class="wrap">
		<h1 style="display:flex;align-items:center;gap:10px;">
			<span class="dashicons dashicons-chart-line" style="font-size:28px;width:28px;height:28px;"></span>
			<?php esc_html_e( 'Marketing &amp; Tracking', 'norvex' ); ?>
		</h1>
		<p style="font-size:14px;max-width:760px;color:#50575e;">
			<?php esc_html_e( 'Connect Google Analytics 4, Google Tag Manager or the Meta (Facebook) Pixel. Paste just the ID — the theme prints the correct script for you and fires a lead conversion when your contact or newsletter form is submitted.', 'norvex' ); ?>
		</p>

		<?php if ( isset( $_GET['norvex_tracking_saved'] ) ) : // phpcs:ignore WordPress.Security.NonceVerification.Recommended ?>
			<div class="notice notice-success is-dismissible"><p><?php esc_html_e( 'Marketing settings saved.', 'norvex' ); ?></p></div>
		<?php endif; ?>

		<div style="display:grid;grid-template-columns:minmax(0,1fr) minmax(0,340px);gap:24px;align-items:start;max-width:1100px;margin-top:12px;">

			<div style="background:#fff;border:1px solid #dcdcde;border-radius:8px;padding:22px 24px;box-shadow:0 1px 2px rgba(0,0,0,.04);">
				<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
					<input type="hidden" name="action" value="norvex_save_tracking" />
					<?php wp_nonce_field( 'norvex_save_tracking' ); ?>
					<table class="form-table" role="presentation">
						<tr>
							<th scope="row"><label for="norvex-ga4"><?php esc_html_e( 'Google Analytics 4 ID', 'norvex' ); ?></label></th>
							<td>
								<input name="norvex_tracking[ga4_id]" id="norvex-ga4" type="text" class="regular-text" value="<?php echo esc_attr( $s['ga4_id'] ); ?>" placeholder="G-XXXXXXXXXX" />
								<p class="description"><?php esc_html_e( 'Your Measurement ID (starts with G-). A Google Ads ID (AW-) also works.', 'norvex' ); ?></p>
							</td>
						</tr>
						<tr>
							<th scope="row"><label for="norvex-gtm"><?php esc_html_e( 'Google Tag Manager ID', 'norvex' ); ?></label></th>
							<td>
								<input name="norvex_tracking[gtm_id]" id="norvex-gtm" type="text" class="regular-text" value="<?php echo esc_attr( $s['gtm_id'] ); ?>" placeholder="GTM-XXXXXXX" />
								<p class="description"><?php esc_html_e( 'Container ID (starts with GTM-). Lead submissions push a “norvex_lead” dataLayer event you can build tags on.', 'norvex' ); ?></p>
							</td>
						</tr>
						<tr>
							<th scope="row"><label for="norvex-pixel"><?php esc_html_e( 'Meta (Facebook) Pixel ID', 'norvex' ); ?></label></th>
							<td>
								<input name="norvex_tracking[pixel_id]" id="norvex-pixel" type="text" class="regular-text" value="<?php echo esc_attr( $s['pixel_id'] ); ?>" placeholder="123456789012345" />
								<p class="description"><?php esc_html_e( 'The numeric Pixel ID from Meta Events Manager.', 'norvex' ); ?></p>
							</td>
						</tr>
						<tr><th colspan="2"><hr style="border:none;border-top:1px solid #eee;margin:4px 0;" /></th></tr>
						<tr>
							<th scope="row"><?php esc_html_e( 'Cookie consent', 'norvex' ); ?></th>
							<td>
								<label>
									<input type="checkbox" name="norvex_tracking[respect_consent]" value="1" <?php checked( $s['respect_consent'] ); ?> />
									<?php esc_html_e( 'Only load tracking after the visitor accepts cookies', 'norvex' ); ?>
								</label>
								<p class="description">
									<?php
									echo esc_html(
										$consent_bar_on
											? __( 'The cookie consent bar is on, so tracking waits for consent. Recommended for GDPR.', 'norvex' )
											: __( 'Tip: the cookie consent bar is currently off (enable it in Customizer → Norvex · Cookie consent). With no consent bar, tracking loads for everyone.', 'norvex' )
									);
									?>
								</p>
							</td>
						</tr>
					</table>
					<?php submit_button( __( 'Save marketing settings', 'norvex' ) ); ?>
				</form>
			</div>

			<div style="background:#fff;border:1px solid #dcdcde;border-left:4px solid #c08a3e;border-radius:8px;padding:20px 22px;box-shadow:0 1px 2px rgba(0,0,0,.04);">
				<h2 style="margin-top:0;"><?php esc_html_e( 'What gets tracked', 'norvex' ); ?></h2>
				<ul style="color:#50575e;font-size:13px;line-height:1.7;margin:0;padding-left:18px;">
					<li><?php esc_html_e( 'Page views — automatically, on every page.', 'norvex' ); ?></li>
					<li><?php esc_html_e( 'Contact form sent → GA4 generate_lead + Meta Lead.', 'norvex' ); ?></li>
					<li><?php esc_html_e( 'Newsletter subscribe → GA4 sign_up + Meta Subscribe.', 'norvex' ); ?></li>
					<li><?php esc_html_e( 'A norvex_lead dataLayer event for Tag Manager.', 'norvex' ); ?></li>
				</ul>
				<p style="color:#646970;font-size:12.5px;margin:14px 0 0;">
					<?php esc_html_e( 'Leave a field blank to skip that platform. Existing Google Ads click IDs (GCLID) are still captured on the lead email for offline-conversion import.', 'norvex' ); ?>
				</p>
			</div>
		</div>

		<?php
		// Sitemap + IndexNow controls (defined in inc/sitemap.php).
		if ( function_exists( 'norvex_sitemap_render_card' ) ) {
			norvex_sitemap_render_card();
		}
		?>
	</div>
	<?php
}

/**
 * Persist the tracking settings (admin-post handler).
 */
function norvex_tracking_save() {
	if ( ! current_user_can( 'manage_options' ) ) {
		wp_die( esc_html__( 'You are not allowed to do that.', 'norvex' ) );
	}
	check_admin_referer( 'norvex_save_tracking' );

	$in = isset( $_POST['norvex_tracking'] ) && is_array( $_POST['norvex_tracking'] ) ? wp_unslash( $_POST['norvex_tracking'] ) : array(); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- each field cleaned individually below.

	$settings = array(
		'ga4_id'          => norvex_tracking_clean_id( 'ga4', isset( $in['ga4_id'] ) ? $in['ga4_id'] : '' ),
		'gtm_id'          => norvex_tracking_clean_id( 'gtm', isset( $in['gtm_id'] ) ? $in['gtm_id'] : '' ),
		'pixel_id'        => norvex_tracking_clean_id( 'pixel', isset( $in['pixel_id'] ) ? $in['pixel_id'] : '' ),
		'respect_consent' => ! empty( $in['respect_consent'] ),
	);

	update_option( 'norvex_tracking', $settings, false );

	wp_safe_redirect( add_query_arg( 'norvex_tracking_saved', '1', admin_url( 'admin.php?page=norvex-tracking' ) ) );
	exit;
}
add_action( 'admin_post_norvex_save_tracking', 'norvex_tracking_save' );
