<?php
/**
 * Google Ads click tracking (GCLID).
 *
 * Captures the Google click identifier (gclid, plus the iOS gbraid/wbraid
 * variants) from the landing URL, remembers it in a first-party cookie for 90
 * days, and attaches it to contact-form and newsletter submissions — so a lead
 * that came from a Google Ads click can be matched back to the campaign (e.g.
 * for offline-conversion import). The capture is done in assets/js/theme.js and
 * respects the cookie-consent choice: nothing is stored if the visitor declined.
 *
 * @package Norvex
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Clean a click id to a safe token (Google click ids are URL-safe already).
 *
 * @param string $value Raw value.
 * @return string
 */
function norvex_gclid_clean( $value ) {
	$value = preg_replace( '/[^A-Za-z0-9._-]/', '', (string) $value );
	return substr( (string) $value, 0, 200 );
}

/**
 * The click id submitted with a form (hidden field populated by theme.js).
 *
 * @return string Empty string when none was captured.
 */
function norvex_gclid_from_request() {
	if ( empty( $_POST['norvex_gclid'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Missing -- read alongside a nonce-verified form; value is a tracking token only.
		return '';
	}
	return norvex_gclid_clean( wp_unslash( $_POST['norvex_gclid'] ) ); // phpcs:ignore WordPress.Security.NonceVerification.Missing
}

/**
 * Print the hidden field theme.js fills with the stored click id.
 */
function norvex_gclid_field() {
	echo '<input type="hidden" name="norvex_gclid" value="" data-norvex-gclid />';
}
