<?php
/**
 * Hook Elements for Norvex.
 *
 * A lightweight, GeneratePress-style "Elements" manager. Each Element is a
 * block-editor post injected into one of the theme's hook locations
 * (see inc/hooks.php) according to a display rule — the entire site, the front
 * page, all posts/pages, archives, services, or specific post/page IDs.
 *
 * This is how you add a new section (banner, promo strip, CTA, notice) to any
 * page without editing template files, plus a code location for analytics and
 * verification tags. Manage them at Norvex → Elements.
 *
 * @package Norvex
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Register the Element custom post type (under the Norvex hub menu).
 */
function norvex_register_element_cpt() {
	$labels = array(
		'name'               => esc_html__( 'Elements', 'norvex' ),
		'singular_name'      => esc_html__( 'Element', 'norvex' ),
		'add_new'            => esc_html__( 'Add New', 'norvex' ),
		'add_new_item'       => esc_html__( 'Add New Element', 'norvex' ),
		'edit_item'          => esc_html__( 'Edit Element', 'norvex' ),
		'new_item'           => esc_html__( 'New Element', 'norvex' ),
		'view_item'          => esc_html__( 'View Element', 'norvex' ),
		'search_items'       => esc_html__( 'Search Elements', 'norvex' ),
		'not_found'          => esc_html__( 'No elements found.', 'norvex' ),
		'not_found_in_trash' => esc_html__( 'No elements found in Trash.', 'norvex' ),
		'all_items'          => esc_html__( 'Elements', 'norvex' ),
		'menu_name'          => esc_html__( 'Elements', 'norvex' ),
	);

	register_post_type(
		'norvex_element',
		array(
			'labels'          => $labels,
			'public'          => false,
			'show_ui'         => true,
			'show_in_menu'    => 'norvex-hub',
			'show_in_rest'    => true,
			'menu_icon'       => 'dashicons-editor-code',
			'supports'        => array( 'title', 'editor', 'revisions' ),
			'capability_type' => 'post',
			'map_meta_cap'    => true,
			'rewrite'         => false,
			'query_var'       => false,
		)
	);
}
add_action( 'init', 'norvex_register_element_cpt' );

/**
 * Human-readable labels for the hook locations shown in the Element editor.
 *
 * @return array hook => label
 */
function norvex_element_hook_choices() {
	return array(
		// Code locations (raw output — for scripts, meta tags, analytics).
		'wp_head'                         => esc_html__( 'Site <head> — scripts, meta tags, analytics', 'norvex' ),
		'wp_footer'                       => esc_html__( 'Site footer — before </body> (scripts)', 'norvex' ),
		// Visible content locations.
		'norvex_before_header'        => esc_html__( 'Before header', 'norvex' ),
		'norvex_after_header'         => esc_html__( 'After header (top of page)', 'norvex' ),
		'norvex_topbar_end'           => esc_html__( 'Top bar — end (next to social icons)', 'norvex' ),
		'norvex_nav_end'              => esc_html__( 'Menu bar — end (add a button next to the CTA)', 'norvex' ),
		'norvex_before_main'          => esc_html__( 'Before main content', 'norvex' ),
		'norvex_after_main'           => esc_html__( 'After main content', 'norvex' ),
		'norvex_before_entry_content' => esc_html__( 'Before entry content (single posts/pages & home)', 'norvex' ),
		'norvex_after_entry_content'  => esc_html__( 'After entry content (single posts/pages & home)', 'norvex' ),
		'norvex_before_footer'        => esc_html__( 'Before footer', 'norvex' ),
		'norvex_footer_top'           => esc_html__( 'Footer — top (inside footer)', 'norvex' ),
		'norvex_footer_bottom'        => esc_html__( 'Footer — bottom bar (next to legal links)', 'norvex' ),
		'norvex_after_footer'         => esc_html__( 'After footer', 'norvex' ),
	);
}

/**
 * Display-rule choices.
 *
 * @return array rule => label
 */
function norvex_element_display_choices() {
	return array(
		'entire_site'  => esc_html__( 'Entire site', 'norvex' ),
		'front_page'   => esc_html__( 'Front page only', 'norvex' ),
		'blog'         => esc_html__( 'Blog / posts index', 'norvex' ),
		'all_posts'    => esc_html__( 'All single posts', 'norvex' ),
		'all_pages'    => esc_html__( 'All pages', 'norvex' ),
		'all_services' => esc_html__( 'All service pages', 'norvex' ),
		'all_archives' => esc_html__( 'All archives', 'norvex' ),
		'specific'     => esc_html__( 'Specific IDs (below)', 'norvex' ),
	);
}

/**
 * Register the Element settings meta box.
 */
function norvex_element_meta_box() {
	add_meta_box(
		'norvex_element_settings',
		esc_html__( 'Element Settings', 'norvex' ),
		'norvex_render_element_meta_box',
		'norvex_element',
		'side',
		'high'
	);
}
add_action( 'add_meta_boxes', 'norvex_element_meta_box' );

/**
 * Render the Element settings meta box.
 *
 * @param WP_Post $post Current element.
 */
function norvex_render_element_meta_box( $post ) {
	wp_nonce_field( 'norvex_element_meta', 'norvex_element_nonce' );

	$hook        = get_post_meta( $post->ID, '_norvex_element_hook', true );
	$priority    = get_post_meta( $post->ID, '_norvex_element_priority', true );
	$display     = get_post_meta( $post->ID, '_norvex_element_display', true );
	$display_ids = get_post_meta( $post->ID, '_norvex_element_display_ids', true );
	$exclude_ids = get_post_meta( $post->ID, '_norvex_element_exclude_ids', true );

	if ( ! $hook ) {
		$hook = 'norvex_after_header';
	}
	if ( '' === $priority ) {
		$priority = 10;
	}
	if ( ! $display ) {
		$display = 'entire_site';
	}
	?>
	<p>
		<label for="norvex_hook" style="display:block;font-weight:600;"><?php esc_html_e( 'Hook location', 'norvex' ); ?></label>
		<select name="norvex_hook" id="norvex_hook" style="width:100%;">
			<?php foreach ( norvex_element_hook_choices() as $value => $label ) : ?>
				<option value="<?php echo esc_attr( $value ); ?>" <?php selected( $hook, $value ); ?>><?php echo esc_html( $label ); ?></option>
			<?php endforeach; ?>
		</select>
		<span class="description"><?php esc_html_e( 'The two "Site <head>/footer" options output raw code — paste a script, style or meta tag into a Custom HTML block for analytics, verification tags, etc.', 'norvex' ); ?></span>
	</p>
	<p>
		<label for="norvex_priority" style="display:block;font-weight:600;"><?php esc_html_e( 'Priority', 'norvex' ); ?></label>
		<input type="number" name="norvex_priority" id="norvex_priority" value="<?php echo esc_attr( $priority ); ?>" min="1" max="999" step="1" style="width:100%;" />
		<span class="description"><?php esc_html_e( 'Lower numbers output earlier.', 'norvex' ); ?></span>
	</p>
	<p>
		<label for="norvex_display" style="display:block;font-weight:600;"><?php esc_html_e( 'Display on', 'norvex' ); ?></label>
		<select name="norvex_display" id="norvex_display" style="width:100%;">
			<?php foreach ( norvex_element_display_choices() as $value => $label ) : ?>
				<option value="<?php echo esc_attr( $value ); ?>" <?php selected( $display, $value ); ?>><?php echo esc_html( $label ); ?></option>
			<?php endforeach; ?>
		</select>
	</p>
	<p>
		<label for="norvex_display_ids" style="display:block;font-weight:600;"><?php esc_html_e( 'Specific IDs', 'norvex' ); ?></label>
		<input type="text" name="norvex_display_ids" id="norvex_display_ids" value="<?php echo esc_attr( $display_ids ); ?>" placeholder="e.g. 12, 34, 56" style="width:100%;" />
		<span class="description"><?php esc_html_e( 'Used when "Display on" is set to Specific IDs. Comma-separated post/page IDs.', 'norvex' ); ?></span>
	</p>
	<p>
		<label for="norvex_exclude_ids" style="display:block;font-weight:600;"><?php esc_html_e( 'Exclude IDs', 'norvex' ); ?></label>
		<input type="text" name="norvex_exclude_ids" id="norvex_exclude_ids" value="<?php echo esc_attr( $exclude_ids ); ?>" placeholder="e.g. 78, 90" style="width:100%;" />
		<span class="description"><?php esc_html_e( 'Never show on these post/page IDs.', 'norvex' ); ?></span>
	</p>
	<?php
}

/**
 * Save the Element settings.
 *
 * @param int $post_id Element ID.
 */
function norvex_save_element_meta( $post_id ) {
	if ( ! isset( $_POST['norvex_element_nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['norvex_element_nonce'] ) ), 'norvex_element_meta' ) ) {
		return;
	}
	if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
		return;
	}
	if ( ! current_user_can( 'edit_post', $post_id ) ) {
		return;
	}

	// Hook (validate against the known list).
	if ( isset( $_POST['norvex_hook'] ) ) {
		$hook = sanitize_key( wp_unslash( $_POST['norvex_hook'] ) );
		if ( array_key_exists( $hook, norvex_element_hook_choices() ) ) {
			update_post_meta( $post_id, '_norvex_element_hook', $hook );
		}
	}

	// Priority.
	if ( isset( $_POST['norvex_priority'] ) ) {
		$priority = absint( wp_unslash( $_POST['norvex_priority'] ) );
		update_post_meta( $post_id, '_norvex_element_priority', $priority ? $priority : 10 );
	}

	// Display rule.
	if ( isset( $_POST['norvex_display'] ) ) {
		$display = sanitize_key( wp_unslash( $_POST['norvex_display'] ) );
		if ( array_key_exists( $display, norvex_element_display_choices() ) ) {
			update_post_meta( $post_id, '_norvex_element_display', $display );
		}
	}

	// ID lists (store a normalised comma list of positive integers).
	foreach ( array( 'norvex_display_ids' => '_norvex_element_display_ids', 'norvex_exclude_ids' => '_norvex_element_exclude_ids' ) as $field => $meta_key ) {
		if ( isset( $_POST[ $field ] ) ) {
			$raw = sanitize_text_field( wp_unslash( $_POST[ $field ] ) );
			$ids = array_filter( array_map( 'absint', array_map( 'trim', explode( ',', $raw ) ) ) );
			update_post_meta( $post_id, $meta_key, implode( ',', $ids ) );
		}
	}
}
add_action( 'save_post_norvex_element', 'norvex_save_element_meta' );

/**
 * Decide whether an element should display on the current view.
 *
 * @param int $element_id Element post ID.
 * @return bool
 */
function norvex_element_should_display( $element_id ) {
	$rule    = get_post_meta( $element_id, '_norvex_element_display', true );
	$rule    = $rule ? $rule : 'entire_site';
	$current = get_queried_object_id();

	// Exclusions win.
	$exclude = array_filter( array_map( 'absint', explode( ',', (string) get_post_meta( $element_id, '_norvex_element_exclude_ids', true ) ) ) );
	if ( $current && in_array( $current, $exclude, true ) ) {
		return false;
	}

	switch ( $rule ) {
		case 'entire_site':
			$match = true;
			break;
		case 'front_page':
			$match = is_front_page();
			break;
		case 'blog':
			$match = is_home();
			break;
		case 'all_posts':
			$match = is_singular( 'post' );
			break;
		case 'all_pages':
			$match = is_page();
			break;
		case 'all_services':
			$match = is_singular( 'norvex_service' );
			break;
		case 'all_archives':
			$match = ( is_archive() || is_category() || is_tag() || is_author() || is_date() );
			break;
		case 'specific':
			$ids   = array_filter( array_map( 'absint', explode( ',', (string) get_post_meta( $element_id, '_norvex_element_display_ids', true ) ) ) );
			$match = ( $current && in_array( $current, $ids, true ) );
			break;
		default:
			$match = false;
			break;
	}

	/**
	 * Filter whether a Hook Element displays on the current view.
	 *
	 * @param bool   $match      Whether it matches.
	 * @param int    $element_id Element ID.
	 * @param string $rule       Display rule.
	 */
	return (bool) apply_filters( 'norvex_element_display', $match, $element_id, $rule );
}

/**
 * Whether a hook is a "code" location (wp_head / wp_footer). Code locations are
 * output raw — no wrapper element and no auto-paragraphs — so scripts, styles
 * and meta tags pass through intact.
 *
 * @param string $hook Hook name.
 * @return bool
 */
function norvex_element_is_code_hook( $hook ) {
	return in_array( $hook, array( 'wp_head', 'wp_footer' ), true );
}

/**
 * Render a single element's content.
 *
 * Visible-content elements are wrapped in a div and filtered through
 * the_content so blocks and shortcodes resolve. Code elements (wp_head /
 * wp_footer) output their blocks raw — no wrapper, no wpautop.
 *
 * @param WP_Post $element Element post.
 * @param bool    $raw     Whether to output raw code (for wp_head / wp_footer).
 */
function norvex_render_element( $element, $raw = false ) {
	if ( ! norvex_element_should_display( $element->ID ) ) {
		return;
	}

	if ( $raw ) {
		echo do_blocks( $element->post_content ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		return;
	}

	echo '<div class="norvex-element norvex-element-' . absint( $element->ID ) . '">';
	echo apply_filters( 'the_content', $element->post_content ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
	echo '</div>';
}

/**
 * Transient key for the cached element-to-hook map.
 */
const NORVEX_ELEMENT_HOOK_CACHE = 'norvex_element_hooks';

/**
 * Build the map of published elements to the hooks they attach to.
 *
 * Cached in a transient so the get_posts() query only runs when the cache is
 * cold (busted whenever an element is saved, trashed or deleted). When no
 * elements are published, we short-circuit to an empty array.
 *
 * @return array List of [ id, hook, priority, raw ] records.
 */
function norvex_get_element_hook_map() {
	$cached = get_transient( NORVEX_ELEMENT_HOOK_CACHE );
	if ( is_array( $cached ) ) {
		return $cached;
	}

	$map = array();

	$counts = wp_count_posts( 'norvex_element' );
	$total  = isset( $counts->publish ) ? (int) $counts->publish : 0;

	if ( $total > 0 ) {
		$element_ids = get_posts(
			array(
				'post_type'        => 'norvex_element',
				'post_status'      => 'publish',
				'numberposts'      => 100,
				'fields'           => 'ids',
				'suppress_filters' => false,
			)
		);

		$valid_hooks = norvex_element_hook_choices();

		foreach ( $element_ids as $element_id ) {
			$hook = get_post_meta( $element_id, '_norvex_element_hook', true );

			if ( ! $hook || ! array_key_exists( $hook, $valid_hooks ) ) {
				continue;
			}

			$priority = get_post_meta( $element_id, '_norvex_element_priority', true );
			$priority = ( '' === $priority ) ? 10 : absint( $priority );

			$map[] = array(
				'id'       => (int) $element_id,
				'hook'     => $hook,
				'priority' => $priority,
				'raw'      => norvex_element_is_code_hook( $hook ),
			);
		}
	}

	set_transient( NORVEX_ELEMENT_HOOK_CACHE, $map, DAY_IN_SECONDS );

	return $map;
}

/**
 * Attach all published elements to their configured hooks on the front end.
 */
function norvex_register_elements() {
	if ( is_admin() ) {
		return;
	}

	foreach ( norvex_get_element_hook_map() as $item ) {
		$element_id = $item['id'];
		$raw        = $item['raw'];

		add_action(
			$item['hook'],
			function () use ( $element_id, $raw ) {
				$element = get_post( $element_id );
				if ( $element instanceof WP_Post ) {
					norvex_render_element( $element, $raw );
				}
			},
			$item['priority']
		);
	}
}
add_action( 'template_redirect', 'norvex_register_elements' );

/**
 * Clear the cached element-to-hook map so the next front-end request rebuilds it.
 */
function norvex_flush_element_hook_cache() {
	delete_transient( NORVEX_ELEMENT_HOOK_CACHE );
}
add_action( 'save_post_norvex_element', 'norvex_flush_element_hook_cache' );

/**
 * Flush the element cache on trash/untrash/delete, guarding by post type.
 *
 * @param int          $post_id Post being changed.
 * @param WP_Post|null $post    Post object, when the hook provides one.
 */
function norvex_flush_element_hook_cache_by_id( $post_id, $post = null ) {
	$post_type = ( $post instanceof WP_Post ) ? $post->post_type : get_post_type( $post_id );

	if ( 'norvex_element' === $post_type ) {
		norvex_flush_element_hook_cache();
	}
}
add_action( 'trashed_post', 'norvex_flush_element_hook_cache_by_id', 10, 2 );
add_action( 'untrashed_post', 'norvex_flush_element_hook_cache_by_id', 10, 2 );
add_action( 'deleted_post', 'norvex_flush_element_hook_cache_by_id', 10, 2 );

/**
 * Add "Hook" and "Display" columns to the Elements list table.
 *
 * @param array $columns Existing columns.
 * @return array
 */
function norvex_element_columns( $columns ) {
	$new = array();
	foreach ( $columns as $key => $label ) {
		$new[ $key ] = $label;
		if ( 'title' === $key ) {
			$new['norvex_hook_col']    = esc_html__( 'Hook', 'norvex' );
			$new['norvex_display_col'] = esc_html__( 'Display', 'norvex' );
		}
	}
	return $new;
}
add_filter( 'manage_norvex_element_posts_columns', 'norvex_element_columns' );

/**
 * Populate the custom Elements columns.
 *
 * @param string $column  Column key.
 * @param int    $post_id Element ID.
 */
function norvex_element_column_content( $column, $post_id ) {
	if ( 'norvex_hook_col' === $column ) {
		$hook    = get_post_meta( $post_id, '_norvex_element_hook', true );
		$choices = norvex_element_hook_choices();
		echo esc_html( isset( $choices[ $hook ] ) ? $choices[ $hook ] : '—' );
	}
	if ( 'norvex_display_col' === $column ) {
		$display = get_post_meta( $post_id, '_norvex_element_display', true );
		$choices = norvex_element_display_choices();
		echo esc_html( isset( $choices[ $display ] ) ? $choices[ $display ] : '—' );
	}
}
add_action( 'manage_norvex_element_posts_custom_column', 'norvex_element_column_content', 10, 2 );
