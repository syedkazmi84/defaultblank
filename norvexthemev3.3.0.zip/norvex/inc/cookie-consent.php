<?php
/**
 * Cookie consent banner (GDPR).
 *
 * A lightweight, self-hosted consent notice — no third-party service. It shows a
 * dismissible bar until the visitor accepts or declines, remembers the choice in
 * a first-party cookie, and exposes norvex_cookie_consent() so analytics or
 * marketing snippets (e.g. added via the Hook Elements manager) can hold off
 * until the visitor has opted in.
 *
 * Text, buttons and the policy link are all editable in
 * Customizer → Norvex · Cookie consent. Off by default is a deliberate
 * choice left to the site owner; enable it there.
 *
 * @package Norvex
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Name of the first-party cookie that stores the visitor's choice.
 */
function norvex_cookie_name() {
	return 'norvex_cookie_consent';
}

/**
 * The visitor's stored consent decision.
 *
 * @return string 'accept', 'decline', or '' when no choice has been made yet.
 */
function norvex_cookie_consent() {
	$name = norvex_cookie_name();
	if ( empty( $_COOKIE[ $name ] ) ) {
		return '';
	}
	$val = sanitize_key( wp_unslash( $_COOKIE[ $name ] ) );
	return in_array( $val, array( 'accept', 'decline' ), true ) ? $val : '';
}

/**
 * Register the Cookie consent Customizer section.
 */
function norvex_cookie_customize( $wp_customize ) {
	$wp_customize->add_section(
		'norvex_cookie',
		array(
			'title'       => __( 'Norvex · Cookie consent', 'norvex' ),
			'description' => __( 'A GDPR-style consent bar shown until a visitor accepts or declines.', 'norvex' ),
			'priority'    => 35,
		)
	);

	$fields = array(
		'norvex_cookie_enabled' => array(
			'label'   => __( 'Show the cookie consent bar', 'norvex' ),
			'type'    => 'checkbox',
			'default' => false,
		),
		'norvex_cookie_message' => array(
			'label'   => __( 'Message', 'norvex' ),
			'type'    => 'textarea',
			'default' => __( 'We use cookies to improve your experience, analyse traffic and remember your preferences. You can accept or decline non-essential cookies.', 'norvex' ),
		),
		'norvex_cookie_accept'  => array(
			'label'   => __( 'Accept button label', 'norvex' ),
			'type'    => 'text',
			'default' => __( 'Accept', 'norvex' ),
		),
		'norvex_cookie_decline' => array(
			'label'   => __( 'Decline button label', 'norvex' ),
			'type'    => 'text',
			'default' => __( 'Decline', 'norvex' ),
		),
		'norvex_cookie_policy'  => array(
			'label'       => __( 'Privacy policy link', 'norvex' ),
			'type'        => 'url',
			'default'     => '',
			'description' => __( 'Leave blank to use the site’s Privacy Policy page (Settings → Privacy).', 'norvex' ),
		),
	);

	foreach ( $fields as $id => $f ) {
		$sanitize = 'norvex_sanitize_checkbox';
		if ( 'textarea' === $f['type'] ) {
			$sanitize = 'sanitize_textarea_field';
		} elseif ( 'url' === $f['type'] ) {
			$sanitize = 'esc_url_raw';
		} elseif ( 'text' === $f['type'] ) {
			$sanitize = 'sanitize_text_field';
		}

		$wp_customize->add_setting(
			$id,
			array(
				'default'           => $f['default'],
				'sanitize_callback' => $sanitize,
			)
		);
		$wp_customize->add_control(
			$id,
			array(
				'label'       => $f['label'],
				'description' => isset( $f['description'] ) ? $f['description'] : '',
				'section'     => 'norvex_cookie',
				'type'        => $f['type'],
			)
		);
	}
}
add_action( 'customize_register', 'norvex_cookie_customize' );

/**
 * Resolve the privacy-policy URL used in the banner (custom link, else the
 * site's configured Privacy Policy page).
 *
 * @return string
 */
function norvex_cookie_policy_url() {
	$url = get_theme_mod( 'norvex_cookie_policy', '' );
	if ( $url ) {
		return $url;
	}
	return function_exists( 'get_privacy_policy_url' ) ? get_privacy_policy_url() : '';
}

/**
 * Print the consent bar in the footer.
 *
 * Rendered server-side only when the visitor has not yet chosen, so there is no
 * flash of an already-answered banner. The script also re-hides it on load if a
 * full-page cache served the pre-consent markup after a choice was made.
 */
function norvex_cookie_banner() {
	if ( ! get_theme_mod( 'norvex_cookie_enabled', false ) ) {
		return;
	}
	if ( '' !== norvex_cookie_consent() ) {
		return; // Already accepted or declined.
	}
	if ( is_customize_preview() ) {
		return; // Don't cover the Customizer preview controls.
	}

	$message = get_theme_mod( 'norvex_cookie_message', __( 'We use cookies to improve your experience, analyse traffic and remember your preferences. You can accept or decline non-essential cookies.', 'norvex' ) );
	$accept  = get_theme_mod( 'norvex_cookie_accept', __( 'Accept', 'norvex' ) );
	$decline = get_theme_mod( 'norvex_cookie_decline', __( 'Decline', 'norvex' ) );
	$policy  = norvex_cookie_policy_url();
	?>
	<div class="norvex-cookie" id="norvex-cookie" role="dialog" aria-live="polite" aria-label="<?php esc_attr_e( 'Cookie consent', 'norvex' ); ?>">
		<div class="norvex-cookie__inner">
			<p class="norvex-cookie__text">
				<?php echo esc_html( $message ); ?>
				<?php if ( $policy ) : ?>
					<a href="<?php echo esc_url( $policy ); ?>"><?php esc_html_e( 'Privacy Policy', 'norvex' ); ?></a>
				<?php endif; ?>
			</p>
			<div class="norvex-cookie__actions">
				<button type="button" class="norvex-btn norvex-btn--ghost" data-norvex-cookie="decline"><?php echo esc_html( $decline ); ?></button>
				<button type="button" class="norvex-btn norvex-btn--primary" data-norvex-cookie="accept"><?php echo esc_html( $accept ); ?></button>
			</div>
		</div>
	</div>
	<?php
}
add_action( 'wp_footer', 'norvex_cookie_banner' );
