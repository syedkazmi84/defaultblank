<?php
/**
 * Leads inbox.
 *
 * Stores every contact-form submission as a private "Lead" record so a message
 * is never lost if email delivery fails or lands in spam. Leads are listed under
 * Norvex → Leads with the name, email, requested service and source, can be
 * opened to read the full message, and exported to CSV. The captured Google Ads
 * click id (GCLID) is kept alongside each lead for offline-conversion import.
 *
 * @package Norvex
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Register the Lead post type (private, under the Norvex hub, no "Add New").
 */
function norvex_register_lead_cpt() {
	$labels = array(
		'name'               => esc_html__( 'Leads', 'norvex' ),
		'singular_name'      => esc_html__( 'Lead', 'norvex' ),
		'edit_item'          => esc_html__( 'View Lead', 'norvex' ),
		'view_item'          => esc_html__( 'View Lead', 'norvex' ),
		'search_items'       => esc_html__( 'Search Leads', 'norvex' ),
		'not_found'          => esc_html__( 'No leads yet.', 'norvex' ),
		'not_found_in_trash' => esc_html__( 'No leads found in Trash.', 'norvex' ),
		'all_items'          => esc_html__( 'Leads', 'norvex' ),
		'menu_name'          => esc_html__( 'Leads', 'norvex' ),
	);

	register_post_type(
		'norvex_lead',
		array(
			'labels'          => $labels,
			'public'          => false,
			'show_ui'         => true,
			'show_in_menu'    => 'norvex-hub',
			'show_in_rest'    => false,
			'menu_icon'       => 'dashicons-email-alt2',
			// Title only — the message is shown read-only in a meta box, so a lead
			// reads as a record rather than an editable document.
			'supports'        => array( 'title' ),
			'capability_type' => 'post',
			'map_meta_cap'    => true,
			// Leads arrive from the contact form — don't offer manual creation.
			'capabilities'    => array( 'create_posts' => 'do_not_allow' ),
			'rewrite'         => false,
			'query_var'       => false,
		)
	);
}
add_action( 'init', 'norvex_register_lead_cpt' );

/**
 * Drop the "Private:" / "Protected:" prefix WordPress adds to lead titles.
 *
 * @param string       $format printf format for the title.
 * @param WP_Post|null $post   The post, when provided by the filter.
 * @return string
 */
function norvex_lead_title_format( $format, $post = null ) {
	if ( $post instanceof WP_Post && 'norvex_lead' === $post->post_type ) {
		return '%s';
	}
	return $format;
}
add_filter( 'private_title_format', 'norvex_lead_title_format', 10, 2 );
add_filter( 'protected_title_format', 'norvex_lead_title_format', 10, 2 );

/**
 * Store a contact-form submission as a Lead.
 *
 * Called on every valid submission — independently of whether the notification
 * email sends — so the enquiry is always captured.
 *
 * @param array $data name, email, service, message, gclid, source.
 * @return int New lead ID, or 0 on failure.
 */
function norvex_store_lead( $data ) {
	$name  = isset( $data['name'] ) ? trim( (string) $data['name'] ) : '';
	$email = isset( $data['email'] ) ? trim( (string) $data['email'] ) : '';
	$title = '' !== $name ? $name : ( '' !== $email ? $email : __( 'Lead', 'norvex' ) );

	$post_id = wp_insert_post(
		array(
			'post_type'    => 'norvex_lead',
			'post_status'  => 'private',
			'post_title'   => $title,
			'post_content' => isset( $data['message'] ) ? (string) $data['message'] : '',
		),
		true
	);

	if ( is_wp_error( $post_id ) || ! $post_id ) {
		return 0;
	}

	if ( '' !== $email ) {
		update_post_meta( $post_id, '_norvex_lead_email', sanitize_email( $email ) );
	}
	if ( ! empty( $data['service'] ) ) {
		update_post_meta( $post_id, '_norvex_lead_service', sanitize_text_field( $data['service'] ) );
	}
	if ( ! empty( $data['gclid'] ) ) {
		update_post_meta( $post_id, '_norvex_lead_gclid', sanitize_text_field( $data['gclid'] ) );
	}
	if ( ! empty( $data['source'] ) ) {
		update_post_meta( $post_id, '_norvex_lead_source', esc_url_raw( $data['source'] ) );
	}

	/**
	 * Fires after a lead is stored. Hook a CRM/webhook integration here.
	 *
	 * @param int   $post_id Lead post ID.
	 * @param array $data    Submitted lead data.
	 */
	do_action( 'norvex_lead_stored', $post_id, $data );

	return (int) $post_id;
}

/**
 * Count of leads received in the current calendar month (for the dashboard).
 *
 * @return int
 */
function norvex_leads_this_month() {
	$leads = get_posts(
		array(
			'post_type'      => 'norvex_lead',
			'post_status'    => array( 'private', 'publish' ),
			'fields'         => 'ids',
			'numberposts'    => -1,
			'date_query'     => array(
				array(
					'year'  => (int) current_time( 'Y' ),
					'month' => (int) current_time( 'n' ),
				),
			),
			'suppress_filters' => false,
		)
	);
	return count( $leads );
}

/* -------------------------------------------------------------------------
 * Admin list: columns, detail box, CSV export.
 * ---------------------------------------------------------------------- */

/**
 * Columns for the Leads list table.
 *
 * @param array $cols Existing columns.
 * @return array
 */
function norvex_lead_columns( $cols ) {
	$new         = array();
	$new['cb']   = isset( $cols['cb'] ) ? $cols['cb'] : '';
	$new['title']                = __( 'Name', 'norvex' );
	$new['norvex_lead_email']    = __( 'Email', 'norvex' );
	$new['norvex_lead_service']  = __( 'Service', 'norvex' );
	$new['norvex_lead_source']   = __( 'Source', 'norvex' );
	$new['norvex_lead_received'] = __( 'Received', 'norvex' );
	return $new;
}
add_filter( 'manage_norvex_lead_posts_columns', 'norvex_lead_columns' );

/**
 * Make the Received column sortable (by post date).
 *
 * @param array $cols Sortable columns.
 * @return array
 */
function norvex_lead_sortable_columns( $cols ) {
	$cols['norvex_lead_received'] = 'date';
	return $cols;
}
add_filter( 'manage_edit-norvex_lead_sortable_columns', 'norvex_lead_sortable_columns' );

/**
 * Hide the "Private" post-state label on leads (they are all private).
 *
 * @param string[] $states Post states.
 * @param WP_Post  $post   The post.
 * @return string[]
 */
function norvex_lead_hide_states( $states, $post ) {
	if ( $post instanceof WP_Post && 'norvex_lead' === $post->post_type ) {
		return array();
	}
	return $states;
}
add_filter( 'display_post_states', 'norvex_lead_hide_states', 10, 2 );

/**
 * Render the custom Lead columns.
 *
 * @param string $column  Column key.
 * @param int    $post_id Lead ID.
 */
function norvex_lead_column_content( $column, $post_id ) {
	if ( 'norvex_lead_email' === $column ) {
		$email = get_post_meta( $post_id, '_norvex_lead_email', true );
		if ( $email ) {
			echo '<a href="mailto:' . esc_attr( $email ) . '">' . esc_html( $email ) . '</a>';
		} else {
			echo '&mdash;';
		}
	} elseif ( 'norvex_lead_service' === $column ) {
		$service = get_post_meta( $post_id, '_norvex_lead_service', true );
		echo $service ? esc_html( $service ) : '&mdash;';
	} elseif ( 'norvex_lead_source' === $column ) {
		$source = get_post_meta( $post_id, '_norvex_lead_source', true );
		if ( $source ) {
			$host = wp_parse_url( $source, PHP_URL_HOST );
			echo '<span title="' . esc_attr( $source ) . '">' . esc_html( $host ? $host : $source ) . '</span>';
		} else {
			echo '&mdash;';
		}
	} elseif ( 'norvex_lead_received' === $column ) {
		echo esc_html( get_the_date( '', $post_id ) . ' · ' . get_the_time( '', $post_id ) );
	}
}
add_action( 'manage_norvex_lead_posts_custom_column', 'norvex_lead_column_content', 10, 2 );

/**
 * Read-only meta boxes on the lead screen: the message + the details side box.
 */
function norvex_lead_boxes() {
	add_meta_box(
		'norvex_lead_message',
		__( 'Message', 'norvex' ),
		'norvex_lead_message_html',
		'norvex_lead',
		'normal',
		'high'
	);
	add_meta_box(
		'norvex_lead_details',
		__( 'Lead details', 'norvex' ),
		'norvex_lead_details_html',
		'norvex_lead',
		'side',
		'high'
	);
}
add_action( 'add_meta_boxes', 'norvex_lead_boxes' );

/**
 * Read-only display of the lead's message.
 *
 * @param WP_Post $post Lead post.
 */
function norvex_lead_message_html( $post ) {
	$message = trim( (string) $post->post_content );
	if ( '' === $message ) {
		echo '<p style="color:#646970;margin:4px 0;">' . esc_html__( 'No message was included.', 'norvex' ) . '</p>';
		return;
	}
	echo '<div style="white-space:pre-wrap;font-size:14px;line-height:1.7;color:#1d2327;padding:4px 2px;">' . esc_html( $message ) . '</div>';
}

/**
 * Make the lead's name (title) read-only — it's a captured record, not a draft.
 */
function norvex_lead_readonly_title() {
	$screen = get_current_screen();
	if ( ! $screen || 'norvex_lead' !== $screen->post_type || 'post' !== $screen->base ) {
		return;
	}
	echo '<style>#titlediv #title{background:#f6f7f7;cursor:default;}</style>';
	echo '<script>document.addEventListener("DOMContentLoaded",function(){var t=document.getElementById("title");if(t){t.readOnly=true;}});</script>';
}
add_action( 'admin_head', 'norvex_lead_readonly_title' );

/**
 * Markup for the Lead details box.
 *
 * @param WP_Post $post Lead post.
 */
function norvex_lead_details_html( $post ) {
	$email   = get_post_meta( $post->ID, '_norvex_lead_email', true );
	$service = get_post_meta( $post->ID, '_norvex_lead_service', true );
	$source  = get_post_meta( $post->ID, '_norvex_lead_source', true );
	$gclid   = get_post_meta( $post->ID, '_norvex_lead_gclid', true );

	echo '<table style="width:100%;font-size:13px;line-height:1.6;">';
	echo '<tr><th style="text-align:left;width:40%;padding:4px 0;">' . esc_html__( 'Email', 'norvex' ) . '</th><td>' . ( $email ? '<a href="mailto:' . esc_attr( $email ) . '">' . esc_html( $email ) . '</a>' : '&mdash;' ) . '</td></tr>';
	echo '<tr><th style="text-align:left;padding:4px 0;">' . esc_html__( 'Service', 'norvex' ) . '</th><td>' . ( $service ? esc_html( $service ) : '&mdash;' ) . '</td></tr>';
	echo '<tr><th style="text-align:left;padding:4px 0;">' . esc_html__( 'Received', 'norvex' ) . '</th><td>' . esc_html( get_the_date( '', $post ) . ' ' . get_the_time( '', $post ) ) . '</td></tr>';
	if ( $source ) {
		echo '<tr><th style="text-align:left;padding:4px 0;">' . esc_html__( 'Source', 'norvex' ) . '</th><td><a href="' . esc_url( $source ) . '" target="_blank" rel="noopener" style="word-break:break-all;">' . esc_html( $source ) . '</a></td></tr>';
	}
	if ( $gclid ) {
		echo '<tr><th style="text-align:left;padding:4px 0;">' . esc_html__( 'Google Ads (GCLID)', 'norvex' ) . '</th><td style="word-break:break-all;">' . esc_html( $gclid ) . '</td></tr>';
	}
	echo '</table>';
	echo '<p style="margin:12px 0 0;color:#646970;font-size:12px;">' . esc_html__( 'This is a read-only record of a form submission. The full message is in the Message box.', 'norvex' ) . '</p>';
}

/**
 * Print an "Export all to CSV" button above the Leads list.
 *
 * @param string $which Position ('top' or 'bottom').
 */
function norvex_leads_export_button( $which ) {
	$screen = get_current_screen();
	if ( ! $screen || 'norvex_lead' !== $screen->post_type || 'top' !== $which ) {
		return;
	}
	$url = wp_nonce_url( admin_url( 'admin-post.php?action=norvex_export_leads' ), 'norvex_export_leads' );
	echo '<div class="alignleft actions"><a href="' . esc_url( $url ) . '" class="button">' . esc_html__( 'Export all to CSV', 'norvex' ) . '</a></div>';
}
add_action( 'manage_posts_extra_tablenav', 'norvex_leads_export_button' );

/**
 * Stream all leads as a CSV download (admin-post handler).
 */
function norvex_leads_export() {
	if ( ! current_user_can( 'edit_posts' ) ) {
		wp_die( esc_html__( 'You are not allowed to do that.', 'norvex' ) );
	}
	check_admin_referer( 'norvex_export_leads' );

	$leads = get_posts(
		array(
			'post_type'   => 'norvex_lead',
			'post_status' => array( 'private', 'publish' ),
			'numberposts' => -1,
			'orderby'     => 'date',
			'order'       => 'DESC',
		)
	);

	nocache_headers();
	header( 'Content-Type: text/csv; charset=utf-8' );
	header( 'Content-Disposition: attachment; filename=norvex-leads-' . gmdate( 'Y-m-d' ) . '.csv' );

	$out = fopen( 'php://output', 'w' );
	fputcsv(
		$out,
		array(
			__( 'Name', 'norvex' ),
			__( 'Email', 'norvex' ),
			__( 'Service', 'norvex' ),
			__( 'Message', 'norvex' ),
			__( 'Source', 'norvex' ),
			__( 'GCLID', 'norvex' ),
			__( 'Received', 'norvex' ),
		)
	);

	foreach ( $leads as $lead ) {
		fputcsv(
			$out,
			array(
				get_the_title( $lead ),
				get_post_meta( $lead->ID, '_norvex_lead_email', true ),
				get_post_meta( $lead->ID, '_norvex_lead_service', true ),
				$lead->post_content,
				get_post_meta( $lead->ID, '_norvex_lead_source', true ),
				get_post_meta( $lead->ID, '_norvex_lead_gclid', true ),
				get_the_date( 'Y-m-d H:i', $lead ),
			)
		);
	}
	fclose( $out ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fclose -- writing to php://output stream.
	exit;
}
add_action( 'admin_post_norvex_export_leads', 'norvex_leads_export' );
