<?php
/**
 * Building blocks + section patterns.
 *
 * Small, single-element blocks used to *compose* custom sections:
 *   - norvex/section-header  (eyebrow + heading + lead)
 *   - norvex/callout         (highlight bar, green/sand/rust)
 *   - norvex/checklist       (check / cross rows)
 * plus a "Section band" container delivered as core/group block styles, and
 * block *patterns* that expose every complete section (a set of blocks) in the
 * editor's Patterns tab — so the dashboard cleanly separates single Building
 * Blocks (Blocks tab) from Sections (Patterns tab).
 *
 * The three blocks are field-based dynamic blocks: their config lives in
 * norvex_blocks_config() (inc/blocks.php) and the editor UI is generated
 * automatically from it, exactly like the existing section blocks.
 *
 * @package Norvex
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Render: Section header (eyebrow + heading + lead).
 *
 * @param array $a Block attributes.
 * @return string
 */
function norvex_render_block_section_header( $a ) {
	$a      = wp_parse_args( $a, norvex_block_defaults( 'section-header' ) );
	$center = ( 'center' === $a['align'] ) ? ' norvex-center' : '';
	ob_start();
	?>
	<div class="norvex-section-head<?php echo esc_attr( $center ); ?>">
		<?php if ( '' !== $a['eyebrow'] ) : ?>
			<span class="norvex-eyebrow"><?php echo esc_html( $a['eyebrow'] ); ?></span>
		<?php endif; ?>
		<?php if ( '' !== $a['title'] ) : ?>
			<h2><?php echo esc_html( $a['title'] ); ?></h2>
		<?php endif; ?>
		<?php if ( '' !== $a['lead'] ) : ?>
			<p class="norvex-lead"><?php echo esc_html( $a['lead'] ); ?></p>
		<?php endif; ?>
	</div>
	<?php
	return ob_get_clean();
}

/**
 * Render: Verdict / Quote — a bordered, background-free statement with an
 * optional attribution and an editable accent colour.
 *
 * @param array $a Block attributes.
 * @return string
 */
function norvex_render_block_callout( $a ) {
	$a      = wp_parse_args( $a, norvex_block_defaults( 'callout' ) );
	$accent = in_array( $a['accent'], array( 'green', 'rust', 'ink', 'muted' ), true ) ? $a['accent'] : 'green';
	if ( '' === trim( (string) $a['text'] ) ) {
		return '';
	}
	ob_start();
	?>
	<blockquote class="norvex-verdict norvex-verdict--<?php echo esc_attr( $accent ); ?>">
		<p class="norvex-verdict__text"><?php echo esc_html( $a['text'] ); ?></p>
		<?php if ( '' !== $a['cite'] ) : ?>
			<cite class="norvex-verdict__cite"><?php echo esc_html( $a['cite'] ); ?></cite>
		<?php endif; ?>
	</blockquote>
	<?php
	return ob_get_clean();
}

/**
 * Render: Checklist (check / cross rows). Prefix a line with "!" to cross it out.
 *
 * @param array $a Block attributes.
 * @return string
 */
function norvex_render_block_checklist( $a ) {
	$a    = wp_parse_args( $a, norvex_block_defaults( 'checklist' ) );
	$rows = norvex_parse_features( $a['items'] );
	if ( empty( $rows ) ) {
		return '';
	}
	$cols = ( '2' === (string) $a['cols'] ) ? ' norvex-checks--2col' : '';
	ob_start();
	?>
	<ul class="norvex-checks<?php echo esc_attr( $cols ); ?>">
		<?php
		foreach ( $rows as $r ) :
			list( $label, $inc ) = $r;
			?>
			<li class="norvex-checks__item<?php echo $inc ? '' : ' is-excluded'; ?>">
				<span class="norvex-checks__icon" aria-hidden="true"><?php echo $inc ? '&#10003;' : '&#10007;'; ?></span>
				<span><?php echo esc_html( $label ); ?></span>
			</li>
		<?php endforeach; ?>
	</ul>
	<?php
	return ob_get_clean();
}

/**
 * Render: Notice — a compact announcement banner (icon + heading + message and
 * an optional button). It ships background-free so the block's own Color panel
 * drives its look; pick a background and text colour in the editor sidebar.
 *
 * @param array $a Block attributes.
 * @return string
 */
function norvex_render_block_notice( $a ) {
	$a = wp_parse_args( $a, norvex_block_defaults( 'notice' ) );
	if ( '' === trim( (string) $a['heading'] ) && '' === trim( (string) $a['text'] ) ) {
		return '';
	}
	$icon   = in_array( $a['icon'], array( 'bulb', 'check', 'star', 'shield', 'bell', 'gift' ), true ) ? $a['icon'] : 'bulb';
	$btn    = (string) $a['btn'];
	$btnurl = (string) $a['btnurl'];
	ob_start();
	?>
	<div class="norvex-notice">
		<span class="norvex-notice__icon" aria-hidden="true"><?php echo norvex_icon( $icon, false ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- static SVG. ?></span>
		<div class="norvex-notice__body">
			<?php if ( '' !== trim( (string) $a['heading'] ) ) : ?>
				<p class="norvex-notice__heading"><?php echo esc_html( $a['heading'] ); ?></p>
			<?php endif; ?>
			<?php if ( '' !== trim( (string) $a['text'] ) ) : ?>
				<p class="norvex-notice__text"><?php echo esc_html( $a['text'] ); ?></p>
			<?php endif; ?>
		</div>
		<?php if ( '' !== trim( $btn ) ) : ?>
			<a class="norvex-notice__btn" href="<?php echo esc_url( '' !== $btnurl ? $btnurl : '#' ); ?>"><?php echo esc_html( $btn ); ?></a>
		<?php endif; ?>
	</div>
	<?php
	return ob_get_clean();
}

/**
 * Register the "Section band" container (core/group block styles) and the
 * section block patterns.
 */
function norvex_register_building_blocks() {

	// "Section band" = themed background wrappers on the core Group block, which
	// natively nests any other blocks inside it.
	if ( function_exists( 'register_block_style' ) ) {
		$bands = array(
			'band-cream' => __( 'Section band — Cream', 'norvex' ),
			'band-sand'  => __( 'Section band — Sand', 'norvex' ),
			'band-paper' => __( 'Section band — Paper', 'norvex' ),
			'band-ink'   => __( 'Section band — Ink (dark)', 'norvex' ),
		);
		foreach ( $bands as $slug => $label ) {
			register_block_style( 'core/group', array( 'name' => 'norvex-' . $slug, 'label' => $label ) );
		}
	}

}
add_action( 'init', 'norvex_register_building_blocks', 20 );

/**
 * "Tabs (with blocks)" — an InnerBlocks tab set.
 *
 * norvex/tabset (parent, dynamic) holds norvex/tab children. Each tab
 * is a label + a panel of arbitrary blocks. The render below rebuilds the same
 * .norvex-tabs markup the text-based Tabs block uses, so the theme's
 * existing tab-switching JS and styles apply unchanged.
 */
function norvex_render_block_tabset( $attributes, $content, $block ) {
	$children = ( isset( $block->parsed_block['innerBlocks'] ) && is_array( $block->parsed_block['innerBlocks'] ) )
		? $block->parsed_block['innerBlocks'] : array();

	$tabs = array();
	foreach ( $children as $child ) {
		if ( ! isset( $child['blockName'] ) || 'norvex/tab' !== $child['blockName'] ) {
			continue;
		}
		$title  = ( isset( $child['attrs']['title'] ) && '' !== trim( (string) $child['attrs']['title'] ) )
			? (string) $child['attrs']['title'] : __( 'Tab', 'norvex' );
		$tabs[] = array( 'title' => $title, 'html' => render_block( $child ) );
	}
	if ( empty( $tabs ) ) {
		return '';
	}

	static $n = 0;
	$n++;
	$uid     = 'norvex-tabset-' . $n;
	$heading = isset( $attributes['heading'] ) ? (string) $attributes['heading'] : '';

	ob_start();
	?>
	<div class="norvex-section norvex-section--tight">
		<div class="norvex-wrap">
			<?php if ( '' !== trim( $heading ) ) : ?>
				<h2 class="norvex-tabs__heading"><?php echo esc_html( $heading ); ?></h2>
			<?php endif; ?>
			<div class="norvex-tabs" data-norvex-tabs>
				<div class="norvex-tabs__nav" role="tablist">
					<?php foreach ( $tabs as $i => $t ) : ?>
						<button type="button" class="norvex-tabs__tab<?php echo 0 === $i ? ' is-active' : ''; ?>" id="<?php echo esc_attr( $uid . '-tab-' . $i ); ?>" role="tab" aria-selected="<?php echo 0 === $i ? 'true' : 'false'; ?>" aria-controls="<?php echo esc_attr( $uid . '-panel-' . $i ); ?>" tabindex="<?php echo 0 === $i ? '0' : '-1'; ?>"><?php echo esc_html( $t['title'] ); ?></button>
					<?php endforeach; ?>
				</div>
				<div class="norvex-tabs__panels">
					<?php foreach ( $tabs as $i => $t ) : ?>
						<div class="norvex-tabs__panel<?php echo 0 === $i ? ' is-active' : ''; ?>" id="<?php echo esc_attr( $uid . '-panel-' . $i ); ?>" role="tabpanel" aria-labelledby="<?php echo esc_attr( $uid . '-tab-' . $i ); ?>" <?php echo 0 === $i ? '' : 'hidden'; ?>><?php echo $t['html']; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- output produced by render_block(). ?></div>
					<?php endforeach; ?>
				</div>
			</div>
		</div>
	</div>
	<?php
	$out = ob_get_clean();
	return function_exists( 'norvex_apply_block_style_supports' ) ? norvex_apply_block_style_supports( $out ) : $out;
}

/**
 * Register the tabset blocks (server side) so the parent renders dynamically
 * and both are known to WordPress.
 */
function norvex_register_tabset() {
	if ( ! function_exists( 'register_block_type' ) ) {
		return;
	}
	register_block_type(
		'norvex/tab',
		array(
			'api_version' => 2,
			'attributes'  => array( 'title' => array( 'type' => 'string', 'default' => 'Tab' ) ),
		)
	);
	register_block_type(
		'norvex/tabset',
		array(
			'api_version'     => 2,
			'attributes'      => array( 'heading' => array( 'type' => 'string', 'default' => '' ) ),
			'supports'        => function_exists( 'norvex_block_style_supports' ) ? norvex_block_style_supports() : array(),
			'render_callback' => 'norvex_render_block_tabset',
		)
	);
}
add_action( 'init', 'norvex_register_tabset' );

/**
 * Load the tabset editor script.
 */
function norvex_tabset_editor_assets() {
	wp_enqueue_script(
		'norvex-tabset',
		NORVEX_URI . '/blocks/tabs-blocks.js',
		array( 'wp-blocks', 'wp-element', 'wp-block-editor', 'wp-components', 'wp-i18n', 'wp-data' ),
		NORVEX_VERSION,
		true
	);
	if ( function_exists( 'wp_set_script_translations' ) ) {
		wp_set_script_translations( 'norvex-tabset', 'norvex' );
	}
}
add_action( 'enqueue_block_editor_assets', 'norvex_tabset_editor_assets' );
