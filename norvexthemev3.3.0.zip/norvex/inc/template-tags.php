<?php
/**
 * Reusable template helpers: icons, meta, breadcrumbs, defaults.
 *
 * @package Norvex
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Output a stat number as a <strong> wired for the count-up animation
 * (assets/js/theme.js). Splits a value like "750+", "100%" or "12,000+" into a
 * numeric target (data-count) and a suffix (data-suffix). Non-numeric values
 * (e.g. "24/7") fall back to plain text with no animation. The visible text is
 * always the full value, so it reads correctly before JS runs or if disabled.
 *
 * @param string $value Display value.
 */
function norvex_stat_number( $value ) {
	$value = (string) $value;
	if ( preg_match( '/^\s*([\d][\d.,]*)(.*)$/', $value, $m ) ) {
		$num    = (float) str_replace( ',', '', $m[1] );
		$suffix = trim( $m[2] );
		printf(
			'<strong data-count="%s" data-suffix="%s">%s</strong>',
			esc_attr( $num ),
			esc_attr( $suffix ),
			esc_html( $value )
		);
		return;
	}
	printf( '<strong>%s</strong>', esc_html( $value ) );
}

/**
 * Return the URL for a bundled asset image.
 */
function norvex_img( $file ) {
	return esc_url( NORVEX_URI . '/assets/images/' . ltrim( $file, '/' ) );
}

/**
 * Inline SVG icon set (stroke icons, 24x24 viewbox).
 */
function norvex_icon_paths() {
	return array(
		'edit'      => '<path d="M12 20h9"/><path d="M16.5 3.5a2.1 2.1 0 0 1 3 3L7 19l-4 1 1-4Z"/>',
		'book'      => '<path d="M4 19.5A2.5 2.5 0 0 1 6.5 17H20"/><path d="M6.5 2H20v20H6.5A2.5 2.5 0 0 1 4 19.5v-15A2.5 2.5 0 0 1 6.5 2Z"/>',
		'design'    => '<circle cx="13.5" cy="6.5" r="2.5"/><circle cx="17.5" cy="10.5" r="2.5"/><circle cx="8.5" cy="7.5" r="2.5"/><circle cx="6.5" cy="12.5" r="2.5"/><path d="M12 2a10 10 0 1 0 0 20 3 3 0 0 0 3-3 2 2 0 0 1 2-2h1a4 4 0 0 0 4-4 10 10 0 0 0-10-9Z"/>',
		'quill'     => '<path d="M3 21c3-3 6-3 9-6s5-6 9-12c-6 4-9 6-12 9s-3 6-6 9Z"/><path d="M3 21h6"/>',
		'megaphone' => '<path d="m3 11 18-5v12L3 14v-3Z"/><path d="M11.6 16.8a3 3 0 1 1-5.8-1.6"/>',
		'print'     => '<path d="M6 9V2h12v7"/><path d="M6 18H4a2 2 0 0 1-2-2v-5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v5a2 2 0 0 1-2 2h-2"/><rect x="6" y="14" width="12" height="8"/>',
		'monitor'   => '<rect x="2" y="3" width="20" height="14" rx="2"/><path d="M8 21h8"/><path d="M12 17v4"/>',
		'mic'       => '<rect x="9" y="2" width="6" height="12" rx="3"/><path d="M5 10a7 7 0 0 0 14 0"/><path d="M12 17v4"/><path d="M8 21h8"/>',
		'calendar'  => '<rect x="3" y="4" width="18" height="18" rx="2"/><path d="M16 2v4M8 2v4M3 10h18"/><path d="m9 16 2 2 4-4"/>',
		'sparkle'   => '<path d="M12 3v4M12 17v4M3 12h4M17 12h4"/><path d="m6.3 6.3 2.8 2.8M14.9 14.9l2.8 2.8M17.7 6.3l-2.8 2.8M9.1 14.9l-2.8 2.8"/>',
		'globe'     => '<circle cx="12" cy="12" r="10"/><path d="M2 12h20"/><path d="M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10Z"/>',
		'search'    => '<circle cx="11" cy="11" r="8"/><path d="m21 21-4.3-4.3"/>',
		'chart'     => '<path d="M3 3v18h18"/><path d="m19 9-5 5-4-4-3 3"/>',
		'shield'    => '<path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10Z"/>',
		'check'     => '<path d="M20 6 9 17l-5-5"/>',
		'mail'      => '<rect x="2" y="4" width="20" height="16" rx="2"/><path d="m22 7-10 6L2 7"/>',
		'phone'     => '<path d="M22 16.9v3a2 2 0 0 1-2.2 2 19.8 19.8 0 0 1-8.6-3 19.5 19.5 0 0 1-6-6 19.8 19.8 0 0 1-3-8.6A2 2 0 0 1 4.1 2h3a2 2 0 0 1 2 1.7 12.8 12.8 0 0 0 .7 2.8 2 2 0 0 1-.5 2.1L8.1 9.9a16 16 0 0 0 6 6l1.3-1.3a2 2 0 0 1 2.1-.4 12.8 12.8 0 0 0 2.8.7 2 2 0 0 1 1.7 2Z"/>',
		'pin'       => '<path d="M20 10c0 6-8 12-8 12s-8-6-8-12a8 8 0 0 1 16 0Z"/><circle cx="12" cy="10" r="3"/>',
		'clock'     => '<circle cx="12" cy="12" r="10"/><path d="M12 6v6l4 2"/>',
		'star'      => '<path d="m12 2 3 6.5 7 .9-5 4.9 1.2 7L12 18l-6.4 3.3L6.9 14 2 9.1l7-1Z"/>',
		'arrow'     => '<path d="M5 12h14"/><path d="m12 5 7 7-7 7"/>',
			'link'      => '<path d="M10 13a5 5 0 0 0 7.5.5l3-3a5 5 0 0 0-7-7l-1.5 1.5"/><path d="M14 11a5 5 0 0 0-7.5-.5l-3 3a5 5 0 0 0 7 7l1.5-1.5"/>',
		'users'     => '<path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M22 21v-2a4 4 0 0 0-3-3.9"/><path d="M16 3.1A4 4 0 0 1 16 11"/>',
		'award'     => '<circle cx="12" cy="8" r="6"/><path d="M8.2 13.9 7 22l5-3 5 3-1.2-8.1"/>',
		'heart'     => '<path d="M19 14c1.49-1.46 3-3.21 3-5.5A5.5 5.5 0 0 0 16.5 3c-1.76 0-3 .5-4.5 2-1.5-1.5-2.74-2-4.5-2A5.5 5.5 0 0 0 2 8.5c0 2.29 1.51 4.04 3 5.5l7 7Z"/>',
		'gift'      => '<rect x="3" y="8" width="18" height="4" rx="1"/><path d="M12 8v13"/><path d="M19 12v7a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2v-7"/><path d="M7.5 8a2.5 2.5 0 0 1 0-5C11 3 12 8 12 8s1-5 4.5-5a2.5 2.5 0 0 1 0 5"/>',
		'target'    => '<circle cx="12" cy="12" r="10"/><circle cx="12" cy="12" r="6"/><circle cx="12" cy="12" r="2"/>',
		'bulb'      => '<path d="M15 14c.2-1 .7-1.7 1.5-2.5 1-.9 1.5-2.2 1.5-3.5A6 6 0 0 0 6 8c0 1 .2 2.2 1.5 3.5.7.7 1.3 1.5 1.5 2.5"/><path d="M9 18h6"/><path d="M10 22h4"/>',
		'tag'       => '<path d="M12.6 2.6A2 2 0 0 0 11.2 2H4a2 2 0 0 0-2 2v7.2a2 2 0 0 0 .6 1.4l8.8 8.8a2 2 0 0 0 2.8 0l6.8-6.8a2 2 0 0 0 0-2.8Z"/><circle cx="7.5" cy="7.5" r="1"/>',
		'flag'      => '<path d="M4 15s1-1 4-1 5 2 8 2 4-1 4-1V3s-1 1-4 1-5-2-8-2-4 1-4 1z"/><line x1="4" y1="22" x2="4" y2="15"/>',
		'home'      => '<path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/><path d="M9 22V12h6v10"/>',
		'bell'      => '<path d="M6 8a6 6 0 0 1 12 0c0 7 3 9 3 9H3s3-2 3-9"/><path d="M10.3 21a1.94 1.94 0 0 0 3.4 0"/>',
		'lock'      => '<rect x="3" y="11" width="18" height="11" rx="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/>',
		'rocket'    => '<path d="M4.5 16.5c-1.5 1.26-2 5-2 5s3.74-.5 5-2c.71-.84.7-2.13-.09-2.91a2.18 2.18 0 0 0-2.91-.09z"/><path d="M12 15l-3-3a22 22 0 0 1 2-3.95A12.88 12.88 0 0 1 22 2c0 2.72-.78 7.5-6 11a22.35 22.35 0 0 1-4 2z"/><path d="M9 12H4s.55-3.03 2-4c1.62-1.08 5 0 5 0"/><path d="M12 15v5s3.03-.55 4-2c1.08-1.62 0-5 0-5"/>',
		'thumbup'   => '<path d="M7 10v12"/><path d="M15 5.88 14 10h5.83a2 2 0 0 1 1.92 2.56l-2.33 8A2 2 0 0 1 17.5 22H4a2 2 0 0 1-2-2v-8a2 2 0 0 1 2-2h2.76a2 2 0 0 0 1.79-1.11L12 2a3.13 3.13 0 0 1 3 3.88Z"/>',
		'download'  => '<path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/>',
		'upload'    => '<path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="17 8 12 3 7 8"/><line x1="12" y1="3" x2="12" y2="15"/>',
		'image'     => '<rect x="3" y="3" width="18" height="18" rx="2"/><circle cx="9" cy="9" r="2"/><path d="m21 15-3.09-3.09a2 2 0 0 0-2.82 0L6 21"/>',
		'folder'    => '<path d="M4 20h16a2 2 0 0 0 2-2V8a2 2 0 0 0-2-2h-7.93a2 2 0 0 1-1.66-.9l-.82-1.2A2 2 0 0 0 7.93 3H4a2 2 0 0 0-2 2v13c0 1.1.9 2 2 2Z"/>',
		'camera'    => '<path d="M14.5 4h-5L7 7H4a2 2 0 0 0-2 2v9a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2V9a2 2 0 0 0-2-2h-3l-2.5-3z"/><circle cx="12" cy="13" r="3"/>',
		'play'      => '<polygon points="6 3 20 12 6 21 6 3"/>',
		'cart'      => '<circle cx="8" cy="21" r="1"/><circle cx="19" cy="21" r="1"/><path d="M2.05 2.05h2l2.66 12.42a2 2 0 0 0 2 1.58h9.78a2 2 0 0 0 1.95-1.57l1.65-7.43H5.12"/>',
		'coffee'    => '<path d="M17 8h1a4 4 0 1 1 0 8h-1"/><path d="M3 8h14v9a4 4 0 0 1-4 4H7a4 4 0 0 1-4-4Z"/><line x1="6" y1="2" x2="6" y2="4"/><line x1="10" y1="2" x2="10" y2="4"/><line x1="14" y1="2" x2="14" y2="4"/>',
		'smile'     => '<circle cx="12" cy="12" r="10"/><path d="M8 14s1.5 2 4 2 4-2 4-2"/><line x1="9" y1="9" x2="9.01" y2="9"/><line x1="15" y1="9" x2="15.01" y2="9"/>',
		'map'       => '<polygon points="3 6 9 3 15 6 21 3 21 18 15 21 9 18 3 21"/><line x1="9" y1="3" x2="9" y2="18"/><line x1="15" y1="6" x2="15" y2="21"/>',
		'twitter'   => '<path d="M22 4c-.8.5-1.7.8-2.6 1a4 4 0 0 0-7 2.7v1A9.7 9.7 0 0 1 4 4s-4 9 5 13a10 10 0 0 1-6 2c9 5 20 0 20-11.5 0-.3 0-.6-.1-.8A6.7 6.7 0 0 0 22 4Z"/>',
		'instagram' => '<rect x="2" y="2" width="20" height="20" rx="5"/><path d="M16 11.4A4 4 0 1 1 12.6 8 4 4 0 0 1 16 11.4Z"/><path d="M17.5 6.5h.01"/>',
		'facebook'  => '<path d="M18 2h-3a5 5 0 0 0-5 5v3H7v4h3v8h4v-8h3l1-4h-4V7a1 1 0 0 1 1-1h3Z"/>',
		'linkedin'  => '<path d="M16 8a6 6 0 0 1 6 6v7h-4v-7a2 2 0 0 0-4 0v7h-4v-13h4v1.5A6 6 0 0 1 16 8Z"/><rect x="2" y="9" width="4" height="12"/><circle cx="4" cy="4" r="2"/>',
	);
}

/**
 * Whether a name is a built-in icon key (lets templates tell an icon from
 * plain text such as a number or letter).
 */
function norvex_icon_exists( $name ) {
	$paths = norvex_icon_paths();
	return isset( $paths[ $name ] );
}

/**
 * Render a built-in icon by name (falls back to the book icon for unknown names).
 */
function norvex_icon( $name, $echo = true ) {
	$paths = norvex_icon_paths();
	$path  = isset( $paths[ $name ] ) ? $paths[ $name ] : $paths['book'];
	$svg  = '<svg class="norvex-icon" width="1em" height="1em" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false">' . $path . '</svg>';

	if ( 'star' === $name || 'facebook' === $name || 'instagram' === $name || 'twitter' === $name || 'linkedin' === $name ) {
		// keep stroke for social; star uses fill toggle below.
	}

	if ( $echo ) {
		echo $svg; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- static markup.
		return;
	}
	return $svg;
}

/**
 * Render an icon that may be either a built-in icon key or a pasted custom SVG.
 *
 * @param string $value    Icon key, or raw <svg> markup.
 * @param string $fallback Icon key to use when $value is empty.
 * @param bool   $echo     Echo (true) or return (false).
 * @return string|void
 */
function norvex_render_icon( $value, $fallback = 'book', $echo = true ) {
	$value = (string) $value;
	// Pasted custom SVG.
	if ( '' !== ltrim( $value ) && '<' === substr( ltrim( $value ), 0, 1 ) ) {
		$svg = function_exists( 'norvex_sanitize_svg' ) ? norvex_sanitize_svg( $value ) : '';
		if ( $echo ) {
			echo $svg; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- sanitised by norvex_sanitize_svg().
			return;
		}
		return $svg;
	}
	$v = trim( $value );
	// Empty → fall back to a default icon.
	if ( '' === $v ) {
		return norvex_icon( $fallback, $echo );
	}
	// A built-in icon name → render that icon.
	if ( function_exists( 'norvex_icon_exists' ) && norvex_icon_exists( $v ) ) {
		return norvex_icon( $v, $echo );
	}
	// Anything else (a number, letter or short word) → render as text.
	$html = '<span class="norvex-iconnum">' . esc_html( $v ) . '</span>';
	if ( $echo ) {
		echo $html; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- escaped above.
		return;
	}
	return $html;
}

/**
 * Whether an icon-field value is free text (a number, letter or word) rather
 * than a built-in icon key or a pasted SVG. Cards use this to render numbers
 * as a large bare badge (no icon box) instead of a boxed icon.
 *
 * @param string $value Icon-field value.
 * @return bool
 */
function norvex_icon_is_text( $value ) {
	$v = trim( (string) $value );
	if ( '' === $v || '<' === substr( $v, 0, 1 ) ) {
		return false;
	}
	return ! ( function_exists( 'norvex_icon_exists' ) && norvex_icon_exists( $v ) );
}

/**
 * Card icon markup: a large bare number badge for a number/letter, a boxed
 * icon for a built-in key or pasted SVG. Keeps every card context (Grid cards
 * block, Services block, Services page) rendering the icon field the same way.
 *
 * @param string $icon Icon-field value.
 * @param bool   $echo Whether to echo (default) or return.
 * @return string
 */
function norvex_card_icon_html( $icon, $echo = true ) {
	$icon = (string) $icon;
	if ( norvex_icon_is_text( $icon ) ) {
		$html = '<span class="norvex-card__num">' . esc_html( trim( $icon ) ) . '</span>';
	} elseif ( '' !== ltrim( $icon ) && '<' === substr( ltrim( $icon ), 0, 1 ) ) {
		$svg  = function_exists( 'norvex_sanitize_svg' ) ? norvex_sanitize_svg( $icon ) : '';
		$html = '' !== $svg ? '<div class="norvex-card__icon">' . $svg . '</div>' : '';
	} elseif ( '' === trim( $icon ) ) {
		$html = '';
	} else {
		$html = '<div class="norvex-card__icon">' . norvex_render_icon( $icon, 'book', false ) . '</div>';
	}
	if ( $echo ) {
		echo $html; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- escaped/sanitised above.
		return '';
	}
	return $html;
}

/**
 * Post meta line for blog listings.
 */
function norvex_post_meta() {
	$cats = get_the_category();
	if ( $cats ) {
		echo '<span class="norvex-article__cat">' . esc_html( $cats[0]->name ) . '</span>';
	}
	echo '<span>' . esc_html( get_the_date() ) . '</span>';
	echo '<span>' . esc_html( norvex_reading_time() ) . '</span>';
}

/**
 * Rough reading time estimate.
 */
function norvex_reading_time() {
	$words   = str_word_count( wp_strip_all_tags( get_the_content() ) );
	$minutes = max( 1, (int) ceil( $words / 200 ) );
	/* translators: %d: number of minutes. */
	return sprintf( _n( '%d min read', '%d min read', $minutes, 'norvex' ), $minutes );
}

/**
 * Render a single comment for the Journal article layout. Passed as the
 * 'callback' to wp_list_comments(); it intentionally leaves the <li> open so
 * WordPress can append nested replies before closing it.
 *
 * @param WP_Comment $comment The comment.
 * @param array      $args    wp_list_comments args.
 * @param int        $depth   Nesting depth.
 */
function norvex_comment( $comment, $args, $depth ) {
	$post_author = (int) get_post_field( 'post_author', get_the_ID() );
	$is_author   = ( $comment->user_id && (int) $comment->user_id === $post_author );
	?>
	<li id="comment-<?php comment_ID(); ?>" <?php comment_class( 'norvex-comment' ); ?>>
		<article class="norvex-comment__body">
			<?php echo get_avatar( $comment, 48, '', '', array( 'class' => 'norvex-comment__avatar' ) ); ?>
			<div class="norvex-comment__main">
				<div class="norvex-comment__head">
					<strong class="norvex-comment__author"><?php comment_author(); ?></strong>
					<?php if ( $is_author ) : ?>
						<span class="norvex-comment__badge"><?php esc_html_e( 'Author', 'norvex' ); ?></span>
					<?php endif; ?>
					<span class="norvex-comment__date"><?php echo esc_html( get_comment_date() ); ?></span>
				</div>
				<div class="norvex-comment__text"><?php comment_text(); ?></div>
				<?php if ( '0' === $comment->comment_approved ) : ?>
					<em class="norvex-comment__pending"><?php esc_html_e( 'Your comment is awaiting moderation.', 'norvex' ); ?></em>
				<?php endif; ?>
				<div class="norvex-comment__actions">
					<?php
					comment_reply_link(
						array_merge(
							$args,
							array(
								'depth'     => $depth,
								'max_depth' => isset( $args['max_depth'] ) ? $args['max_depth'] : get_option( 'thread_comments_depth' ),
								'reply_text' => __( 'Reply', 'norvex' ),
							)
						)
					);
					?>
				</div>
			</div>
		</article>
	<?php
	// No closing </li> — wp_list_comments() adds it after any child replies.
}

/**
 * Add anchor ids to every <h2> in rendered post content and collect a table
 * of contents. Returns array( 'html' => processed HTML, 'items' => array of
 * array( 'id' => …, 'title' => … ) ). Used by single.php for the "In this
 * article" sidebar and in-page anchors.
 *
 * @param string $html Rendered post content.
 * @return array
 */
function norvex_post_toc( $html ) {
	$items = array();
	$used  = array();

	$html = preg_replace_callback(
		'/<h2\b([^>]*)>(.*?)<\/h2>/is',
		function ( $m ) use ( &$items, &$used ) {
			$attrs = $m[1];
			$title = trim( wp_strip_all_tags( $m[2] ) );
			if ( '' === $title ) {
				return $m[0];
			}
			if ( preg_match( '/\bid=["\']([^"\']+)["\']/', $attrs, $idm ) ) {
				$id = $idm[1];
			} else {
				$id = sanitize_title( $title );
				if ( '' === $id || isset( $used[ $id ] ) ) {
					$id = 'section-' . ( count( $items ) + 1 );
				}
				$attrs .= ' id="' . esc_attr( $id ) . '"';
			}
			$used[ $id ] = true;
			$items[]     = array( 'id' => $id, 'title' => $title );
			return '<h2' . $attrs . '>' . $m[2] . '</h2>';
		},
		$html
	);

	return array( 'html' => $html, 'items' => $items );
}

/**
 * Build one schema.org BreadcrumbList list item.
 *
 * @param string $title    Crumb label.
 * @param string $url      Crumb URL (empty for the current page).
 * @param int    $position 1-based position in the trail.
 * @param bool   $current  Whether this is the current page.
 * @return string
 */
function norvex_breadcrumb_item( $title, $url, $position, $current = false ) {
	$title = wp_strip_all_tags( $title );
	$item  = '<li class="norvex-breadcrumb__item' . ( $current ? ' is-current' : '' ) . '" itemprop="itemListElement" itemscope itemtype="https://schema.org/ListItem">';
	if ( $url && ! $current ) {
		$item .= '<a itemprop="item" href="' . esc_url( $url ) . '"><span itemprop="name">' . esc_html( $title ) . '</span></a>';
	} else {
		$item .= '<span itemprop="name"' . ( $current ? ' aria-current="page"' : '' ) . '>' . esc_html( $title ) . '</span>';
	}
	$item .= '<meta itemprop="position" content="' . absint( $position ) . '" />';
	$item .= '</li>';
	return $item;
}

/**
 * Accessible breadcrumb trail with schema.org BreadcrumbList markup (helps
 * Google show breadcrumb rich results). Hidden on the front page.
 */
function norvex_breadcrumb() {
	if ( is_front_page() ) {
		return;
	}

	$pos   = 1;
	$items = array();

	// Always start with Home.
	$items[] = norvex_breadcrumb_item( esc_html__( 'Home', 'norvex' ), home_url( '/' ), $pos++ );

	if ( is_home() ) {
		$items[] = norvex_breadcrumb_item( single_post_title( '', false ), '', $pos++, true );

	} elseif ( is_singular( 'post' ) ) {
		$posts_page = get_option( 'page_for_posts' );
		if ( $posts_page ) {
			$items[] = norvex_breadcrumb_item( __( 'Journal', 'norvex' ), get_permalink( $posts_page ), $pos++ );
		}
		$items[] = norvex_breadcrumb_item( get_the_title(), '', $pos++, true );

	} elseif ( is_singular( 'norvex_service' ) ) {
		$services = get_page_by_path( 'services' );
		if ( $services ) {
			$items[] = norvex_breadcrumb_item( __( 'Services', 'norvex' ), get_permalink( $services ), $pos++ );
		}
		$items[] = norvex_breadcrumb_item( get_the_title(), '', $pos++, true );

	} elseif ( is_singular( 'book' ) ) {
		$portfolio = get_page_by_path( 'portfolio' );
		if ( $portfolio ) {
			$items[] = norvex_breadcrumb_item( __( 'Portfolio', 'norvex' ), get_permalink( $portfolio ), $pos++ );
		}
		$items[] = norvex_breadcrumb_item( get_the_title(), '', $pos++, true );

	} elseif ( is_page() ) {
		foreach ( array_reverse( get_post_ancestors( get_the_ID() ) ) as $ancestor ) {
			$items[] = norvex_breadcrumb_item( get_the_title( $ancestor ), get_permalink( $ancestor ), $pos++ );
		}
		$items[] = norvex_breadcrumb_item( get_the_title(), '', $pos++, true );

	} elseif ( is_search() ) {
		$items[] = norvex_breadcrumb_item( esc_html__( 'Search results', 'norvex' ), '', $pos++, true );

	} elseif ( is_404() ) {
		$items[] = norvex_breadcrumb_item( esc_html__( 'Not found', 'norvex' ), '', $pos++, true );

	} elseif ( is_archive() ) {
		$items[] = norvex_breadcrumb_item( get_the_archive_title(), '', $pos++, true );

	} else {
		$items[] = norvex_breadcrumb_item( wp_title( '', false ), '', $pos++, true );
	}

	echo '<nav class="norvex-breadcrumb" aria-label="' . esc_attr__( 'Breadcrumb', 'norvex' ) . '">';
	echo '<ol class="norvex-breadcrumb__list" itemscope itemtype="https://schema.org/BreadcrumbList">';
	echo implode( '<li class="norvex-breadcrumb__sep" aria-hidden="true">/</li>', $items ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
	echo '</ol></nav>';
}

/**
 * Numeric pagination wrapper.
 */
function norvex_pagination() {
	the_posts_pagination(
		array(
			'mid_size'  => 1,
			'prev_text' => '&larr;',
			'next_text' => '&rarr;',
			'class'     => 'norvex-pagination',
		)
	);
}

/**
 * Featured image with a graceful SVG fallback.
 */
function norvex_thumbnail( $size = 'norvex-card', $fallback = 'placeholder-wide.svg' ) {
	if ( has_post_thumbnail() ) {
		the_post_thumbnail( $size, array( 'loading' => 'lazy', 'alt' => the_title_attribute( array( 'echo' => false ) ) ) );
	} else {
		echo '<img src="' . norvex_img( $fallback ) . '" alt="" loading="lazy" />';
	}
}

/**
 * Fetch a Customizer contact detail with sane default.
 */
function norvex_option( $key, $default = '' ) {
	$value = get_theme_mod( $key, $default );
	return $value ? $value : $default;
}

/**
 * Wrap the accented portion of a hero/page title in a gold-italic span.
 *
 * Accents the phrase after the last comma when present (e.g. "Everything your
 * book needs, in one place"), otherwise the last word. Returns safe HTML.
 *
 * @param string $title Plain title text.
 * @return string HTML with the accent wrapped in <span class="norvex-accent">.
 */
function norvex_hero_accent( $title ) {
	$title = trim( (string) $title );
	if ( '' === $title ) {
		return '';
	}
	if ( false !== strpos( $title, ',' ) ) {
		$pos    = strrpos( $title, ',' );
		$head   = substr( $title, 0, $pos + 1 );
		$accent = trim( substr( $title, $pos + 1 ) );
		if ( '' !== $accent ) {
			return esc_html( $head ) . ' <span class="norvex-accent">' . esc_html( $accent ) . '</span>';
		}
	}
	$words = preg_split( '/\s+/', $title );
	// A single-word title stays one colour — accenting the whole thing would
	// turn the entire heading gold/italic, which reads as a mistake.
	if ( count( $words ) < 2 ) {
		return esc_html( $title );
	}
	$last = array_pop( $words );
	return esc_html( implode( ' ', $words ) ) . ' <span class="norvex-accent">' . esc_html( $last ) . '</span>';
}

/**
 * Echo a hero <h1>'s title with its accent word(s) highlighted. This is the
 * single, standard way every template renders a page-hero title, so the
 * two-tone styling is consistent everywhere. Pass any title string —
 * norvex_pf('hero_title'), get_the_title(), single_cat_title('',false),
 * get_the_archive_title(), etc.
 *
 * @param string $title Plain title text (may be empty).
 */
function norvex_hero_title( $title ) {
	echo wp_kses_post( norvex_hero_accent( $title ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- accent output is escaped internally.
}
