<?php
/**
 * Theme Customizer options.
 *
 * Only site-wide contact & social details live here now. Everything on the
 * homepage and inner pages — hero, headings, stats, process steps, images and
 * so on — is edited directly in the block editor sidebar (see inc/blocks.php),
 * so those Customizer panels have been retired.
 *
 * @package Norvex
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

function norvex_customize_register( $wp_customize ) {

	/* -------- Contact & Brand panel -------- */
	$wp_customize->add_section(
		'norvex_contact',
		array(
			'title'    => __( 'Norvex · Contact & Social', 'norvex' ),
			'priority' => 30,
		)
	);

	$controls = array(
		'norvex_phone'     => array( __( 'Phone number', 'norvex' ), '+1 (732) 454-6871', 'text' ),
		'norvex_email'     => array( __( 'Email address', 'norvex' ), 'hello@norvexpublishingservices.com', 'text' ),
		'norvex_address'   => array( __( 'Street address', 'norvex' ), '1102 Glenwood Road, F4, Brooklyn, NY 11230', 'text' ),
		'norvex_hours'     => array( __( 'Office hours', 'norvex' ), 'Mon–Fri · 9:00 AM – 6:00 PM', 'text' ),
		'norvex_tagline'   => array( __( 'Brand tagline', 'norvex' ), 'Book Publishing Services', 'text' ),
		'norvex_cta_text'  => array( __( 'Header button label', 'norvex' ), 'Get a quote', 'text' ),
		'norvex_cta_url'   => array( __( 'Header button link', 'norvex' ), '', 'url' ),
		'norvex_social_tw' => array( __( 'Twitter / X URL', 'norvex' ), '#', 'url' ),
		'norvex_social_ig' => array( __( 'Instagram URL', 'norvex' ), '#', 'url' ),
		'norvex_social_fb' => array( __( 'Facebook URL', 'norvex' ), '#', 'url' ),
		'norvex_social_in' => array( __( 'LinkedIn URL', 'norvex' ), '#', 'url' ),
		'norvex_footer_txt' => array( __( 'Footer about text', 'norvex' ), 'Norvex LLC is a New York–registered book publishing services company. We help authors write, edit, design, publish and market their books on a flat fee — and you keep 100% of your rights and royalties.', 'textarea' ),
	);

	foreach ( $controls as $id => $data ) {
		list( $label, $default, $type ) = $data;
		$sanitize = ( 'url' === $type ) ? 'esc_url_raw' : ( 'textarea' === $type ? 'sanitize_textarea_field' : 'sanitize_text_field' );
		$wp_customize->add_setting(
			$id,
			array(
				'default'           => $default,
				'sanitize_callback' => $sanitize,
			)
		);
		$wp_customize->add_control(
			$id,
			array(
				'label'   => $label,
				'section' => 'norvex_contact',
				'type'    => ( 'textarea' === $type ) ? 'textarea' : ( 'url' === $type ? 'url' : 'text' ),
			)
		);
	}

	// Header button — description + optional hide toggle.
	$wp_customize->add_setting(
		'norvex_cta_hide',
		array(
			'default'           => false,
			'sanitize_callback' => 'norvex_sanitize_checkbox',
		)
	);
	$wp_customize->add_control(
		'norvex_cta_hide',
		array(
			'label'       => __( 'Hide the header button', 'norvex' ),
			'description' => __( 'The button in the top-right of the header. Leave its link blank to point at your Contact page.', 'norvex' ),
			'section'     => 'norvex_contact',
			'type'        => 'checkbox',
		)
	);

	/* -------- Site Identity: header branding options -------- */
	$wp_customize->add_setting(
		'norvex_hide_site_title',
		array(
			'default'           => false,
			'sanitize_callback' => 'norvex_sanitize_checkbox',
		)
	);
	$wp_customize->add_control(
		'norvex_hide_site_title',
		array(
			'label'    => __( 'Hide site title in header', 'norvex' ),
			'section'  => 'title_tagline',
			'type'     => 'checkbox',
			'priority' => 8,
		)
	);

	$wp_customize->add_setting(
		'norvex_hide_tagline',
		array(
			'default'           => false,
			'sanitize_callback' => 'norvex_sanitize_checkbox',
		)
	);
	$wp_customize->add_control(
		'norvex_hide_tagline',
		array(
			'label'    => __( 'Hide tagline in header', 'norvex' ),
			'section'  => 'title_tagline',
			'type'     => 'checkbox',
			'priority' => 9,
		)
	);

	$wp_customize->add_setting(
		'norvex_logo_width',
		array(
			'default'           => 44,
			'sanitize_callback' => 'absint',
		)
	);
	$wp_customize->add_control(
		'norvex_logo_width',
		array(
			'label'       => __( 'Logo width (px)', 'norvex' ),
			'description' => __( 'Width of the logo image in the header.', 'norvex' ),
			'section'     => 'title_tagline',
			'type'        => 'number',
			'input_attrs' => array(
				'min'  => 24,
				'max'  => 320,
				'step' => 2,
			),
			'priority'    => 10,
		)
	);
}
add_action( 'customize_register', 'norvex_customize_register' );

/**
 * Sanitise a Customizer checkbox to a strict boolean.
 *
 * @param mixed $checked Raw value.
 * @return bool
 */
function norvex_sanitize_checkbox( $checked ) {
	return ( isset( $checked ) && true === (bool) $checked );
}
