<?php
/**
 * Theme hook framework for Norvex.
 *
 * Provides a GeneratePress-style set of action hooks placed throughout the
 * templates. The Hook Elements manager (inc/elements.php) attaches
 * dashboard-managed content to any of these locations, so new sections can be
 * added to any page without editing template files.
 *
 * Available hooks (all fire `do_action( '<name>' )`):
 *
 *   norvex_before_header         Before the site header.
 *   norvex_after_header          After the site header (top of the page).
 *   norvex_topbar_end            End of the top bar, next to the social icons.
 *   norvex_nav_end               End of the primary nav, next to the CTA — add a menu button here.
 *   norvex_before_main           Top of the <main> content column.
 *   norvex_after_main            Bottom of the <main> content column.
 *   norvex_before_footer         Before the site footer.
 *   norvex_footer_top            Top of the footer, inside the wrap.
 *   norvex_footer_bottom         In the footer's bottom bar, next to the legal links.
 *   norvex_after_footer          After the site footer.
 *   norvex_before_entry_content  Before the content on single posts/pages and the home page.
 *   norvex_after_entry_content   After the content on single posts/pages and the home page.
 *
 * Plus the WordPress core `wp_head` and `wp_footer` locations for raw code
 * (analytics, verification tags, custom scripts).
 *
 * @package Norvex
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// The hook locations above are fired with `do_action( '<name>' )` directly in
// the templates (header.php, footer.php, page.php, front-page.php) and are
// wired up to dashboard-managed content by the Hook Elements manager in
// inc/elements.php. No further code is needed here — this file documents the
// available hooks in one canonical place.
